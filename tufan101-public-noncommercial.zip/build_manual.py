# -*- coding: utf-8 -*-
"""TUFAN 101 — Kullanim Kilavuzu PDF uretici."""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_JUSTIFY
from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer, PageBreak,
                                Table, TableStyle, ListFlowable, ListItem, HRFlowable)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# ---- Fontlar (Turkce karakter destegi icin Arial) ----
FONTDIR = r"C:\Windows\Fonts"
pdfmetrics.registerFont(TTFont("AR",  os.path.join(FONTDIR, "arial.ttf")))
pdfmetrics.registerFont(TTFont("ARB", os.path.join(FONTDIR, "arialbd.ttf")))
pdfmetrics.registerFont(TTFont("ARI", os.path.join(FONTDIR, "ariali.ttf")))
from reportlab.pdfbase.pdfmetrics import registerFontFamily
registerFontFamily("AR", normal="AR", bold="ARB", italic="ARI", boldItalic="ARB")

CYAN = colors.HexColor("#0EA5E9")
CYAN2 = colors.HexColor("#38BDF8")
GOLD = colors.HexColor("#F59E0B")
DARK = colors.HexColor("#0F172A")
SLATE = colors.HexColor("#334155")
MUTED = colors.HexColor("#64748B")
LIGHT = colors.HexColor("#F1F5F9")
BORDER = colors.HexColor("#E2E8F0")

styles = getSampleStyleSheet()
def S(name, **kw):
    return ParagraphStyle(name, **kw)

body = S("body", fontName="AR", fontSize=10.5, leading=15.5, textColor=SLATE, alignment=TA_JUSTIFY, spaceAfter=6)
h1 = S("h1", fontName="ARB", fontSize=19, leading=23, textColor=DARK, spaceBefore=6, spaceAfter=10)
h2 = S("h2", fontName="ARB", fontSize=13.5, leading=18, textColor=CYAN, spaceBefore=14, spaceAfter=6)
h3 = S("h3", fontName="ARB", fontSize=11.5, leading=15, textColor=DARK, spaceBefore=8, spaceAfter=3)
bullet = S("bullet", fontName="AR", fontSize=10.5, leading=15, textColor=SLATE)
note = S("note", fontName="AR", fontSize=9.5, leading=13.5, textColor=MUTED)
tiny = S("tiny", fontName="AR", fontSize=8.5, leading=11, textColor=MUTED)

story = []

# Arial emoji glyph'i icermez -> emojileri temizle (kutu cikmasin)
import re
_EMOJI = re.compile(
    "[\U0001F000-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF"
    "\U00002190-\U000021FF\U00002B00-\U00002BFF\U0000FE00-\U0000FE0F\U0000200D]+",
    flags=re.UNICODE)
def clean(s):
    return _EMOJI.sub("", str(s)).replace("  ", " ").strip()

# ---------------- KAPAK ----------------
def cover():
    story.append(Spacer(1, 60*mm))
    story.append(Paragraph('<font color="#0F172A">TUFAN</font> <font color="#0EA5E9">101</font>',
                           S("logo", fontName="ARB", fontSize=46, leading=54, alignment=TA_CENTER, textColor=DARK)))
    story.append(Spacer(1, 10*mm))
    story.append(Paragraph("İşletme Yönetim ve Satış Sistemi", S("sub", fontName="AR", fontSize=15, leading=20, alignment=TA_CENTER, textColor=MUTED)))
    story.append(Spacer(1, 5*mm))
    story.append(HRFlowable(width="40%", thickness=2, color=GOLD, hAlign="CENTER"))
    story.append(Spacer(1, 9*mm))
    story.append(Paragraph("KULLANIM KILAVUZU", S("title", fontName="ARB", fontSize=22, alignment=TA_CENTER, textColor=CYAN)))
    story.append(Spacer(1, 90*mm))
    story.append(Paragraph("Balıkesir · tufan101.com.tr", S("foot", fontName="AR", fontSize=11, alignment=TA_CENTER, textColor=MUTED)))
    story.append(Paragraph("Sürüm 1.0 · 2026", tiny_c()))
    story.append(PageBreak())

def tiny_c():
    return S("tc", fontName="AR", fontSize=9, alignment=TA_CENTER, textColor=MUTED, spaceBefore=3)

cover()

# ---------------- Yardimcilar ----------------
def H1(txt):
    story.append(Paragraph(clean(txt), h1))
    story.append(HRFlowable(width="100%", thickness=1.5, color=CYAN, spaceAfter=8))

def H2(txt): story.append(Paragraph(clean(txt), h2))
def H3(txt): story.append(Paragraph(clean(txt), h3))
def P(txt): story.append(Paragraph(clean(txt), body))
def N(txt): story.append(Paragraph("<b>Not:</b> " + clean(txt), note))

def BUL(items):
    lf = ListFlowable(
        [ListItem(Paragraph(clean(i), bullet), leftIndent=6, value="•") for i in items],
        bulletType="bullet", bulletColor=CYAN, bulletFontSize=9, leftIndent=14, spaceAfter=6)
    story.append(lf)
    story.append(Spacer(1, 2))

def STEPS(items):
    lf = ListFlowable(
        [ListItem(Paragraph(clean(i), bullet), leftIndent=6) for i in items],
        bulletType="1", bulletColor=GOLD, bulletFontName="ARB", leftIndent=16, spaceAfter=6)
    story.append(lf)
    story.append(Spacer(1, 2))

def TBL(header, rows, widths):
    data = [[Paragraph(f'<font color="white"><b>{clean(c)}</b></font>', S("th", fontName="ARB", fontSize=9.5, textColor=colors.white)) for c in header]]
    for r in rows:
        data.append([Paragraph(clean(c), S("td", fontName="AR", fontSize=9.5, leading=13, textColor=SLATE)) for c in r])
    t = Table(data, colWidths=widths, repeatRows=1)
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,0), CYAN),
        ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LIGHT]),
        ("GRID", (0,0), (-1,-1), 0.5, BORDER),
        ("VALIGN", (0,0), (-1,-1), "MIDDLE"),
        ("TOPPADDING", (0,0), (-1,-1), 6),
        ("BOTTOMPADDING", (0,0), (-1,-1), 6),
        ("LEFTPADDING", (0,0), (-1,-1), 8),
        ("RIGHTPADDING", (0,0), (-1,-1), 8),
    ]))
    story.append(t)
    story.append(Spacer(1, 8))

def BOX(title, txt):
    inner = [Paragraph(clean(title), S("bxt", fontName="ARB", fontSize=10, textColor=DARK, spaceAfter=3)),
             Paragraph(clean(txt), S("bxb", fontName="AR", fontSize=9.5, leading=13.5, textColor=SLATE))]
    t = Table([[inner]], colWidths=[165*mm])
    t.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#FFFBEB")),
        ("BOX", (0,0), (-1,-1), 1, GOLD),
        ("LEFTPADDING", (0,0), (-1,-1), 12),
        ("RIGHTPADDING", (0,0), (-1,-1), 12),
        ("TOPPADDING", (0,0), (-1,-1), 9),
        ("BOTTOMPADDING", (0,0), (-1,-1), 9),
    ]))
    story.append(t)
    story.append(Spacer(1, 8))

# ---------------- İCINDEKILER ----------------
H1("İçindekiler")
toc = [
    "1. TUFAN 101 Nedir?",
    "2. İlk Adımlar: Kayıt ve Giriş",
    "3. Ana Ekran (Panel)",
    "4. Ürün ve Stok Yönetimi",
    "5. Satış Ekranı (Kasa / POS)",
    "6. Fiş ve Rapor Yazdırma",
    "7. Gelir, Gider ve Kasa",
    "8. Müşteri ve Cari Hesaplar",
    "9. Vardiya ve Z Raporu",
    "10. QR Menü (Dijital Menü)",
    "11. Personel Yönetimi",
    "12. Raporlar ve Excel/CSV Dışa Aktarma",
    "13. Veri Yedekleme ve Geri Yükleme",
    "14. Ayarlar",
    "15. Sektöre Özel Alanlar (Oto Yedek Parça)",
    "16. Çevrimdışı Çalışma ve Bulut Senkron",
    "17. Sık Sorulan Sorular",
    "18. İletişim ve Destek",
]
BUL(toc)
story.append(PageBreak())

# 1
H1("1. TUFAN 101 Nedir?")
P("TUFAN 101; market, kafe, restoran, mağaza, oto yedek parça ve benzeri işletmeler için tasarlanmış "
  "bir <b>işletme yönetim ve satış (POS) sistemidir</b>. Ürün ve stok takibi, hızlı satış, gelir-gider "
  "kaydı, müşteri/cari yönetimi, personel, vardiya, raporlama ve QR menü gibi onlarca özelliği tek bir "
  "panelde toplar.")
P("Uygulama internet tarayıcısında çalışır ve bilgisayarınıza kurulabilir (PWA). Verileriniz cihazınızda "
  "anında saklanır; internet olduğunda buluta otomatik yedeklenir. İnternet kesilse bile uygulama açılır "
  "ve çalışmaya devam eder.")
H2("Öne Çıkan Özellikler")
BUL([
    "🛒 <b>Hızlı satış ekranı</b> — barkod okuma, sepet, nakit/kart tahsilat, para üstü.",
    "📦 <b>Ürün & stok yönetimi</b> — kategori, fiyat, maliyet, minimum stok uyarısı.",
    "🧾 <b>Fiş yazdırma</b> — 80mm termal ve A4 yazıcı uyumlu.",
    "📋 <b>Raporlar</b> — satış, stok, gelir/gider; PDF ve Excel/CSV dışa aktarma.",
    "👤 <b>Müşteri / cari hesap</b> — borç-alacak takibi.",
    "🕒 <b>Vardiya & Z raporu</b> — gün sonu kasa sayımı, eksik/fazla kontrolü.",
    "🍽️ <b>QR menü</b> — müşteriye telefondan dijital menü.",
    "💾 <b>Yedekleme</b> — tek dosyayla tüm veriyi indirme/geri yükleme.",
])
story.append(PageBreak())

# 2
H1("2. İlk Adımlar: Kayıt ve Giriş")
H2("Üye Olma")
STEPS([
    "tufan101.com.tr adresini tarayıcıda açın.",
    "<b>Üye Ol</b> ekranından işletme adınızı, kullanıcı adınızı ve şifrenizi girin.",
    "Formu onaylayın; hesabınız oluşturulur ve doğrudan panele yönlendirilirsiniz.",
])
H2("Giriş Yapma")
STEPS([
    "<b>Giriş Yap</b> ekranını açın.",
    "Kullanıcı adı ve şifrenizi yazın. Şifrenizi göstermek için göz (👁) simgesine dokunabilirsiniz.",
    "<b>Giriş Yap →</b> düğmesine basın.",
])
BOX("Şifre Güvenliği", "Şifreniz sunucuda şifrelenerek (hash) saklanır; kimse düz metin olarak göremez. "
    "Şifrenizi kimseyle paylaşmayın. Kasiyerleriniz için ayrı kullanıcılar tanımlayabilirsiniz "
    "(Bkz. Bölüm 11 — Personel Yönetimi).")
H2("Uygulamayı Cihaza Kurma (PWA)")
P("Tarayıcının adres çubuğundaki <b>Yükle / Install</b> simgesine tıklayarak TUFAN 101'i masaüstü "
  "veya telefonunuza uygulama gibi kurabilirsiniz. Böylece tek tıkla açılır ve tam ekran çalışır.")
story.append(PageBreak())

# 3
H1("3. Ana Ekran (Panel)")
P("Giriş yaptığınızda karşınıza <b>Panel (Dashboard)</b> gelir. Buradan günün satış özetini, kasa "
  "durumunu ve hızlı kısayolları görürsünüz. Sol taraftaki menüden tüm modüllere ulaşılır.")
H2("Menü Grupları")
TBL(["Grup", "İçerdiği Modüller"], [
    ["📊 İşlemler", "Panel, Stok, Gelir, Gider, Borçlar, Kasa, Siparişler"],
    ["👥 Personel", "Personel, Çalışan Yönetimi"],
    ["🏷️ Yönetim", "Kategoriler, QR Menü, Raporlar"],
    ["🏠 Emlak & Belge", "Emlak, PDF Oluşturucu, Sözleşmeler"],
    ["🛒 Satış & İşletme", "Müşteriler, Tedarikçiler, Şubeler, Barkod"],
    ["📈 Analiz", "Grafikler, Döviz, Excel İçe Aktarma"],
    ["🕒 Gelişmiş", "Vardiya, Sadakat, Kurye, Dinamik Fiyat, Roller"],
    ["🏪 Market Kasa", "POS Satış Ekranı, Market Ayarları"],
    ["⚙️ Yönetim+", "Kasiyer İzinleri, Otomatik Kayıt, Ayarlar"],
], [45*mm, 120*mm])
N("Tüm modüller açıktır; kilitli/ücretli özellik yoktur. İşletmenize uymayan modülleri kullanmasanız da olur.")
story.append(PageBreak())

# 4
H1("4. Ürün ve Stok Yönetimi")
P("<b>Stok</b> modülü ürünlerinizi yönettiğiniz yerdir. Yeni ürün ekleyebilir, fiyat/maliyet/stok "
  "güncelleyebilir ve arama yapabilirsiniz.")
H2("Yeni Ürün Ekleme")
STEPS([
    "Menüden <b>📦 Stok</b>'u açın.",
    "<b>+ Yeni Ürün</b> düğmesine basın.",
    "Ürün adı, barkod, kategori, satış fiyatı, maliyet ve stok miktarını girin.",
    "Minimum stok değeri belirlerseniz, stok bu seviyenin altına düştüğünde uyarı alırsınız.",
    "<b>Kaydet</b>'e basın.",
])
H2("Ürün Arama")
P("Arama kutusuna ürün adı veya barkod yazarak anında filtreleyebilirsiniz. Oto yedek parça alanları "
  "açıksa OEM numarası, çapraz referans ve araç uyumuna göre de arama yapılır (Bkz. Bölüm 15).")
BOX("Barkod Okuma", "Ürün eklerken veya satış yaparken el barkod okuyucunuzu kullanabilir ya da "
    "'Kamera ile Barkod' özelliğiyle telefon/bilgisayar kamerasından okutabilirsiniz.")
story.append(PageBreak())

# 5
H1("5. Satış Ekranı (Kasa / POS)")
P("<b>POS / Market Kasa</b> ekranı günlük satışların yapıldığı yerdir. Ürünleri sepete ekleyip tahsilatı "
  "tamamlarsınız.")
H2("Satış Adımları")
STEPS([
    "<b>🛒 POS</b> ekranını açın.",
    "Ürünü barkod okutarak veya listeden dokunarak sepete ekleyin.",
    "Adet değiştirmek için ürünün yanındaki +/− düğmelerini kullanın.",
    "Toplam tutarı kontrol edin.",
    "<b>Nakit</b> veya <b>Kart</b> ödeme yöntemini seçin.",
    "Nakitte, alınan parayı girin; sistem para üstünü otomatik hesaplar.",
    "Satışı onaylayın — stok otomatik düşer, satış kaydı oluşur.",
])
H2("Fiş ile Satış")
P("Ödeme ekranındaki <b>🧾 Nakit + Fiş</b> düğmesi satışı tamamlayıp fişi doğrudan yazdırır. "
  "Ayarlar'dan 'Satıştan sonra fişi otomatik yazdır' seçeneğini açarsanız her satışta fiş kendiliğinden basılır.")
story.append(PageBreak())

# 6
H1("6. Fiş ve Rapor Yazdırma")
H2("Satış Fişi")
P("Fişler <b>80mm termal yazıcı</b> ve normal <b>A4 yazıcı</b> ile uyumludur. İşletme adı, adres ve "
  "telefon bilgisi Ayarlar'dan alınıp fişe otomatik eklenir. Fişte tarih, fiş numarası, kasiyer, ürünler, "
  "toplam, ödeme yöntemi ve para üstü yer alır.")
H2("Fiş Tekrar Yazdırma")
STEPS([
    "Menüden <b>📋 Raporlar</b>'ı açın.",
    "<b>🖨 Fiş Tekrar Yazdır</b> kartında <b>Satış Seç</b>'e basın.",
    "Son 50 satış listelenir; yazdırmak istediğiniz satışa dokunun.",
])
H2("Rapor Yazdırma (PDF)")
P("Raporlar modülünden Satış Dökümü, Stok Listesi ve Gelir/Gider raporlarını PDF olarak yazdırabilir "
  "veya Excel/CSV olarak indirebilirsiniz.")
story.append(PageBreak())

# 7
H1("7. Gelir, Gider ve Kasa")
BUL([
    "💰 <b>Gelir</b> — Satış dışı gelirlerinizi (ör. tahsilat, ek gelir) kaydedin.",
    "💸 <b>Gider</b> — Kira, fatura, maaş, alım gibi giderleri kaydedin.",
    "💳 <b>Borçlar</b> — Ödenecek/alınacak borçları takip edin.",
    "🏦 <b>Kasa</b> — Nakit ve banka hesap hareketlerinizi görün.",
])
P("Her kayıtta tür, tutar, tarih ve açıklama girebilirsiniz. Gelir/gider dengeniz raporlarda ve "
  "grafiklerde özetlenir.")
story.append(Spacer(1, 4))

# 8
H1("8. Müşteri ve Cari Hesaplar")
P("<b>Müşteriler</b> modülünde müşteri kartları oluşturur, borç-alacak (cari) hareketlerini takip "
  "edersiniz. Veresiye çalışan işletmeler için müşteri bazında bakiye tutulur.")
BUL([
    "Müşteri adı, telefon, ünvan ve vergi bilgilerini kaydedin.",
    "Her müşteri için borç/alacak hareketi ekleyin.",
    "Güncel bakiyeyi anında görün.",
])
story.append(PageBreak())

# 9
H1("9. Vardiya ve Z Raporu")
P("<b>Vardiya</b> modülü gün sonu kasa denetimini sağlar. Vardiya başında kasadaki nakdi girer, gün "
  "sonunda sayarak eksik/fazla olup olmadığını görürsünüz.")
H2("Vardiya Açma")
STEPS([
    "<b>🕒 Vardiya</b> modülünü açın.",
    "<b>▶ Vardiya Aç</b>'a basın ve kasadaki başlangıç nakdini girin.",
])
H2("Vardiya Kapatma (Z Raporu)")
STEPS([
    "Gün sonunda <b>⏹ Z Raporu Al & Kapat</b>'a basın.",
    "Kasada saydığınız nakit tutarı girin.",
    "Sistem beklenen kasa ile karşılaştırır: <b>Tam</b>, <b>Fazla</b> veya <b>Eksik</b> gösterir.",
    "<b>🖨 Kapat & Yazdır</b> ile Z raporunu basın veya <b>Kapat & Kaydet</b> ile sadece kaydedin.",
])
BOX("Z Raporu Nedir?", "Z raporu; başlangıç nakdi, nakit satış, kart satış, fiş adedi, beklenen kasa, "
    "sayılan nakit ve farkı özetleyen gün sonu raporudur. Geçmiş vardiyaların raporunu istediğiniz "
    "zaman yeniden yazdırabilirsiniz.")
story.append(PageBreak())

# 10
H1("10. QR Menü (Dijital Menü)")
P("<b>QR Menü</b> ile ürünlerinizi müşterinin telefonundan görüntülenen dijital bir menüye dönüştürürsünüz. "
  "Kafe ve restoranlar için idealdir.")
BUL([
    "Menüde görünmesini istediğiniz ürünleri seçin.",
    "İşletmenizin QR kodunu oluşturup masalara/afişe yerleştirin.",
    "Müşteri QR'ı okutunca menünüzü telefonunda görür.",
    "Profesyonel afiş çıktısı alarak yazdırabilirsiniz.",
])
story.append(Spacer(1, 4))

# 11
H1("11. Personel Yönetimi")
P("<b>Personel</b> ve <b>Çalışan Yönetimi</b> modülleriyle çalışanlarınızı, izinlerini ve "
  "yetkilerini yönetirsiniz.")
BUL([
    "Kasiyerler için ayrı kullanıcı hesapları açın.",
    "<b>🔐 Kasiyer İzinleri</b> ile her kullanıcının hangi ekranlara erişebileceğini belirleyin.",
    "Çalışan bilgilerini, giriş-çıkış ve izin kayıtlarını tutun.",
])
BOX("Yetkilendirme", "İşletme sahibi tüm modülleri görür. Kasiyerlere yalnızca satış ve gerekli "
    "ekranların yetkisini vererek hassas raporları ve ayarları koruyabilirsiniz.")
story.append(PageBreak())

# 12
H1("12. Raporlar ve Excel/CSV Dışa Aktarma")
P("Verilerinizi muhasebe, vergi veya analiz için dışa aktarabilirsiniz. CSV dosyaları Türkçe karakter "
  "ve noktalı virgül (;) ayraç uyumludur — çift tıklayınca doğrudan Excel'de açılır.")
H2("CSV Dışa Aktarma")
STEPS([
    "<b>⚙️ Ayarlar</b> → <b>📊 Excel / CSV Dışa Aktar</b> kartına gidin.",
    "İndirmek istediğiniz listeyi seçin: Ürünler, Satışlar, Gelir/Gider, Müşteriler veya Stok Durumu.",
    "Dosya bilgisayarınıza .csv olarak iner ve Excel'de açılır.",
])
N("Tutarlar Türkçe ondalık (örn. 5,00) ve fiyatlar doğru sütunlarda gelir.")
story.append(Spacer(1, 4))

# 13
H1("13. Veri Yedekleme ve Geri Yükleme")
P("Tüm işletme verinizi (ürünler, satışlar, gelir/gider, müşteriler, stok, cari, personel, ayarlar) "
  "tek bir <b>.json</b> dosyasında yedekleyebilirsiniz.")
H2("Yedek Alma")
STEPS([
    "<b>⚙️ Ayarlar</b> → <b>💾 Veri Yedekleme</b> kartına gidin.",
    "<b>⬇ Dışa Aktar (Yedek İndir)</b>'e basın; yedek dosyası bilgisayarınıza iner.",
])
H2("Yedekten Geri Yükleme")
STEPS([
    "<b>⬆ İçe Al (Yedekten Yükle)</b>'ye basın ve .json dosyanızı seçin.",
    "<b>Birleştir</b>: Mevcut verilerle birleştirir (en güncel kayıt korunur).",
    "<b>Üzerine Yaz</b>: Mevcut veriyi silip yedekteki veriyle değiştirir.",
])
BOX("Öneri", "Düzenli olarak (ör. haftada bir) yedek alın ve dosyayı güvenli bir yerde saklayın. "
    "Yeni cihaza geçerken yedeği içe alarak tüm verinizi taşıyabilirsiniz.")
story.append(PageBreak())

# 14
H1("14. Ayarlar")
P("<b>⚙️ Ayarlar</b> modülünden işletme bilgilerinizi ve uygulama davranışını yapılandırırsınız.")
TBL(["Ayar", "Açıklama"], [
    ["İşletme Bilgileri", "İşletme adı, adres, telefon — fiş ve raporlarda görünür."],
    ["Sektör", "İşletme türünüz; hazır ürün önerileri buna göre gelir."],
    ["Resmi / Fatura", "Ünvan, VKN/TCKN, vergi dairesi, e-Fatura/e-Arşiv."],
    ["Barkod Sistemi", "GS1 (EAN/GTIN) barkodu veya dahili barkod."],
    ["Sektör / Ürün Alanları", "Yedek parça alanlarını aç/kapat (varsayılan kapalı)."],
    ["Fiş / Yazdırma", "Satış sonrası fişi otomatik yazdırma."],
    ["Excel / CSV", "Listeleri dışa aktarma."],
    ["Veri Yedekleme", "Yedek alma ve geri yükleme."],
], [50*mm, 115*mm])
story.append(PageBreak())

# 15
H1("15. Sektöre Özel Alanlar (Oto Yedek Parça)")
P("Otomotiv ve yedek parça satıcıları için ürün kartına özel alanlar eklenebilir. Bu alanlar "
  "<b>varsayılan olarak kapalıdır</b>; market, kafe veya genel perakende işletmeleri görmez.")
H2("Yedek Parça Alanlarını Açma")
STEPS([
    "<b>⚙️ Ayarlar</b> → <b>🔧 Sektör / Ürün Alanları</b> kartına gidin.",
    "<b>Yedek parça alanlarını göster</b> anahtarını açın.",
])
P("Anahtar açıldığında ürün kartında şu alanlar görünür ve CSV dışa aktarımına eklenir:")
BUL([
    "<b>OEM No</b> — orijinal parça numarası.",
    "<b>Çapraz Referans</b> — muadil/eşdeğer parça numaraları.",
    "<b>Araç Uyumu</b> — parçanın uyduğu araç marka/model.",
    "<b>Raf</b> — deponuzdaki raf/konum bilgisi.",
])
N("Bu alanlar açıkken ürün aramasında OEM numarası ve çapraz referanstan da arama yapabilirsiniz.")
story.append(Spacer(1, 4))

# 16
H1("16. Çevrimdışı Çalışma ve Bulut Senkron")
P("TUFAN 101 verilerinizi önce cihazınıza anında kaydeder; bu yüzden gecikme yaşamazsınız. İnternet "
  "bağlantısı olduğunda veriler otomatik olarak buluta yedeklenir ve cihazlar arasında eşitlenir.")
BUL([
    "İnternet kesilse bile uygulama açılır ve satış yapmaya devam edersiniz.",
    "Bağlantı geri geldiğinde bekleyen kayıtlar otomatik gönderilir.",
    "Aynı hesapla başka cihazdan girdiğinizde verileriniz eşitlenir.",
])
story.append(PageBreak())

# 17
H1("17. Sık Sorulan Sorular")
def FAQ(q, a):
    story.append(Paragraph("<b>S:</b> " + clean(q), S("faqq", fontName="ARB", fontSize=10.5, textColor=DARK, spaceBefore=8, spaceAfter=2)))
    story.append(Paragraph("<b>C:</b> " + clean(a), S("faqa", fontName="AR", fontSize=10, leading=14, textColor=SLATE, spaceAfter=4)))

FAQ("Şifremi unuttum, ne yapmalıyım?",
    "İşletme yöneticinizle iletişime geçin veya destek hattımıza başvurun. Kasiyer şifreleri işletme "
    "sahibi tarafından sıfırlanabilir.")
FAQ("İnternetim yok, satış yapabilir miyim?",
    "Evet. Uygulama çevrimdışı çalışır; internet geldiğinde verileriniz otomatik yedeklenir.")
FAQ("Fiş yazıcım termal (80mm). Uyumlu mu?",
    "Evet. Fişler 80mm termal ve A4 yazıcıyla uyumludur. Yazdırma penceresinden doğru yazıcıyı seçin.")
FAQ("Verilerimi başka bilgisayara nasıl taşırım?",
    "Ayarlar → Veri Yedekleme'den yedek indirin, yeni cihazda 'İçe Al' ile yükleyin.")
FAQ("Market işletiyorum, oto parça alanları çıkıyor mu?",
    "Hayır. Yedek parça alanları varsayılan kapalıdır; yalnızca Ayarlar'dan açarsanız görünür.")
FAQ("Yazdırma penceresi açılmıyor?",
    "Tarayıcınız açılır pencereyi engellemiş olabilir. Adres çubuğundaki engelleme simgesinden bu site "
    "için açılır pencereye izin verin.")
FAQ("Kasiyerim tüm raporları görüyor, nasıl kısıtlarım?",
    "Kasiyer İzinleri modülünden kullanıcının erişebileceği ekranları sınırlandırabilirsiniz.")
story.append(PageBreak())

# 18
H1("18. İletişim ve Destek")
P("Sorularınız, önerileriniz ve teknik destek için bize ulaşın:")
BUL([
    "🌐 Web: <b>tufan101.com.tr</b>",
    "📍 Balıkesir",
])
story.append(Spacer(1, 6))
story.append(HRFlowable(width="100%", thickness=1, color=BORDER))
story.append(Spacer(1, 8))
story.append(Paragraph("Bu kılavuz TUFAN 101 kullanıcıları için hazırlanmıştır. Uygulama sürekli "
    "geliştirilmektedir; ekranlar ve özellikler zamanla güncellenebilir.", tiny))
story.append(Paragraph("© 2026 TUFAN 101 · Balıkesir · Tüm hakları saklıdır.", tiny))

# ---------------- Sayfa altligi / ustbilgi ----------------
def footer(canvas, doc):
    canvas.saveState()
    if doc.page > 1:
        canvas.setFont("AR", 8)
        canvas.setFillColor(MUTED)
        canvas.drawString(20*mm, 12*mm, "TUFAN 101 — Kullanım Kılavuzu")
        canvas.drawRightString(190*mm, 12*mm, "Sayfa %d" % (doc.page))
        canvas.setStrokeColor(BORDER)
        canvas.setLineWidth(0.5)
        canvas.line(20*mm, 15*mm, 190*mm, 15*mm)
    canvas.restoreState()

OUT = r"C:\Users\MASTER\Desktop\_tufan8\TUFAN101-Kullanim-Kilavuzu.pdf"
doc = SimpleDocTemplate(OUT, pagesize=A4,
                        leftMargin=20*mm, rightMargin=20*mm,
                        topMargin=18*mm, bottomMargin=20*mm,
                        title="TUFAN 101 Kullanım Kılavuzu", author="TUFAN 101")
doc.build(story, onFirstPage=footer, onLaterPages=footer)
print("OK ->", OUT)
