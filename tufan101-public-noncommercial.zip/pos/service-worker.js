/* TUFAN 101 — Service Worker (mod-09 PWA, mod-17 Offline)
   Uygulama kabuğunu önbelleğe alır; internet kopsa bile açılır. */
const CACHE = "tufan101-v76";
const ASSETS = [
  "./",
  "./index.html",
  "./manifest.webmanifest",
  "./assets/img/logo-3dmenshop.png",
  "./assets/img/tufan-logo.png",
  "./assets/css/theme.css",
  "./assets/js/app.js",
  "./assets/js/core/store.js",
  "./assets/js/core/api.js",
  "./assets/js/core/auth.js",
  "./assets/js/core/i18n.js",
  "./assets/js/core/ui.js",
  "./assets/js/core/nav.js",
  "./assets/js/core/sectors.js",
  "./assets/js/modules/index.js"
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(ASSETS).catch(() => {})).then(() => self.skipWaiting())
  );
});

// Sayfadan gelen "hemen etkinleş" mesajı → beklemeden yeni sürüme geç
self.addEventListener("message", (e) => {
  if (e.data && e.data.type === "SKIP_WAITING") self.skipWaiting();
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const { request } = e;
  if (request.method !== "GET") return;

  let url;
  try { url = new URL(request.url); } catch { return; }

  // DIŞ KAYNAKLAR (Google Fonts vb.): SW HİÇ karışmaz.
  // Böylece tarayıcı isteği doğal olarak (style-src/font-src altında) yükler;
  // SW içinden fetch() connect-src'a takılıp "Failed to convert to Response" hatası
  // ÜRETMEZ. Sadece http/https ve aynı-origin isteklerle ilgileniyoruz.
  if (url.origin !== location.origin) return;

  // API çağrıları: önce ağ, ulaşılamazsa istemciye "offline" bilgisi (kuyruk istemcide)
  if (url.pathname.includes("/api/")) {
    e.respondWith(
      fetch(request).catch(() =>
        new Response(JSON.stringify({ offline: true }), {
          headers: { "Content-Type": "application/json" },
        })
      )
    );
    return;
  }

  // Aynı-origin uygulama dosyaları (HTML/CSS/JS): ÖNCE AĞ, olmazsa önbellek.
  // Ağ hatası + önbellekte de yoksa ASLA undefined döndürmeyiz — geçerli bir
  // Response üretiriz (navigasyonda önbellekteki index.html, aksi halde 504).
  e.respondWith(
    fetch(request)
      .then((res) => {
        // Sadece başarılı, aynı-origin (basic) yanıtları önbelleğe al.
        if (res && res.status === 200 && res.type === "basic") {
          const clone = res.clone();
          caches.open(CACHE).then((c) => c.put(request, clone)).catch(() => {});
        }
        return res;
      })
      .catch(async () => {
        const cached = await caches.match(request);
        if (cached) return cached;
        if (request.mode === "navigate") {
          const shell = await caches.match("./index.html");
          if (shell) return shell;
        }
        return new Response("", { status: 504, statusText: "Offline" });
      })
  );
});
