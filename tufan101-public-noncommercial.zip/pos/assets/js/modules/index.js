// Tüm modüllerin tek panelde toplandığı kayıt defteri (mod-01 → mod-22 + ek modüller)
import { renderDashboard } from "./dashboard.js";
import { renderPOS } from "./pos.js";
import { renderProducts } from "./products.js";
import { renderCategories } from "./categories.js";
import { renderShift } from "./shift.js";
import { renderQrMenu } from "./qrmenu.js";
import { renderReports } from "./reports.js";
import { renderStaff } from "./staff.js";
import { renderOrders } from "./orders.js";
import { renderEmlak } from "./emlak.js";
import { renderContracts } from "./contracts.js";
import { renderOcr } from "./ocr.js";
import { renderUsers } from "./users.js";
import { renderSettings } from "./settings.js";
import { renderBoss } from "./boss.js";
import { renderAccounts } from "./accounts.js";
import { renderCari } from "./cari.js";
import { renderAI } from "./ai.js";
import { renderWaiter } from "./waiter.js";
import { renderEndOfDay } from "./endofday.js";
import { renderKitchen } from "./kds.js";
import { renderSmartPanel } from "./smart.js";
import { renderCampaigns } from "./campaigns.js";
import { renderCashSession } from "./cashsession.js";
import { renderRefund } from "./refund.js";
import { renderBundles } from "./bundles.js";
import { renderGiftcards } from "./giftcard.js";
import { renderTargets } from "./targets.js";
import { renderAudit } from "./audit.js";
import { renderAlarms } from "./alarms.js";
import { renderProfit } from "./profit.js";
import { renderTvMode } from "./tvmode.js";
import { renderStaffScore } from "./staffscore.js";
import { renderBranchCompare } from "./branchcompare.js";
import { renderAutomation } from "./automation.js";
import { renderCalAnalysis } from "./calanalysis.js";
import { renderHeatmap } from "./heatmap.js";
import { renderRecipe } from "./recipe.js";
import { renderPriceTag } from "./pricetag.js";
import { renderMobilePanel } from "./mobilepanel.js";
import { renderStocktake } from "./stocktake.js";
import { renderWarehouse } from "./warehouse.js";
import { renderWaMarketing } from "./wamarketing.js";
import { renderDayReport } from "./dayreport.js";
import { renderTables } from "./tables.js";
import { renderBudget } from "./budget.js";
import { renderPnl } from "./pnl.js";

// Ek modüller (extras.js) — gelir/gider, patron, esnaf, satış+, analiz, vizyon vb.
import {
  renderIncome, renderExpense, renderPdfGen, renderActiveAccounts,
  renderAppointments, renderProduction, renderNotifications, renderCompany,
  renderEinvoice, renderTools, renderPcb, renderCustomers, renderSuppliers,
  renderBranches, renderBarcode, renderReportXls, renderCharts, renderCurrency,
  renderExcelImport, renderSmartOrder, renderRecipeRoll, renderCourier,
  renderDynPrice, renderLoyalty, renderFinCal, renderPwa, renderApprovals,
  renderFaceShift, renderSecurity, renderMarketSet, renderCashierPerms, renderAutoSave,
  renderEmployeeMgmt, renderDebts, renderStaffSales, renderReceipts,
} from "./extras.js";

// Gruplar (i18n): grpOps grpStaff grpManage grpEmlak grpPatron grpExtra grpBiz
//   grpSalesBiz grpAnalysis grpAdvanced grpVision grpSecPlus grpMarket grpManagePlus
export const MODULES = [
  // 📊 İşlemler
  { id: "dashboard",   key: "navDashboard", icon: "📊", group: "grpOps",       render: renderDashboard },
  { id: "smart",       key: "navSmart",     icon: "🧠", group: "grpOps",       render: renderSmartPanel },
  { id: "alarms",      key: "navAlarms",    icon: "🚨", group: "grpOps",       render: renderAlarms },
  // 'TV Modu' gizlendi — Dashboard/Mobil Panel ile örtüşüyor. Kod duruyor.
  { id: "tvmode",      key: "navTvmode",    icon: "📺", group: "grpOps",       render: renderTvMode, hidden: true },
  // 'Mobil Panel' gizlendi — Dashboard ile örtüşüyor (mobil görünüm). Kod duruyor.
  { id: "mobilepanel", key: "navMobilePanel",icon: "📱", group: "grpOps",      render: renderMobilePanel, hidden: true },
  { id: "ai",          key: "navAI",        icon: "🤖", group: "grpOps",       render: renderAI },
  { id: "products",    key: "navStock",     icon: "📦", group: "grpOps",       render: renderProducts },
  { id: "income",      key: "navIncome",    icon: "💰", group: "grpOps",       render: renderIncome },
  { id: "expense",     key: "navExpense",   icon: "💸", group: "grpOps",       render: renderExpense },
  { id: "debts",       key: "navDebts",     icon: "💳", group: "grpOps",       render: renderDebts },
  { id: "stocktake",   key: "navStocktake", icon: "📋", group: "grpOps",       render: renderStocktake },
  // 'Günlük Rapor' gizlendi — 'Gün Sonu Raporu' (🌙) ile aynı işi yapıyor (mükerrer). Kod duruyor.
  { id: "dayreport",   key: "navDayReport", icon: "🧾", group: "grpOps",       render: renderDayReport, hidden: true },
  { id: "kasa",        key: "navKasa",      icon: "🏦", group: "grpOps",       render: renderAccounts },
  { id: "cashsession", key: "navCashSession",icon: "💵", group: "grpOps",      render: renderCashSession },
  { id: "targets",     key: "navTargets",   icon: "🎯", group: "grpOps",       render: renderTargets },
  { id: "tables",      key: "navTables",    icon: "🍽️", group: "grpOps",       render: renderTables },
  { id: "orders",      key: "navOrders",    icon: "🛒", group: "grpOps",       render: renderOrders },
  { id: "refund",      key: "navRefund",    icon: "↩️", group: "grpOps",       render: renderRefund },
  { id: "receipts",    key: "navReceipts",  icon: "🧾", group: "grpOps",       render: renderReceipts },
  { id: "endofday",    key: "navEndOfDay",  icon: "🌙", group: "grpOps",       render: renderEndOfDay },

  // Personel
  { id: "staff",       key: "navStaff",     icon: "👥", group: "grpStaff",     render: renderStaff },
  { id: "empmgmt",     key: "navEmployees", icon: "👔", group: "grpStaff",     render: renderEmployeeMgmt },
  { id: "staffsales",  key: "navStaffSales",icon: "📊", group: "grpStaff",     render: renderStaffSales },
  { id: "staffscore",  key: "navStaffScore",icon: "🏅", group: "grpStaff",     render: renderStaffScore },

  // Yönetim
  { id: "categories",  key: "navCats",      icon: "🏷️", group: "grpManage",    render: renderCategories },
  { id: "qrmenu",      key: "navQr",        icon: "🍽️", group: "grpManage",    render: renderQrMenu },
  { id: "reports",     key: "navReports",   icon: "📋", group: "grpManage",    render: renderReports },

  // Emlak & Araçlar
  { id: "emlak",       key: "navEmlak",     icon: "🏠", group: "grpEmlak",     render: renderEmlak, hidden: true },
  { id: "pdfgen",      key: "navPdf",       icon: "📄", group: "grpEmlak",     render: renderPdfGen },
  { id: "contracts",   key: "navContracts", icon: "📑", group: "grpEmlak",     render: renderContracts },

  // Patron+
  { id: "accounts",    key: "navAccounts",  icon: "📊", group: "grpPatron",    render: renderActiveAccounts },
  { id: "pnl",         key: "navPnl",       icon: "📊", group: "grpPatron",    render: renderPnl },
  { id: "budget",      key: "navBudget",    icon: "🎯", group: "grpPatron",    render: renderBudget },
  { id: "boss",        key: "navBoss",      icon: "🛡️", group: "grpPatron",    render: renderBoss, bossOnly: true },

  // Ek Modüller
  { id: "appointments",key: "navAppt",      icon: "📅", group: "grpExtra",     render: renderAppointments },
  { id: "production",  key: "navProduction",icon: "🏭", group: "grpExtra",     render: renderProduction },
  { id: "notifications",key: "navNotif",    icon: "🔔", group: "grpExtra",     render: renderNotifications },
  { id: "company",     key: "navCompany",   icon: "🏢", group: "grpExtra",     render: renderCompany },
  // e-Fatura GİZLENDİ (mod-D Uyum): resmî/devlet belgesi düzenleme kaldırıldı ki
  // mali/yasal sorumluluk (ceza) doğmasın. Kod duruyor; sadece menüden çıkarıldı.
  { id: "einvoice",    key: "navEinvoice",  icon: "🧾", group: "grpExtra",     render: renderEinvoice, hidden: true },

  // İşletme
  { id: "tools",       key: "navTools",     icon: "🧰", group: "grpBiz",       render: renderTools },
  { id: "pcb",         key: "navPcb",       icon: "🔧", group: "grpBiz",       render: renderPcb },

  // Satış & İşletme+
  { id: "customers",   key: "navCustomers", icon: "👤", group: "grpSalesBiz",  render: renderCari },
  { id: "suppliers",   key: "navSuppliers", icon: "🚚", group: "grpSalesBiz",  render: renderSuppliers },
  { id: "branches",    key: "navBranches",  icon: "🏪", group: "grpSalesBiz",  render: renderBranches },
  { id: "barcode",     key: "navBarcode",   icon: "🏷️", group: "grpSalesBiz",  render: renderBarcode },
  { id: "warehouse",   key: "navWarehouse", icon: "🗺️", group: "grpSalesBiz",  render: renderWarehouse },
  { id: "wamarketing", key: "navWaMarketing",icon: "💬", group: "grpSalesBiz",  render: renderWaMarketing },
  { id: "reportxls",   key: "navReportXls", icon: "📊", group: "grpSalesBiz",  render: renderReportXls },

  // Analiz & Araçlar+
  { id: "charts",      key: "navCharts",    icon: "📈", group: "grpAnalysis",  render: renderCharts },
  { id: "profit",      key: "navProfit",    icon: "💹", group: "grpAnalysis",  render: renderProfit },
  // 'Şube Karşılaştır' gizlendi — çok şubeli işletmeye özel, Raporlar ile örtüşüyor. Kod duruyor.
  { id: "branchcompare",key: "navBranchCompare",icon: "🏪", group: "grpAnalysis", render: renderBranchCompare, hidden: true },
  // 'Takvim Analizi' gizlendi — Grafikler/Isı Haritası ile örtüşüyor. Kod duruyor.
  { id: "calanalysis", key: "navCalAnalysis",icon: "📅", group: "grpAnalysis",  render: renderCalAnalysis, hidden: true },
  // 'Isı Haritası' gizlendi — Grafikler ile örtüşüyor. Kod duruyor.
  { id: "heatmap",     key: "navHeatmap",   icon: "🔥", group: "grpAnalysis",  render: renderHeatmap, hidden: true },
  { id: "currency",    key: "navCurrency",  icon: "💱", group: "grpAnalysis",  render: renderCurrency },
  { id: "excelimport", key: "navExcel",     icon: "📥", group: "grpAnalysis",  render: renderExcelImport },

  // Gelişmiş Modüller+
  { id: "smartorder",  key: "navSmartOrder",icon: "🛒", group: "grpAdvanced",  render: renderSmartOrder },
  // 'Recipe' (reciperoll) gizlendi — POS'a entegre '🍹 Reçete/BOM' (recipe) ile mükerrer. Kod duruyor.
  { id: "reciperoll",  key: "navRecipe",    icon: "🧪", group: "grpAdvanced",  render: renderRecipeRoll, hidden: true },
  { id: "recipe",      key: "navRecipe2",   icon: "🍹", group: "grpAdvanced",  render: renderRecipe },
  { id: "pricetag",    key: "navPriceTag",  icon: "🏷️", group: "grpAdvanced",  render: renderPriceTag },
  { id: "courier",     key: "navCourier",   icon: "🛵", group: "grpAdvanced",  render: renderCourier },
  // 'Dinamik Fiyat' gizlendi — Fiyat Etiketi/Ürünler ile örtüşüyor. Kod duruyor.
  { id: "dynprice",    key: "navDynPrice",  icon: "🏷️", group: "grpAdvanced",  render: renderDynPrice, hidden: true },
  { id: "shift",       key: "navShift",     icon: "🕒", group: "grpAdvanced",  render: renderShift },
  { id: "loyalty",     key: "navLoyalty",   icon: "🎁", group: "grpAdvanced",  render: renderLoyalty },
  // 'Finans Takvimi' gizlendi — Randevular/Gider ile örtüşüyor. Kod duruyor.
  { id: "fincal",      key: "navFinCal",    icon: "📅", group: "grpAdvanced",  render: renderFinCal, hidden: true },
  // QR Menü artık panelde görünür (Yönetim grubunda). Sosyal medya / web sitesi /
  // menü (stoktan) bağlantıları buradan yönetilir; müşteri #/m/hesap ile tıklama ekranını açar.
  { id: "pwa",         key: "navPwa",       icon: "📶", group: "grpAdvanced",  render: renderPwa },
  { id: "roles",       key: "navRoles",     icon: "🔐", group: "grpAdvanced",  render: renderUsers },

  // Vizyon Modülleri+
  { id: "approvals",   key: "navApprovals", icon: "✅", group: "grpVision",    render: renderApprovals },
  { id: "ocr",         key: "navOcr",       icon: "🧾", group: "grpVision",    render: renderOcr },
  { id: "faceshift",   key: "navFace",      icon: "🧑‍💻", group: "grpVision",  render: renderFaceShift },

  // Güvenlik+
  { id: "security",    key: "navSecurity",  icon: "🛡️", group: "grpSecPlus",   render: renderSecurity },
  { id: "audit",       key: "navAudit",     icon: "🔒", group: "grpSecPlus",   render: renderAudit },

  // Hızlı Satış+
  { id: "pos",         key: "navPos",       icon: "🛒", group: "grpMarket",    render: renderPOS },
  // 'Garson' gizlendi — yerine 'Masa / Adisyon' (tables) kullanılıyor. Kod duruyor.
  { id: "waiter",      key: "navWaiter",    icon: "🧑‍🍳", group: "grpMarket",   render: renderWaiter, hidden: true },
  { id: "kitchen",     key: "navKitchen",   icon: "🍳", group: "grpMarket",    render: renderKitchen },
  { id: "campaigns",   key: "navCampaigns", icon: "🎯", group: "grpMarket",    render: renderCampaigns },
  { id: "bundles",     key: "navBundles",   icon: "🍔", group: "grpMarket",    render: renderBundles },
  { id: "giftcards",   key: "navGiftcards", icon: "🎁", group: "grpMarket",    render: renderGiftcards },
  { id: "marketset",   key: "navMarketSet", icon: "🏪", group: "grpMarket",    render: renderMarketSet },

  // Yönetim+
  { id: "cashierperms",key: "navCashierPerms",icon: "🔐", group: "grpManagePlus", render: renderCashierPerms },
  { id: "autosave",    key: "navAutoSave",  icon: "☁️", group: "grpManagePlus", render: renderAutoSave },
  { id: "automation",  key: "navAutomation",icon: "⚙️", group: "grpManagePlus", render: renderAutomation },
  { id: "settings",    key: "navSettings",  icon: "⚙️", group: "grpManagePlus", render: renderSettings },
];

// Paket/deneme sistemi kaldırıldı — hiçbir modül kilitli değil, tüm özellikler açık.
export const PREMIUM_IDS = new Set();
