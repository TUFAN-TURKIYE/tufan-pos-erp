// Kâr / Zarar (P&L) Özeti — patron için aylık gelir-gider-kâr tablosu.
// Gelir: satışlardan (db.sales, void hariç). SMM (COGS): ürün.cost × satılan adet.
// Diğer gelir/gider: db.txns (income/expense). Brüt kâr, net kâr, marjlar.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

function ymOf(ts) { const d = new Date(ts); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"); }
function curYm() { return ymOf(Date.now()); }

function compute(ym) {
  let revenue = 0, cogs = 0, otherIncome = 0, otherExpense = 0, salesCount = 0;
  const costMap = {}; // productId → cost
  db.products.all().forEach((p) => { costMap[p.id] = Number(p.cost) || 0; });

  db.sales.all().forEach((s) => {
    if (s.void) return;
    if (ymOf(s.ts) !== ym) return;
    revenue += Number(s.total) || 0;
    salesCount++;
    (s.items || []).forEach((it) => {
      const c = costMap[it.productId] || 0;
      cogs += c * (Number(it.qty) || 0);
    });
  });

  db.txns.all().forEach((x) => {
    if (ymOf(x.ts) !== ym) return;
    const amt = Number(x.amount) || 0;
    if ((x.type || "") === "income") otherIncome += amt;
    else if ((x.type || "") === "expense") otherExpense += amt;
  });

  const grossProfit = revenue - cogs;
  const netProfit = grossProfit + otherIncome - otherExpense;
  const grossMargin = revenue > 0 ? (grossProfit / revenue) * 100 : 0;
  const netMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;
  return { revenue, cogs, grossProfit, otherIncome, otherExpense, netProfit, grossMargin, netMargin, salesCount };
}

export function renderPnl(host) {
  let ym = curYm();
  const monthInput = el("input", { type: "month", class: "input", value: ym, style: "max-width:180px" });
  monthInput.addEventListener("change", () => { ym = monthInput.value || curYm(); draw(); });
  const printBtn = el("button", { class: "btn ghost", onClick: () => printPnl() }, ["🖨️ Yazdır / PDF"]);

  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "📊 " + t("navPnl") }), el("div", { class: "spacer" }), monthInput, printBtn]),
    body,
  );

  function row(label, val, opts) {
    opts = opts || {};
    return el("div", { class: "pnl-row" + (opts.cls ? " " + opts.cls : "") }, [
      el("span", { class: "pnl-lbl", text: label }),
      el("span", { class: "pnl-amt num", style: opts.color ? "color:" + opts.color : "", text: (opts.neg ? "− " : "") + money(Math.abs(val)) }),
    ]);
  }

  function draw() {
    clear(body);
    const r = compute(ym);
    const ok = "var(--ok,#16a34a)", danger = "var(--danger,#dc2626)";

    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Ciro" }), el("div", { class: "smart-val num", text: money(r.revenue) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Brüt Kâr" }), el("div", { class: "smart-val num", style: "color:" + (r.grossProfit >= 0 ? ok : danger), text: money(r.grossProfit) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Net Kâr" }), el("div", { class: "smart-val num", style: "color:" + (r.netProfit >= 0 ? ok : danger), text: money(r.netProfit) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Net Marj" }), el("div", { class: "smart-val num", text: "%" + r.netMargin.toFixed(1) })]),
    ]));

    const table = el("div", { class: "pnl-table" }, [
      row("Ciro (Satışlar · " + r.salesCount + " fiş)", r.revenue),
      row("Satılan Malın Maliyeti (SMM)", r.cogs, { neg: true, color: danger }),
      row("BRÜT KÂR", r.grossProfit, { cls: "sub", color: r.grossProfit >= 0 ? ok : danger }),
      row("Diğer Gelirler", r.otherIncome, { color: ok }),
      row("Giderler", r.otherExpense, { neg: true, color: danger }),
      row("NET KÂR / ZARAR", r.netProfit, { cls: "total", color: r.netProfit >= 0 ? ok : danger }),
    ]);
    body.appendChild(table);

    body.appendChild(el("div", { class: "pnl-margins" }, [
      el("div", { class: "muted", style: "font-size:12px", text: "Brüt marj: %" + r.grossMargin.toFixed(1) + "  ·  Net marj: %" + r.netMargin.toFixed(1) }),
    ]));

    if (r.cogs === 0 && r.revenue > 0) {
      body.appendChild(el("p", { class: "muted", style: "padding:10px;font-size:12px", text: "ℹ️ SMM sıfır görünüyor — ürünlere 'maliyet (cost)' girerseniz brüt kâr doğru hesaplanır." }));
    }
  }

  function printPnl() {
    const r = compute(ym);
    const s = settings.get();
    const biz = (s.bizName || s.businessName || "TUFAN 101");
    const w = window.open("", "_blank");
    if (!w) return;
    const line = (l, v, bold) => `<tr class="${bold ? "b" : ""}"><td>${l}</td><td class="r">${money(v)}</td></tr>`;
    w.document.write(`<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Kâr/Zarar ${ym}</title>
<style>
  *{font-family:Arial,Helvetica,sans-serif;box-sizing:border-box}
  body{padding:28px;color:#111}
  h1{margin:0 0 2px;font-size:22px}
  .sub{color:#666;margin:0 0 18px;font-size:13px}
  table{width:100%;border-collapse:collapse;margin-top:8px}
  td{padding:9px 6px;border-bottom:1px solid #e5e7eb;font-size:14px}
  td.r{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}
  tr.b td{font-weight:800;border-top:2px solid #111;font-size:15px}
  .foot{margin-top:22px;color:#888;font-size:11px;text-align:center}
  @media print{body{padding:10px}}
</style></head><body>
  <h1>${biz} — Kâr / Zarar Özeti</h1>
  <p class="sub">Dönem: ${ym} · ${r.salesCount} satış fişi</p>
  <table>
    ${line("Ciro (Satışlar)", r.revenue)}
    ${line("Satılan Malın Maliyeti (−)", r.cogs)}
    ${line("BRÜT KÂR", r.grossProfit, true)}
    ${line("Diğer Gelirler (+)", r.otherIncome)}
    ${line("Giderler (−)", r.otherExpense)}
    ${line("NET KÂR / ZARAR", r.netProfit, true)}
  </table>
  <p class="sub" style="margin-top:14px">Brüt marj: %${r.grossMargin.toFixed(1)} · Net marj: %${r.netMargin.toFixed(1)}</p>
  <div class="foot">TUFAN 101 · ${new Date().toLocaleString("tr-TR")}</div>
  <script>window.onload=function(){setTimeout(function(){window.print()},250)}<\/script>
</body></html>`);
    w.document.close();
  }

  draw();
}
