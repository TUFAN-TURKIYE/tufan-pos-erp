// mod-25 Garson Yönetimi — garson menüden masaya sipariş alır, satışı ana kasaya
// (patron/kasiyer bell paneline) bildirim olarak düşürür. Kasadan para almaz.
import { el, clear, toast, sound } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings, currentAccount } from "../core/store.js";
import { currentUser } from "../core/auth.js";
import { cloud } from "../core/api.js";

export function renderWaiter(host) {
  const account = currentAccount();
  const me = currentUser();
  let cart = new Map();      // productId -> {name, price, qty}
  let masa = "";
  let catFilter = "";

  const layout = el("div", { style: "display:grid;grid-template-columns:1fr 340px;gap:16px;height:100%" });

  // ---- Masa seçimi ----
  const tableWrap = el("div", { class: "waiter-tables", style: "display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px" });
  const tableCount = Math.max(0, parseInt(settings.get().tableCount, 10) || 0);
  const manualMasa = el("input", { class: "input", type: "number", inputmode: "numeric", min: "1", placeholder: t("tableNo"), style: "max-width:120px" });
  manualMasa.addEventListener("input", () => { masa = manualMasa.value.trim(); drawTables(); });
  function drawTables() {
    clear(tableWrap);
    if (tableCount > 0) {
      for (let i = 1; i <= tableCount; i++) {
        const n = String(i);
        tableWrap.appendChild(el("button", {
          class: "btn " + (masa === n ? "success" : "ghost"), style: "min-width:46px;padding:8px 10px",
          onClick: () => { masa = n; manualMasa.value = n; drawTables(); },
        }, ["🪑 " + n]));
      }
    }
    tableWrap.appendChild(manualMasa);
  }

  // ---- Ürün arama + kategori + ızgara ----
  const search = el("input", { class: "input", placeholder: "🔍 " + t("barcode"), autofocus: true });
  const chips = el("div", { class: "cat-chips", style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:12px" });
  const grid = el("div", { class: "prod-grid", style: "margin-top:14px" });
  search.addEventListener("input", () => drawGrid(search.value.trim()));

  const left = el("div", {}, [
    el("div", { class: "view-head" }, [el("h1", { text: "🧑‍🍳 " + t("navWaiter") }), el("div", { class: "spacer" })]),
    el("div", { class: "muted", style: "margin:2px 0 10px", text: t("waiterHint") }),
    el("label", { class: "muted", style: "font-weight:600;font-size:13px", text: "🪑 " + t("selectTable") }),
    tableWrap, search, chips, grid,
  ]);

  function drawChips() {
    clear(chips);
    const cats = db.categories.all();
    if (!cats.length) return;
    const chip = (label, val, color) => el("button", {
      class: "btn " + (catFilter === val ? "" : "ghost"), style: "padding:6px 12px" + (color && catFilter === val ? `;background:${color};border-color:${color}` : ""),
      onClick: () => { catFilter = val; drawChips(); drawGrid(search.value.trim()); },
    }, [label]);
    chips.append(chip("● " + t("total"), ""), ...cats.map((c) => chip((c.icon || "🏷️") + " " + c.name, c.id, c.color)));
  }

  function drawGrid(filter = "") {
    clear(grid);
    const list = db.products.all().filter((p) => p.active &&
      (!catFilter || p.categoryId === catFilter) &&
      (!filter || p.name.toLowerCase().includes(filter.toLowerCase()) || (p.barcode || "").includes(filter)));
    if (!list.length) { grid.appendChild(el("p", { class: "muted", text: t("noProducts") })); return; }
    list.forEach((p) => grid.appendChild(
      el("button", { class: "prod", onClick: () => addItem(p) }, [
        p.image ? el("img", { class: "pimg", src: p.image, alt: p.name }) : el("div", { class: "emoji", text: p.emoji || "📦" }),
        el("div", { class: "pname", text: p.name }),
        el("div", { class: "pprice", text: p.price > 0 ? money(p.price) : t("enterPrice") }),
      ])
    ));
  }

  // ---- Sipariş sepeti (sağ) ----
  const orderItems = el("div", { class: "cart-items" });
  const totalEl = el("div", { class: "cart-total num" });
  const noteInput = el("input", { class: "input", placeholder: t("orderNote"), style: "margin-top:8px" });
  const sendBtn = el("button", { class: "btn success lg block", onClick: () => submitOrder() }, ["📨 " + t("sendToKasa")]);
  const right = el("div", { class: "card cart" }, [
    el("h3", { text: "🧾 " + t("tableOrder") }),
    orderItems,
    el("div", { style: "border-top:1px solid var(--border);padding-top:12px;margin-top:8px" }, [
      el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:8px" }, [
        el("span", { class: "muted", text: t("total") }), totalEl,
      ]),
      noteInput,
      sendBtn,
      el("button", { class: "btn ghost block", style: "margin-top:8px", onClick: () => { cart = new Map(); refreshCart(); } }, ["🗑 " + t("cancel")]),
    ]),
  ]);

  function addItem(p) {
    const line = cart.get(p.id);
    if (line) line.qty++;
    else cart.set(p.id, { name: p.name, price: p.price || 0, qty: 1 });
    sound.add();
    refreshCart();
  }
  function changeQty(id, d) {
    const line = cart.get(id); if (!line) return;
    line.qty += d;
    if (line.qty <= 0) { cart.delete(id); sound.remove(); } else sound.tick();
    refreshCart();
  }
  function cartTotal() { let s = 0; cart.forEach((x) => s += x.price * x.qty); return s; }
  function refreshCart() {
    clear(orderItems);
    if (!cart.size) { orderItems.appendChild(el("p", { class: "muted", text: t("emptyCart") })); }
    cart.forEach((item, id) => {
      orderItems.appendChild(el("div", { class: "cart-row" }, [
        el("div", { style: "flex:1" }, [
          el("div", { style: "font-weight:700", text: item.name }),
          el("div", { class: "muted", style: "font-size:12px", text: money(item.price) }),
        ]),
        el("div", { class: "qty" }, [
          el("button", { class: "qbtn", onClick: () => changeQty(id, -1) }, ["−"]),
          el("b", { class: "num", text: String(item.qty) }),
          el("button", { class: "qbtn", onClick: () => changeQty(id, 1) }, ["+"]),
        ]),
        el("div", { class: "num", style: "width:80px;text-align:right;font-weight:700", text: money(item.price * item.qty) }),
      ]));
    });
    totalEl.textContent = money(cartTotal());
  }

  async function submitOrder() {
    if (!masa) { sound.error(); toast(t("pickTableFirst"), "warn"); return; }
    if (!cart.size) { sound.error(); toast(t("emptyCart"), "warn"); return; }
    if (!account) { toast(t("noCloudAccount"), "warn"); return; }
    const items = [...cart.values()].map((x) => ({ name: x.name, qty: x.qty, price: x.price }));
    const waiterName = me && me.name ? me.name : "";
    const note = [waiterName ? "👤 " + waiterName : "", noteInput.value.trim()].filter(Boolean).join(" · ");
    sendBtn.disabled = true; sendBtn.textContent = "⏳ " + t("sending");
    try {
      await cloud.call(account, { type: "order", masa, items, note, waiter: waiterName });
      sound.sale();
      toast(t("orderSentOk") + " • " + t("tableNo") + " " + masa, "success");
      cart = new Map(); noteInput.value = ""; refreshCart();
    } catch (e) {
      toast(t("orderSendFail"), "error");
    } finally {
      sendBtn.disabled = false; sendBtn.textContent = "📨 " + t("sendToKasa");
    }
  }

  layout.append(left, right);
  clear(host).appendChild(layout);
  drawTables(); drawChips(); drawGrid(); refreshCart();
}
