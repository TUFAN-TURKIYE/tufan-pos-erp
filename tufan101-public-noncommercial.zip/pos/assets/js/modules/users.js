// mod-15 Rol Yönetimi + mod-06 PIN kullanıcıları + mod-13 Güvenlik Kayıtları
import { el, clear, toast, modal, confirmDialog, sound } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { users, saveUser, removeUser, ROLE_PERMS, can, currentUser } from "../core/auth.js";
import { settings, db, uid } from "../core/store.js";
import { isBoss } from "./boss.js";
// Modül listesi (id/ikon/başlık) — çalışma anında okunur; döngüsel import güvenli.
import * as registry from "./index.js";

// Rol atamada aç/kapat edilebilecek modüller (patron paneli, ayarlar ve
// bildirimler her zaman kuralın dışında tutulur).
function togglableModules() {
  const list = Array.isArray(registry.MODULES) ? registry.MODULES : [];
  return list.filter((m) => m && !m.hidden && !m.bossOnly && m.id !== "settings" && m.id !== "notifications");
}
// Sınır aşıldığında patronun görmesi için bildirim bırak (Bildirimler modülü + zil sesi).
function notifyLimit(limit) {
  try {
    db.notifications.upsert({
      id: uid(),
      title: "⚠️ Kullanıcı/rol sınırı aşılmak istendi",
      body: "En fazla " + limit + " kullanıcıya yetki verilebilir. Yeni kişi eklemek için sınırı artırın. (" + new Date().toLocaleString("tr-TR") + ")",
      ts: Date.now(), seen: 0,
    });
    sound.notify();
  } catch {}
}

const ROLES = ["owner", "manager", "cashier", "apprentice", "waiter", "kitchen", "courier"];
// Kısıtlı roller için varsayılan modül erişimi. Kurye müşteri/ürün/stok ekleyemez;
// yalnızca kendi teslimat ekranını görür ve patronun yazdığı parayı (POS/nakit) tahsil eder.
const ROLE_DEFAULT_MODULES = {
  courier: ["courier"],
  kitchen: ["kitchen"],
  waiter: ["tables"],
};
const DEFAULT_USER_LIMIT = 5;
// TUFAN 101 destek (Doruk) — "daha fazla istiyorum" talebi buraya WhatsApp ile düşer.
const SUPPORT_WA = "905449641775";

// "Daha fazla rol istiyorum" → telefon al, destek hattına (Doruk) ticket gönder.
function requestMoreRoles() {
  const phone = el("input", { class: "input", inputmode: "tel", placeholder: "05xx xxx xx xx" });
  const noteI = el("input", { class: "input", placeholder: "Kaç kullanıcı/rol lazım? (opsiyonel)" });
  modal({
    title: "➕ Daha Fazla Rol İstiyorum",
    body: el("div", {}, [
      el("p", { class: "muted", style: "margin:0 0 8px;font-size:13px", text: "Telefonunuzu bırakın; ekibimiz (TUFAN 101) sizinle iletişime geçip rol/kullanıcı sınırınızı artırsın." }),
      el("div", { class: "field" }, [el("label", { text: "📞 Telefon" }), phone]),
      el("div", { class: "field" }, [el("label", { text: "📝 Not" }), noteI]),
    ]),
    actions: [
      { label: "📨 Talep Gönder", kind: "success", onClick: (close) => {
        const tel = phone.value.trim();
        if (!tel || tel.replace(/\D/g, "").length < 10) { toast("Geçerli bir telefon girin", "warn"); return; }
        const biz = settings.get().business || "";
        const msg = "TUFAN 101 — Rol/Kullanıcı Sınırı Artırma Talebi\n"
          + "İşletme: " + (biz || "-") + "\n"
          + "Telefon: " + tel + "\n"
          + "Mevcut sınır: " + getUserLimit() + " · Kullanıcı: " + users().length + "\n"
          + (noteI.value.trim() ? "Not: " + noteI.value.trim() + "\n" : "");
        // Talebi patronun Bildirimler defterine de yaz (iz kalsın).
        try {
          db.notifications.upsert({ id: uid(), title: "📨 Rol artırma talebi gönderildi",
            body: "Telefon: " + tel + " · Destek hattına iletildi. (" + new Date().toLocaleString("tr-TR") + ")",
            ts: Date.now(), seen: 0 });
        } catch {}
        window.open("https://wa.me/" + SUPPORT_WA + "?text=" + encodeURIComponent(msg), "_blank", "noopener");
        toast("Talebiniz iletildi. En kısa sürede dönüş yapılacak.", "success");
        close();
      } },
      { label: "İptal", kind: "ghost" },
    ],
  });
}
// Ayarlardan kullanıcı (rol atama) sınırı — admin menüden değiştirebilir. Varsayılan 5.
function getUserLimit() {
  const v = parseInt(settings.get().userLimit, 10);
  return Number.isFinite(v) && v > 0 ? v : DEFAULT_USER_LIMIT;
}
// Sınırı yalnızca işletme sahibi (owner) veya patron değiştirebilir.
function canManageLimit() {
  return isBoss() || currentUser()?.role === "owner";
}
const PERM_KEYS = ["sell", "refund", "changePrice", "manageStock", "viewReports", "manageUsers", "cashOut", "voidSale"];
const PERM_LABEL = { sell: "Satış", refund: "İade", changePrice: "Fiyat Değiştir", manageStock: "Stok Yönet", viewReports: "Rapor Gör", manageUsers: "Kullanıcı Yönet", cashOut: "Kasadan Para", voidSale: "Fiş İptal" };

export function renderUsers(host) {
  if (!can("manageUsers")) {
    clear(host).appendChild(el("div", { class: "card locked-note" }, [
      el("div", { class: "big", text: "🔒" }),
      el("p", { class: "muted", text: "Bu bölüm yalnızca Patron/Müdür yetkisiyle görülebilir." }),
    ]));
    return;
  }
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: t("users") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn", onClick: () => edit(null) }, ["+ " + t("add")]),
  ]);

  // ---- Rol atama sınırı (varsayılan 5) — admin arttırıp azaltabilir ----
  const limitCard = el("div", { class: "card", style: "margin-bottom:12px" });
  function drawLimit() {
    const limit = getUserLimit();
    const count = users().length;
    clear(limitCard);
    const info = el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap" }, [
      el("span", { style: "font-size:18px", text: "👥" }),
      el("b", { text: "Kullanıcı / Rol Sınırı" }),
      el("span", { class: "pill " + (count >= limit ? "amber" : "blue"), text: count + " / " + limit }),
    ]);
    limitCard.appendChild(info);
    if (canManageLimit()) {
      const num = el("input", { class: "input", type: "number", min: "1", max: "999", value: String(limit), style: "width:90px" });
      const row = el("div", { style: "display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-top:8px" }, [
        el("span", { class: "muted", text: "En fazla kaç kullanıcı eklenebilsin?" }),
        el("button", { class: "iconbtn", onClick: () => { num.value = String(Math.max(1, (parseInt(num.value, 10) || 1) - 1)); } }, ["−"]),
        num,
        el("button", { class: "iconbtn", onClick: () => { num.value = String(Math.min(999, (parseInt(num.value, 10) || 1) + 1)); } }, ["+"]),
        el("button", { class: "btn success", onClick: () => {
          const v = parseInt(num.value, 10);
          if (!Number.isFinite(v) || v < 1) { toast("Geçerli bir sayı girin", "warn"); return; }
          if (v < users().length) { toast("Sınır mevcut kullanıcı sayısından az olamaz (" + users().length + ")", "warn"); return; }
          settings.set({ userLimit: v });
          toast("Sınır güncellendi: " + v, "success");
          drawLimit();
        } }, ["💾 Kaydet"]),
      ]);
      limitCard.appendChild(row);
    } else {
      limitCard.appendChild(el("p", { class: "muted", style: "margin:6px 0 0;font-size:13px", text: "Sınırı yalnızca işletme sahibi değiştirebilir." }));
    }
    // "Daha fazla istiyorum" — destek hattına (Doruk) ticket gönderir.
    limitCard.appendChild(el("button", {
      class: "btn ghost", style: "margin-top:10px", onClick: requestMoreRoles,
    }, ["➕ Daha fazla istiyorum"]));
  }

  const card = el("div", { class: "card" });
  clear(host).append(head, limitCard, card);

  function draw() {
    clear(card).appendChild(el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: t("name") }), el("th", { text: t("role") }), el("th", { text: "İzinler" }), el("th", {})])]),
      el("tbody", {}, users().map((u) =>
        el("tr", {}, [
          el("td", { text: u.name + (currentUser()?.id === u.id ? " (siz)" : "") }),
          el("td", {}, [el("span", { class: "pill blue", text: t(u.role) })]),
          el("td", { class: "muted", style: "font-size:12px" }, [
            el("span", { text: PERM_KEYS.filter((k) => u.perms?.[k]).map((k) => PERM_LABEL[k]).join(", ") }),
            Array.isArray(u.modules)
              ? el("span", { class: "pill amber", style: "margin-left:6px;font-size:11px", text: "🔒 " + Math.max(0, togglableModules().length - u.modules.length) + " kilitli" })
              : null,
          ]),
          el("td", { style: "text-align:right" }, [
            el("button", { class: "iconbtn", style: "display:inline-grid", onClick: () => edit(u) }, ["✏️"]),
            u.role !== "owner" ? el("button", { class: "iconbtn", style: "display:inline-grid;margin-left:6px", onClick: () => confirmDialog(t("delete") + "?", () => { removeUser(u.id); draw(); drawLimit(); }) }, ["🗑"]) : null,
          ]),
        ])
      )),
    ]));
  }

  function edit(u) {
    const isNew = !u;
    // Rol atama sınırı: yeni kullanıcı eklerken sınıra ulaşıldıysa engelle + patrona bildir.
    if (isNew && users().length >= getUserLimit()) {
      const lim = getUserLimit();
      notifyLimit(lim);
      toast("Kullanıcı sınırına ulaştınız (" + lim + ")." + (canManageLimit() ? " Sınırı yukarıdan arttırabilirsiniz." : " Patrona bildirim gönderildi."), "warn");
      return;
    }
    u = u ? { ...u, perms: { ...u.perms } } : { role: "cashier", perms: { ...ROLE_PERMS.cashier }, active: true };

    // Patron/işletme sahibi KENDİ hesabını düzenliyorsa kullanıcı adı ve şifresini
    // değiştiremesin (kilitlenmeyi/yanlış değişimi önler). Sunucu tarafı yönetir.
    const editingSelf = !isNew && currentUser()?.id === u.id;
    const lockCreds = editingSelf && (u.role === "owner" || isBoss());

    const name = el("input", { class: "input", value: u.name || "" });
    const username = el("input", { class: "input", value: u.username || "", placeholder: t("usernameLabel"), autocomplete: "off" });
    const password = el("input", { class: "input", type: "text", value: u.password || "", placeholder: t("passwordLabel"), autocomplete: "off" });
    if (lockCreds) {
      [username, password].forEach((i) => { i.readOnly = true; i.disabled = true; i.style.opacity = ".6"; i.title = "Patron kendi kullanıcı adı/şifresini buradan değiştiremez."; });
    }
    const roleSel = el("select", { class: "input" }, ROLES.map((r) => el("option", { value: r, ...(r === u.role ? { selected: true } : {}) }, [t(r)])));
    if (lockCreds) { roleSel.disabled = true; }
    const permBox = el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:6px" });
    const drawPerms = () => {
      clear(permBox);
      PERM_KEYS.forEach((k) => {
        const cb = el("input", { type: "checkbox", ...(u.perms[k] ? { checked: true } : {}) });
        cb.addEventListener("change", () => { u.perms[k] = cb.checked ? 1 : 0; });
        permBox.appendChild(el("label", { style: "display:flex;gap:8px;align-items:center;padding:6px;border:1px solid var(--border);border-radius:8px" }, [cb, el("span", { text: PERM_LABEL[k] })]));
      });
    };
    roleSel.addEventListener("change", () => { u.role = roleSel.value; u.perms = { ...ROLE_PERMS[u.role] }; drawPerms(); });
    drawPerms();

    // ---- Modül erişimi (aç/kapat) — kapalı modüller kullanıcıda "🔒 Kilitli" görünür ----
    // u.modules: izinli modül id'leri dizisi. null/yok = tüm modüller açık.
    const isOwnerRole = () => roleSel.value === "owner";
    const allMods = togglableModules();
    const allowedSet = new Set(
      Array.isArray(u.modules) ? u.modules
        : (ROLE_DEFAULT_MODULES[u.role] || allMods.map((m) => m.id))
    );
    const modBox = el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:6px;max-height:220px;overflow:auto;padding:4px;border:1px solid var(--border);border-radius:8px" });
    const modNote = el("p", { class: "muted", style: "font-size:12px;margin:4px 0 0" });
    const drawMods = () => {
      clear(modBox);
      if (isOwnerRole()) { modNote.textContent = "İşletme sahibi (owner) tüm modülleri görür — kısıtlanamaz."; modBox.style.display = "none"; return; }
      modBox.style.display = "";
      modNote.textContent = "İşaretli modüller açık; işareti kaldırılanlar kullanıcıda kilitli görünür.";
      allMods.forEach((m) => {
        const cb = el("input", { type: "checkbox", ...(allowedSet.has(m.id) ? { checked: true } : {}) });
        cb.addEventListener("change", () => { if (cb.checked) allowedSet.add(m.id); else allowedSet.delete(m.id); });
        modBox.appendChild(el("label", { style: "display:flex;gap:8px;align-items:center;padding:6px;border:1px solid var(--border);border-radius:8px;font-size:13px" }, [cb, el("span", { text: (m.icon || "") + " " + t(m.key) })]));
      });
    };
    const selAll = el("button", { class: "btn tiny", onClick: () => { allMods.forEach((m) => allowedSet.add(m.id)); drawMods(); } }, ["Tümünü Aç"]);
    const selNone = el("button", { class: "btn tiny ghost", onClick: () => { allowedSet.clear(); drawMods(); } }, ["Tümünü Kapat"]);
    // Rol değişince kısıtlı roller (kurye/mutfak/garson) varsayılan modül setine dönsün.
    roleSel.addEventListener("change", () => {
      const def = ROLE_DEFAULT_MODULES[roleSel.value];
      if (def) { allowedSet.clear(); def.forEach((id) => allowedSet.add(id)); }
      else if (isOwnerRole()) { allMods.forEach((m) => allowedSet.add(m.id)); }
    });
    roleSel.addEventListener("change", drawMods);
    drawMods();

    modal({
      title: isNew ? t("add") : t("edit"),
      body: el("div", {}, [
        lockCreds ? el("p", { class: "muted", style: "margin:0 0 8px;font-size:12px", text: "🔒 Patron hesabı: kullanıcı adı, şifre ve rol buradan değiştirilemez." }) : null,
        el("div", { class: "field" }, [el("label", { text: t("name") }), name]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: t("usernameLabel") }), username]),
          el("div", { class: "field" }, [el("label", { text: t("role") }), roleSel]),
        ]),
        el("div", { class: "field" }, [el("label", { text: t("passwordLabel") }), password]),
        el("div", { class: "field" }, [el("label", { text: "İzinler (mod-15)" }), permBox]),
        el("div", { class: "field" }, [
          el("div", { style: "display:flex;align-items:center;gap:8px;flex-wrap:wrap" }, [el("label", { style: "margin:0", text: "🔐 Modül Erişimi" }), el("div", { style: "flex:1" }), selAll, selNone]),
          modBox, modNote,
        ]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim() || !username.value.trim() || !password.value) { toast("Ad, kullanıcı adı ve şifre gerekli", "warn"); return; }
          // Owner → tüm modüller açık (null). Diğer rollerde: hepsi seçiliyse null, değilse dizi.
          let modules = null;
          if (!isOwnerRole()) {
            const arr = allMods.filter((m) => allowedSet.has(m.id)).map((m) => m.id);
            modules = (arr.length === allMods.length) ? null : arr;
          }
          const patch = { ...u, name: name.value.trim(), role: roleSel.value, modules };
          // Patron kendini düzenliyorsa kimlik/rol alanlarını KORU (kilitli olduğu için).
          if (!lockCreds) { patch.username = username.value.trim(); patch.password = password.value; }
          saveUser(patch);
          toast(t("save"), "success"); close(); draw(); drawLimit();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  drawLimit();
  draw();
}
