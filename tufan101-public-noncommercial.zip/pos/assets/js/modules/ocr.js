// Fatura Tarayıcı (OCR) — fatura/fiş görselini tara, tutar/firma/tarih/KDV çıkar, gider olarak kaydet
// Tesseract.js CDN'den yüklenir (ilk kullanımda internet gerekir; sonra tarayıcı önbelleğinden).
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

const TESSERACT_CDN = "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js";
const today = () => new Date().toISOString().slice(0, 10);

let loaderPromise = null;
function loadTesseract() {
  if (window.Tesseract) return Promise.resolve(window.Tesseract);
  if (loaderPromise) return loaderPromise;
  loaderPromise = new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = TESSERACT_CDN;
    s.onload = () => resolve(window.Tesseract);
    s.onerror = () => reject(new Error("Tesseract yüklenemedi"));
    document.head.appendChild(s);
  });
  return loaderPromise;
}

export function renderOcr(host) {
  const head = el("div", { class: "view-head" }, [el("h1", { text: "🧾 " + t("ocr") })]);
  const layout = el("div", { class: "grid", style: "grid-template-columns:1fr 1fr;gap:16px;align-items:start" });
  clear(host).append(head, layout);

  // Sol: görsel seç + tara
  const fileInp = el("input", { type: "file", accept: "image/*", capture: "environment", style: "display:none" });
  const img = el("img", { style: "display:none;max-width:100%;border-radius:10px;margin-top:12px;border:1px solid var(--border)" });
  const prog = el("div", { class: "muted", style: "margin-top:10px;font-size:13px", text: "Fatura/fiş fotoğrafı seçin veya çekin." });
  const raw = el("pre", { style: "white-space:pre-wrap;font:12px/1.5 ui-monospace,monospace;color:var(--muted);max-height:180px;overflow:auto;margin:8px 0 0;background:#0000000a;border:1px solid var(--border);border-radius:8px;padding:10px", text: "—" });

  const scanCard = el("div", { class: "card" }, [
    el("h3", { text: "📷 Görsel" }),
    el("button", { class: "btn success block", onClick: () => fileInp.click() }, ["📂 Fatura Görseli Seç / Çek"]),
    fileInp, img, prog,
    el("h3", { style: "margin-top:16px", text: "🔍 Ham OCR Metni" }), raw,
  ]);

  // Sağ: çıkarılan alanlar + kaydet
  const firma = el("input", { class: "input", placeholder: "Firma adı" });
  const tarih = el("input", { class: "input", type: "date", value: today() });
  const tutar = el("input", { class: "input num", type: "number", step: "0.01", placeholder: "0.00" });
  const kdv = el("input", { class: "input num", type: "number", step: "0.01", placeholder: "KDV %" });
  const aciklama = el("input", { class: "input", value: "Toptancı faturası", placeholder: "Açıklama" });

  const formCard = el("div", { class: "card" }, [
    el("h3", { text: "🧾 Gider Bilgileri" }),
    el("p", { class: "muted", style: "font-size:12px", text: "Tarama sonrası alanları kontrol edip düzeltebilirsiniz." }),
    two(field("Firma", firma), field("Tarih", tarih)),
    two(field("Tutar (₺)", tutar), field("KDV (%)", kdv)),
    field("Açıklama", aciklama),
    el("button", { class: "btn success block", style: "margin-top:12px", onClick: () => save() }, ["💾 Gider Olarak Kaydet"]),
  ]);

  layout.append(scanCard, formCard);

  fileInp.addEventListener("change", async (e) => {
    const f = e.target.files && e.target.files[0];
    if (!f) return;
    const url = URL.createObjectURL(f);
    img.src = url; img.style.display = "block";
    prog.textContent = "OCR kütüphanesi yükleniyor…";
    let Tesseract;
    try { Tesseract = await loadTesseract(); }
    catch { prog.textContent = "⚠ OCR kütüphanesi yüklenemedi (internet gerekli). Alanları elle doldurabilirsiniz."; return; }
    prog.textContent = "Taranıyor… %0";
    try {
      const res = await Tesseract.recognize(url, "tur+eng", {
        logger: (m) => { if (m.status === "recognizing text") prog.textContent = "Taranıyor… %" + Math.round(m.progress * 100); },
      });
      const txt = (res && res.data && res.data.text) || "";
      raw.textContent = txt || "—";
      parseInvoice(txt);
      prog.textContent = "Tarama tamam ✔ — alanları kontrol edin.";
    } catch (err) {
      prog.textContent = "Tarama hatası: " + (err.message || err);
    }
  });

  function parseInvoice(txt) {
    if (!txt) return;
    const lines = txt.split(/\n/).map((l) => l.trim()).filter(Boolean);
    // Firma: ilk anlamlı satır
    const firstLine = lines.find((l) => l.length > 3 && /[a-zçğıöşü]/i.test(l));
    if (firstLine && !firma.value) firma.value = firstLine.slice(0, 40);
    // Tutar: "TOPLAM / GENEL TOPLAM" satırındaki en büyük para değeri, yoksa metindeki en büyük
    const nums = [];
    const re = /(\d{1,3}(?:[.\s]\d{3})*(?:[.,]\d{2})|\d+[.,]\d{2})/g;
    let m;
    while ((m = re.exec(txt))) {
      const v = parseFloat(m[1].replace(/[.\s](?=\d{3}\b)/g, "").replace(",", "."));
      if (!isNaN(v)) nums.push(v);
    }
    const totalLine = lines.find((l) => /genel\s*toplam|toplam|tutar/i.test(l));
    let total = 0;
    if (totalLine) {
      const tm = totalLine.match(re);
      if (tm) total = Math.max(...tm.map((x) => parseFloat(x.replace(/[.\s](?=\d{3}\b)/g, "").replace(",", "."))).filter((x) => !isNaN(x)));
    }
    if (!total && nums.length) total = Math.max(...nums);
    if (total && !tutar.value) tutar.value = total.toFixed(2);
    // KDV yüzdesi
    const kdvm = txt.match(/%\s?(\d{1,2})|kdv[^0-9]{0,6}(\d{1,2})/i);
    if (kdvm && !kdv.value) kdv.value = kdvm[1] || kdvm[2] || "";
    // Tarih (gg.aa.yyyy / gg/aa/yyyy)
    const dm = txt.match(/(\d{1,2})[./-](\d{1,2})[./-](\d{2,4})/);
    if (dm) {
      let [, d, mo, y] = dm;
      if (y.length === 2) y = "20" + y;
      const iso = `${y}-${String(mo).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      if (!isNaN(new Date(iso))) tarih.value = iso;
    }
  }

  function save() {
    const a = parseFloat(tutar.value);
    if (!a || a <= 0) { toast("Geçerli bir tutar girin", "warn"); return; }
    const note = [firma.value.trim(), aciklama.value.trim(), kdv.value ? "KDV %" + kdv.value : ""].filter(Boolean).join(" • ") || "Fatura";
    db.txns.upsert({ id: uid(), type: "expense", amount: a, note, ts: new Date(tarih.value || today()).getTime() });
    toast("Gider kaydedildi: " + money(a) + " ✔", "success");
    firma.value = ""; tutar.value = ""; kdv.value = ""; aciklama.value = "Toptancı faturası";
    img.style.display = "none"; raw.textContent = "—"; prog.textContent = "Yeni fatura seçebilirsiniz.";
  }
}

function field(label, node) { return el("div", { class: "field" }, [el("label", { text: label }), node]); }
function two(a, b) { return el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [a, b]); }
