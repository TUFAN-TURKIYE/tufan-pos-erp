// Anlık Alarm Merkezi — patronu anında uyarır.
// Açık kasa, geç kalan sipariş/kurye, kritik/negatif stok, hedef sapması vb.
// Otomatik yenilenir; kritik alarmlar büyük ve renkli gösterilir.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

const MIN = 60000;

// Açık kasa oturumu (kapanmamış)
function openCashSession() { return db.cashSessions.all().find((s) => s.open); }

// Geç kalan siparişler: tamamlanmamış ve X dakikadan eski
function lateOrders(mins) {
  const cut = Date.now() - mins * MIN;
  return db.orders.all().filter((o) => {
    const ts = Number(o.ts || o.createdTs || 0);
    const done = o.status === "tamam" || o.status === "teslim" || o.done;
    return ts > 0 && ts < cut && !done && !o.void;
  });
}

function collect() {
  const out = [];
  const now = Date.now();

  // 1) Açık kasa (mesai sonu kontrolü)
  const cs = openCashSession();
  if (cs) {
    const hrs = Math.floor((now - Number(cs.openTs || now)) / 3600000);
    out.push({
      level: hrs >= 12 ? "crit" : "warn", icon: "💵",
      title: "Kasa hâlâ açık",
      desc: (hrs >= 1 ? hrs + " saattir açık. " : "") + "Gün sonunda kapatmayı unutmayın (Z raporu).",
    });
  }

  // 2) Geç kalan siparişler (45 dk+)
  const late = lateOrders(45);
  if (late.length) {
    out.push({
      level: "crit", icon: "⏱️",
      title: late.length + " sipariş gecikti",
      desc: "45 dakikadan uzun süredir tamamlanmadı. Mutfak/kurye kontrol edin.",
    });
  }

  // 3) Negatif stok (veri hatası / fazla satış)
  const neg = db.products.all().filter((p) => typeof p.stock === "number" && p.stock < 0);
  if (neg.length) {
    out.push({
      level: "crit", icon: "📉",
      title: neg.length + " üründe eksi stok",
      desc: neg.slice(0, 4).map((p) => p.name).join(", ") + (neg.length > 4 ? "…" : ""),
    });
  }

  // 4) Kritik/tükenen stok
  const low = db.products.all().filter((p) => p.active !== false && typeof p.stock === "number" && p.stock >= 0 && p.stock <= (Number(p.minStock) || 5));
  const out0 = low.filter((p) => p.stock === 0);
  if (out0.length) {
    out.push({ level: "crit", icon: "🚫", title: out0.length + " ürün tükendi", desc: out0.slice(0, 5).map((p) => p.name).join(", ") + (out0.length > 5 ? "…" : "") });
  }
  const lowOnly = low.filter((p) => p.stock > 0);
  if (lowOnly.length) {
    out.push({ level: "warn", icon: "⚠️", title: lowOnly.length + " üründe stok azaldı", desc: lowOnly.slice(0, 5).map((p) => p.name + " (" + p.stock + ")").join(", ") + (lowOnly.length > 5 ? "…" : "") });
  }

  // 5) Günlük hedef sapması (öğleden sonra hâlâ %40 altındaysa)
  const s = settings.get();
  const target = Number(s.targetDaily) || 0;
  if (target > 0) {
    const t0 = new Date(); t0.setHours(0, 0, 0, 0);
    const rev = db.sales.all().filter((x) => !x.void && Number(x.ts) >= t0.getTime()).reduce((a, x) => a + (Number(x.total) || 0), 0);
    const pct = Math.round(rev / target * 100);
    const hour = new Date().getHours();
    if (hour >= 15 && pct < 40) {
      out.push({ level: "warn", icon: "🎯", title: "Günlük hedefin gerisindesiniz", desc: "Şu ana kadar %" + pct + " (" + money(rev) + " / " + money(target) + ")." });
    }
  }

  return out;
}

export function renderAlarms(host) {
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🚨 " + t("navAlarms") }), el("div", { class: "spacer" }), el("span", { class: "pill", text: "Canlı" })]),
    body,
  );

  function draw() {
    clear(body);
    const alarms = collect();
    const crit = alarms.filter((a) => a.level === "crit");
    const warn = alarms.filter((a) => a.level === "warn");

    if (!alarms.length) {
      body.appendChild(el("div", { class: "alarm-ok" }, [
        el("div", { style: "font-size:54px", text: "✅" }),
        el("h2", { style: "margin:8px 0 4px", text: "Her şey yolunda" }),
        el("p", { class: "muted", text: "Aktif alarm yok. Sistem otomatik izliyor." }),
      ]));
      return;
    }

    body.appendChild(el("div", { class: "alarm-summary" }, [
      el("span", { class: "pill red", text: "🔴 " + crit.length + " kritik" }),
      el("span", { class: "pill amber", text: "🟡 " + warn.length + " uyarı" }),
    ]));

    const wrap = el("div", { class: "alarm-list" });
    [...crit, ...warn].forEach((a) => {
      wrap.appendChild(el("div", { class: "alarm-card alarm-" + a.level }, [
        el("div", { class: "alarm-icon", text: a.icon }),
        el("div", { style: "flex:1" }, [
          el("div", { class: "alarm-title", text: a.title }),
          el("div", { class: "alarm-desc", text: a.desc }),
        ]),
      ]));
    });
    body.appendChild(wrap);
  }

  draw();
  const timer = setInterval(() => { if (document.body.contains(host)) draw(); else clearInterval(timer); }, 20000);
}
