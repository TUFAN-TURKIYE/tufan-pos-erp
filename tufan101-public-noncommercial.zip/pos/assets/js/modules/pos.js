// mod-12 POS Terminali — barkodlu, klavye kısayollu (F1/F2/Enter) hızlı satış
import { el, clear, toast, modal, sound } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, todayRange, ensureAccounts, defaultAccountId, postAccountMove, settings, currentAccount } from "../core/store.js";
import { currentUser } from "../core/auth.js";
import { bestCampaign } from "./campaigns.js";
import { findGiftcard, redeemGiftcard } from "./giftcard.js";

let cart = [];

export function renderPOS(host) {
  cart = [];
  const layout = el("div", { style: "display:grid;grid-template-columns:1fr 340px;gap:16px;height:100%" });

  // Sol: arama + kategori filtreleri + ürün ızgarası
  const search = el("input", { class: "input pos-search", placeholder: "🔍 " + t("barcode"), autofocus: true });
  const chips = el("div", { class: "cat-chips", style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:12px" });
  const grid = el("div", { class: "prod-grid", style: "margin-top:14px" });
  let catFilter = "";
  const left = el("div", {}, [
    el("div", { class: "view-head" }, [el("h1", { text: t("pos") }), el("div", { class: "spacer" })]),
    search, chips, grid,
  ]);

  function drawChips() {
    clear(chips);
    const cats = db.categories.all();
    if (!cats.length) return;
    const chip = (label, val, color) => el("button", {
      class: "btn " + (catFilter === val ? "" : "ghost"),
      style: "padding:6px 12px" + (color && catFilter === val ? `;background:${color};border-color:${color}` : ""),
      onClick: () => { catFilter = val; drawChips(); drawGrid(search.value.trim()); },
    }, [label]);
    chips.append(chip("● " + t("total"), ""), ...cats.map((c) => chip((c.icon || "🏷️") + " " + c.name, c.id, c.color)));
  }

  // Sağ: sepet
  const cartItems = el("div", { class: "cart-items" });
  const totalEl = el("div", { class: "cart-total num" });
  const afterSale = () => drawGrid(search.value.trim());
  const payBtn = el("button", { class: "btn success lg block", onClick: () => checkout(refreshCart, afterSale) }, ["✓ " + t("pay") + " (Enter)"]);
  const right = el("div", { class: "card cart" }, [
    el("h3", { text: "🛒 " + t("cart") }),
    cartItems,
    el("div", { style: "border-top:1px solid var(--border);padding-top:12px;margin-top:8px" }, [
      el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-bottom:12px" }, [
        el("span", { class: "muted", text: t("total") }), totalEl,
      ]),
      payBtn,
      el("button", { class: "btn ghost block", style: "margin-top:8px", onClick: () => { cart = []; refreshCart(); } }, ["🗑 " + t("cancel")]),
    ]),
  ]);

  layout.append(left, right);
  clear(host).appendChild(layout);

  function drawGrid(filter = "") {
    clear(grid);
    const list = db.products.all().filter((p) => p.active &&
      (!catFilter || p.categoryId === catFilter) &&
      (!filter || p.name.toLowerCase().includes(filter.toLowerCase()) || (p.barcode || "").includes(filter)));
    if (!list.length) { grid.appendChild(el("p", { class: "muted", text: t("noProducts") })); return; }
    list.forEach((p) => grid.appendChild(
      el("button", { class: "prod", onClick: () => tapProduct(p) }, [
        p.image
          ? el("img", { class: "pimg", src: p.image, alt: p.name })
          : el("div", { class: "emoji", text: p.emoji || "📦" }),
        el("div", { class: "pname", text: p.name }),
        el("div", { class: "pprice", text: p.price > 0 ? money(p.price) : t("enterPrice") }),
        el("div", { class: "pstock", text: t("stock") + ": " + p.stock }),
      ])
    ));
  }

  // Fiyatı olan ürün doğrudan eklenir; fiyatı 0 olan (ör. "elma") tıklanınca fiyat sorulur.
  function tapProduct(p) {
    if (p.price > 0) { addToCart(p, p.price); return; }
    const priceInput = el("input", { class: "input num", type: "number", step: "0.01", inputmode: "decimal", style: "font-size:24px;text-align:right" });
    const c = modal({
      title: p.name + " — " + t("enterPrice"),
      body: el("div", { class: "field" }, [el("label", { text: t("price") }), priceInput]),
      actions: [
        { label: "✓ " + t("add"), kind: "success", onClick: (close) => {
          const pr = parseFloat(priceInput.value);
          if (!pr || pr <= 0) { toast(t("price") + "?", "warn"); return; }
          addToCart(p, pr); close();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
    setTimeout(() => priceInput.focus(), 60);
  }

  function refreshCart() {
    clear(cartItems);
    if (!cart.length) { cartItems.appendChild(el("p", { class: "muted", text: t("emptyCart") })); }
    cart.forEach((item) => {
      cartItems.appendChild(el("div", { class: "cart-row" }, [
        el("div", { style: "flex:1" }, [
          el("div", { style: "font-weight:700", text: item.name }),
          el("div", { class: "muted", style: "font-size:12px", text: money(item.price) }),
        ]),
        el("div", { class: "qty" }, [
          el("button", { class: "qbtn", onClick: () => changeQty(item, -1) }, ["−"]),
          el("b", { class: "num", text: String(item.qty) }),
          el("button", { class: "qbtn", onClick: () => changeQty(item, 1) }, ["+"]),
        ]),
        el("div", { class: "num", style: "width:80px;text-align:right;font-weight:700", text: money(item.price * item.qty) }),
      ]));
    });
    totalEl.textContent = money(cartTotal());
  }

  function addToCart(p, price) {
    const unit = (price != null ? price : p.price) || 0;
    const line = cart.find((c) => c.productId === p.id);
    // Stok takibi olan üründe uyarı ver ama satışı engelleme (hızlı satış akışı)
    const inCart = line ? line.qty : 0;
    if (typeof p.stock === "number" && p.stock > 0 && inCart + 1 > p.stock) {
      toast(p.name + ": " + t("outOfStock"), "warn");
    }
    if (line) { line.qty++; line.price = unit; }
    else cart.push({ productId: p.id, name: p.name, price: unit, qty: 1 });
    sound.add();
    refreshCart();
  }
  function changeQty(item, d) {
    item.qty += d;
    if (item.qty <= 0) { cart = cart.filter((c) => c !== item); sound.remove(); }
    else sound.tick();
    refreshCart();
  }

  // Barkod: tam eşleşme varsa direkt sepete
  search.addEventListener("keydown", (e) => {
    if (e.key === "Enter") {
      const val = search.value.trim();
      const exact = db.products.all().find((p) => p.barcode === val);
      if (exact) { tapProduct(exact); search.value = ""; drawGrid(""); }
      else if (cart.length) { checkout(refreshCart, afterSale); }
    }
  });
  search.addEventListener("input", () => drawGrid(search.value.trim()));

  // Klavye kısayolları (dökümandaki F1/F2/Enter)
  const keyHandler = (e) => {
    if (!document.body.contains(host)) { window.removeEventListener("keydown", keyHandler); return; }
    if (e.key === "F1") { e.preventDefault(); search.focus(); search.select(); }
    if (e.key === "F2") { e.preventDefault(); checkout(refreshCart, afterSale); }
    if (e.key === "Enter" && document.activeElement !== search && cart.length) { e.preventDefault(); checkout(refreshCart, afterSale); }
  };
  window.addEventListener("keydown", keyHandler);

  drawChips();
  drawGrid();
  refreshCart();
}

function cartTotal() { return cart.reduce((a, c) => a + c.price * c.qty, 0); }

// ---- Satış fişi yazdır (termal 80mm uyumlu; A4'te de düzgün basar) ----
export function printReceipt(sale) {
  if (!sale) return;
  const s = settings.get();
  const biz = s.business || "TUFAN 101";
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));
  const dt = new Date(sale.ts || Date.now()).toLocaleString("tr-TR");
  const items = (sale.items || []).map((it) => {
    const name = it.name || it.productName || "Ürün";
    const qty = it.qty || 1, price = it.price || 0, line = qty * price;
    return `<tr><td class="l"><span class="name">${esc(name)}</span><br><span class="q">${qty} × ${esc(money(price))}</span></td><td class="r">${esc(money(line))}</td></tr>`;
  }).join("");
  const method = sale.method === "card" ? "Kart" : sale.method === "cash" ? "Nakit" : (sale.method || "");

  // Resmi kimlik bloğu: Ayarlar > "Fiş / Resmi Bilgiler" doldurulmuşsa fişe basılır.
  // Hiçbiri girilmemişse sade bilgilendirme fişi çıkar (ad + adres + telefon).
  const official = [
    s.companyTitle ? `<div class="c muted">${esc(s.companyTitle)}</div>` : "",
    s.address ? `<div class="c muted">${esc(s.address)}</div>` : "",
    s.phone ? `<div class="c muted">Tel: ${esc(s.phone)}</div>` : "",
    (s.taxOffice || s.taxNo)
      ? `<div class="c muted">${esc([s.taxOffice, s.taxNo].filter(Boolean).join(" - "))}</div>` : "",
    s.mersis ? `<div class="c muted">MERSIS: ${esc(s.mersis)}</div>` : "",
  ].filter(Boolean).join("");
  const isOfficial = !!(s.companyTitle || s.taxOffice || s.taxNo || s.mersis);
  const footNote = s.receiptFooter
    ? esc(s.receiptFooter)
    : "Bizi tercih ettiğiniz için teşekkürler!";

  // Fiş genişliği ayarı: 58mm küçük termal, 80mm standart (varsayılan 80).
  const rw = String(s.receiptWidth) === "58" ? 58 : 80;
  const isNarrow = rw === 58;
  const winW = isNarrow ? 260 : 340;
  const bodyPad = isNarrow ? "5mm 3mm" : "6mm 4mm";
  const baseFs = isNarrow ? 11 : 12;
  const bizFs = isNarrow ? 14 : 16;
  const totFs = isNarrow ? 13 : 15;

  // Logo (Ayarlar > işletme logosu) — varsa fişin başına basılır.
  const logo = (typeof s.logo === "string" && s.logo.startsWith("data:image")) ? s.logo : "";
  // Logo boyutu (Ayarlar > Fiş): 0.5–2.0 kat (varsayılan 1).
  const logoScale = Math.max(0.5, Math.min(2, Number(s.receiptLogoScale) || 1));
  // Dijital menü QR kodu: hesabı olan işletmenin QR menü linkini fişe basar.
  // Ayarlardan kapatılabilir (receiptQr === false). CSP'de api.qrserver.com izinli.
  const acc = (typeof currentAccount === "function") ? currentAccount() : "";
  const menuLink = acc ? `${location.origin}${location.pathname}#/m/${encodeURIComponent(acc)}` : "";
  const showQr = (s.receiptQr !== false) && menuLink;
  const qrSrc = showQr ? ("https://api.qrserver.com/v1/create-qr-code/?margin=0&size=200x200&data=" + encodeURIComponent(menuLink)) : "";
  // Ürün özeti: kaç çeşit, kaç adet.
  const lineCount = (sale.items || []).length;
  const qtyTot = (sale.items || []).reduce((a, it) => a + (Number(it.qty) || 1), 0);
  const gift = Number(sale.giftUsed) || 0;
  // Alt bilgi: iletişim (girilmişse).
  const contact = [
    s.whatsapp ? "WhatsApp: " + esc(s.whatsapp) : "",
    s.instagram ? "Instagram: " + esc(s.instagram) : "",
    s.website ? esc(s.website) : "",
  ].filter(Boolean).join(" · ");

  const w = window.open("", "_blank", "width=" + winW + ",height=680");
  if (!w) { toast("Açılır pencere engellendi (fiş için izin verin)", "warn"); return; }
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Fiş</title>
    <style>
      *{box-sizing:border-box}
      body{font-family:'Segoe UI',Arial,'Helvetica Neue',sans-serif;width:${rw}mm;margin:0 auto;padding:${bodyPad};color:#000;font-size:${baseFs}px;line-height:1.35}
      .c{text-align:center}
      .logo{display:block;margin:0 auto 4px;max-width:${((isNarrow ? 34 : 46) * logoScale).toFixed(1)}mm;max-height:${((isNarrow ? 16 : 20) * logoScale).toFixed(1)}mm;object-fit:contain}
      .qr{margin:9px auto 0;text-align:center}
      .qr img{width:${isNarrow ? 26 : 30}mm;height:${isNarrow ? 26 : 30}mm;display:block;margin:0 auto}
      .qr .cap{font-size:${isNarrow ? 9 : 10}px;color:#333;margin-top:3px}
      .biz{font-size:${bizFs}px;font-weight:800;letter-spacing:.3px;margin-bottom:2px}
      .muted{color:#222;font-size:${isNarrow ? 10 : 11}px}
      .kind{display:inline-block;font-size:${isNarrow ? 10 : 11}px;font-weight:700;letter-spacing:1.5px;margin-top:6px;padding:2px 12px;border:1px solid #000;border-radius:12px}
      .meta{margin-top:6px;font-size:${isNarrow ? 10 : 11}px}
      .meta span{color:#666}
      hr{border:none;border-top:1px dashed #000;margin:7px 0}
      table{width:100%;border-collapse:collapse}
      td{padding:3px 0;vertical-align:top} td.r{text-align:right;white-space:nowrap;padding-left:8px}
      .name{font-weight:600}
      .q{color:#666;font-size:${isNarrow ? 9 : 10}px}
      .sum td{padding:2px 0}
      .tot td{font-size:${totFs}px;font-weight:800;padding:5px 0;border-top:2px solid #000;border-bottom:2px solid #000}
      .foot{margin-top:10px;text-align:center;font-size:${isNarrow ? 9 : 10}px;color:#444;line-height:1.5}
      .thanks{font-weight:700;color:#000;font-size:${isNarrow ? 10 : 11}px;margin-bottom:2px}
      @media print{@page{margin:0}body{width:${rw}mm}}
    </style></head><body>
    ${logo ? `<img class="logo" src="${logo}" alt="">` : ""}
    <div class="c biz">${esc(biz)}</div>
    ${official}
    <div class="c"><span class="kind">${isOfficial ? "SATIŞ FİŞİ" : "BİLGİLENDİRME FİŞİ"}</span></div>
    <div class="meta">
      <div><span>Tarih:</span> ${esc(dt)}</div>
      <div><span>Fiş No:</span> ${esc(String(sale.id || "").slice(-8).toUpperCase())}</div>
      ${sale.cashierName ? `<div><span>Kasiyer:</span> ${esc(sale.cashierName)}</div>` : ""}
    </div>
    <hr>
    <table>${items || `<tr><td>—</td></tr>`}</table>
    <hr>
    <div class="muted c">${lineCount} çeşit · ${qtyTot} adet</div>
    <hr>
    <table class="sum">
      ${sale.discount > 0 ? `<tr><td>Ara Toplam</td><td class="r">${esc(money(sale.subtotal || (sale.total + sale.discount)))}</td></tr>
      <tr><td>İndirim${sale.discountLabel ? " (" + esc(sale.discountLabel) + ")" : ""}</td><td class="r">- ${esc(money(sale.discount))}</td></tr>` : ""}
      <tr class="tot"><td>TOPLAM</td><td class="r">${esc(money(sale.total || 0))}</td></tr>
      ${gift > 0 ? `<tr><td>Hediye Çeki${sale.giftCode ? " (" + esc(sale.giftCode) + ")" : ""}</td><td class="r">- ${esc(money(gift))}</td></tr>` : ""}
      <tr><td>Ödeme (${esc(method)})</td><td class="r">${esc(money(sale.paid || sale.total || 0))}</td></tr>
      ${sale.change ? `<tr><td>Para Üstü</td><td class="r">${esc(money(sale.change))}</td></tr>` : ""}
    </table>
    <hr>
    ${showQr ? `<div class="qr"><img src="${qrSrc}" alt="menu"><div class="cap">📱 Menümüzü görmek için okutun</div></div>` : ""}
    <div class="foot">
      <div class="thanks">${footNote}</div>
      ${contact ? `<div>${contact}</div>` : ""}
      <div>${isOfficial ? "Bu belge bilgilendirme amaçlıdır; mali değeri yoktur." : "TUFAN 101 ile hazırlanmıştır."}</div>
    </div>
    <script>
      window.onload=function(){
        var imgs=document.images,n=imgs.length,done=0;
        function go(){try{window.print();}catch(e){}setTimeout(function(){window.close();},400);}
        if(!n)return go();
        for(var i=0;i<n;i++){var im=imgs[i];if(im.complete){if(++done===n)go();}else{im.onload=im.onerror=function(){if(++done===n)go();};}}
      };
    <\/script>
    </body></html>`);
  w.document.close();
}

function checkout(refreshCart, afterSale) {
  const subtotal = cartTotal();
  if (!subtotal) { sound.error(); toast(t("emptyCart"), "warn"); return; }

  // ---- İndirim: otomatik kampanya + manuel iskonto ----
  const auto = bestCampaign(subtotal); // { campaign, amount, label } | null
  let manual = 0;             // kasiyerin elle girdiği ek indirim (TL)
  let manualLabel = "";
  let giftUsed = 0, giftCode = ""; // hediye çeki ile karşılanan tutar
  const discountAmount = () => Math.min(subtotal, (auto ? auto.amount : 0) + manual);
  const netTotal = () => Math.max(0, Math.round((subtotal - discountAmount()) * 100) / 100);
  const payable = () => Math.max(0, Math.round((netTotal() - giftUsed) * 100) / 100); // hediye çeki sonrası ödenecek

  const discRow = el("div", { style: "display:flex;justify-content:space-between;color:var(--success);font-weight:700;margin-bottom:4px" });
  const netRow = el("div", { style: "display:flex;justify-content:space-between;font-size:20px;font-weight:800;margin-bottom:10px" });
  const giftRow = el("div", { style: "display:flex;justify-content:space-between;color:#7c3aed;font-weight:700;margin-bottom:4px" });
  const paidInput = el("input", { class: "input num", type: "number", inputmode: "decimal", value: netTotal(), style: "font-size:26px;text-align:right" });
  const changeEl = el("div", { class: "num", style: "font-size:20px;text-align:right;margin-top:6px;color:var(--success)" });
  const calc = () => { const c = (parseFloat(paidInput.value) || 0) - payable(); changeEl.textContent = t("change") + ": " + money(Math.max(0, c)); };
  const refreshTotals = () => {
    // Hediye çeki uygulandıktan SONRA indirim eklenirse, çekten satış toplamından
    // fazla düşülmesin: kullanımı güncel net toplama göre yeniden sınırla.
    if (giftUsed > 0) giftUsed = Math.min(giftUsed, netTotal());
    const d = discountAmount();
    const parts = [];
    if (auto) parts.push(auto.label);
    if (manual > 0) parts.push(manualLabel || "El indirimi");
    discRow.style.display = d > 0 ? "flex" : "none";
    clear(discRow).append(el("span", { text: "🎯 " + (parts.join(" + ") || "İndirim") }), el("span", { text: "− " + money(d) }));
    giftRow.style.display = giftUsed > 0 ? "flex" : "none";
    clear(giftRow).append(el("span", { text: "🎁 Hediye çeki (" + giftCode + ")" }), el("span", { text: "− " + money(giftUsed) }));
    clear(netRow).append(el("span", { text: giftUsed > 0 ? "Ödenecek" : t("total") }), el("span", { class: "num", text: money(payable()) }));
    paidInput.value = payable();
    calc();
  };
  paidInput.addEventListener("input", calc);

  // Elle indirim gir (yüzde veya TL)
  const manualBtn = el("button", { class: "btn ghost block", style: "margin-top:6px", onClick: () => askManual() }, ["% El ile indirim"]);

  // Hediye çeki uygula
  const giftBtn = el("button", { class: "btn ghost block", style: "margin-top:6px", onClick: () => askGift() }, ["🎁 Hediye çeki kullan"]);
  function askGift() {
    if (giftUsed > 0) { giftUsed = 0; giftCode = ""; refreshTotals(); toast("Hediye çeki kaldırıldı", "info"); return; }
    const inp = el("input", { class: "input", placeholder: "HED-XXXX-0000", style: "font-family:monospace;letter-spacing:1px;text-transform:uppercase" });
    const info = el("div", { class: "muted", style: "margin-top:6px;font-size:13px" });
    inp.addEventListener("input", () => {
      const g = findGiftcard(inp.value);
      info.textContent = g ? (g.active ? "Bakiye: " + money(g.balance || 0) : "Kart pasif") : "Kart bulunamadı";
    });
    const c2 = modal({
      title: "🎁 Hediye Çeki",
      body: el("div", {}, [el("div", { class: "field" }, [el("label", { text: "Kart kodu" }), inp, info])]),
      actions: [
        { label: "Uygula", kind: "success", onClick: (close) => {
          const g = findGiftcard(inp.value);
          if (!g) { toast("Kart bulunamadı", "warn"); return; }
          if (!g.active || (Number(g.balance) || 0) <= 0) { toast("Bu kartta kullanılabilir bakiye yok", "warn"); return; }
          giftUsed = Math.min(Number(g.balance) || 0, netTotal());
          giftCode = g.code;
          refreshTotals(); close();
          toast("Hediye çeki uygulandı • " + money(giftUsed), "success");
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
    setTimeout(() => inp.focus(), 60);
  }
  function askManual() {
    const inp = el("input", { class: "input num", type: "number", step: "0.01", inputmode: "decimal", style: "font-size:22px;text-align:right", value: "" });
    const asPct = el("input", { type: "checkbox" });
    const c2 = modal({
      title: "El ile indirim",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Miktar" }), inp]),
        el("label", { style: "display:flex;gap:8px;align-items:center;margin-top:4px" }, [asPct, el("span", { text: "Yüzde (%) olarak uygula" })]),
      ]),
      actions: [
        { label: "Uygula", kind: "success", onClick: (close) => {
          const v = parseFloat(inp.value) || 0;
          if (v <= 0) { manual = 0; manualLabel = ""; refreshTotals(); close(); return; }
          if (asPct.checked) { manual = Math.round(subtotal * (v / 100) * 100) / 100; manualLabel = "%" + v + " el indirimi"; }
          else { manual = v; manualLabel = money(v) + " el indirimi"; }
          refreshTotals(); close();
        } },
        { label: "Kaldır", kind: "ghost", onClick: (close) => { manual = 0; manualLabel = ""; refreshTotals(); close(); } },
      ],
    });
    setTimeout(() => inp.focus(), 60);
  }

  const finalize = (method, forcePrint) => {
    const total = netTotal();
    const discount = discountAmount();
    const toPay = payable();
    const paid = parseFloat(paidInput.value) || toPay;
    const user = currentUser();
    const saleId = uid();
    // Hediye çeki varsa bakiyeden düş (satış onaylandığı an)
    if (giftUsed > 0 && giftCode) {
      const r = redeemGiftcard(giftCode, giftUsed, "Satış #" + String(saleId).slice(-6).toUpperCase());
      if (!r.ok) { toast("Hediye çeki kullanılamadı: " + r.error, "error"); return; }
    }
    // Stok düş + satışı kaydet
    cart.forEach((c) => {
      const p = db.products.get(c.productId);
      if (!p) return;
      if (Array.isArray(p.bundle) && p.bundle.length) {
        // Paket/menü: bileşen ürünlerin stoğunu düş (paketin kendi stoğu takip edilmez)
        p.bundle.forEach((b) => {
          const comp = db.products.get(b.productId);
          if (comp) { comp.stock = Math.max(0, (Number(comp.stock) || 0) - (Number(b.qty) || 1) * c.qty); db.products.upsert(comp); }
        });
      } else if (Array.isArray(p.recipe) && p.recipe.length) {
        // Üretim/Reçete: mamul satılınca hammadde stoğu otomatik düşer (latte → süt+kahve)
        p.recipe.forEach((ing) => {
          const raw = db.products.get(ing.productId);
          if (raw) { raw.stock = Math.max(0, (Number(raw.stock) || 0) - (Number(ing.qty) || 0) * c.qty); db.products.upsert(raw); }
        });
        // Mamulün kendi stoğu tutuluyorsa onu da düş (sayı ise)
        if (typeof p.stock === "number") { p.stock = Math.max(0, p.stock - c.qty); db.products.upsert(p); }
      } else {
        p.stock = Math.max(0, p.stock - c.qty); db.products.upsert(p);
      }
    });
    const dLabelParts = [];
    if (auto) dLabelParts.push(auto.label);
    if (manual > 0) dLabelParts.push(manualLabel || "El indirimi");
    const saleRow = db.sales.upsert({
      id: saleId, ts: Date.now(), items: cart.map((c) => ({ ...c })),
      subtotal, discount, discountLabel: dLabelParts.join(" + "),
      giftUsed, giftCode,
      total, paid, method: giftUsed >= total ? "gift" : method, change: Math.max(0, paid - toPay),
      cashierId: user ? user.id : null, cashierName: user ? user.name : "", void: false,
      // Şube bazlı ciro için: satışı aktif şubeye etiketle (yoksa boş).
      branchId: (user && user.branchId) || settings.get().activeBranch || "",
    });
    // Entegrasyon: satış tutarı hesaba işlenir (nakit → Kasa, kart → Banka).
    try {
      ensureAccounts();
      const accId = defaultAccountId(method === "card" ? "bank" : "cash");
      // Kasa/banka hareketine satışın detayını yaz: fiş no, ürün sayısı, kasiyer, ödeme türü.
      const qtyTot = cart.reduce((a, c) => a + (Number(c.qty) || 0), 0);
      const itemsTxt = cart.slice(0, 3).map((c) => (c.name || "?") + "×" + (c.qty || 1)).join(", ") + (cart.length > 3 ? " +" + (cart.length - 3) : "");
      const noteDetail = (method === "card" ? "💳 Kart" : "💵 Nakit") + " satış · Fiş #" + String(saleId).slice(-6).toUpperCase()
        + " · " + qtyTot + " ürün" + (itemsTxt ? " (" + itemsTxt + ")" : "")
        + (user && user.name ? " · " + user.name : "");
      // Kasaya/bankaya yalnızca hediye çeki DIŞINDAKİ ödenen kısım işlenir.
      if (accId && toPay > 0) postAccountMove({ accountId: accId, dir: "in", amount: toPay, source: "sale", refId: saleId, note: noteDetail + (giftUsed > 0 ? " · 🎁 " + money(giftUsed) : ""), party: "POS" });
    } catch {}
    sound.sale();
    toast(t("saleDone") + " • " + money(total), "success");
    cart = []; refreshCart();
    // Anlık stok düşümü ekranda görünsün: ürün ızgarasını yeniden çiz.
    if (typeof afterSale === "function") { try { afterSale(); } catch {} }
    close();
    // Fiş yazdır: kullanıcı "Öde + Fiş" dediyse ya da ayardan otomatik açıksa.
    if (forcePrint || settings.get().autoReceipt) { try { printReceipt(saleRow); } catch {} }
  };

  var close = modal({
    title: t("pay") + " — " + money(subtotal),
    body: el("div", {}, [
      el("div", { style: "display:flex;justify-content:space-between;color:var(--muted);margin-bottom:4px" }, [
        el("span", { text: "Ara toplam" }), el("span", { class: "num", text: money(subtotal) }),
      ]),
      discRow,
      giftRow,
      netRow,
      el("div", { style: "display:flex;gap:8px" }, [manualBtn, giftBtn]),
      el("div", { class: "field", style: "margin-top:10px" }, [el("label", { text: t("paid") }), paidInput, changeEl]),
    ]),
    actions: [
      { label: "💵 " + t("cash"), kind: "success", onClick: () => finalize("cash") },
      { label: "💳 " + t("card"), kind: "success", onClick: () => finalize("card") },
      { label: "🧾 Nakit + Fiş", kind: "", onClick: () => finalize("cash", true) },
      { label: t("cancel"), kind: "ghost" },
    ],
  });
  refreshTotals();
}
