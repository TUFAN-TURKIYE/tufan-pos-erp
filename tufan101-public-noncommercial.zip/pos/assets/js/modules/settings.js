// Ayarlar — İşletme bilgileri, Dil (mod-20), Tema (mod-01), Erişilebilirlik (mod-19), Kurulum (mod-16/09)
import { el, clear, toast, modal } from "../core/ui.js";
import { t, langs, getLang, setLang } from "../core/i18n.js";
import { settings, db, uid, wipeAllData, currentAccount, exportData, importData, backupSummary } from "../core/store.js";
import { canInstall, doInstall } from "../core/nav.js";
import { SECTORS, searchSectors, quickProductsFor } from "../core/sectors.js";
import { isBoss } from "./boss.js";

const LANG_LABEL = { tr: "🇹🇷 Türkçe", en: "🇬🇧 English", de: "🇩🇪 Deutsch", ru: "🇷🇺 Русский" };
const CURRENCIES = ["₺", "$", "€", "£", "₽"];

export function renderSettings(host, ctx) {
  const s = settings.get();
  const head = el("div", { class: "view-head" }, [el("h1", { text: t("settings") })]);
  const grid = el("div", { class: "grid", style: "grid-template-columns:repeat(auto-fit,minmax(300px,1fr));max-width:1000px" });

  // ---- İşletme Bilgileri (adı müşteri kendisi girer) ----
  const biz = el("input", { class: "input", value: s.business || "" });
  const phone = el("input", { class: "input", inputmode: "tel", value: s.phone || "", placeholder: "05xx xxx xx xx" });
  const whatsapp = el("input", { class: "input", inputmode: "tel", value: s.whatsapp || "", placeholder: "905xx xxx xx xx" });
  const address = el("input", { class: "input", value: s.address || "", placeholder: t("address") });
  const instagram = el("input", { class: "input", value: s.instagram || "", placeholder: "@kullaniciadi" });
  const website = el("input", { class: "input", value: s.website || "", placeholder: "https://siteadresiniz.com" });
  const curSel = el("select", { class: "input" }, CURRENCIES.map((c) => el("option", { value: c, ...(c === (s.currency || "₺") ? { selected: true } : {}) }, [c])));
  grid.appendChild(card("🏪 " + t("businessInfo"), [
    field(t("business"), biz),
    el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [field(t("phone"), phone), field(t("currency"), curSel)]),
    field("💬 WhatsApp (QR menüde görünür)", whatsapp),
    field(t("address"), address),
    el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [field(t("instagram"), instagram), field(t("website"), website)]),
    el("button", { class: "btn success", style: "margin-top:6px", onClick: () => {
      settings.set({
        business: biz.value.trim(), phone: phone.value.trim(), whatsapp: whatsapp.value.trim(),
        address: address.value.trim(),
        instagram: instagram.value.trim(), website: website.value.trim(), currency: curSel.value,
      });
      toast(t("save"), "success");
    } }, [t("save")]),
  ]));

  // ---- Fiş / Resmi Bilgiler (satış fişinde görünür) ----
  // Doldurulan alanlar fişe basılır → resmi görünüm. Boş bırakılırsa fiş sade
  // "bilgilendirme fişi" olarak çıkar (ad + adres + telefon).
  const rcTitle   = el("input", { class: "input", value: s.companyTitle || "", placeholder: "Örn: Tufan Market Gıda San. Tic. Ltd. Şti." });
  const rcTaxOff  = el("input", { class: "input", value: s.taxOffice || "", placeholder: "Örn: Balıkesir V.D." });
  const rcTaxNo   = el("input", { class: "input", inputmode: "numeric", value: s.taxNo || "", placeholder: "Vergi No / TC Kimlik No" });
  const rcMersis  = el("input", { class: "input", inputmode: "numeric", value: s.mersis || "", placeholder: "MERSIS No (16 hane)" });
  const rcFoot    = el("input", { class: "input", value: s.receiptFooter || "", placeholder: "Örn: Bizi tercih ettiğiniz için teşekkürler" });
  grid.appendChild(card("🧾 Fiş / Resmi Bilgiler", [
    el("p", { class: "muted", style: "font-size:13px", text: "Bu alanlar satış fişinin üstüne basılır. Doldurursanız fiş resmi görünür; boş bırakırsanız sade bilgilendirme fişi çıkar. (Adres ve telefon 'İşletme Bilgileri'nden alınır.)" }),
    field("Resmi Ünvan", rcTitle),
    el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [field("Vergi Dairesi", rcTaxOff), field("Vergi / TC No", rcTaxNo)]),
    field("MERSIS No", rcMersis),
    field("Fiş Alt Notu", rcFoot),
    el("button", { class: "btn success", style: "margin-top:6px", onClick: () => {
      settings.set({
        companyTitle: rcTitle.value.trim(), taxOffice: rcTaxOff.value.trim(),
        taxNo: rcTaxNo.value.trim(), mersis: rcMersis.value.trim(),
        receiptFooter: rcFoot.value.trim(),
      });
      toast(t("save"), "success");
    } }, [t("save")]),
  ]));

  // ---- İşletme Logosu (QR menüde ve girişte görünür) ----
  const logoPreview = el("img", {
    alt: "Logo",
    style: "width:88px;height:88px;border-radius:16px;object-fit:cover;border:1px solid var(--border);" + (s.logo ? "" : "display:none"),
    ...(s.logo ? { src: s.logo } : {}),
  });
  const logoEmpty = el("div", { class: "muted", style: "font-size:13px" + (s.logo ? ";display:none" : ""), text: "Henüz logo eklenmedi" });
  const logoFile = el("input", { type: "file", accept: "image/*", style: "display:none" });
  let logoData = s.logo || "";       // seçilen/mevcut logo (kaydet'e basınca yazılır)
  // Herhangi bir boyuttaki görseli otomatik küçült (en fazla 320px, JPEG) → asla reddedilmez
  function compressLogo(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const img = new Image();
        img.onload = () => {
          const max = 320;
          let { width: w, height: h } = img;
          if (w > h && w > max) { h = Math.round(h * max / w); w = max; }
          else if (h >= w && h > max) { w = Math.round(w * max / h); h = max; }
          const c = document.createElement("canvas"); c.width = w; c.height = h;
          c.getContext("2d").drawImage(img, 0, 0, w, h);
          try { resolve(c.toDataURL("image/jpeg", 0.85)); }
          catch { resolve(String(reader.result || "")); }
        };
        img.onerror = reject;
        img.src = String(reader.result || "");
      };
      reader.onerror = reject;
      reader.readAsDataURL(file);
    });
  }
  logoFile.addEventListener("change", async () => {
    const f = logoFile.files && logoFile.files[0];
    if (!f) return;
    try {
      logoData = await compressLogo(f);
      logoPreview.src = logoData; logoPreview.style.display = "";
      logoEmpty.style.display = "none";
      toast("Görsel hazır — 'Logoyu Kaydet' ile onaylayın.", "success");
    } catch { toast("Görsel okunamadı, başka bir dosya deneyin.", "error"); }
    logoFile.value = "";
  });
  grid.appendChild(card("🖼 İşletme Logosu", [
    el("p", { class: "muted", text: "Logonuz QR menüde ve giriş ekranında görünür. (Her boyut olur — otomatik küçültülür.)" }),
    el("div", { style: "display:flex;align-items:center;gap:14px;margin:6px 0" }, [logoPreview, logoEmpty]),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [
      el("button", { class: "btn", onClick: () => logoFile.click() }, ["⬆ Görsel Seç"]),
      el("button", { class: "btn success", onClick: () => {
        if (!logoData) { toast("Önce bir görsel seçin.", "warn"); return; }
        settings.set({ logo: logoData });
        logoPreview.src = logoData; logoPreview.style.display = "";
        logoEmpty.style.display = "none";
        toast("Logo kaydedildi ✔", "success");
      } }, ["💾 Logoyu Kaydet"]),
      el("button", { class: "btn ghost", onClick: () => {
        logoData = "";
        settings.set({ logo: "" });
        logoPreview.style.display = "none"; logoEmpty.style.display = "";
        toast("Logo kaldırıldı", "success");
      } }, ["🗑 Kaldır"]),
    ]),
    logoFile,
  ]));

  // ---- Dil (mod-20) — düzeltildi: setLang çağrılıyor ----
  grid.appendChild(card("🌐 " + t("language"), [
    el("div", { style: "display:grid;gap:8px" }, langs().map((l) =>
      el("button", { class: "btn " + (getLang() === l ? "" : "ghost"), onClick: () => {
        settings.set({ lang: l });
        setLang(l);            // anlık uygula (langchange olayını tetikler)
        toast(t("save"), "success");
      } }, [LANG_LABEL[l] || l])
    )),
  ]));

  // ---- Sektör (100 sektör veritabanı) ----
  const sectorNow = el("b", { style: "color:var(--primary)", text: s.sector || "—" });
  grid.appendChild(card("🏭 " + t("sector"), [
    el("p", { class: "muted", text: "İşletmenizin sektörünü seçin; hazır ürün şablonu içe aktarabilirsiniz." }),
    el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:8px" }, [el("span", { class: "muted", text: "Seçili:" }), sectorNow]),
    el("button", { class: "btn", onClick: () => openSectorPicker((name) => { sectorNow.textContent = name; }) }, ["🏭 " + t("chooseSector")]),
  ]));

  // ---- Tema kaldırıldı: uygulama her zaman aydınlık (beyaz) temada çalışır. ----

  // ---- Erişilebilirlik (mod-19) — yazı boyutu ----
  const scaleVal = el("b", { class: "num", text: Math.round((s.scale || 1) * 100) + "%" });
  const range = el("input", { type: "range", min: "0.85", max: "1.6", step: "0.05", value: s.scale || 1, style: "width:100%" });
  range.addEventListener("input", () => {
    document.documentElement.style.setProperty("--scale", range.value);
    scaleVal.textContent = Math.round(parseFloat(range.value) * 100) + "%";
  });
  range.addEventListener("change", () => { settings.set({ scale: parseFloat(range.value) }); });
  grid.appendChild(card("🔎 " + t("access"), [
    el("div", { style: "display:flex;justify-content:space-between;margin-bottom:8px" }, [el("span", { class: "muted", text: t("fontSize") }), scaleVal]),
    range,
  ]));

  // ---- PWA kurulum (mod-16 / mod-09) ----
  grid.appendChild(card("📲 " + t("installApp"), [
    el("p", { class: "muted", text: "Uygulamayı cihaza kurarak tam ekran ve çevrimdışı kullanın." }),
    el("button", { class: "btn", onClick: () => doInstall() }, ["⬇ " + t("installApp")]),
  ]));

  // ---- Resmi / Fatura Bilgileri + GS1 Barkodu ----
  const legalTitle = el("input", { class: "input", value: s.legalTitle || "", placeholder: "Resmi ünvan (fatura başlığı)" });
  const taxNo = el("input", { class: "input", inputmode: "numeric", value: s.taxNo || "", placeholder: "VKN (10) / TCKN (11)" });
  const taxOffice = el("input", { class: "input", value: s.taxOffice || "", placeholder: "Vergi dairesi" });
  const mersis = el("input", { class: "input", inputmode: "numeric", value: s.mersis || "", placeholder: "MERSİS No (opsiyonel)" });
  const eInvoice = toggleRow("📄 e-Fatura mükellefiyim", "Faturalarım GİB e-Fatura olarak düzenlenir (entegratör/anahtar gerekir).", s.eInvoice);
  const eArchive = toggleRow("🗄️ e-Arşiv fatura kesiyorum", "Nihai tüketiciye e-Arşiv fatura.", s.eArchive);
  const gs1 = toggleRow("🌍 GS1 Barkodu (EAN/GTIN) kullan", "Açıkken üründe resmi GS1 barkodu alanı görünür; market/perakende için önerilir. Kapalıyken dahili barkod kullanılır.", s.gs1Enabled);
  grid.appendChild(card("🧾 Resmi / Fatura Bilgileri", [
    el("p", { class: "muted", style: "font-size:12.5px", text: "Devlet/GİB uyumu için resmi bilgiler. e-Fatura/e-Arşiv'in canlı kesimi için entegratör (ör. resmi GİB özel entegratörü) ve anahtar gerekir; bilgiler burada saklanır." }),
    field("Resmi Ünvan", legalTitle),
    el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [field("VKN / TCKN", taxNo), field("Vergi Dairesi", taxOffice)]),
    field("MERSİS No", mersis),
    eInvoice.wrap, eArchive.wrap,
    el("hr", { style: "border:none;border-top:1px solid var(--border);margin:8px 0" }),
    el("div", { style: "font-weight:700", text: "Barkod Sistemi" }),
    gs1.wrap,
    el("button", { class: "btn success", style: "margin-top:6px", onClick: () => {
      settings.set({
        legalTitle: legalTitle.value.trim(), taxNo: taxNo.value.trim(), taxOffice: taxOffice.value.trim(),
        mersis: mersis.value.trim(), eInvoice: eInvoice.input.checked, eArchive: eArchive.input.checked,
        gs1Enabled: gs1.input.checked,
      });
      toast(t("save"), "success");
    } }, [t("save")]),
  ]));

  // ---- Yedek Parça / Otomotiv alanları (opsiyonel — varsayılan KAPALI) ----
  const autoParts = toggleRow("🔧 Yedek parça alanlarını göster", "Otomotiv/yedek parça satıcıları için: ürün kartında OEM No, Çapraz Referans, Araç Uyumu ve Raf alanları görünür ve CSV dışa aktarımına eklenir. Market/kafe/genel perakende için KAPALI bırakın.", s.autoParts === true);
  autoParts.input.addEventListener("change", () => {
    settings.set({ autoParts: autoParts.input.checked });
    toast(autoParts.input.checked ? "Yedek parça alanları açık ✔" : "Yedek parça alanları kapalı", "success");
  });
  grid.appendChild(card("🔧 Sektör / Ürün Alanları", [
    el("p", { class: "muted", style: "font-size:13px", text: "Ürün kartındaki ek alanları işletmenize göre açıp kapatın. Varsayılan olarak kapalıdır." }),
    autoParts.wrap,
  ]));

  // ---- Süper Admin ipucu — YALNIZCA PATRON (doruk) görür ----
  // Diğer işletme sahipleri/kullanıcılar bu kartı ve kısayol ipucunu göremez.
  if (isBoss()) {
    grid.appendChild(card("🛡️ Merkez Yönetim", [
      el("p", { class: "muted", text: "Süper Admin paneline gizli kısayol ile ulaşılır: Ctrl+Shift+D" }),
    ]));
  }

  // ---- Veri Yedekleme: Dışa Aktar / İçe Al (yerel .json yedeği) ----
  const importFile = el("input", { type: "file", accept: ".json,application/json", style: "display:none" });
  importFile.addEventListener("change", () => {
    const f = importFile.files && importFile.files[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => {
      let obj = null;
      try { obj = JSON.parse(String(reader.result || "")); }
      catch { toast("Dosya okunamadı — geçerli bir yedek (.json) seçin.", "error"); return; }
      askImportBackup(obj);
    };
    reader.onerror = () => toast("Dosya okunamadı.", "error");
    reader.readAsText(f);
    importFile.value = "";
  });
  grid.appendChild(card("💾 Veri Yedekleme", [
    el("p", { class: "muted", style: "font-size:13px", text: "Tüm işletme verinizi (ürünler, satışlar, gelir/gider, müşteriler, stok, cari, personel, ayarlar…) bilgisayarınıza .json dosyası olarak indirin. Başka bir cihaza taşımak veya güvenli yedek almak için kullanın." }),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:6px" }, [
      el("button", { class: "btn success", onClick: () => doExportBackup() }, ["⬇ Dışa Aktar (Yedek İndir)"]),
      el("button", { class: "btn", onClick: () => importFile.click() }, ["⬆ İçe Al (Yedekten Yükle)"]),
    ]),
    importFile,
  ]));

  // ---- Excel / CSV Dışa Aktarma (muhasebe / vergi / analiz için) ----
  grid.appendChild(card("📊 Excel / CSV Dışa Aktar", [
    el("p", { class: "muted", style: "font-size:13px", text: "Listelerinizi Excel'de açılabilen .csv dosyası olarak indirin. Türkçe karakter ve noktalı virgül (;) ayraç uyumludur — çift tıklayınca doğrudan Excel'de açılır." }),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:6px" }, [
      el("button", { class: "btn ghost", onClick: () => exportProductsCSV() }, ["📦 Ürünler"]),
      el("button", { class: "btn ghost", onClick: () => exportSalesCSV() }, ["🧾 Satışlar"]),
      el("button", { class: "btn ghost", onClick: () => exportTxnsCSV() }, ["💰 Gelir/Gider"]),
      el("button", { class: "btn ghost", onClick: () => exportCustomersCSV() }, ["👤 Müşteriler"]),
      el("button", { class: "btn ghost", onClick: () => exportStockCSV() }, ["📊 Stok Durumu"]),
    ]),
  ]));

  // ---- Fiş / Yazdırma ayarları ----
  const autoReceipt = toggleRow("🧾 Satıştan sonra fişi otomatik yazdır", "Her satış tamamlandığında yazdırma penceresi otomatik açılır. Kapalıyken ödeme ekranındaki 'Nakit + Fiş' düğmesiyle elle yazdırabilirsiniz.", s.autoReceipt);
  autoReceipt.input.addEventListener("change", () => {
    settings.set({ autoReceipt: autoReceipt.input.checked });
    toast(autoReceipt.input.checked ? "Otomatik fiş açık ✔" : "Otomatik fiş kapalı", "success");
  });
  // Fiş genişliği: termal yazıcı 58mm mi 80mm mi? Fiş çıktısı buna göre ölçeklenir.
  const widthSel = el("select", { class: "input" }, [
    el("option", { value: "80", ...((s.receiptWidth || "80") === "80" ? { selected: true } : {}) }, ["80 mm (standart termal)"]),
    el("option", { value: "58", ...(String(s.receiptWidth) === "58" ? { selected: true } : {}) }, ["58 mm (küçük termal / mobil)"]),
  ]);
  widthSel.addEventListener("change", () => {
    settings.set({ receiptWidth: widthSel.value });
    toast("Fiş genişliği: " + widthSel.value + " mm ✔", "success");
  });
  // Fiş logo boyutu: fişin başındaki işletme logosunun büyüklüğü.
  const logoScaleSel = el("select", { class: "input" }, [["0.7", "Küçük"], ["1", "Normal"], ["1.3", "Büyük"], ["1.6", "Çok Büyük"]]
    .map(([v, lbl]) => el("option", { value: v, ...((String(s.receiptLogoScale ?? "1") === v) ? { selected: true } : {}) }, [lbl])));
  logoScaleSel.addEventListener("change", () => {
    settings.set({ receiptLogoScale: Number(logoScaleSel.value) });
    toast("Fiş logo boyutu güncellendi ✔", "success");
  });
  // Fişe dijital menü QR kodu ekle (bulut hesabı varsa). Varsayılan açık.
  const qrToggle = toggleRow("📱 Fişe dijital menü QR kodu ekle", "Fişin altına, müşteri okutunca dijital menünüzü açan bir QR kod basılır. Yalnızca bulut hesabı/giriş varsa çalışır.", s.receiptQr !== false);
  qrToggle.input.addEventListener("change", () => {
    settings.set({ receiptQr: qrToggle.input.checked });
    toast(qrToggle.input.checked ? "Fiş QR kodu açık ✔" : "Fiş QR kodu kapalı", "success");
  });
  grid.appendChild(card("🖨 Fiş / Yazdırma", [
    el("p", { class: "muted", style: "font-size:13px", text: "Satış fişi termal yazıcıya ve normal A4 yazıcıya uyumludur. İşletme adı, adres ve telefon fişte otomatik görünür." }),
    field("📏 Fiş Genişliği (termal yazıcı)", widthSel),
    field("🖼 Fiş Logo Boyutu", logoScaleSel),
    autoReceipt.wrap,
    qrToggle.wrap,
  ]));

  // ---- Tehlikeli Bölge: Tüm Verileri Sil (yalnızca giriş yapan hesaba özel) ----
  const dangerCard = el("div", {
    class: "card",
    style: "border:1px solid var(--danger,#ef4444);background:rgba(239,68,68,.05)",
  }, [
    el("div", { style: "display:flex;align-items:center;gap:8px;margin-bottom:6px" }, [
      el("span", { style: "font-size:20px", text: "⚠️" }),
      el("h3", { style: "margin:0;color:var(--danger,#ef4444)", text: "Tüm Verilerimi Sil" }),
    ]),
    el("p", { class: "muted", style: "font-size:13px;margin:4px 0 10px", text: "Yalnızca bu hesabın (" + (currentAccount() || "mevcut") + ") verileri silinir: ürünler, satışlar, gelir/gider, müşteriler, stok, cari... Diğer işletmeler/kullanıcılar etkilenmez. İşletme ayarların (ad, logo) ve girişin korunur. Bu işlem GERİ ALINAMAZ." }),
    el("button", { class: "btn danger", onClick: () => confirmWipeSettings() }, ["🗑️ Verilerimi Sıfırla"]),
  ]);
  grid.appendChild(dangerCard);

  clear(host).append(head, grid, el("p", { class: "owner-sign", style: "margin-top:22px", text: "TUFAN 101 • © Balıkesir / Doruk Tufan" }));
}

// "SIL" yazarak onay iste → yalnızca giriş yapan hesabın verisini temizle
function confirmWipeSettings() {
  const input = el("input", {
    class: "input",
    placeholder: "SIL",
    style: "margin-top:10px;text-align:center;font-weight:700;letter-spacing:2px",
    autocomplete: "off",
  });
  modal({
    title: "⚠️ Verilerinizi silmek üzeresiniz",
    body: el("div", {}, [
      el("p", { text: "Bu hesabın (" + (currentAccount() || "mevcut") + ") tüm işletme kayıtları kalıcı olarak silinecek ve GERİ ALINAMAZ." }),
      el("p", { class: "muted", text: "Onaylamak için aşağıya büyük harflerle SIL yazın." }),
      input,
    ]),
    actions: [
      { label: "Vazgeç", kind: "ghost" },
      { label: "Kalıcı Olarak Sil", kind: "danger", onClick: async (close) => {
        if ((input.value || "").trim().toUpperCase() !== "SIL") { toast("Onay için SIL yazmalısınız.", "error"); return; }
        close();
        toast("Verileriniz siliniyor…", "");
        try {
          await wipeAllData();
          toast("✓ Verileriniz silindi.", "success");
          setTimeout(() => location.reload(), 900);
        } catch (e) {
          toast("Silme sırasında hata oluştu.", "error");
        }
      } },
    ],
  });
}

// Tüm veriyi .json dosyası olarak indir
function doExportBackup() {
  try {
    const payload = exportData();
    const sum = backupSummary(payload);
    const json = JSON.stringify(payload, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const d = new Date();
    const pad = (n) => String(n).padStart(2, "0");
    const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}`;
    const acc = (currentAccount() || "tufan101").replace(/[^a-z0-9_\-.]/gi, "");
    const a = el("a", { href: url, download: `tufan101-yedek-${acc}-${stamp}.json` });
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    toast(`Yedek indirildi ✔ (${sum.total} kayıt)`, "success");
  } catch (e) {
    toast("Yedek oluşturulamadı.", "error");
  }
}

// ============================================================
//  CSV DIŞA AKTARMA — Excel (TR) uyumlu: BOM + ; ayraç + CRLF
// ============================================================
function csvCell(v) {
  v = (v == null) ? "" : String(v);
  if (/[";\n\r]/.test(v)) v = '"' + v.replace(/"/g, '""') + '"';
  return v;
}
function buildCSV(headers, rows) {
  const head = headers.map(csvCell).join(";");
  const body = rows.map((r) => r.map(csvCell).join(";")).join("\r\n");
  return "﻿" + head + "\r\n" + body; // ﻿ = UTF-8 BOM (Excel Türkçe karakter uyumu)
}
function downloadCSV(baseName, csv) {
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const d = new Date();
  const pad = (n) => String(n).padStart(2, "0");
  const stamp = `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const a = el("a", { href: url, download: `${baseName}-${stamp}.csv` });
  document.body.appendChild(a); a.click(); a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 4000);
}
function csvDate(ts) {
  if (!ts) return "";
  const d = new Date(ts); const pad = (n) => String(n).padStart(2, "0");
  return `${pad(d.getDate())}.${pad(d.getMonth() + 1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
function csvNum(n) { return (Number(n) || 0).toFixed(2).replace(".", ","); } // TR ondalık ayracı: virgül

function exportProductsCSV() {
  const cats = new Map(db.categories.all().map((c) => [c.id, c.name]));
  const auto = settings.get().autoParts === true;
  const headers = ["Ürün Adı", "Kategori", "Fiyat", "Maliyet", "Stok", "Min. Stok", "Birim", "Barkod", "GTIN", "Durum"];
  if (auto) headers.push("OEM No", "Çapraz Referans", "Araç Uyumu", "Raf");
  const rows = db.products.all().map((p) => {
    const r = [
      p.name || "", cats.get(p.categoryId) || "", csvNum(p.price), csvNum(p.cost),
      p.stock ?? 0, p.minStock ?? 0, p.unit || "", p.barcode || "", p.gtin || "",
      (p.active === false ? "Pasif" : "Aktif"),
    ];
    if (auto) r.push(p.oemNo || "", p.crossRef || "", p.vehicleFit || "", p.shelf || "");
    return r;
  });
  if (!rows.length) { toast("Aktarılacak ürün yok.", "warn"); return; }
  downloadCSV("tufan101-urunler", buildCSV(headers, rows));
  toast(`${rows.length} ürün aktarıldı ✔`, "success");
}
function exportSalesCSV() {
  const rows = db.sales.all().sort((a, b) => (b.ts || 0) - (a.ts || 0)).map((s) => [
    csvDate(s.ts), s.id || "", (s.items ? s.items.length : 0), csvNum(s.total), csvNum(s.paid),
    (s.method === "card" ? "Kart" : s.method === "cash" ? "Nakit" : s.method || ""),
    s.cashierName || "", (s.void ? "İPTAL" : "Geçerli"),
  ]);
  if (!rows.length) { toast("Aktarılacak satış yok.", "warn"); return; }
  downloadCSV("tufan101-satislar", buildCSV(["Tarih", "Fiş No", "Ürün Adedi", "Toplam", "Ödenen", "Ödeme", "Kasiyer", "Durum"], rows));
  toast(`${rows.length} satış aktarıldı ✔`, "success");
}
function exportTxnsCSV() {
  const rows = db.txns.all().sort((a, b) => (b.ts || 0) - (a.ts || 0)).map((x) => [
    csvDate(x.ts), (x.type === "income" ? "Gelir" : "Gider"), csvNum(x.amount),
    x.category || "", x.method || "", x.note || "",
  ]);
  if (!rows.length) { toast("Aktarılacak kayıt yok.", "warn"); return; }
  downloadCSV("tufan101-gelir-gider", buildCSV(["Tarih", "Tür", "Tutar", "Kategori", "Ödeme", "Açıklama"], rows));
  toast(`${rows.length} kayıt aktarıldı ✔`, "success");
}
function exportCustomersCSV() {
  const rows = db.customers.all().map((c) => [
    (c.name || "") + (c.surname ? " " + c.surname : ""), c.title || "", c.phone || "", c.taxId || "",
  ]);
  if (!rows.length) { toast("Aktarılacak müşteri yok.", "warn"); return; }
  downloadCSV("tufan101-musteriler", buildCSV(["Ad Soyad", "Ünvan", "Telefon", "VKN/TCKN"], rows));
  toast(`${rows.length} müşteri aktarıldı ✔`, "success");
}
function exportStockCSV() {
  const cats = new Map(db.categories.all().map((c) => [c.id, c.name]));
  const rows = db.products.all().map((p) => {
    const stock = p.stock ?? 0, min = p.minStock ?? 0;
    const durum = stock <= 0 ? "TÜKENDİ" : (stock <= min ? "KRİTİK" : "Yeterli");
    return [p.name || "", cats.get(p.categoryId) || "", stock, min, csvNum(p.cost), csvNum((Number(p.cost) || 0) * stock), durum];
  });
  if (!rows.length) { toast("Ürün yok.", "warn"); return; }
  downloadCSV("tufan101-stok-durumu", buildCSV(["Ürün", "Kategori", "Stok", "Min. Stok", "Birim Maliyet", "Stok Değeri", "Durum"], rows));
  toast(`${rows.length} ürün aktarıldı ✔`, "success");
}

// Yedek dosyası seçilince: özet göster + birleştir / üzerine yaz seçtir
function askImportBackup(obj) {
  const sum = backupSummary(obj);
  if (!sum.total && !sum.hasSettings) {
    toast("Bu dosyada içe alınacak veri bulunamadı.", "error");
    return;
  }
  const rows = Object.entries(sum.tables).sort((a, b) => b[1] - a[1]);
  const meta = (obj && obj._exportedAt) ? new Date(obj._exportedAt).toLocaleString("tr-TR") : "";
  modal({
    title: "⬆ Yedeği İçe Al",
    body: el("div", {}, [
      meta ? el("p", { class: "muted", style: "font-size:13px", text: "Yedek tarihi: " + meta + (obj._account ? "  •  Hesap: " + obj._account : "") }) : el("span"),
      el("p", { text: `Bu yedekte toplam ${sum.total} kayıt var:` }),
      el("ul", { style: "margin:6px 0 10px;padding-left:18px;color:var(--muted);font-size:13px;max-height:32vh;overflow:auto" },
        rows.map(([k, v]) => el("li", { text: `${TABLE_LABEL[k] || k}: ${v}` }))
          .concat(sum.hasSettings ? [el("li", { text: "İşletme ayarları" })] : [])),
      el("p", { class: "muted", style: "font-size:12.5px", text: "• Birleştir: mevcut verinle karşılaştırıp yalnızca daha yeni/eksik kayıtları ekler (güvenli). • Üzerine Yaz: mevcut veriyi yedekteki ile tamamen değiştirir." }),
    ]),
    actions: [
      { label: "Vazgeç", kind: "ghost" },
      { label: "🔁 Üzerine Yaz", kind: "danger", onClick: (close) => { close(); confirmReplaceImport(obj); } },
      { label: "➕ Birleştir", kind: "success", onClick: (close) => { runImport(obj, "merge"); close(); } },
    ],
  });
}

// "Üzerine yaz" yıkıcı bir işlem — ekstra onay iste
function confirmReplaceImport(obj) {
  modal({
    title: "⚠️ Mevcut verinin üzerine yazılacak",
    body: el("div", {}, [
      el("p", { text: "Bu işlem cihazdaki mevcut kayıtları yedektekiyle DEĞİŞTİRİR. Yedekte olmayan güncel kayıtlarınız kaybolabilir." }),
      el("p", { class: "muted", text: "Emin değilseniz 'Birleştir' seçeneğini kullanın." }),
    ]),
    actions: [
      { label: "Vazgeç", kind: "ghost" },
      { label: "Evet, Üzerine Yaz", kind: "danger", onClick: (close) => { runImport(obj, "replace"); close(); } },
    ],
  });
}

function runImport(obj, mode) {
  try {
    const res = importData(obj, mode);
    if (!res.ok) { toast(res.error || "İçe alma başarısız.", "error"); return; }
    toast("Yedek yüklendi ✔ Sayfa yenileniyor…", "success");
    setTimeout(() => location.reload(), 900);
  } catch (e) {
    toast("İçe alma sırasında hata oluştu.", "error");
  }
}

// Tablo teknik adlarını kullanıcı dostu etiketlere çevir (içe alma özetinde gösterilir)
const TABLE_LABEL = {
  products: "Ürünler", categories: "Kategoriler", sales: "Satışlar", txns: "Gelir/Gider",
  customers: "Müşteriler", cariEntries: "Cari hareketler", shifts: "Vardiyalar", staff: "Personel",
  orders: "Siparişler", properties: "İlanlar/Emlak", suppliers: "Tedarikçiler", branches: "Şubeler",
  appointments: "Randevular", productions: "Üretim", notifications: "Bildirimler", loyalty: "Sadakat",
  couriers: "Kuryeler", approvals: "Onaylar", invoices: "Faturalar", contracts: "Sözleşmeler",
  attendance: "Devam/Puantaj", leaves: "İzinler", stockMoves: "Stok hareketleri", debts: "Borçlar",
  accounts: "Kasa/Banka", accountMoves: "Kasa hareketleri", supplierEntries: "Tedarikçi cari",
};

function openSectorPicker(onSaved) {
  const cur = settings.get().sector || "";
  const search = el("input", { class: "input", placeholder: "Sektör ara (örn: restoran, emlak, arıcılık)…", autofocus: true });
  const grid = el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:8px;max-height:44vh;overflow:auto;margin-top:10px;padding:2px" });
  let chosen = cur;

  function paint(list) {
    clear(grid);
    if (!list.length) { grid.appendChild(el("p", { class: "muted", text: "Eşleşme yok." })); return; }
    list.forEach((name) => {
      const b = el("button", {
        class: "btn " + (name === chosen ? "success" : "ghost"),
        style: "text-align:left;justify-content:flex-start;font-size:13px",
        onClick: () => { chosen = name; paint(list); },
      }, [name]);
      grid.appendChild(b);
    });
  }
  search.addEventListener("input", () => paint(searchSectors(search.value)));
  paint(SECTORS);

  modal({
    title: "🏭 " + t("chooseSector") + " (100 Sektör)",
    body: el("div", {}, [search, grid]),
    actions: [
      { label: "💾 " + t("save"), kind: "success", onClick: (close) => {
        if (!chosen) { toast("Bir sektör seçin", "warn"); return; }
        settings.set({ sector: chosen });
        onSaved && onSaved(chosen);
        const qp = quickProductsFor(chosen);
        close();
        if (qp.length) askImportProducts(chosen, qp);
        else toast("Sektör kaydedildi: " + chosen, "success");
      } },
      { label: t("cancel"), kind: "ghost" },
    ],
  });
}

function askImportProducts(sector, products) {
  modal({
    title: "📦 Hazır Ürünler",
    body: el("div", {}, [
      el("p", { text: `"${sector}" sektörü için ${products.length} hazır ürün bulundu. Stok listenize eklensin mi?` }),
      el("ul", { style: "margin:8px 0 0;padding-left:18px;color:var(--muted);font-size:13px" },
        products.map((p) => el("li", { text: `${p.name} — ${p.price} (${p.cat})` }))),
    ]),
    actions: [
      { label: "✅ Evet, ekle", kind: "success", onClick: (close) => {
        const existingCats = db.categories.all();
        products.forEach((p) => {
          if (!existingCats.some((c) => c.name === p.cat)) {
            const c = { id: uid(), name: p.cat };
            db.categories.upsert(c);
            existingCats.push(c);
          }
          const cat = existingCats.find((c) => c.name === p.cat);
          db.products.upsert({ id: uid(), name: p.name, price: p.price, cost: 0, stock: 0, active: true, emoji: "📦", categoryId: cat ? cat.id : "" });
        });
        toast(`${products.length} ürün eklendi ✔`, "success");
        close();
      } },
      { label: "Hayır, sadece sektörü kaydet", kind: "ghost" },
    ],
  });
}

function field(label, node) {
  return el("div", { class: "field" }, [el("label", { text: label }), node]);
}
function card(title, children) {
  return el("div", { class: "card" }, [el("h3", { text: title }), ...children]);
}
// Açık/kapalı anahtar satırı (başlık + açıklama + checkbox)
function toggleRow(title, desc, checked) {
  const input = el("input", { type: "checkbox" }); input.checked = !!checked;
  const wrap = el("label", { style: "display:flex;align-items:center;gap:10px;cursor:pointer;margin:6px 0;padding:8px;border:1px solid var(--border);border-radius:10px" }, [
    input,
    el("span", {}, [
      el("div", { style: "font-weight:700", text: title }),
      el("div", { class: "muted", style: "font-size:12px", text: desc }),
    ]),
  ]);
  return { wrap, input };
}
