// Yönetici Mobil Paneli — patron telefondan tek bakışta işletmeyi görür.
// Canlı ciro, sipariş, sepet, aktif kurye, açık kasa, kritik stok, en çok satan.
// Mobil öncelikli büyük kartlar; 15 sn'de bir yenilenir.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

const DAY = 86400000;

export function renderMobilePanel(host) {
  const body = el("div", { class: "mp-wrap" });
  const stamp = el("div", { class: "muted", style: "text-align:center;font-size:12px;margin-top:10px" });
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "📱 " + t("navMobilePanel") }), el("div", { class: "spacer" }), el("span", { class: "pill green", text: "● Canlı" })]),
    body, stamp,
  );

  function draw() {
    clear(body);
    const now = Date.now();
    const t0 = new Date(); t0.setHours(0, 0, 0, 0);
    const from = t0.getTime();
    const y0 = from - DAY;

    const sales = db.sales.all().filter((s) => !s.void);
    const today = sales.filter((s) => Number(s.ts) >= from);
    const yest = sales.filter((s) => Number(s.ts) >= y0 && Number(s.ts) < from);
    const rev = today.reduce((a, s) => a + (Number(s.total) || 0), 0);
    const revY = yest.reduce((a, s) => a + (Number(s.total) || 0), 0);
    const pct = revY > 0 ? Math.round((rev - revY) / revY * 100) : (rev > 0 ? 100 : 0);
    const n = today.length;
    const basket = n ? rev / n : 0;

    // Aktif kurye teslimatı
    const activeCour = db.couriers.all().filter((r) => (r.status || (r.done ? "teslim" : "hazirlaniyor")) !== "teslim").length;
    // Açık kasa
    const openCash = db.cashSessions.all().find((s) => s.open);
    // Kritik stok
    const lowStock = db.products.all().filter((p) => p.active !== false && typeof p.stock === "number" && p.stock >= 0 && p.stock <= (Number(p.minStock) || 5)).length;
    // Hedef
    const target = Number(settings.get().targetDaily) || 0;
    const tgtPct = target > 0 ? Math.min(100, Math.round(rev / target * 100)) : null;
    // En çok satan (bugün)
    const map = {};
    today.forEach((s) => (s.items || []).forEach((it) => { const k = it.name || "Ürün"; map[k] = (map[k] || 0) + (Number(it.qty) || 1); }));
    const top = Object.entries(map).sort((a, b) => b[1] - a[1])[0];

    // Büyük ciro kartı
    body.appendChild(el("div", { class: "mp-hero" }, [
      el("div", { class: "mp-hero-label", text: "BUGÜNKÜ CİRO" }),
      el("div", { class: "mp-hero-val num", text: money(rev) }),
      el("div", { class: "mp-hero-sub" }, [
        el("span", { class: "pill " + (pct >= 0 ? "green" : "amber"), text: (pct >= 0 ? "▲ +" : "▼ ") + pct + "% düne göre" }),
        tgtPct != null ? el("span", { class: "pill blue", text: "🎯 Hedef %" + tgtPct }) : el("span", {}),
      ]),
    ]));

    const cards = el("div", { class: "mp-grid" });
    const card = (icon, label, val, cls) => el("div", { class: "mp-card" + (cls ? " " + cls : "") }, [
      el("div", { class: "mp-ic", text: icon }),
      el("div", { class: "mp-val num", text: val }),
      el("div", { class: "mp-lbl", text: label }),
    ]);
    cards.append(
      card("🧾", "Sipariş", String(n)),
      card("🛒", "Sepet Ort.", money(basket)),
      card("🛵", "Aktif Kurye", String(activeCour), activeCour ? "warn" : ""),
      card("💵", "Kasa", openCash ? "AÇIK" : "Kapalı", openCash ? "warn" : ""),
      card("📦", "Kritik Stok", String(lowStock), lowStock ? "bad" : ""),
      card("🏆", top ? "En çok: " + top[1] + " adet" : "En Çok Satan", top ? top[0] : "—"),
    );
    body.appendChild(cards);

    stamp.textContent = "Güncelleme: " + new Date().toLocaleTimeString("tr-TR");
  }

  draw();
  const timer = setInterval(() => { if (document.body.contains(host)) draw(); else clearInterval(timer); }, 15000);
}
