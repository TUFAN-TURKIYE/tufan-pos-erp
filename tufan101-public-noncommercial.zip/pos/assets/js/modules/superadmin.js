// mod-22 Merkez Yönetim (Süper Admin) — gizli panel
// Gerçek kimlik doğrulama sunucu tarafında (api/auth.php) yapılır; şifre istemcide tutulmaz.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { superAdminLogin } from "../core/auth.js";
import { api } from "../core/api.js";

const SS = "t101_admin_session";
// Yerel önizleme için demo veri (sunucu bağlıyken backend verisi kullanılır)
function demo(key, fallback) { try { return JSON.parse(localStorage.getItem("t101_saas_" + key)) || fallback; } catch { return fallback; } }
function saveDemo(key, val) { localStorage.setItem("t101_saas_" + key, JSON.stringify(val)); }

function seedSaas() {
  if (demo("users", null)) return;
  saveDemo("users", [
    { id: "u1", business: "Ahmet Market", owner: "Ahmet Yılmaz", phone: "0555 111 22 33", package: "premium", createdAt: Date.now() - 86400000 * 40, expiresAt: Date.now() + 86400000 * 320, contractIp: "88.234.10.5", contractAt: Date.now() - 86400000 * 40 },
    { id: "u2", business: "Cafe Deniz", owner: "Deniz Kaya", phone: "0533 444 55 66", package: "free", createdAt: Date.now() - 86400000 * 3, expiresAt: null, contractIp: "78.180.44.9", contractAt: Date.now() - 86400000 * 3 },
    { id: "u3", business: "Tekno Elektronik", owner: "Selin Ak", phone: "0542 777 88 99", package: "pending", createdAt: Date.now() - 3600000 * 5, expiresAt: null, contractIp: "85.100.2.14", contractAt: Date.now() - 3600000 * 5 },
  ]);
  saveDemo("pricing", { monthly: 800, yearly: 8000 });
  saveDemo("logs", [
    { user: "Ahmet Yılmaz", action: "Giriş", ip: "88.234.10.5", ts: Date.now() - 3600000 },
    { user: "Deniz Kaya", action: "Giriş", ip: "78.180.44.9", ts: Date.now() - 7200000 },
    { user: "Ahmet Yılmaz", action: "Çıkış", ip: "88.234.10.5", ts: Date.now() - 1800000 },
  ]);
}

export function renderSuperAdmin(host, ctx) {
  const authed = sessionStorage.getItem(SS) === "1";
  if (!authed) return renderLogin(host, ctx);
  seedSaas();
  renderPanel(host, ctx);
}

function renderLogin(host, ctx) {
  const user = el("input", { class: "input", placeholder: "Kullanıcı Adı", autofocus: true });
  const pass = el("input", { class: "input", type: "password", placeholder: "Şifre" });
  const submit = async () => {
    const res = await superAdminLogin(user.value.trim(), pass.value);
    if (res.ok) { sessionStorage.setItem(SS, "1"); toast("Merkez Yönetim'e hoş geldiniz", "success"); renderSuperAdmin(host, ctx); }
    else if (res.offline) {
      // Yerel önizleme: backend yok. Salt-demo görünümüne izin ver (gerçek dağıtımda backend zorunlu).
      confirmDialog("Sunucuya ulaşılamadı. Yerel DEMO panelini açmak ister misiniz?", () => {
        sessionStorage.setItem(SS, "1"); renderSuperAdmin(host, ctx);
      });
    } else toast(res.error, "error");
  };
  pass.addEventListener("keydown", (e) => { if (e.key === "Enter") submit(); });
  clear(host).appendChild(el("div", { class: "auth-wrap" }, [
    el("div", { class: "card auth-card" }, [
      el("div", { class: "brand", style: "justify-content:center" }, [el("div", { class: "logo", style: "background:#0F172A" }, ["🛡️"]), el("b", {}, ["Merkez Yönetim"])]),
      el("p", { class: "muted", style: "text-align:center", text: "Süper Admin girişi" }),
      el("div", { class: "field" }, [el("label", { text: "Kullanıcı Adı" }), user]),
      el("div", { class: "field" }, [el("label", { text: "Şifre" }), pass]),
      el("button", { class: "btn block lg", onClick: submit }, ["Giriş"]),
      el("button", { class: "btn ghost block", style: "margin-top:8px", onClick: () => { location.hash = "#/dashboard"; } }, ["← Panele Dön"]),
    ]),
  ]));
}

function renderPanel(host, ctx) {
  const server = !!localStorage.getItem("t101_token");
  const tabs = [
    { id: "users", label: "👥 Kullanıcılar" },
    { id: "pricing", label: "💳 Fiyatlandırma" },
    { id: "logs", label: "📜 Giriş Kayıtları" },
    { id: "contracts", label: "📝 Sözleşme Takibi" },
  ];
  let active = "users";
  const nav = el("nav", { class: "nav", style: "flex-direction:row;flex-wrap:wrap;padding:0" });
  const view = el("div", { style: "margin-top:16px" });

  const drawTabs = () => {
    clear(nav);
    tabs.forEach((tb) => nav.appendChild(el("a", { href: "javascript:void 0", class: active === tb.id ? "active" : "", onClick: () => { active = tb.id; render(); } }, [tb.label])));
  };
  const render = () => {
    drawTabs(); clear(view);
    if (active === "users") usersTab(view);
    else if (active === "pricing") pricingTab(view);
    else if (active === "logs") logsTab(view);
    else contractsTab(view);
  };

  clear(host).appendChild(el("div", { style: "max-width:1100px;margin:0 auto;padding:22px" }, [
    el("div", { class: "view-head" }, [
      el("h1", { text: "🛡️ Merkez Yönetim (Süper Admin)" }),
      el("div", { style: "flex:1" }),
      el("span", { class: "pill " + (server ? "green" : "amber"), text: server ? "● Sunucu" : "○ Yerel Demo" }),
      el("button", { class: "btn ghost", onClick: () => { sessionStorage.removeItem(SS); location.hash = "#/dashboard"; } }, ["Çıkış"]),
    ]),
    nav, view,
  ]));
  render();
}

function pkgPill(p) {
  const map = { premium: ["green", "💎 Premium"], free: ["amber", "🆓 Ücretsiz"], pending: ["red", "⏳ Onay Bekliyor"] };
  const [c, txt] = map[p] || ["blue", p];
  return el("span", { class: "pill " + c, text: txt });
}
function daysLeft(exp) { if (!exp) return "—"; const d = Math.ceil((exp - Date.now()) / 86400000); return d > 0 ? d + " gün" : "Süresi doldu"; }

function usersTab(host) {
  const users = demo("users", []);
  const card = el("div", { class: "card" }, [
    el("h3", { text: "Kayıtlı İşletmeler" }),
    el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: "İşletme" }), el("th", { text: "Sahibi" }), el("th", { text: "Paket" }), el("th", { text: "Kalan Süre" }), el("th", {})])]),
      el("tbody", {}, users.map((u) => el("tr", {}, [
        el("td", {}, [el("div", { style: "font-weight:700", text: u.business }), el("div", { class: "muted", style: "font-size:12px", text: u.phone })]),
        el("td", { text: u.owner }),
        el("td", {}, [pkgPill(u.package)]),
        el("td", { class: "num", text: daysLeft(u.expiresAt) }),
        el("td", { style: "text-align:right" }, [
          el("button", { class: "btn ghost", onClick: () => manage(u) }, ["Yönet"]),
        ]),
      ]))),
    ]),
  ]);
  host.appendChild(card);

  function manage(u) {
    const days = el("input", { class: "input num", type: "number", value: 30 });
    modal({
      title: u.business + " — Üyelik Yönetimi",
      body: el("div", {}, [
        el("div", { style: "display:flex;gap:8px;margin-bottom:12px" }, [
          el("button", { class: "btn success", style: "flex:1", onClick: () => setPkg(u, "premium") }, ["💎 Premium Ata"]),
          el("button", { class: "btn ghost", style: "flex:1", onClick: () => setPkg(u, "free") }, ["🆓 Ücretsiz"]),
        ]),
        el("div", { class: "field" }, [el("label", { text: "Süre Ekle (gün) — ceza için negatif girin" }), days]),
        el("button", { class: "btn block", onClick: () => addDays(u, parseInt(days.value) || 0) }, ["Süre Uygula"]),
      ]),
      actions: [{ label: "Kapat", kind: "ghost" }],
    });
  }
  function persist(u) { const all = demo("users", []); const i = all.findIndex((x) => x.id === u.id); all[i] = u; saveDemo("users", all); usersTab(clear(host)); }
  function setPkg(u, p) { u.package = p; if (p === "premium" && !u.expiresAt) u.expiresAt = Date.now() + 86400000 * 30; toast("Paket güncellendi: " + p, "success"); persist(u); }
  function addDays(u, d) { u.expiresAt = (u.expiresAt || Date.now()) + d * 86400000; if (u.package === "pending") u.package = "premium"; toast(d + " gün uygulandı", "success"); persist(u); }
}

function pricingTab(host) {
  const p = demo("pricing", { monthly: 800, yearly: 8000 });
  const m = el("input", { class: "input num", type: "number", value: p.monthly });
  const y = el("input", { class: "input num", type: "number", value: p.yearly });
  host.appendChild(el("div", { class: "card", style: "max-width:420px" }, [
    el("h3", { text: "Abonelik Fiyatları" }),
    el("div", { class: "field" }, [el("label", { text: "Aylık (₺)" }), m]),
    el("div", { class: "field" }, [el("label", { text: "Yıllık (₺)" }), y]),
    el("button", { class: "btn success", onClick: () => { saveDemo("pricing", { monthly: +m.value, yearly: +y.value }); toast("Fiyatlar güncellendi", "success"); } }, ["Kaydet"]),
  ]));
}

function logsTab(host) {
  const logs = demo("logs", []);
  host.appendChild(el("div", { class: "card" }, [
    el("div", { style: "display:flex;align-items:center" }, [
      el("h3", { style: "margin:0;flex:1", text: "Giriş / Çıkış Kayıtları" }),
      el("button", { class: "btn danger", onClick: () => confirmDialog("Tüm eski logları sil?", () => { saveDemo("logs", []); logsTab(clear(host)); }) }, ["🗑 Temizle"]),
    ]),
    el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: "Kullanıcı" }), el("th", { text: "İşlem" }), el("th", { text: "IP" }), el("th", { text: "Zaman" })])]),
      el("tbody", {}, logs.length ? logs.map((l) => el("tr", {}, [
        el("td", { text: l.user }), el("td", { text: l.action }), el("td", { class: "muted num", text: l.ip }),
        el("td", { class: "muted", text: new Date(l.ts).toLocaleString("tr-TR") }),
      ])) : [el("tr", {}, [el("td", { class: "muted", text: "—" })])]),
    ]),
  ]));
}

function contractsTab(host) {
  const users = demo("users", []);
  host.appendChild(el("div", { class: "card" }, [
    el("h3", { text: "Sözleşme Onayları" }),
    el("p", { class: "muted", text: "Hangi kullanıcı, hangi IP'den, hangi tarihte kullanıcı sözleşmesini onayladı." }),
    el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: "İşletme" }), el("th", { text: "IP Adresi" }), el("th", { text: "Onay Tarihi" })])]),
      el("tbody", {}, users.map((u) => el("tr", {}, [
        el("td", { text: u.business }), el("td", { class: "num muted", text: u.contractIp || "—" }),
        el("td", { text: u.contractAt ? new Date(u.contractAt).toLocaleString("tr-TR") : "—" }),
      ]))),
    ]),
  ]));
}
