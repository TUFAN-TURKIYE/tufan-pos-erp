// Ürün Paketleri / Menü (örn. "Menü 1 = Hamburger + Patates + Kola")
// Paket, products tablosunda `bundle:[{productId,qty}]` alanı olan normal bir üründür.
// Kasada tek ürün gibi satılır; satışta bileşenlerin stoğu otomatik düşer (pos.js).
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

export function renderBundles(host) {
  const wrap = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form(null) }, ["+ Paket Oluştur"]);
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🍔 " + t("navBundles") }), el("div", { class: "spacer" }), addBtn]),
    el("p", { class: "muted", style: "margin:0 0 12px", text: "Birden fazla ürünü tek menü gibi satın. Menü satılınca içindeki ürünlerin stoğu otomatik düşer." }),
    wrap,
  );

  function bundles() { return db.products.all().filter((p) => Array.isArray(p.bundle) && p.bundle.length); }

  function draw() {
    clear(wrap);
    const list = bundles();
    if (!list.length) { wrap.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:16px", text: "Henüz paket yok. Örn: Menü 1 = Hamburger + Patates + Kola." })])); return; }
    wrap.appendChild(el("div", { class: "camp-grid" }, list.map((p) => {
      const names = p.bundle.map((b) => { const c = db.products.get(b.productId); return (c ? c.name : "?") + (b.qty > 1 ? " ×" + b.qty : ""); }).join(" + ");
      return el("div", { class: "camp-card" }, [
        el("div", { style: "display:flex;justify-content:space-between;align-items:center" }, [
          el("h3", { style: "margin:0", text: (p.emoji || "🍔") + " " + p.name }),
          el("b", { class: "num", text: money(p.price || 0) }),
        ]),
        el("div", { class: "muted", style: "font-size:13px;margin-top:6px", text: names }),
        el("div", { style: "display:flex;gap:8px;margin-top:12px" }, [
          el("button", { class: "btn ghost tiny", onClick: () => form(p) }, ["✏ " + t("edit")]),
          el("button", { class: "btn ghost tiny", onClick: () => confirmDialog("Paket silinsin mi?", () => { db.products.remove(p.id); draw(); }) }, ["🗑"]),
        ]),
      ]);
    })));
  }

  function form(p) {
    const isNew = !p;
    p = p || { id: uid(), bundle: [], active: true, emoji: "🍔", stock: 9999 };
    const name = el("input", { class: "input", value: p.name || "", placeholder: "Menü adı (örn. Menü 1)" });
    const price = el("input", { class: "input num", type: "number", step: "0.01", value: p.price != null ? p.price : "", placeholder: "Menü fiyatı" });
    const comps = (p.bundle || []).map((b) => ({ ...b }));
    const compHost = el("div", {});

    const prods = db.products.all().filter((x) => !Array.isArray(x.bundle) || !x.bundle.length); // paket olmayan ürünler
    const sel = el("select", { class: "input" }, [el("option", { value: "", text: "— Ürün ekle —" }), ...prods.map((x) => el("option", { value: x.id, text: x.name + " (" + money(x.price || 0) + ")" }))]);
    const addComp = el("button", { class: "btn ghost", type: "button", onClick: () => {
      if (!sel.value) return;
      if (comps.find((c) => c.productId === sel.value)) { toast("Zaten ekli", "warn"); return; }
      comps.push({ productId: sel.value, qty: 1 }); sel.value = ""; drawComps();
    } }, ["+ Ekle"]);

    function drawComps() {
      clear(compHost);
      if (!comps.length) { compHost.appendChild(el("p", { class: "muted", text: "Henüz ürün eklenmedi." })); return; }
      comps.forEach((c) => {
        const prod = db.products.get(c.productId);
        compHost.appendChild(el("div", { class: "cart-row" }, [
          el("div", { style: "flex:1", text: prod ? prod.name : "?" }),
          el("div", { class: "qty" }, [
            el("button", { class: "qbtn", type: "button", onClick: () => { c.qty = Math.max(1, c.qty - 1); drawComps(); } }, ["−"]),
            el("b", { class: "num", text: String(c.qty) }),
            el("button", { class: "qbtn", type: "button", onClick: () => { c.qty++; drawComps(); } }, ["+"]),
          ]),
          el("button", { class: "btn ghost tiny", type: "button", onClick: () => { comps.splice(comps.indexOf(c), 1); drawComps(); } }, ["🗑"]),
        ]));
      });
    }
    drawComps();

    modal({
      title: isNew ? "Paket Oluştur" : "Paket Düzenle",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Menü adı" }), name]),
        el("div", { class: "field" }, [el("label", { text: "Menü fiyatı (TL)" }), price]),
        el("div", { style: "border-top:1px solid var(--border);margin:10px 0;padding-top:10px" }, [
          el("label", { style: "font-weight:600", text: "İçindeki ürünler" }),
          el("div", { style: "display:flex;gap:8px;margin:8px 0" }, [sel, addComp]),
          compHost,
        ]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast("Menü adı gerekli", "warn"); return; }
          if (!comps.length) { toast("En az bir ürün ekleyin", "warn"); return; }
          db.products.upsert({ ...p, name: name.value.trim(), price: parseFloat(price.value) || 0, bundle: comps, active: true });
          toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}
