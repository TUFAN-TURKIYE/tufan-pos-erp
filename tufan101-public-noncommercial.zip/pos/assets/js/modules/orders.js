// Toplu Sipariş / Alım — tedarikçiden çoklu ürün alımı, nakliye, sipariş geçmişi
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

export function renderOrders(host) {
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: "🛒 " + t("orders") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn success", onClick: () => newOrder() }, ["+ " + t("orders")]),
  ]);
  const body = el("div", {});
  clear(host).append(head, body);

  function draw() {
    clear(body);
    const list = db.orders.all().slice().sort((a, b) => b.ts - a.ts);
    const totalSpend = list.reduce((a, o) => a + (o.grand || 0), 0);
    body.appendChild(el("div", { class: "stat-grid" }, [
      statCard("Sipariş Sayısı", String(list.length), "var(--primary)"),
      statCard("Toplam Alım", money(totalSpend), "var(--danger)"),
    ]));

    const listCard = el("div", { class: "card", style: "margin-top:16px" });
    listCard.appendChild(el("h3", { text: "📦 Sipariş Geçmişi" }));
    if (!list.length) { listCard.appendChild(el("p", { class: "muted", text: "Sipariş yok. Sağ üstten ekleyin." })); body.appendChild(listCard); return; }
    listCard.appendChild(el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [
        el("th", { text: "Tarih" }), el("th", { text: "Tedarikçi" }), el("th", { text: "Kalem" }),
        el("th", { text: "Ürün Toplamı" }), el("th", { text: "Nakliye" }), el("th", { text: "Genel Toplam" }), el("th", {}),
      ])]),
      el("tbody", {}, list.map((o) =>
        el("tr", {}, [
          el("td", { class: "muted", text: o.date || new Date(o.ts).toLocaleDateString("tr-TR") }),
          el("td", { style: "font-weight:600", text: o.supplier || "—" }),
          el("td", { text: (o.items || []).length + " kalem" }),
          el("td", { class: "num", text: money(o.itemsTotal) }),
          el("td", { class: "num", text: money(o.shipping) }),
          el("td", { class: "num", style: "font-weight:700", text: money(o.grand) }),
          el("td", { style: "text-align:right" }, [
            el("button", { class: "iconbtn", title: "Detay", onClick: () => showDetail(o) }, ["👁"]),
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog("Siparişi sil?", () => { db.orders.remove(o.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
          ]),
        ])
      )),
    ]));
    body.appendChild(listCard);
  }

  function showDetail(o) {
    modal({
      title: "🧾 " + (o.supplier || "Sipariş"),
      body: el("div", {}, [
        el("p", { class: "muted", text: (o.date || "") + " • Nakliye: " + money(o.shipping) }),
        el("table", { class: "tbl" }, [
          el("thead", {}, [el("tr", {}, [el("th", { text: "Ürün" }), el("th", { text: "Adet" }), el("th", { text: "Birim" }), el("th", { text: "Tutar" })])]),
          el("tbody", {}, (o.items || []).map((it) =>
            el("tr", {}, [el("td", { text: it.name }), el("td", { class: "num", text: String(it.qty) }), el("td", { class: "num", text: money(it.unit) }), el("td", { class: "num", text: money(it.qty * it.unit) })])
          )),
        ]),
        el("div", { style: "text-align:right;font-weight:700;margin-top:10px", text: "Genel Toplam: " + money(o.grand) }),
      ]),
      actions: [{ label: t("close"), kind: "ghost" }],
    });
  }

  function newOrder() {
    const date = el("input", { class: "input", type: "date", value: new Date().toISOString().slice(0, 10) });
    const supplier = el("input", { class: "input", placeholder: "Tedarikçi adı" });
    const shipping = el("input", { class: "input num", type: "number", step: "0.01", value: 0 });
    const rows = el("div", {});
    const totalEl = el("b", { class: "num" });

    function addRow(it) {
      const nm = el("input", { class: "input", placeholder: "Ürün", value: it ? it.name : "" });
      const qty = el("input", { class: "input num", type: "number", step: "0.001", value: it ? it.qty : 1, style: "max-width:80px" });
      const unit = el("input", { class: "input num", type: "number", step: "0.01", value: it ? it.unit : "", style: "max-width:110px" });
      const del = el("button", { class: "iconbtn", onClick: () => { row.remove(); recalc(); } }, ["🗑"]);
      const row = el("div", { style: "display:grid;grid-template-columns:1fr 80px 110px 36px;gap:6px;margin-bottom:6px;align-items:center" }, [nm, qty, unit, del]);
      row._get = () => ({ name: nm.value.trim(), qty: parseFloat(qty.value) || 0, unit: parseFloat(unit.value) || 0 });
      [qty, unit].forEach((i) => i.addEventListener("input", recalc));
      rows.appendChild(row);
    }
    function collect() { return [...rows.children].map((r) => r._get()).filter((x) => x.name); }
    function recalc() {
      const items = collect();
      const itemsTotal = items.reduce((a, x) => a + x.qty * x.unit, 0);
      totalEl.textContent = money(itemsTotal + (parseFloat(shipping.value) || 0));
    }
    shipping.addEventListener("input", recalc);
    addRow(); recalc();

    modal({
      title: "🛒 " + t("orders"),
      body: el("div", {}, [
        two(field("Tarih", date), field("Nakliye Ücreti", shipping)),
        field("Tedarikçi / Açıklama", supplier),
        el("div", { style: "display:grid;grid-template-columns:1fr 80px 110px 36px;gap:6px;margin:8px 0 4px;font-size:12px;color:var(--muted)" }, [
          el("span", { text: "Ürün" }), el("span", { text: "Adet" }), el("span", { text: "Birim" }), el("span", {}),
        ]),
        rows,
        el("button", { class: "btn ghost block", style: "margin-top:6px", onClick: () => addRow() }, ["+ Ürün Satırı Ekle"]),
        el("div", { style: "display:flex;justify-content:space-between;align-items:center;margin-top:12px;border-top:1px solid var(--border);padding-top:10px" }, [
          el("span", { class: "muted", text: "Genel Toplam" }), totalEl,
        ]),
      ]),
      actions: [
        { label: "💾 " + t("save"), kind: "success", onClick: (close) => {
          const items = collect();
          if (!items.length) { toast("En az bir ürün satırı ekleyin", "warn"); return; }
          const itemsTotal = items.reduce((a, x) => a + x.qty * x.unit, 0);
          const ship = parseFloat(shipping.value) || 0;
          db.orders.upsert({ id: uid(), ts: Date.now(), date: date.value, supplier: supplier.value.trim(), items, itemsTotal, shipping: ship, grand: itemsTotal + ship });
          toast("Sipariş kaydedildi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}

function field(label, node) { return el("div", { class: "field" }, [el("label", { text: label }), node]); }
function two(a, b) { return el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [a, b]); }
function statCard(label, value, color) {
  return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
    el("div", { class: "label", text: label }),
    el("div", { class: "value num", text: value }),
  ]);
}
