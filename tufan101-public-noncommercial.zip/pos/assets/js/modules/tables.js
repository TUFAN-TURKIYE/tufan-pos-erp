// Masa / Adisyon Yönetimi — restoran/kafe için masa bazlı sipariş.
// Her masaya ürün eklenir (adisyon), "Ödeme Al" ile satışa dönüşür: stok düşer,
// kasa/banka hareketi işlenir, satış kaydı oluşur. Açık adisyonlar settings.tables'da.
import { el, clear, toast, modal, confirmDialog, sound } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, settings, ensureAccounts, defaultAccountId, postAccountMove, currentAccount } from "../core/store.js";
import { currentUser } from "../core/auth.js";
import { cloud } from "../core/api.js";
import { printReceipt } from "./pos.js";

function getTables() { const s = settings.get(); return (s.tables && typeof s.tables === "object") ? { ...s.tables } : {}; }
function saveTables(tabs) { settings.set({ tables: tabs }); }
function tableCount() { return Number(settings.get().tableCount) || 12; }

// Masa id ("M3") → mutfak/çağrı sisteminin beklediği masa no ("3")
function masaNo(id) { return String(id || "").replace(/^M/i, ""); }

// Mutfak (KDS) durumları: masa no → { id, status } (bekliyor|alindi|hazir)
let _kitchenByMasa = {};
let _kdsTimer = null;

function tabTotal(items) { return (items || []).reduce((a, it) => a + (Number(it.price) || 0) * (Number(it.qty) || 0), 0); }

// POS ile aynı stok düşme mantığı (paket / reçete / normal)
function deductStock(items) {
  items.forEach((c) => {
    const p = db.products.get(c.productId); if (!p) return;
    if (Array.isArray(p.bundle) && p.bundle.length) {
      p.bundle.forEach((b) => { const comp = db.products.get(b.productId); if (comp) { comp.stock = Math.max(0, (Number(comp.stock) || 0) - (Number(b.qty) || 1) * c.qty); db.products.upsert(comp); } });
    } else if (Array.isArray(p.recipe) && p.recipe.length) {
      p.recipe.forEach((ing) => { const raw = db.products.get(ing.productId); if (raw) { raw.stock = Math.max(0, (Number(raw.stock) || 0) - (Number(ing.qty) || 0) * c.qty); db.products.upsert(raw); } });
      if (typeof p.stock === "number") { p.stock = Math.max(0, p.stock - c.qty); db.products.upsert(p); }
    } else { p.stock = Math.max(0, (Number(p.stock) || 0) - c.qty); db.products.upsert(p); }
  });
}

export function renderTables(host) {
  const account = currentAccount();
  const body = el("div", {});
  const setBtn = el("button", { class: "btn ghost", onClick: () => { const n = prompt("Masa sayısı:", tableCount()); if (n && Number(n) > 0) { settings.set({ tableCount: Math.min(60, Number(n)) }); draw(); } } }, ["⚙️ Masa Sayısı"]);
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🍽️ " + t("navTables") }), el("div", { class: "spacer" }), setBtn]),
    body,
  );

  // Mutfak durumlarını buluttan çek — masa "hazır" olunca kasa hemen görsün.
  async function pollKitchen() {
    if (!account) return;
    try {
      const res = await cloud.listCalls(account);
      const list = (res && (res.calls || res.data || res)) || [];
      const map = {};
      (Array.isArray(list) ? list : [])
        .filter((c) => c.type === "order" && (c.status || "bekliyor") !== "tamam")
        .forEach((c) => { if (c.masa != null) map[String(c.masa)] = { id: c.id, status: c.status || "bekliyor" }; });
      _kitchenByMasa = map;
      draw();
    } catch {}
  }
  function kitchenOf(id) { return _kitchenByMasa[masaNo(id)] || null; }

  function draw() {
    clear(body);
    const tabs = getTables();
    const occupied = Object.keys(tabs).filter((k) => (tabs[k].items || []).length).length;
    const totalOpen = Object.values(tabs).reduce((a, tb) => a + tabTotal(tb.items), 0);
    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Dolu Masa" }), el("div", { class: "smart-val num", text: occupied + " / " + tableCount() })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Açık Adisyon Toplamı" }), el("div", { class: "smart-val num", text: money(totalOpen) })]),
    ]));

    const grid = el("div", { class: "tbl-grid" });
    for (let i = 1; i <= tableCount(); i++) {
      const id = "M" + i;
      const tb = tabs[id];
      const items = tb ? tb.items || [] : [];
      const tot = tabTotal(items);
      const busy = items.length > 0;
      const k = kitchenOf(id);
      const ready = k && k.status === "hazir";
      const cooking = k && (k.status === "alindi" || k.status === "bekliyor");
      const badge = ready
        ? el("div", { class: "tbl-kds ready", text: "✅ HAZIR" })
        : cooking ? el("div", { class: "tbl-kds cooking", text: "🍳 Mutfakta" }) : null;
      grid.appendChild(el("div", { class: "tbl-cell" + (busy ? " busy" : "") + (ready ? " ready" : ""), onClick: () => openTab(id) }, [
        el("div", { class: "tbl-no", text: "🍽️ " + id }),
        busy
          ? el("div", {}, [el("div", { class: "tbl-tot num", text: money(tot) }), el("div", { class: "muted", style: "font-size:11px", text: items.reduce((a, x) => a + (Number(x.qty) || 0), 0) + " ürün" })])
          : el("div", { class: "muted", style: "font-size:12px", text: "Boş" }),
        badge,
      ]));
    }
    body.appendChild(grid);
  }

  function openTab(id) {
    let tabs = getTables();
    const tb = tabs[id] || { items: [], openedTs: Date.now() };
    let items = (tb.items || []).map((x) => ({ ...x }));

    const listEl = el("div", { class: "tbl-items" });
    const totEl = el("b", { class: "num", style: "font-size:20px" });
    const search = el("input", { class: "input", placeholder: "🔍 Ürün ekle (ara)", style: "margin-bottom:8px" });
    const pick = el("div", { class: "tbl-pick" });

    const redraw = () => {
      clear(listEl);
      if (!items.length) listEl.appendChild(el("p", { class: "muted", style: "padding:8px", text: "Adisyon boş. Aşağıdan ürün ekleyin." }));
      items.forEach((it, i) => {
        listEl.appendChild(el("div", { class: "cart-row" }, [
          el("div", { style: "flex:1" }, [el("div", { style: "font-weight:600", text: it.name }), el("div", { class: "muted", style: "font-size:12px", text: money(it.price) })]),
          el("div", { class: "qty" }, [
            el("button", { class: "qbtn", onClick: () => { it.qty = Math.max(0, it.qty - 1); if (!it.qty) items.splice(i, 1); redraw(); } }, ["−"]),
            el("b", { class: "num", text: String(it.qty) }),
            el("button", { class: "qbtn", onClick: () => { it.qty++; redraw(); } }, ["+"]),
          ]),
        ]));
      });
      totEl.textContent = money(tabTotal(items));
    };

    const drawPick = () => {
      clear(pick);
      const q = search.value.trim().toLowerCase();
      const prods = db.products.all().filter((p) => p.active !== false && (!q ? true : (p.name || "").toLowerCase().includes(q) || (p.barcode || "").includes(q))).slice(0, q ? 30 : 18);
      prods.forEach((p) => pick.appendChild(el("button", { class: "tbl-pick-btn", onClick: () => {
        const ex = items.find((x) => x.productId === p.id);
        if (ex) ex.qty++; else items.push({ productId: p.id, name: p.name, price: Number(p.price) || 0, qty: 1 });
        redraw();
      } }, [(p.emoji || "📦") + " " + p.name, el("span", { class: "muted", style: "font-size:11px;display:block", text: money(p.price) })])));
    };
    search.addEventListener("input", drawPick);
    redraw(); drawPick();

    // Masa-bazlı senkron: her yazımda '_u' damgası; boşalınca 'delete' yerine mezar
    // taşı bırak (kapanma diğer cihaza yayılsın, stale cihaz masayı geri diriltmesin).
    const persist = (closeTab) => { tabs = getTables(); if (items.length) tabs[id] = { items, openedTs: tb.openedTs || Date.now(), _u: Date.now() }; else tabs[id] = { _deleted: true, _u: Date.now() }; saveTables(tabs); if (closeTab) closeTab(); draw(); };

    // Adisyonu mutfağa (KDS) gönder — mutfak hazırlayınca kasa "HAZIR" görür.
    async function sendToKitchen(c) {
      if (!items.length) { toast("Adisyon boş", "warn"); return; }
      if (!account) { toast("Bulut hesabı yok — mutfağa gönderilemedi. Adisyon kaydedildi.", "warn"); persist(); c && c(); return; }
      persist();
      const payload = { type: "order", masa: masaNo(id), items: items.map((x) => ({ name: x.name, qty: x.qty, price: x.price })), note: "🍽️ Masa " + id };
      try { await cloud.call(account, payload); try { sound.sale(); } catch {} toast("Masa " + id + " mutfağa gönderildi", "success"); pollKitchen(); }
      catch { toast("Mutfağa gönderilemedi (bağlantı yok)", "error"); }
      c && c();
    }

    const close = modal({
      title: "🍽️ Masa " + id,
      body: el("div", {}, [
        listEl,
        el("div", { style: "display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border);padding-top:10px;margin:8px 0" }, [el("span", { class: "muted", text: "Adisyon toplamı" }), totEl]),
        el("hr", {}), search, pick,
      ]),
      actions: [
        { label: "💾 Kaydet", kind: "", onClick: (c) => { persist(); toast("Adisyon kaydedildi", "success"); c(); } },
        { label: "🍳 Mutfağa Gönder", kind: "primary", onClick: (c) => sendToKitchen(c) },
        { label: "💵 Ödeme Al", kind: "success", onClick: (c) => { if (!items.length) { toast("Adisyon boş", "warn"); return; } pay(id, items, () => { tabs = getTables(); tabs[id] = { _deleted: true, _u: Date.now() }; saveTables(tabs); draw(); c(); }); } },
        { label: "🗑 Boşalt", kind: "ghost", onClick: (c) => { confirmDialog("Masa " + id + " adisyonu silinsin mi?", () => { tabs = getTables(); tabs[id] = { _deleted: true, _u: Date.now() }; saveTables(tabs); draw(); c(); }); } },
      ],
    });
  }

  function pay(id, items, done) {
    const total = tabTotal(items);
    modal({
      title: "💵 Masa " + id + " — Ödeme · " + money(total),
      body: el("div", {}, [el("p", { class: "muted", text: items.reduce((a, x) => a + x.qty, 0) + " ürün · Toplam " + money(total) })]),
      actions: [
        { label: "🧾 Nakit + Fiş", kind: "success", onClick: (c) => { finalize(id, items, "cash", true); c(); done && done(); } },
        { label: "🧾 Kart + Fiş", kind: "success", onClick: (c) => { finalize(id, items, "card", true); c(); done && done(); } },
        { label: "💵 Nakit", kind: "ghost", onClick: (c) => { finalize(id, items, "cash"); c(); done && done(); } },
        { label: "💳 Kart", kind: "ghost", onClick: (c) => { finalize(id, items, "card"); c(); done && done(); } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function finalize(id, items, method, forcePrint) {
    const total = tabTotal(items);
    const user = currentUser();
    deductStock(items);
    const saleId = uid();
    const saleRow = {
      id: saleId, ts: Date.now(), items: items.map((c) => ({ ...c })),
      subtotal: total, discount: 0, discountLabel: "", total, paid: total, method, change: 0,
      cashierId: user ? user.id : null, cashierName: user ? user.name : "", void: false,
      table: id, branchId: (user && user.branchId) || settings.get().activeBranch || "",
    };
    db.sales.upsert(saleRow);
    try {
      ensureAccounts();
      const accId = defaultAccountId(method === "card" ? "bank" : "cash");
      if (accId && total > 0) postAccountMove({ accountId: accId, dir: "in", amount: total, source: "sale", refId: saleId, note: (method === "card" ? "💳 Kart" : "💵 Nakit") + " · Masa " + id + " · Fiş #" + String(saleId).slice(-6).toUpperCase() + (user && user.name ? " · " + user.name : ""), party: "Masa " + id });
    } catch {}
    // Mutfaktaki fişi kapat (varsa) — kasa ödeme aldıysa sipariş tamamlanmıştır.
    const k = kitchenOf(id);
    if (account && k && k.id) {
      delete _kitchenByMasa[masaNo(id)];
      cloud.setCallStatus(account, k.id, "tamam").catch(() => {});
    }
    try { sound.sale(); } catch {}
    toast("Masa " + id + " ödendi • " + money(total), "success");
    if (forcePrint || settings.get().autoReceipt) { try { printReceipt(saleRow); } catch {} }
  }

  draw();
  pollKitchen();
  _kdsTimer = setInterval(() => {
    if (!document.body.contains(host)) { clearInterval(_kdsTimer); _kdsTimer = null; return; }
    pollKitchen();
  }, 12000);
}
