// mod-14 Vardiya ve Z Raporu — gün sonu ciro, eksik/fazla bakiye
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, todayRange, settings } from "../core/store.js";
import { currentUser } from "../core/auth.js";

// ---- Z Raporu yazdır (termal 80mm + A4 uyumlu) ----
function printZReport(z) {
  const s = settings.get();
  const biz = s.business || "TUFAN 101";
  const esc = (v) => String(v == null ? "" : v).replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m]));
  const line = (a, b, bold) => `<tr${bold ? ' class="b"' : ""}><td>${esc(a)}</td><td class="r">${esc(b)}</td></tr>`;
  const diffTxt = z.diff === 0 ? "TAM" : (z.diff > 0 ? "FAZLA " : "EKSİK ") + money(Math.abs(z.diff));
  const w = window.open("", "_blank", "width=340,height=680");
  if (!w) { toast("Açılır pencere engellendi (yazdırma için izin verin)", "warn"); return; }
  w.document.write(`<!doctype html><html><head><meta charset="utf-8"><title>Z Raporu</title>
    <style>
      body{font-family:'Courier New',monospace;width:80mm;margin:0 auto;padding:6mm 4mm;color:#000;font-size:12px}
      .c{text-align:center} .biz{font-size:16px;font-weight:bold} .ttl{font-weight:bold;margin:4px 0}
      .muted{color:#333;font-size:11px}
      hr{border:none;border-top:1px dashed #000;margin:6px 0}
      table{width:100%;border-collapse:collapse} td{padding:2px 0} td.r{text-align:right}
      .b td{font-weight:bold;font-size:14px}
      .foot{margin-top:8px;text-align:center;font-size:10px;color:#333}
      @media print{@page{margin:0}}
    </style></head><body>
    <div class="c biz">${esc(biz)}</div>
    <div class="c ttl">Z RAPORU (Gün Sonu)</div>
    <hr>
    <div class="muted">Kasiyer: ${esc(z.cashierName || "—")}</div>
    <div class="muted">Açılış: ${esc(new Date(z.openTs).toLocaleString("tr-TR"))}</div>
    <div class="muted">Kapanış: ${esc(new Date(z.closeTs).toLocaleString("tr-TR"))}</div>
    <hr>
    <table>
      ${line("Başlangıç Nakit", money(z.openingCash))}
      ${line("Nakit Satış", money(z.cashSales))}
      ${line("Kart Satış", money(z.cardSales))}
      ${line("Fiş Adedi", String(z.saleCount || 0))}
      <tr><td colspan="2"><hr></td></tr>
      ${line("Beklenen Kasa", money(z.expected), true)}
      ${line("Sayılan Nakit", money(z.counted))}
      ${line("Fark", diffTxt, true)}
    </table>
    <hr>
    <div class="foot">TUFAN 101 ile hazırlanmıştır.</div>
    <script>window.onload=()=>{window.print();setTimeout(()=>window.close(),400);}<\/script>
    </body></html>`);
  w.document.close();
}

const OPEN_KEY = "t101_openShift";

export function renderShift(host) {
  const head = el("div", { class: "view-head" }, [el("h1", { text: t("shift") })]);
  const body = el("div", {});
  clear(host).append(head, body);

  function openShift() { try { return JSON.parse(localStorage.getItem(OPEN_KEY)); } catch { return null; } }

  function draw() {
    clear(body);
    const cur = openShift();
    if (!cur) {
      body.appendChild(el("div", { class: "card" }, [
        el("h3", { text: "Vardiya kapalı" }),
        el("p", { class: "muted", text: "Kasadaki başlangıç nakdini girerek vardiyayı açın." }),
        el("button", { class: "btn success lg", onClick: () => start() }, ["▶ Vardiya Aç"]),
      ]));
      pastShifts();
      return;
    }
    // Açık vardiya özeti
    const sales = db.sales.all().filter((s) => !s.void && s.ts >= cur.openTs);
    const cashSales = sales.filter((s) => s.method === "cash").reduce((a, s) => a + s.total, 0);
    const cardSales = sales.filter((s) => s.method === "card").reduce((a, s) => a + s.total, 0);
    const expected = cur.openingCash + cashSales;
    body.appendChild(el("div", { class: "card" }, [
      el("h3", { text: "🟢 Açık Vardiya" }),
      el("p", { class: "muted", text: (currentUser()?.name || "") + " • " + new Date(cur.openTs).toLocaleString("tr-TR") }),
      el("div", { class: "stat-grid", style: "margin-top:10px" }, [
        mini("Başlangıç Nakit", money(cur.openingCash)),
        mini(t("cash"), money(cashSales)),
        mini(t("card"), money(cardSales)),
        mini("Beklenen Kasa", money(expected)),
      ]),
      el("button", { class: "btn danger lg", style: "margin-top:14px", onClick: () => close(cur, expected, sales.length) }, ["⏹ Z Raporu Al & Kapat"]),
    ]));
    pastShifts();
  }

  function start() {
    const cash = el("input", { class: "input num", type: "number", value: 0, autofocus: true });
    modal({
      title: "Vardiya Aç", body: el("div", { class: "field" }, [el("label", { text: "Başlangıç Nakiti" }), cash]),
      actions: [
        { label: t("confirm"), kind: "success", onClick: (c) => {
          localStorage.setItem(OPEN_KEY, JSON.stringify({ openTs: Date.now(), openingCash: parseFloat(cash.value) || 0, cashierId: currentUser()?.id }));
          c(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function close(cur, expected, count) {
    const counted = el("input", { class: "input num", type: "number", value: expected, autofocus: true });
    const diffEl = el("div", { class: "num", style: "margin-top:8px;font-size:18px" });
    const upd = () => { const d = (parseFloat(counted.value) || 0) - expected; diffEl.textContent = (d === 0 ? "✓ Tam" : (d > 0 ? "Fazla " : "Eksik ") + money(Math.abs(d))); diffEl.style.color = d === 0 ? "var(--success)" : "var(--danger)"; };
    counted.addEventListener("input", upd); upd();
    // Nakit/kart kırılımı (fiş yazdırma için)
    const periodSales = db.sales.all().filter((x) => !x.void && x.ts >= cur.openTs);
    const cashSales = periodSales.filter((x) => x.method === "cash").reduce((a, x) => a + x.total, 0);
    const cardSales = periodSales.filter((x) => x.method === "card").reduce((a, x) => a + x.total, 0);
    const saveShift = (doPrint) => {
      const countedVal = parseFloat(counted.value) || 0;
      const rec = { id: uid(), cashierId: cur.cashierId, cashierName: currentUser()?.name || "",
        openTs: cur.openTs, closeTs: Date.now(), openingCash: cur.openingCash,
        cashSales, cardSales, expected, counted: countedVal, diff: countedVal - expected, saleCount: count };
      db.shifts.upsert(rec);
      localStorage.removeItem(OPEN_KEY);
      toast("Z Raporu kaydedildi", "success");
      if (doPrint) { try { printZReport(rec); } catch {} }
      draw();
    };
    modal({
      title: "Z Raporu", body: el("div", {}, [el("div", { class: "field" }, [el("label", { text: "Sayılan Nakit" }), counted, diffEl])]),
      actions: [
        { label: "🖨 Kapat & Yazdır", kind: "danger", onClick: (c) => { saveShift(true); c(); } },
        { label: "Kapat & Kaydet", kind: "", onClick: (c) => { saveShift(false); c(); } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function pastShifts() {
    const rows = db.shifts.all().sort((a, b) => b.closeTs - a.closeTs).slice(0, 20);
    if (!rows.length) return;
    body.appendChild(el("div", { class: "card", style: "margin-top:16px" }, [
      el("h3", { text: "Geçmiş Vardiyalar" }),
      el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, [el("th", { text: t("date") }), el("th", { text: "Kasiyer" }), el("th", { text: "Beklenen" }), el("th", { text: "Sayılan" }), el("th", { text: "Fark" }), el("th", {})])]),
        el("tbody", {}, rows.map((s) => el("tr", {}, [
          el("td", { class: "muted", text: new Date(s.closeTs).toLocaleDateString("tr-TR") }),
          el("td", { text: s.cashierName || "—" }),
          el("td", { class: "num", text: money(s.expected) }),
          el("td", { class: "num", text: money(s.counted) }),
          el("td", {}, [el("span", { class: "pill " + (s.diff === 0 ? "green" : "red"), text: money(s.diff) })]),
          el("td", { style: "text-align:right" }, [el("button", { class: "iconbtn", title: "Z Raporu Yazdır", onClick: () => printZReport(s) }, ["🖨"])]),
        ]))),
      ]),
    ]));
  }

  draw();
}
function mini(label, value) { return el("div", { class: "stat" }, [el("div", { class: "label", text: label }), el("div", { class: "value num", text: value })]); }
