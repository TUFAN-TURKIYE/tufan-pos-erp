// Personel Skor Sistemi — kasiyer/personel performansını satış verisinden puanlar.
// Ölçütler: satış adedi, ciro, sepet ortalaması, iade oranı → 0-100 skor.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money } from "../core/store.js";

const DAY = 86400000;

export function renderStaffScore(host) {
  const periodSel = el("select", { class: "input", style: "max-width:180px" }, [
    el("option", { value: "7", text: "Son 7 gün" }),
    el("option", { value: "30", text: "Son 30 gün", selected: true }),
    el("option", { value: "90", text: "Son 90 gün" }),
    el("option", { value: "0", text: "Tüm zamanlar" }),
  ]);
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🏅 " + t("navStaffScore") }), el("div", { class: "spacer" }), periodSel]),
    body,
  );

  function draw() {
    clear(body);
    const days = Number(periodSel.value);
    const from = days > 0 ? Date.now() - days * DAY : 0;
    const sales = db.sales.all().filter((s) => Number(s.ts) >= from);

    // Kasiyer bazında topla (void olanlar iade sayılır)
    const map = {}; // id → {name, rev, orders, refunds, refundAmt, basketSum}
    sales.forEach((s) => {
      const id = s.cashierId || s.cashierName || "—";
      const name = s.cashierName || "Bilinmeyen";
      if (!map[id]) map[id] = { name, rev: 0, orders: 0, refunds: 0, refundAmt: 0 };
      const m = map[id];
      if (s.void) { m.refunds++; m.refundAmt += Number(s.refundAmount || s.total || 0); }
      else { m.rev += Number(s.total || 0); m.orders++; }
    });

    const rows = Object.values(map).filter((m) => m.orders > 0 || m.refunds > 0);
    if (!rows.length) {
      body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Bu dönemde personel satış verisi yok." })]));
      return;
    }

    const maxRev = Math.max(...rows.map((m) => m.rev), 1);
    const maxOrd = Math.max(...rows.map((m) => m.orders), 1);
    rows.forEach((m) => {
      m.basket = m.orders ? m.rev / m.orders : 0;
      m.refundRate = m.orders + m.refunds > 0 ? m.refunds / (m.orders + m.refunds) : 0;
      // Skor: %50 ciro payı + %30 adet payı + %20 sepet, iade cezası
      const revScore = m.rev / maxRev * 50;
      const ordScore = m.orders / maxOrd * 30;
      const basketScore = Math.min(20, m.basket / (maxRev / maxOrd || 1) * 20);
      m.score = Math.max(0, Math.round(revScore + ordScore + basketScore - m.refundRate * 25));
    });
    rows.sort((a, b) => b.score - a.score);

    const medals = ["🥇", "🥈", "🥉"];
    rows.forEach((m, i) => {
      const scoreCls = m.score >= 70 ? "green" : m.score >= 40 ? "blue" : "amber";
      body.appendChild(el("div", { class: "card score-card" }, [
        el("div", { class: "score-rank", text: medals[i] || "#" + (i + 1) }),
        el("div", { style: "flex:1;min-width:0" }, [
          el("div", { style: "display:flex;justify-content:space-between;align-items:center;gap:8px" }, [
            el("h3", { style: "margin:0", text: m.name }),
            el("span", { class: "pill " + scoreCls, text: "Skor: " + m.score }),
          ]),
          el("div", { class: "score-bar" }, [el("div", { class: "score-fill", style: "width:" + Math.min(100, m.score) + "%" })]),
          el("div", { class: "score-stats" }, [
            el("span", {}, ["💰 " + money(m.rev)]),
            el("span", {}, ["🧾 " + m.orders + " satış"]),
            el("span", {}, ["🛒 " + money(m.basket) + " sepet"]),
            el("span", { style: m.refunds ? "color:var(--danger,#dc2626)" : "" }, ["↩️ " + m.refunds + " iade"]),
          ]),
        ]),
      ]));
    });
  }

  periodSel.addEventListener("change", draw);
  draw();
}
