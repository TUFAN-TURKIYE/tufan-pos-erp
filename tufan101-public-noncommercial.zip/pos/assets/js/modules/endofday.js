// mod-26 Gün Sonu Raporu — gün boyu yapılan tüm işlemlerin detaylı dökümü.
// Tarih/saat bazlı; satış, gelir, gider, ödeme dağılımı, en çok satanlar, kasiyer
// kırılımı ve düşük stok. Termal (80mm) yazdırılabilir. Gece 00:00'da bildirim düşer.
import { el, clear, toast } from "../core/ui.js";
import { db, money, settings } from "../core/store.js";

// Belirli bir günün [başlangıç, bitiş) zaman aralığı (yerel saat).
function dayRange(d) {
  const s = new Date(d); s.setHours(0, 0, 0, 0);
  const from = s.getTime();
  return { from, to: from + 86400000, date: s };
}

// Bir günün tüm özetini hesapla.
export function computeDaySummary(dateLike = new Date()) {
  const { from, to, date } = dayRange(dateLike);
  const sales = db.sales.all().filter((x) => !x.void && x.ts >= from && x.ts < to);
  const voids = db.sales.all().filter((x) => x.void && x.ts >= from && x.ts < to);
  const txns = db.txns.all().filter((x) => x.ts >= from && x.ts < to);
  const income = txns.filter((x) => x.type === "income");
  const expense = txns.filter((x) => x.type === "expense");

  const revenue = sales.reduce((a, x) => a + (Number(x.total) || 0), 0);
  const incomeSum = income.reduce((a, x) => a + (Number(x.amount) || 0), 0);
  const expenseSum = expense.reduce((a, x) => a + (Number(x.amount) || 0), 0);

  const pay = { cash: 0, card: 0, other: 0 };
  sales.forEach((s) => {
    const m = String(s.method || "").toLowerCase();
    const amt = Number(s.total) || 0;
    if (m === "card" || m === "kart" || m === "kredi" || m === "credit") pay.card += amt;
    else if (m === "cash" || m === "nakit" || m === "") pay.cash += amt;
    else pay.other += amt;
  });

  // Ürün kırılımı
  const prodMap = new Map();
  sales.forEach((sale) => (sale.items || []).forEach((it) => {
    const key = it.name || it.productId || "?";
    const cur = prodMap.get(key) || { name: key, qty: 0, total: 0 };
    cur.qty += Number(it.qty) || 0;
    cur.total += (Number(it.qty) || 0) * (Number(it.price) || 0);
    prodMap.set(key, cur);
  }));
  const topProducts = [...prodMap.values()].sort((a, b) => b.qty - a.qty);
  const itemsSold = topProducts.reduce((a, p) => a + p.qty, 0);

  // Kasiyer kırılımı
  const cashierMap = new Map();
  sales.forEach((s) => {
    const key = s.cashierName || s.cashierId || "—";
    const cur = cashierMap.get(key) || { name: key, count: 0, total: 0 };
    cur.count++; cur.total += Number(s.total) || 0;
    cashierMap.set(key, cur);
  });
  const cashiers = [...cashierMap.values()].sort((a, b) => b.total - a.total);

  const net = revenue + incomeSum - expenseSum;
  const avgTicket = sales.length ? revenue / sales.length : 0;

  return {
    date, from, to, sales, voids, income, expense,
    revenue, incomeSum, expenseSum, net, avgTicket, itemsSold,
    pay, topProducts, cashiers,
  };
}

function dateLabel(d) {
  return new Date(d).toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
}
function timeLabel(ts) {
  return new Date(ts).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}

export function renderEndOfDay(host, dateLike) {
  const state = { date: dateLike ? new Date(dateLike) : new Date() };

  function draw() {
    const sum = computeDaySummary(state.date);
    const s = settings.get();
    clear(host);

    // Başlık + tarih gezinme
    const head = el("div", { class: "view-head" }, [
      el("h1", { text: "🌙 Gün Sonu Raporu" }),
      el("div", { class: "spacer" }),
      el("button", { class: "btn ghost", onClick: () => { state.date = new Date(sum.from - 86400000); draw(); } }, ["◀ Önceki gün"]),
      el("button", { class: "btn ghost", onClick: () => { const n = new Date(sum.from + 86400000); if (n.getTime() <= Date.now()) { state.date = n; draw(); } else toast("İleri tarih seçilemez", "warn"); } }, ["Sonraki gün ▶"]),
      el("button", { class: "btn ghost", onClick: () => { draw(); toast("Yenilendi", "success"); } }, ["↻ Yenile"]),
      el("button", { class: "btn", onClick: () => printReport(sum, s) }, ["🖨 Yazdır"]),
    ]);
    host.appendChild(head);

    host.appendChild(el("div", { class: "card", style: "margin-bottom:12px" }, [
      el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap" }, [
        el("span", { style: "font-size:22px", text: "📅" }),
        el("b", { style: "font-size:17px", text: dateLabel(sum.date) }),
        el("span", { class: "muted", style: "font-size:13px", text: "· Rapor oluşturma: " + new Date().toLocaleString("tr-TR") }),
      ]),
    ]));

    // KPI özet
    host.appendChild(el("div", { class: "kpi-grid" }, [
      kpi("💰", "Toplam Ciro", money(sum.revenue), sum.sales.length + " satış", "blue"),
      kpi("🧾", "Ort. Sepet", money(sum.avgTicket), sum.itemsSold + " ürün satıldı", "violet"),
      kpi("➕", "Ek Gelir", money(sum.incomeSum), sum.income.length + " kayıt", "green"),
      kpi("➖", "Gider", money(sum.expenseSum), sum.expense.length + " kayıt", "amber"),
      kpi("🪙", "Net Akış", money(sum.net), "ciro + gelir − gider", sum.net >= 0 ? "green" : "red"),
      kpi("🚫", "İptal/İade", String(sum.voids.length), "iptal edilen fiş", sum.voids.length ? "red" : "slate"),
    ]));

    // Ödeme dağılımı
    const payTotal = sum.pay.cash + sum.pay.card + sum.pay.other;
    host.appendChild(el("div", { class: "card" }, [
      el("div", { class: "card-head" }, [el("h3", { text: "💳 Ödeme Dağılımı" }), el("span", { class: "pill slate", text: "Toplam " + money(payTotal) })]),
      payTotal > 0
        ? el("div", {}, [
            payRow("💵 Nakit", sum.pay.cash, payTotal, "#22C55E"),
            payRow("💳 Kart", sum.pay.card, payTotal, "#2563EB"),
            sum.pay.other > 0 ? payRow("🧾 Diğer", sum.pay.other, payTotal, "#94A3B8") : null,
          ])
        : el("p", { class: "muted", text: "Bu gün satış yok." }),
    ]));

    // İki sütun: En çok satanlar + Kasiyer performansı
    const cols = el("div", { class: "dash-cols" });
    cols.appendChild(el("div", { class: "card" }, [
      el("div", { class: "card-head" }, [el("h3", { text: "🔥 En Çok Satanlar" })]),
      sum.topProducts.length
        ? el("div", { class: "mini-list" }, sum.topProducts.slice(0, 10).map((p, i) =>
            el("div", { class: "mini-row" }, [
              el("span", { class: "rank rank-" + (i < 3 ? i + 1 : "n"), text: String(i + 1) }),
              el("span", { class: "mini-name", text: p.name }),
              el("span", { class: "pill slate", text: p.qty + " adet" }),
              el("b", { class: "num", text: money(p.total) }),
            ])
          ))
        : el("p", { class: "muted", text: "Satış yok." }),
    ]));
    cols.appendChild(el("div", { class: "card" }, [
      el("div", { class: "card-head" }, [el("h3", { text: "👤 Kasiyer Performansı" })]),
      sum.cashiers.length
        ? el("div", { class: "mini-list" }, sum.cashiers.map((c) =>
            el("div", { class: "mini-row" }, [
              el("span", { class: "mini-name", text: c.name }),
              el("span", { class: "pill blue", text: c.count + " satış" }),
              el("b", { class: "num", text: money(c.total) }),
            ])
          ))
        : el("p", { class: "muted", text: "Satış yok." }),
    ]));
    host.appendChild(cols);

    // Detaylı işlem zaman çizelgesi (tarih/saat yazsın)
    const timeline = [
      ...sum.sales.map((x) => ({ ts: x.ts, kind: "sale", label: (x.items || []).length + " ürün satış", amount: Number(x.total) || 0, extra: (x.method === "card" ? "💳 Kart" : "💵 Nakit") + (x.cashierName ? " · " + x.cashierName : "") })),
      ...sum.income.map((x) => ({ ts: x.ts, kind: "income", label: "Gelir: " + (x.note || x.category || "-"), amount: Number(x.amount) || 0, extra: "" })),
      ...sum.expense.map((x) => ({ ts: x.ts, kind: "expense", label: "Gider: " + (x.note || x.category || "-"), amount: -(Number(x.amount) || 0), extra: "" })),
      ...sum.voids.map((x) => ({ ts: x.ts, kind: "void", label: "İptal/İade fişi", amount: -(Number(x.total) || 0), extra: x.cashierName || "" })),
    ].sort((a, b) => a.ts - b.ts);

    host.appendChild(el("div", { class: "card" }, [
      el("div", { class: "card-head" }, [el("h3", { text: "🕓 Gün İçi İşlem Dökümü" }), el("span", { class: "pill slate", text: timeline.length + " işlem" })]),
      timeline.length
        ? el("div", { class: "eod-timeline" }, timeline.map((r) =>
            el("div", { class: "eod-row eod-" + r.kind }, [
              el("span", { class: "eod-time num", text: timeLabel(r.ts) }),
              el("span", { class: "eod-ico", text: r.kind === "sale" ? "🛒" : r.kind === "income" ? "➕" : r.kind === "expense" ? "➖" : "🚫" }),
              el("span", { class: "eod-label" }, [el("div", { text: r.label }), r.extra ? el("div", { class: "muted", style: "font-size:12px", text: r.extra }) : null]),
              el("b", { class: "num eod-amt", style: "color:" + (r.amount >= 0 ? "var(--success)" : "var(--danger)"), text: (r.amount >= 0 ? "+" : "") + money(r.amount) }),
            ])
          ))
        : el("p", { class: "muted", text: "Bu gün için kayıt yok." }),
    ]));
  }

  draw();

  // Yeni satışlar anında yansısın: bugünü izlerken 15 sn'de bir otomatik tazele.
  const timer = setInterval(() => {
    if (!document.body.contains(host)) { clearInterval(timer); return; }
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const shown = new Date(state.date); shown.setHours(0, 0, 0, 0);
    if (shown.getTime() === today.getTime()) draw(); // sadece "bugün" görünümünde
  }, 15000);
}

function kpi(icon, label, value, sub, color) {
  return el("div", { class: "kpi kpi-" + color }, [
    el("div", { class: "kpi-ico", text: icon }),
    el("div", { class: "kpi-body" }, [
      el("div", { class: "kpi-lbl", text: label }),
      el("div", { class: "kpi-val num", text: value }),
      el("div", { class: "kpi-sub", text: sub }),
    ]),
  ]);
}
function payRow(lbl, val, total, color) {
  const pct = total > 0 ? Math.round((val / total) * 100) : 0;
  return el("div", { class: "paybar-row", style: "margin:8px 0" }, [
    el("div", { class: "paybar-head" }, [el("span", { text: lbl }), el("b", { class: "num", text: money(val) + "  ·  %" + pct })]),
    el("div", { class: "paybar-track" }, [el("div", { class: "paybar-fill", style: `width:${pct}%;background:${color}` })]),
  ]);
}

// ---- Termal (80mm) yazdırma ----
function printReport(sum, s) {
  const biz = (s && s.business) || "İşletme";
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[m]));
  const payTotal = sum.pay.cash + sum.pay.card + sum.pay.other;
  const w = window.open("", "_blank", "width=380,height=700");
  if (!w) { toast("Açılır pencere engellendi", "warn"); return; }
  const rows = (label, val) => `<div class="r"><span>${esc(label)}</span><b>${esc(val)}</b></div>`;
  w.document.write(`<!DOCTYPE html><html><head><meta charset="utf-8"><title>Gün Sonu</title><style>
    *{font-family:'Courier New',monospace;box-sizing:border-box}
    body{width:80mm;margin:0;padding:8px 10px;color:#000}
    h2{text-align:center;margin:4px 0;font-size:16px}
    .muted{color:#333;text-align:center;font-size:12px;margin-bottom:6px}
    hr{border:none;border-top:1px dashed #000;margin:6px 0}
    .r{display:flex;justify-content:space-between;font-size:13px;margin:2px 0}
    .big{font-size:15px;font-weight:bold}
    .sec{font-weight:bold;margin-top:6px;font-size:13px}
    .foot{text-align:center;font-size:11px;margin-top:8px}
  </style></head><body>
    <h2>${esc(biz)}</h2>
    <div class="muted">GÜN SONU RAPORU<br>${esc(dateLabel(sum.date))}</div>
    <hr>
    ${rows("Satış adedi", sum.sales.length)}
    ${rows("Satılan ürün", sum.itemsSold)}
    ${rows("Toplam ciro", money(sum.revenue))}
    ${rows("Ort. sepet", money(sum.avgTicket))}
    <hr>
    <div class="sec">ÖDEME</div>
    ${rows("Nakit", money(sum.pay.cash))}
    ${rows("Kart", money(sum.pay.card))}
    ${sum.pay.other > 0 ? rows("Diğer", money(sum.pay.other)) : ""}
    ${rows("Toplam tahsilat", money(payTotal))}
    <hr>
    ${rows("Ek gelir", money(sum.incomeSum))}
    ${rows("Gider", money(sum.expenseSum))}
    ${rows("İptal/İade", sum.voids.length + " fiş")}
    <hr>
    <div class="r big"><span>NET AKIŞ</span><b>${esc(money(sum.net))}</b></div>
    <hr>
    <div class="sec">EN ÇOK SATANLAR</div>
    ${sum.topProducts.slice(0, 8).map((p) => rows(p.qty + "x " + p.name, money(p.total))).join("")}
    ${sum.cashiers.length ? '<hr><div class="sec">KASİYER</div>' + sum.cashiers.map((c) => rows(c.name, c.count + " · " + money(c.total))).join("") : ""}
    <div class="foot">TUFAN 101 ile hazırlandı<br>Bu belge bilgilendirme amaçlıdır; mali değeri yoktur.</div>
    <script>window.onload=()=>{window.print();setTimeout(()=>window.close(),400);}<\/script>
  </body></html>`);
  w.document.close();
}
