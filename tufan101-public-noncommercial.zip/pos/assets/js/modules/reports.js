// mod-07 Dışa Aktarım (PDF/Excel) + mod-08 OCR/Kamera ile barkod okuma
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";
import { printReceipt } from "./pos.js";

export function renderReports(host) {
  const head = el("div", { class: "view-head" }, [el("h1", { text: t("reports") })]);
  const grid = el("div", { class: "grid", style: "grid-template-columns:repeat(auto-fill,minmax(240px,1fr))" });

  // Her rapor için hem PDF hem CSV
  grid.append(
    tool("🧾", "Satış Dökümü", "Satış listesi ve ciro", [
      ["📄 PDF", () => printReport("sales")], ["📊 CSV", () => exportCsv("sales")],
    ]),
    tool("📦", "Stok Listesi", "Ürünler ve stok durumu", [
      ["📄 PDF", () => printReport("products")], ["📊 CSV", () => exportCsv("products")],
    ]),
    tool("💹", "Gelir / Gider", "Kasa hareketleri", [
      ["📄 PDF", () => printReport("txns")], ["📊 CSV", () => exportCsv("txns")],
    ]),
    tool("🖨", "Fiş Tekrar Yazdır", "Geçmiş bir satışın fişini yeniden bas", [
      ["🧾 Satış Seç", () => reprintReceiptPicker()],
    ]),
    tool("📷", "Kamera ile Barkod", "OCR / kamera oku", [
      ["📷 Kamerayı Aç", () => cameraScan()],
    ]),
  );

  clear(host).append(head, grid);
}

function tool(icon, title, sub, buttons) {
  return el("div", { class: "card", style: "text-align:left" }, [
    el("div", { style: "font-size:32px", text: icon }),
    el("div", { style: "font-weight:700;margin-top:8px", text: title }),
    el("div", { class: "muted", style: "margin-bottom:10px", text: sub }),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, buttons.map(([label, onClick]) =>
      el("button", { class: "btn ghost", style: "flex:1;min-width:110px", onClick }, [label])
    )),
  ]);
}

function exportCsv(kind) {
  let rows = [], name = kind;
  if (kind === "sales") {
    rows.push(["Tarih", "Kasiyer", "Yöntem", "Ürünler", "Adet", "Toplam"]);
    db.sales.all().filter((s) => !s.void).forEach((s) =>
      rows.push([new Date(s.ts).toLocaleString("tr-TR"), s.cashierName || "", s.method, itemsSummary(s, 20), s.items.reduce((a, i) => a + i.qty, 0), s.total]));
  } else if (kind === "products") {
    rows.push(["Ad", "Barkod", "Fiyat", "Maliyet", "Stok"]);
    db.products.all().forEach((p) => rows.push([p.name, p.barcode || "", p.price, p.cost, p.stock]));
  } else if (kind === "txns") {
    rows.push(["Tarih", "Tür", "Tutar", "Not"]);
    db.txns.all().forEach((x) => rows.push([new Date(x.ts).toLocaleString("tr-TR"), x.type, x.amount, x.note || ""]));
  }
  const csv = "﻿" + rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob); a.download = `tufan101-${name}-${Date.now()}.csv`; a.click();
  toast(t("export") + " ✓", "success");
}

// Geçmiş satışlardan birini seçip fişini yeniden yazdır
function reprintReceiptPicker() {
  const sales = db.sales.all().slice().sort((a, b) => (b.ts || 0) - (a.ts || 0)).slice(0, 50);
  if (!sales.length) { toast("Henüz satış yok.", "warn"); return; }
  const list = el("div", { style: "display:flex;flex-direction:column;gap:6px;max-height:52vh;overflow:auto;margin-top:8px" },
    sales.map((s) => el("button", {
      class: "btn ghost",
      style: "justify-content:space-between;text-align:left;display:flex;gap:10px" + (s.void ? ";opacity:.55" : ""),
      onClick: () => { printReceipt(s); },
    }, [
      el("span", { style: "min-width:0;flex:1" }, [
        el("div", { style: "font-weight:700", text: itemsSummary(s) + (s.void ? "  (İPTAL)" : "") }),
        el("div", { class: "muted", style: "font-size:11px", text: `${new Date(s.ts).toLocaleString("tr-TR")} • ${(s.items || []).reduce((a, i) => a + (i.qty || 0), 0)} ürün • ${s.method === "card" ? "Kart" : "Nakit"}${s.cashierName ? " • " + s.cashierName : ""}` }),
      ]),
      el("b", { text: money(s.total || 0) }),
    ]))
  );
  modal({
    title: "🧾 Fiş Tekrar Yazdır",
    body: el("div", {}, [el("p", { class: "muted", text: "Son 50 satış listelenir. Fişini yazdırmak için satışa dokunun." }), list]),
    actions: [{ label: "Kapat", kind: "ghost" }],
  });
}

function esc(v) { return String(v == null ? "" : v).replace(/[&<>"]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[m])); }

// Satışın ürünlerini "Çay×2, Kola×1 +2" gibi kısa bir özete çevirir.
function itemsSummary(s, maxNames) {
  const its = (s && s.items) || [];
  if (!its.length) return "—";
  const max = maxNames || 3;
  const txt = its.slice(0, max).map((i) => (i.name || i.productName || "Ürün") + "×" + (i.qty || 1)).join(", ");
  return txt + (its.length > max ? " +" + (its.length - max) : "");
}

function printReport(kind) {
  const biz = settings.get().business || "TUFAN 101";
  let title, cols, rows, tot = "";
  if (kind === "products") {
    const ps = db.products.all();
    title = "Stok Listesi"; cols = ["Ad", "Barkod", "Fiyat", "Maliyet", "Stok"];
    rows = ps.map((p) => [p.name, p.barcode || "", money(p.price), money(p.cost || 0), String(p.stock)]);
    tot = "Toplam ürün: " + ps.length;
  } else if (kind === "txns") {
    const tx = db.txns.all().slice().sort((a, b) => b.ts - a.ts);
    title = "Gelir / Gider"; cols = ["Tarih", "Tür", "Not", "Tutar"];
    rows = tx.map((x) => [new Date(x.ts).toLocaleString("tr-TR"), x.type === "income" ? "Gelir" : "Gider", x.note || "", money(x.amount)]);
    const inc = tx.filter((x) => x.type === "income").reduce((a, x) => a + x.amount, 0);
    const exp = tx.filter((x) => x.type === "expense").reduce((a, x) => a + x.amount, 0);
    tot = `Gelir: ${money(inc)}  •  Gider: ${money(exp)}  •  Bakiye: ${money(inc - exp)}`;
  } else {
    const sales = db.sales.all().filter((s) => !s.void);
    title = "Satış Dökümü"; cols = ["Tarih", "Kasiyer", "Yöntem", "Ürünler", "Toplam"];
    rows = sales.map((s) => [new Date(s.ts).toLocaleString("tr-TR"), s.cashierName || "", s.method, itemsSummary(s, 8), money(s.total)]);
    tot = "Genel Toplam: " + money(sales.reduce((a, s) => a + s.total, 0));
  }
  const w = window.open("", "_blank");
  if (!w) { toast("Açılır pencere engellendi (PDF için izin verin)", "warn"); return; }
  w.document.write(`<html><head><meta charset="utf-8"><title>${esc(biz)} — ${esc(title)}</title>
    <style>body{font-family:Arial,Helvetica,sans-serif;padding:24px;color:#0F172A}
    h1{color:#2563EB;margin:0 0 2px} .sub{color:#64748B;font-size:13px;margin-bottom:14px}
    table{width:100%;border-collapse:collapse;margin-top:8px}
    td,th{border-bottom:1px solid #E2E8F0;padding:8px;text-align:left;font-size:13px}
    th{background:#F1F5F9} .tot{font-size:18px;font-weight:bold;margin-top:16px}
    .foot{margin-top:28px;color:#94A3B8;font-size:11px;text-align:center;border-top:1px solid #E2E8F0;padding-top:10px}</style></head><body>
    <h1>${esc(biz)}</h1><div class="sub">${esc(title)} — ${esc(new Date().toLocaleString("tr-TR"))}</div>
    <table><thead><tr>${cols.map((c) => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>
    ${rows.map((r) => `<tr>${r.map((c) => `<td>${esc(c)}</td>`).join("")}</tr>`).join("") || `<tr><td colspan="${cols.length}">—</td></tr>`}
    </tbody></table><div class="tot">${esc(tot)}</div>
    <div class="foot">TUFAN 101 • Bu yapı Balıkesir / Doruk Tufan'a aittir.</div>
    <script>window.onload=()=>window.print()<\/script></body></html>`);
  w.document.close();
}

async function cameraScan() {
  // BarcodeDetector destekliyse gerçek okuma; değilse kamera önizleme (mod-08)
  const video = el("video", { autoplay: true, playsinline: true, style: "width:100%;border-radius:12px;background:#000" });
  const info = el("div", { class: "muted", style: "margin-top:8px", text: "Barkodu kameraya gösterin…" });
  const close = modal({ title: "📷 Kamera ile Barkod", body: el("div", {}, [video, info]),
    actions: [{ label: t("close"), kind: "ghost", onClick: (c) => { stop(); c(); } }] });
  let stream, raf, stopped = false;
  const stop = () => { stopped = true; if (raf) cancelAnimationFrame(raf); stream?.getTracks().forEach((tr) => tr.stop()); };
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
    video.srcObject = stream;
    if ("BarcodeDetector" in window) {
      const det = new window.BarcodeDetector();
      const tick = async () => {
        if (stopped) return;
        try { const codes = await det.detect(video); if (codes[0]) { onCode(codes[0].rawValue); return; } } catch {}
        raf = requestAnimationFrame(tick);
      };
      raf = requestAnimationFrame(tick);
    } else {
      info.textContent = "Bu tarayıcı otomatik okumayı desteklemiyor; kamera önizlemesi aktif.";
    }
  } catch { info.textContent = "Kameraya erişilemedi."; }
  function onCode(val) {
    stop(); close();
    const p = db.products.all().find((x) => x.barcode === val);
    if (p) toast(`✓ ${p.name} (${val})`, "success");
    else toast("Barkod: " + val + " — kayıtlı ürün yok", "warn");
  }
}
