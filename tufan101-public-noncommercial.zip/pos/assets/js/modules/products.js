// Ürünler & Stok yönetimi — kapsamlı: barkod tarama/üretme/etiket, stok hareketi, min-stok uyarısı (mod-15)
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, settings } from "../core/store.js";
import { can } from "../core/auth.js";
import { drawEAN13, generateEAN13, scanBarcode, scannerSupported, isValidEAN13 } from "../core/barcode.js";

// Seçilen görseli küçültüp dataURL olarak döndürür (localStorage'ı şişirmemek için).
function fileToDataURL(file, max = 640) {
  return new Promise((resolve, reject) => {
    if (!file) return resolve("");
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const scale = Math.min(1, max / Math.max(img.width, img.height));
        const w = Math.max(1, Math.round(img.width * scale));
        const h = Math.max(1, Math.round(img.height * scale));
        const canvas = document.createElement("canvas");
        canvas.width = w; canvas.height = h;
        canvas.getContext("2d").drawImage(img, 0, 0, w, h);
        try { resolve(canvas.toDataURL("image/jpeg", 0.82)); }
        catch { resolve(reader.result); }
      };
      img.onerror = reject;
      img.src = reader.result;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

const UNITS = ["adet", "kg", "gr", "lt", "ml", "paket", "kutu", "koli"];

// Yedek parça alanları (OEM no, çapraz referans, araç uyumu, raf) yalnızca
// Ayarlar'dan açıkça etkinleştirildiğinde gösterilir.
function isAutoSector() {
  return settings.get().autoParts === true;
}

export function renderProducts(host) {
  const canEdit = can("manageStock");
  const canPrice = can("changePrice");
  let filter = "all"; // all | low | out

  const search = el("input", { class: "input", placeholder: t("search") + " / barkod…", style: "max-width:240px" });
  const scanBtn = el("button", { class: "iconbtn", title: "Barkod Tara", onClick: () => scanBarcode((code) => { search.value = code; draw(); }) }, ["📷"]);
  const filterSel = el("select", { class: "input", style: "max-width:150px" }, [
    el("option", { value: "all", text: "Tümü" }),
    el("option", { value: "low", text: "Kritik Stok" }),
    el("option", { value: "out", text: "Tükenen" }),
  ]);
  filterSel.addEventListener("change", () => { filter = filterSel.value; draw(); });

  const head = el("div", { class: "view-head" }, [
    el("h1", { text: "📦 " + t("products") }),
    el("div", { class: "spacer" }),
    search, scanBtn, filterSel,
    el("button", { class: "btn ghost", title: "CSV Dışa Aktar", onClick: exportCSV }, ["⬇️ CSV"]),
    canEdit ? el("button", { class: "btn success", onClick: () => editProduct(null, () => draw()) }, ["+ " + t("add")]) : null,
  ]);
  const statsWrap = el("div", { class: "stat-grid" });
  const tableWrap = el("div", { class: "card", style: "margin-top:16px" });
  clear(host).append(head, statsWrap, tableWrap);

  function stat(label, value, color) {
    return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
      el("div", { class: "label", text: label }),
      el("div", { class: "value num", text: value }),
    ]);
  }

  function drawStats() {
    const all = db.products.all();
    const totalStock = all.reduce((a, p) => a + (Number(p.stock) || 0), 0);
    const costVal = all.reduce((a, p) => a + (Number(p.stock) || 0) * (Number(p.cost) || 0), 0);
    const retailVal = all.reduce((a, p) => a + (Number(p.stock) || 0) * (Number(p.price) || 0), 0);
    const low = all.filter((p) => (Number(p.stock) || 0) <= (p.minStock ?? 5) && (Number(p.stock) || 0) > 0).length;
    const out = all.filter((p) => (Number(p.stock) || 0) <= 0).length;
    clear(statsWrap).append(
      stat("Ürün Çeşidi", String(all.length), "var(--primary)"),
      stat("Toplam Stok", String(totalStock), "#0ea5e9"),
      stat("Maliyet Değeri", money(costVal), "var(--warning)"),
      stat("Satış Değeri", money(retailVal), "var(--success)"),
      stat("Kritik Stok", String(low), "#f59e0b"),
      stat("Tükenen", String(out), "var(--danger)"),
    );
  }

  function draw() {
    drawStats();
    const q = search.value.trim().toLowerCase();
    const cats = Object.fromEntries(db.categories.all().map((c) => [c.id, c]));
    let list = db.products.all().filter((p) => !q || p.name.toLowerCase().includes(q) || (p.barcode || "").includes(q)
      || (p.oemNo || "").toLowerCase().includes(q) || (p.crossRef || "").toLowerCase().includes(q) || (p.vehicleFit || "").toLowerCase().includes(q));
    if (filter === "low") list = list.filter((p) => (Number(p.stock) || 0) <= (p.minStock ?? 5) && (Number(p.stock) || 0) > 0);
    if (filter === "out") list = list.filter((p) => (Number(p.stock) || 0) <= 0);

    clear(tableWrap);
    if (!list.length) { tableWrap.appendChild(el("p", { class: "muted", text: t("noProducts") })); return; }
    tableWrap.appendChild(el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [
        el("th", { text: t("image") }), el("th", { text: t("name") }), el("th", { text: "Barkod" }), el("th", { text: t("categories") }),
        el("th", { text: t("price") }), el("th", { text: t("cost") }), el("th", { text: t("stock") }), el("th", { text: "Birim" }), el("th", {}),
      ])]),
      el("tbody", {}, list.map((p) => {
        const stock = Number(p.stock) || 0;
        const min = p.minStock ?? 5;
        const stockClass = stock <= 0 ? "red" : stock <= min ? "amber" : "green";
        return el("tr", {}, [
          el("td", {}, [
            p.image
              ? el("img", { class: "prod-thumb", src: p.image, alt: p.name })
              : el("span", { class: "prod-thumb-emoji", text: p.emoji || "📦" }),
          ]),
          el("td", {}, [
            el("div", { text: p.name }),
            (p.oemNo || p.crossRef || p.vehicleFit || p.shelf)
              ? el("div", { class: "muted", style: "font-size:11px;margin-top:2px" }, [
                  [p.oemNo ? "OEM: " + p.oemNo : "", p.vehicleFit ? "🚗 " + p.vehicleFit : "", p.shelf ? "📍 " + p.shelf : ""].filter(Boolean).join("  •  "),
                ])
              : null,
          ]),
          el("td", { class: "muted num", text: p.barcode || "—" }),
          el("td", { text: cats[p.categoryId] ? cats[p.categoryId].name : "—" }),
          el("td", { class: "num", text: money(p.price) }),
          el("td", { class: "num muted", text: money(p.cost) }),
          el("td", {}, [el("span", { class: "pill " + stockClass, text: String(stock) })]),
          el("td", { class: "muted", text: p.unit || "adet" }),
          el("td", { style: "text-align:right;white-space:nowrap" }, canEdit ? [
            el("button", { class: "iconbtn", title: "Stok Girişi", style: "display:inline-grid", onClick: () => stockMove(p, "in") }, ["➕"]),
            el("button", { class: "iconbtn", title: "Stok Çıkışı", style: "display:inline-grid;margin-left:4px", onClick: () => stockMove(p, "out") }, ["➖"]),
            el("button", { class: "iconbtn", title: "Barkod Etiketi", style: "display:inline-grid;margin-left:4px", onClick: () => printLabel(p) }, ["🏷️"]),
            el("button", { class: "iconbtn", title: t("edit"), style: "display:inline-grid;margin-left:4px", onClick: () => editProduct(p, () => draw()) }, ["✏️"]),
            el("button", { class: "iconbtn", title: t("delete"), style: "display:inline-grid;margin-left:4px", onClick: () => confirmDialog(t("delete") + "?", () => { db.products.remove(p.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
          ] : [el("span", { class: "muted", text: "—" })]),
        ]);
      })),
    ]));
  }

  // ---- Stok giriş/çıkış hareketi ----
  function stockMove(p, dir) {
    const qty = el("input", { class: "input num", type: "number", min: "1", value: "1", autofocus: true });
    const reason = el("input", { class: "input", placeholder: dir === "in" ? "Alım / iade / sayım" : "Fire / zayi / düzeltme" });
    const cur = Number(p.stock) || 0;
    modal({
      title: (dir === "in" ? "➕ Stok Girişi" : "➖ Stok Çıkışı") + " — " + p.name,
      body: el("div", {}, [
        el("p", { class: "muted", text: "Mevcut stok: " + cur + " " + (p.unit || "adet") }),
        el("div", { class: "field" }, [el("label", { text: "Miktar" }), qty]),
        el("div", { class: "field" }, [el("label", { text: "Açıklama" }), reason]),
      ]),
      actions: [
        { label: t("save"), kind: dir === "in" ? "success" : "danger", onClick: (close) => {
          const n = Math.abs(parseInt(qty.value) || 0);
          if (!n) { toast("Miktar girin", "warn"); return; }
          const delta = dir === "in" ? n : -n;
          const newStock = Math.max(0, cur + delta);
          db.products.upsert({ ...p, stock: newStock });
          db.stockMoves.upsert({ id: uid(), productId: p.id, productName: p.name, dir, qty: n, reason: reason.value.trim(), before: cur, after: newStock, ts: Date.now() });
          toast(p.name + ": " + cur + " → " + newStock, "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  // ---- Barkod etiketi yazdır ----
  function printLabel(p) {
    let code = (p.barcode || "").replace(/\D/g, "");
    if (!isValidEAN13(code)) code = generateEAN13();
    const canvas = document.createElement("canvas");
    drawEAN13(canvas, code, { unit: 2, height: 70 });
    const img = canvas.toDataURL("image/png");
    const w = window.open("", "_blank", "width=420,height=320");
    if (!w) { toast("Açılır pencere engellendi", "warn"); return; }
    w.document.write(`<!doctype html><html><head><title>Etiket</title>
      <style>body{font-family:system-ui,Arial;text-align:center;margin:0;padding:14px}
      .name{font-weight:700;font-size:15px;margin:4px 0}
      .price{font-size:18px;font-weight:800;margin:4px 0}
      img{margin-top:6px}@media print{@page{margin:6mm}}</style></head>
      <body onload="window.print()">
      <div class="name">${escapeHtml(p.name)}</div>
      <div class="price">${escapeHtml(money(p.price))}</div>
      <img src="${img}" alt="barkod">
      </body></html>`);
    w.document.close();
  }

  // ---- CSV dışa aktar ----
  function exportCSV() {
    const cats = Object.fromEntries(db.categories.all().map((c) => [c.id, c.name]));
    const auto = isAutoSector();
    const head = ["Ad", "Barkod", "Kategori", "Fiyat", "Maliyet", "Stok", "Min", "Birim"];
    if (auto) head.push("OEM No", "Çapraz Referans", "Araç Uyumu", "Raf");
    const rows = [head];
    db.products.all().forEach((p) => {
      const r = [p.name, p.barcode || "", cats[p.categoryId] || "", p.price || 0, p.cost || 0, p.stock || 0, p.minStock ?? 5, p.unit || "adet"];
      if (auto) r.push(p.oemNo || "", p.crossRef || "", p.vehicleFit || "", p.shelf || "");
      rows.push(r);
    });
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
    const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
    const a = el("a", { href: URL.createObjectURL(blob), download: "stok-listesi.csv" });
    document.body.appendChild(a); a.click(); a.remove();
    toast("CSV indirildi", "success");
  }

  // ---- Ürün ekle/düzenle ----
  function editProduct(p, done) {
    const isNew = !p; p = p || { emoji: "📦", active: true, stock: 0, price: 0, cost: 0, minStock: 5, unit: "adet" };
    const f = {};
    const row = (label, node, k) => { f[k] = node; return el("div", { class: "field" }, [el("label", { text: label }), node]); };
    const catOpts = db.categories.all().map((c) => el("option", { value: c.id, ...(c.id === p.categoryId ? { selected: true } : {}) }, [c.name]));
    const unitOpts = UNITS.map((u) => el("option", { value: u, ...(u === (p.unit || "adet") ? { selected: true } : {}) }, [u]));

    // Görsel yükleme
    let imageData = p.image || "";
    const preview = el("img", { class: "prod-img-preview", alt: p.name || "", ...(imageData ? { src: imageData } : { style: "display:none" }) });
    const placeholder = el("div", { class: "prod-img-ph", ...(imageData ? { style: "display:none" } : {}) }, [p.emoji || "🖼️"]);
    const fileInput = el("input", { type: "file", accept: "image/*", class: "input" });
    const removeBtn = el("button", { class: "btn ghost", type: "button", onClick: () => {
      imageData = ""; preview.removeAttribute("src"); preview.style.display = "none"; placeholder.style.display = ""; fileInput.value = "";
    } }, ["🗑 " + t("delete")]);
    fileInput.addEventListener("change", async () => {
      const file = fileInput.files && fileInput.files[0];
      if (!file) return;
      try {
        imageData = await fileToDataURL(file);
        preview.src = imageData; preview.style.display = ""; placeholder.style.display = "none";
      } catch { toast(t("image") + " ✗", "error"); }
    });
    const imageField = el("div", { class: "field" }, [
      el("label", { text: t("image") }),
      el("div", { class: "prod-img-picker" }, [
        el("div", { class: "prod-img-box" }, [preview, placeholder]),
        el("div", { style: "display:flex;flex-direction:column;gap:8px;flex:1;min-width:0" }, [fileInput, removeBtn]),
      ]),
    ]);

    // Barkod alanı + Tara / Üret / Önizleme
    const barcodeInput = el("input", { class: "input", value: p.barcode || "", placeholder: "13 haneli EAN-13 veya elle" });
    const barCanvas = el("canvas", { style: "max-width:100%" });
    const renderPreview = () => {
      const c = (barcodeInput.value || "").replace(/\D/g, "");
      if (isValidEAN13(c)) { barCanvas.style.display = ""; drawEAN13(barCanvas, c, { unit: 2, height: 56 }); }
      else barCanvas.style.display = "none";
    };
    barcodeInput.addEventListener("input", renderPreview);
    const scanB = el("button", { class: "btn ghost", type: "button", title: "Kamerayla oku", disabled: !scannerSupported(), onClick: () => scanBarcode((code) => { barcodeInput.value = code; renderPreview(); }) }, ["📷 Tara"]);
    const genB = el("button", { class: "btn ghost", type: "button", title: "Otomatik üret", onClick: () => { barcodeInput.value = generateEAN13(); renderPreview(); } }, ["🎲 Üret"]);
    f.barcode = barcodeInput;
    const barcodeField = el("div", { class: "field" }, [
      el("label", { text: "Barkod" }),
      el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [
        el("div", { style: "flex:1;min-width:160px" }, [barcodeInput]), scanB, genB,
      ]),
      barCanvas,
    ]);
    setTimeout(renderPreview, 0);

    // GS1 Barkodu (Harici/Opsiyonel) — yalnızca Ayarlar'dan açıksa görünür.
    // Market gibi resmi satış yapan işletme, GS1'den aldığı EAN/GTIN'i buraya yükler.
    const gs1On = !!settings.get().gs1Enabled;
    const gtinInput = el("input", { class: "input", inputmode: "numeric", value: p.gtin || "", placeholder: "GS1'den alınan resmi EAN/GTIN (8–14 hane)" });
    f.gtin = gtinInput;
    const gtinField = gs1On ? el("div", { class: "field" }, [
      el("label", { text: "GS1 Barkodu — EAN/GTIN (Opsiyonel)" }),
      gtinInput,
      el("div", { class: "muted", style: "font-size:12px;margin-top:4px", text: "Resmi GS1 üyeliğiyle alınan küresel barkod. Girilirse satış/etiket bu kodu kullanır. (Ayarlar → GS1 barkodundan açıp kapatabilirsiniz.)" }),
    ]) : null;

    // Oto yedek parça alanları — yalnızca otomotiv/yedek parça sektörlerinde görünür
    const autoParts = isAutoSector();
    const autoField = autoParts ? el("div", { style: "margin-top:6px;padding-top:12px;border-top:1px dashed var(--border)" }, [
      el("div", { class: "muted", style: "font-size:12px;font-weight:700;margin-bottom:8px", text: "🔧 Yedek Parça Bilgileri" }),
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
        row("OEM / Orijinal No", el("input", { class: "input", value: p.oemNo || "", placeholder: "Örn: 06A115561B" }), "oemNo"),
        row("Çapraz Referans / Muadil", el("input", { class: "input", value: p.crossRef || "", placeholder: "Muadil parça no(ları)" }), "crossRef"),
      ]),
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px;margin-top:12px" }, [
        row("Araç Uyumu (Marka/Model/Yıl)", el("input", { class: "input", value: p.vehicleFit || "", placeholder: "Örn: VW Golf 2015-2020" }), "vehicleFit"),
        row("Raf / Lokasyon", el("input", { class: "input", value: p.shelf || "", placeholder: "Örn: A3-Raf-2" }), "shelf"),
      ]),
    ]) : null;

    const body = el("div", {}, [
      imageField,
      row(t("name"), el("input", { class: "input", value: p.name || "" }), "name"),
      barcodeField,
      gtinField,
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
        row(t("categories"), el("select", { class: "input" }, catOpts), "categoryId"),
        row("Birim", el("select", { class: "input" }, unitOpts), "unit"),
      ]),
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:12px" }, [
        row(t("price"), el("input", { class: "input num", type: "number", step: "0.01", value: p.price, ...(canPrice ? {} : { disabled: true }) }), "price"),
        row(t("cost"), el("input", { class: "input num", type: "number", step: "0.01", value: p.cost }), "cost"),
        row(t("stock"), el("input", { class: "input num", type: "number", value: p.stock }), "stock"),
        row("Min. Stok", el("input", { class: "input num", type: "number", value: p.minStock ?? 5 }), "minStock"),
      ]),
      autoField,
    ]);
    modal({
      title: isNew ? "➕ " + t("add") : "✏️ " + t("edit"),
      body,
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          const bc = (f.barcode.value || "").trim();
          if (bc && bc.replace(/\D/g, "").length === 13 && !isValidEAN13(bc)) { toast("Geçersiz EAN-13 (kontrol hanesi)", "warn"); return; }
          const upd = {
            ...p,
            name: f.name.value.trim(),
            barcode: bc,
            gtin: (f.gtin && f.gtin.value.trim()) || "",
            image: imageData,
            categoryId: f.categoryId.value,
            unit: f.unit.value,
            price: parseFloat(f.price.value) || 0,
            cost: parseFloat(f.cost.value) || 0,
            stock: parseInt(f.stock.value) || 0,
            minStock: parseInt(f.minStock.value) || 0,
            ...(autoParts ? {
              oemNo: (f.oemNo.value || "").trim(),
              crossRef: (f.crossRef.value || "").trim(),
              vehicleFit: (f.vehicleFit.value || "").trim(),
              shelf: (f.shelf.value || "").trim(),
            } : {}),
          };
          if (!upd.name) { toast(t("name") + "?", "warn"); return; }
          db.products.upsert(upd); toast(t("save"), "success"); close(); done();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  search.addEventListener("input", draw);
  draw();
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
