// mod-04 Şirket Araçları — Cari / Veresiye defteri, tedarikçi takibi
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, postAccountMove } from "../core/store.js";
import { buildAccountSelect } from "./accounts.js";

export function renderCari(host) {
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: t("cari") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn", onClick: () => editCustomer(null) }, ["+ " + t("customer")]),
  ]);
  const body = el("div", { class: "grid", style: "grid-template-columns:1fr 1.4fr" });
  clear(host).append(head, body);

  let selected = null;
  const listCard = el("div", { class: "card" });
  const detailCard = el("div", { class: "card" });
  body.append(listCard, detailCard);

  function balanceOf(cid) {
    return db.cariEntries.all().filter((e) => e.customerId === cid)
      .reduce((a, e) => a + (e.type === "debt" ? e.amount : -e.amount), 0);
  }

  function drawList() {
    clear(listCard).appendChild(el("h3", { text: "👥 " + t("customer") }));
    const cs = db.customers.all();
    if (!cs.length) { listCard.appendChild(el("p", { class: "muted", text: "—" })); return; }
    cs.forEach((c) => {
      const bal = balanceOf(c.id);
      listCard.appendChild(el("div", {
        class: "cart-row", style: "cursor:pointer", onClick: () => { selected = c.id; drawDetail(); },
      }, [
        el("div", { style: "flex:1" }, [
          el("div", { style: "font-weight:700", text: [c.name, c.surname].filter(Boolean).join(" ") }),
          el("div", { class: "muted", style: "font-size:12px", text: c.title || c.phone || "" }),
        ]),
        el("span", { class: "pill " + (bal > 0 ? "red" : "green"), text: money(bal) }),
      ]));
    });
  }

  function drawDetail() {
    clear(detailCard);
    if (!selected) { detailCard.appendChild(el("p", { class: "muted", text: "← " + t("customer") }));  return; }
    const c = db.customers.get(selected);
    if (!c) { selected = null; return drawDetail(); }
    const bal = balanceOf(c.id);
    const entries = db.cariEntries.all().filter((e) => e.customerId === c.id).sort((a, b) => b.ts - a.ts);
    const fullName = [c.name, c.surname].filter(Boolean).join(" ");
    const meta = [c.title, c.taxId ? "TC: " + c.taxId : "", c.phone].filter(Boolean).join("  •  ");
    detailCard.append(
      el("div", { style: "display:flex;align-items:center;gap:10px" }, [
        el("div", { style: "flex:1" }, [
          el("h3", { style: "margin:0", text: fullName }),
          meta ? el("div", { class: "muted", style: "font-size:12px;margin-top:2px", text: meta }) : null,
        ]),
        el("button", { class: "iconbtn", title: t("edit"), onClick: () => editCustomer(c) }, ["✏️"]),
        el("span", { class: "pill " + (bal > 0 ? "red" : "green"), text: t("balance") + ": " + money(bal) }),
      ]),
      el("div", { style: "display:flex;gap:8px;margin:12px 0" }, [
        el("button", { class: "btn danger", style: "flex:1", onClick: () => addEntry(c, "debt") }, ["+ " + t("debt")]),
        el("button", { class: "btn success", style: "flex:1", onClick: () => addEntry(c, "payment") }, ["+ " + t("payment")]),
      ]),
      el("table", { class: "tbl" }, [
        el("tbody", {}, entries.length ? entries.map((e) =>
          el("tr", {}, [
            el("td", { class: "muted", text: new Date(e.ts).toLocaleDateString("tr-TR") }),
            el("td", {}, [el("span", { class: "pill " + (e.type === "debt" ? "red" : "green"), text: t(e.type) })]),
            el("td", { text: e.note || "" }),
            el("td", { class: "num", text: money(e.amount) }),
          ])
        ) : [el("tr", {}, [el("td", { class: "muted", text: "—" })])]),
      ])
    );
  }

  function addEntry(c, type) {
    const amount = el("input", { class: "input num", type: "number", step: "0.01", autofocus: true });
    const note = el("input", { class: "input", placeholder: t("note") });
    // Tahsilat (ödeme) alınırken: parayı hangi hesaba (Kasa/Banka) işleyeceğiz?
    const isPayment = type === "payment";
    const acctSel = isPayment ? buildAccountSelect() : null;
    const fullName = [c.name, c.surname].filter(Boolean).join(" ") || c.name || "";
    modal({
      title: fullName + " — " + t(type),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: t("amount") }), amount]),
        isPayment ? el("div", { class: "field" }, [el("label", { text: "💰 Nereye işlensin? (Kasa / Banka)" }), acctSel]) : null,
        el("div", { class: "field" }, [el("label", { text: t("note") }), note]),
      ]),
      actions: [
        { label: t("save"), kind: type === "debt" ? "danger" : "success", onClick: (close) => {
          const a = parseFloat(amount.value); if (!a || a <= 0) { toast(t("amount") + "?", "warn"); return; }
          const entryId = uid();
          const accountId = isPayment && acctSel ? acctSel.value : "";
          db.cariEntries.upsert({ id: entryId, customerId: c.id, type, amount: a, note: note.value.trim(), accountId, ts: Date.now() });
          // Entegrasyon: müşteriden tahsilat → seçilen Kasa/Banka hesabına GİRİŞ olarak işlenir.
          if (isPayment && accountId) {
            postAccountMove({ accountId, dir: "in", amount: a, source: "cari", refId: entryId, note: note.value.trim(), party: fullName });
            const accName = (db.accounts.get(accountId) || {}).name || "";
            toast("Tahsilat " + accName + " hesabına işlendi", "success");
          }
          close(); drawList(); drawDetail();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function editCustomer(existing) {
    const c0 = existing || {};
    const name = el("input", { class: "input", value: c0.name || "", autofocus: true });
    const surname = el("input", { class: "input", value: c0.surname || "" });
    const title = el("input", { class: "input", value: c0.title || "", placeholder: t("title") });
    const taxId = el("input", { class: "input", inputmode: "numeric", value: c0.taxId || "", placeholder: t("taxId") });
    const phone = el("input", { class: "input", inputmode: "tel", value: c0.phone || "" });
    modal({
      title: t("customer"),
      body: el("div", {}, [
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: t("name") + " *" }), name]),
          el("div", { class: "field" }, [el("label", { text: t("surname") }), surname]),
        ]),
        el("div", { class: "field" }, [el("label", { text: t("title") }), title]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: t("taxId") }), taxId]),
          el("div", { class: "field" }, [el("label", { text: t("phone") }), phone]),
        ]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast(t("name") + "?", "warn"); return; }
          const c = db.customers.upsert({
            id: c0.id || uid(),
            name: name.value.trim(), surname: surname.value.trim(), title: title.value.trim(),
            taxId: taxId.value.trim(), phone: phone.value.trim(),
          });
          selected = c.id; close(); drawList(); drawDetail();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  drawList(); drawDetail();
}
