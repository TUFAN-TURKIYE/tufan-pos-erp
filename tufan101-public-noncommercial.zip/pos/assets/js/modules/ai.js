// 🤖 TUFAN Asistan (AI) — işletme sahibinin sorularını, işletme verisinin ÖZETİNE
// göre yanıtlar. Güvenlik: API anahtarı sunucuda (pos/api/ai.php); istemcide YOK.
// Gizlilik: modele yalnızca AGREGAT özet gider; müşteri adı/telefonu GÖNDERİLMEZ.
import { el, clear, toast } from "../core/ui.js";
import { db, money, settings } from "../core/store.js";
import { ai } from "../core/api.js";

const money0 = (n) => money(Number(n) || 0);
const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d.getTime(); };
const startOfMonth = () => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1).getTime(); };

// ---- İşletme verisinden kompakt, kişisel veri içermeyen özet üret ----
function buildContext() {
  const L = [];
  const s = (() => { try { return settings.get() || {}; } catch { return {}; } })();
  const all = (t) => { try { return db[t].all() || []; } catch { return []; } };

  const now = new Date();
  L.push("Tarih: " + now.toLocaleDateString("tr-TR"));
  if (s.business) L.push("İşletme: " + s.business + (s.sector ? " (" + s.sector + ")" : ""));

  // Satış / ciro
  const sales = all("sales").filter((x) => !x.void);
  const tStart = startOfToday(), mStart = startOfMonth();
  const sum = (arr) => arr.reduce((a, x) => a + (Number(x.total) || 0), 0);
  const todaySales = sales.filter((x) => x.ts >= tStart);
  const monthSales = sales.filter((x) => x.ts >= mStart);
  L.push("Bugün ciro: " + money0(sum(todaySales)) + " (" + todaySales.length + " satış)");
  L.push("Bu ay ciro: " + money0(sum(monthSales)) + " (" + monthSales.length + " satış)");

  // Gelir / gider (txns) — bu ay
  const txns = all("txns");
  const inc = txns.filter((x) => x.type === "income" && x.ts >= mStart).reduce((a, x) => a + (+x.amount || 0), 0);
  const exp = txns.filter((x) => x.type === "expense" && x.ts >= mStart).reduce((a, x) => a + (+x.amount || 0), 0);
  L.push("Bu ay gelir: " + money0(inc) + " | gider: " + money0(exp) + " | net: " + money0(inc - exp));

  // Kasa / banka bakiyeleri
  const accounts = all("accounts");
  if (accounts.length) {
    const moves = all("accountMoves");
    const balOf = (id, opening) => moves.filter((m) => m.accountId === id)
      .reduce((a, m) => a + (m.dir === "out" ? -(+m.amount || 0) : (+m.amount || 0)), (Number(opening) || 0));
    L.push("Kasa/Banka: " + accounts.map((a) => (a.name || "?") + " " + money0(balOf(a.id, a.opening))).join(", "));
  }

  // Stok
  const products = all("products");
  if (products.length) {
    const stockVal = products.reduce((a, p) => a + (Number(p.stock) || 0) * (Number(p.cost) || 0), 0);
    const low = products.filter((p) => (Number(p.stock) || 0) <= (p.minStock ?? 5));
    L.push("Ürün sayısı: " + products.length + " | stok maliyet değeri: " + money0(stockVal));
    if (low.length) {
      L.push("Düşük/biten stok (" + low.length + "): " + low.slice(0, 15).map((p) => (p.name || "?") + "=" + (Number(p.stock) || 0)).join(", "));
    }
  }

  // En çok satan ürünler (bu ay)
  const byProd = {};
  monthSales.forEach((sale) => (sale.items || []).forEach((it) => {
    const k = it.name || "?"; byProd[k] = byProd[k] || { qty: 0, tutar: 0 };
    byProd[k].qty += Number(it.qty) || 0; byProd[k].tutar += (Number(it.qty) || 0) * (Number(it.price) || 0);
  }));
  const top = Object.entries(byProd).sort((a, b) => b[1].tutar - a[1].tutar).slice(0, 5);
  if (top.length) L.push("En çok satan (bu ay): " + top.map(([n, v]) => n + " (" + v.qty + " adet, " + money0(v.tutar) + ")").join(", "));

  // Tedarikçi borçları (firma adları — kişisel veri değil)
  const suppliers = all("suppliers");
  if (suppliers.length) {
    const supEntries = all("supplierEntries");
    const balSup = (sid) => supEntries.filter((e) => e.supplierId === sid)
      .reduce((a, e) => a + (e.type === "purchase" ? (+e.amount || 0) : -(+e.amount || 0)), 0);
    const debts = suppliers.map((su) => ({ n: su.name, b: balSup(su.id) })).filter((x) => x.b > 0).sort((a, b) => b.b - a.b);
    const totalOwe = debts.reduce((a, x) => a + x.b, 0);
    if (totalOwe > 0) L.push("Tedarikçi borcu toplam: " + money0(totalOwe) + " → " + debts.slice(0, 5).map((x) => x.n + ": " + money0(x.b)).join(", "));
  }

  // Borç / alacak defteri (kişi adı olmadan toplamlar)
  const debtsAll = all("debts");
  if (debtsAll.length) {
    const rem = (d) => Math.max(0, (+d.amount || 0) - (+d.paid || 0));
    const payable = debtsAll.filter((d) => d.kind === "payable").reduce((a, d) => a + rem(d), 0);
    const receivable = debtsAll.filter((d) => d.kind === "receivable").reduce((a, d) => a + rem(d), 0);
    L.push("Borçlarım (ödenecek): " + money0(payable) + " | Alacaklarım (tahsil edilecek): " + money0(receivable));
  }

  // Müşteri sayısı (yalnızca sayı — kişisel veri paylaşılmaz)
  const custCount = all("customers").length;
  if (custCount) L.push("Kayıtlı müşteri sayısı: " + custCount);

  return L.join("\n");
}

const SUGGESTIONS = [
  "Bu ay kârım ne durumda?",
  "Hangi ürünlerin stoğu azaldı?",
  "Bu ayın en çok satan ürünleri neler?",
  "Kime ne kadar borcum var?",
  "Bugünkü ciromu geçen aya göre nasıl artırırım?",
];

// Animasyon/stil enjeksiyonu (bir kez) — CSP style-src 'unsafe-inline' izinli.
function injectAIStyles() {
  if (document.getElementById("tufan-ai-style")) return;
  const st = document.createElement("style");
  st.id = "tufan-ai-style";
  st.textContent = `
  @keyframes tufanAiGlow { 0%,100%{box-shadow:0 0 14px 2px rgba(99,102,241,.55),0 0 4px rgba(56,189,248,.6) inset} 50%{box-shadow:0 0 26px 6px rgba(139,92,246,.8),0 0 8px rgba(56,189,248,.7) inset} }
  @keyframes tufanAiFloat { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-3px)} }
  @keyframes tufanAiIn { from{opacity:0;transform:translateY(8px) scale(.98)} to{opacity:1;transform:none} }
  @keyframes tufanDot { 0%,80%,100%{transform:translateY(0);opacity:.4} 40%{transform:translateY(-5px);opacity:1} }
  @keyframes tufanShimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
  .tufan-ai-orb{width:52px;height:52px;border-radius:50%;display:grid;place-items:center;font-size:26px;
    background:radial-gradient(circle at 30% 30%,#a5b4fc,#6366f1 45%,#7c3aed 100%);
    animation:tufanAiGlow 2.6s ease-in-out infinite, tufanAiFloat 4s ease-in-out infinite;flex:0 0 auto}
  .tufan-ai-title{font-family:'Orbitron','Poppins',sans-serif;font-weight:800;letter-spacing:.5px;
    font-size:22px;line-height:1.1;background:linear-gradient(90deg,#e0e7ff,#a5b4fc,#38bdf8,#e0e7ff);
    background-size:200% auto;-webkit-background-clip:text;background-clip:text;color:transparent;
    animation:tufanShimmer 6s linear infinite}
  .tufan-ai-bubble{animation:tufanAiIn .25s ease both}
  .tufan-ai-chip{border:1px solid rgba(148,163,184,.4);background:rgba(148,163,184,.08);
    border-radius:999px;padding:6px 12px;font-size:12.5px;cursor:pointer;transition:.15s;color:inherit}
  .tufan-ai-chip:hover{border-color:#6366f1;background:rgba(99,102,241,.14);transform:translateY(-1px)}
  .tufan-ai-dot{width:7px;height:7px;border-radius:50%;background:#6366f1;display:inline-block;
    animation:tufanDot 1.2s infinite ease-in-out}
  .tufan-ai-send{background:linear-gradient(90deg,#6366f1,#7c3aed);color:#fff;border:none;font-weight:700;
    border-radius:12px;padding:10px 18px;cursor:pointer;transition:.15s;box-shadow:0 4px 14px rgba(99,102,241,.4)}
  .tufan-ai-send:hover{filter:brightness(1.08);transform:translateY(-1px)}
  .tufan-ai-cancel{background:linear-gradient(90deg,#ef4444,#dc2626);box-shadow:0 4px 14px rgba(239,68,68,.4)}
  /* ---- Bakım / YAKINDA ekranı ---- */
  @keyframes aiSoonPulse{0%,100%{transform:scale(1);opacity:.55}50%{transform:scale(1.15);opacity:.9}}
  @keyframes aiSoonBadge{0%,100%{transform:translateY(0) rotate(-3deg)}50%{transform:translateY(-4px) rotate(3deg)}}
  @keyframes aiSoonSpin{from{transform:rotate(0)}to{transform:rotate(360deg)}}
  .ai-soon{position:relative;overflow:hidden;display:flex;flex-direction:column;align-items:center;justify-content:center;
    text-align:center;gap:14px;min-height:60vh;padding:40px 22px;border-radius:22px;
    background:radial-gradient(120% 80% at 50% -10%,#1e1b4b 0%,#0f172a 55%,#0b1020 100%);
    border:1px solid rgba(99,102,241,.35);box-shadow:0 18px 50px rgba(30,27,75,.5);color:#fff;
    animation:tufanAiIn .4s ease both}
  .ai-soon-glowbg{position:absolute;inset:-40% -20% auto -20%;height:70%;pointer-events:none;
    background:conic-gradient(from 0deg,rgba(99,102,241,.0),rgba(139,92,246,.35),rgba(56,189,248,.3),rgba(99,102,241,.0));
    filter:blur(46px);animation:aiSoonSpin 14s linear infinite}
  .ai-soon-orb{width:88px;height:88px;font-size:44px;position:relative;z-index:1}
  .ai-soon-badge{position:relative;z-index:1;font-family:'Orbitron','Poppins',sans-serif;font-weight:900;letter-spacing:2px;
    font-size:13px;color:#0b1020;background:linear-gradient(90deg,#fbbf24,#f59e0b);
    padding:6px 16px;border-radius:999px;box-shadow:0 6px 18px rgba(245,158,11,.5);animation:aiSoonBadge 2.4s ease-in-out infinite}
  .ai-soon-title{position:relative;z-index:1;font-size:26px}
  .ai-soon-text{position:relative;z-index:1;max-width:440px;font-size:14.5px;line-height:1.6;color:#c7d2fe;margin:0}
  .ai-soon-dots{position:relative;z-index:1;display:flex;gap:7px}
  .ai-soon-dots .tufan-ai-dot{width:9px;height:9px;background:#8b5cf6}
  .ai-soon-note{position:relative;z-index:1;font-size:12px;color:#93c5fd;opacity:.85;margin-top:4px}
  `;
  document.head.appendChild(st);
}

// Bakım modu: true iken AI yerine "YAKINDA" ekranı gösterilir.
// (Yapay zekâ mantığı DEĞİŞTİRİLMEDİ — yeniden açmak için false yapın.)
const AI_MAINTENANCE = true;

// "Çok yakında / bakımda" ekranı — animasyonlu, şık.
function renderAIMaintenance(host) {
  injectAIStyles();
  const wrap = el("div", { class: "ai-soon" }, [
    el("div", { class: "ai-soon-glowbg" }),
    el("div", { class: "tufan-ai-orb ai-soon-orb" }, ["🤖"]),
    el("span", { class: "ai-soon-badge" }, ["YAKINDA"]),
    el("div", { class: "tufan-ai-title ai-soon-title" }, ["TUFAN Yapay Zekâ"]),
    el("p", { class: "ai-soon-text" }, [
      "Yapay zekâ asistanı şu an bakımda. Çok daha akıllı ve hızlı bir sürümle çok yakında karşınızda! ✨",
    ]),
    el("div", { class: "ai-soon-dots" }, [
      el("span", { class: "tufan-ai-dot" }),
      el("span", { class: "tufan-ai-dot", style: "animation-delay:.18s" }),
      el("span", { class: "tufan-ai-dot", style: "animation-delay:.36s" }),
    ]),
    el("div", { class: "ai-soon-note" }, ["🔧 Bakım çalışması sürüyor · TUFAN 101"]),
  ]);
  clear(host).append(wrap);
}

export function renderAI(host) {
  if (AI_MAINTENANCE) { renderAIMaintenance(host); return; }
  injectAIStyles();
  const history = []; // {role, content}

  // ---- Havalı gradyan başlık bandı ----
  const header = el("div", {
    style: "display:flex;align-items:center;gap:14px;padding:16px 18px;border-radius:16px;margin-bottom:12px;" +
      "background:linear-gradient(120deg,#0f172a 0%,#1e1b4b 45%,#312e81 100%);" +
      "border:1px solid rgba(99,102,241,.35);box-shadow:0 8px 30px rgba(49,46,129,.35);color:#fff",
  }, [
    el("div", { class: "tufan-ai-orb" }, ["🤖"]),
    el("div", { style: "flex:1;min-width:0" }, [
      el("div", { class: "tufan-ai-title" }, ["TUFAN Yapay Zekâ"]),
      el("div", { style: "font-size:12.5px;opacity:.8;margin-top:3px;display:flex;align-items:center;gap:6px" }, [
        el("span", { style: "width:8px;height:8px;border-radius:50%;background:#22c55e;display:inline-block;box-shadow:0 0 8px #22c55e" }),
        "Akıllı İşletme Asistanı · çevrim içi",
      ]),
    ]),
  ]);

  const note = el("div", { style: "background:rgba(99,102,241,.08);border:1px solid rgba(99,102,241,.25);color:var(--muted,#475569);border-radius:12px;padding:9px 12px;font-size:12px;margin-bottom:12px;line-height:1.5" }, [
    "🔒 İşletme verilerinizin yalnızca ÖZETİ (ciro, gelir/gider, stok, borç) sorunuzla birlikte gönderilir. Müşteri adı/telefonu gibi kişisel veriler PAYLAŞILMAZ. Yanıtlar bilgilendirme amaçlıdır; kesin mali/hukuki karar için uzmana danışın.",
  ]);

  const feed = el("div", { style: "display:flex;flex-direction:column;gap:10px;min-height:240px;max-height:52vh;overflow:auto;padding:8px 4px" });
  const bubble = (role, text) => el("div", {
    class: "tufan-ai-bubble",
    style: "max-width:88%;padding:10px 13px;border-radius:14px;white-space:pre-wrap;line-height:1.55;font-size:14px;" +
      (role === "user"
        ? "align-self:flex-end;background:linear-gradient(90deg,#6366f1,#7c3aed);color:#fff;border-bottom-right-radius:4px;box-shadow:0 3px 12px rgba(99,102,241,.3)"
        : "align-self:flex-start;background:var(--card,#f1f5f9);border:1px solid var(--border);border-bottom-left-radius:4px"),
  }, [text]);

  // Animasyonlu "yazıyor" göstergesi (3 zıplayan nokta)
  const makeTyping = () => el("div", {
    class: "tufan-ai-bubble",
    style: "align-self:flex-start;background:var(--card,#f1f5f9);border:1px solid var(--border);border-radius:14px;border-bottom-left-radius:4px;padding:12px 15px;display:flex;gap:5px;align-items:center",
  }, [
    el("span", { class: "tufan-ai-dot" }),
    el("span", { class: "tufan-ai-dot", style: "animation-delay:.18s" }),
    el("span", { class: "tufan-ai-dot", style: "animation-delay:.36s" }),
  ]);

  feed.appendChild(bubble("assistant", "Merhaba! 👋 Ben TUFAN Yapay Zekâ. İşletmenle ilgili sorularını yanıtlayabilirim — ciro, gelir/gider, stok, borç/alacak, en çok satanlar… Aşağıdan bir soru seçebilir ya da kendi sorunu yazabilirsin."));

  const input = el("textarea", { class: "input", rows: "1", placeholder: "Sorunuzu yazın… (örn. bu ayki giderlerim ne kadar?)", style: "resize:none;flex:1;max-height:120px" });
  const sendBtn = el("button", { class: "tufan-ai-send", text: "Sor ✨" });

  let busy = false;
  let controller = null;    // aktif isteğin AbortController'ı (İptal için)

  function setBusy(on) {
    busy = on;
    if (on) { sendBtn.textContent = "⏹ İptal"; sendBtn.classList.add("tufan-ai-cancel"); }
    else { sendBtn.textContent = "Sor ✨"; sendBtn.classList.remove("tufan-ai-cancel"); }
  }

  async function send(q) {
    // İstek sürüyorsa buton "İptal" görevi görür → isteği durdur.
    if (busy) { if (controller) controller.abort(); return; }
    const question = (q != null ? q : input.value).trim();
    if (!question) return;
    setBusy(true); input.value = "";
    feed.appendChild(bubble("user", question));
    const typing = makeTyping();
    feed.appendChild(typing);
    feed.scrollTop = feed.scrollHeight;
    controller = new AbortController();
    try {
      const context = buildContext();
      const res = await ai.ask({ question, context, history: history.slice(-6) }, { signal: controller.signal });
      const answer = (res && res.answer) ? res.answer : "Yanıt alınamadı.";
      typing.remove();
      feed.appendChild(bubble("assistant", answer));
      history.push({ role: "user", content: question });
      history.push({ role: "assistant", content: answer });
    } catch (e) {
      typing.remove();
      if (e && (e.name === "AbortError" || e.code === 20)) {
        const b = bubble("assistant", "⏹ İptal edildi.");
        b.style.opacity = ".7"; b.style.fontStyle = "italic";
        feed.appendChild(b);
      } else {
        const msg = (e && e.data && e.data.msg) ? e.data.msg : "Bağlantı hatası. Sunucu AI ayarını (ai_api_key) kontrol edin.";
        const det = (e && e.data && e.data.detail) ? "\n\n(" + e.data.detail + ")" : "";
        feed.appendChild(bubble("assistant", "⚠️ " + msg + det));
      }
    } finally {
      controller = null; setBusy(false); feed.scrollTop = feed.scrollHeight; input.focus();
    }
  }

  sendBtn.addEventListener("click", () => send());
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(); } });

  const chips = el("div", { style: "display:flex;flex-wrap:wrap;gap:7px;margin:12px 0" },
    SUGGESTIONS.map((q) => el("button", {
      class: "tufan-ai-chip", onClick: () => send(q),
    }, [q])));

  const inputBar = el("div", { style: "display:flex;gap:8px;align-items:flex-end;margin-top:8px" }, [input, sendBtn]);

  clear(host).append(header, el("div", { class: "card" }, [note, feed, chips, inputBar]));
  setTimeout(() => input.focus(), 100);
}
