// Dinamik Fiyat Etiketi — ürünler için yazdırılabilir raf/fiyat etiketi üretir.
// Seç → boyut ayarla → Yazdır/PDF (tarayıcının "PDF olarak kaydet"i ile PDF olur).
// Harici kütüphane gerektirmez; yeni pencerede yazdırma sayfası açar.
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

export function renderPriceTag(host) {
  const prods = db.products.all().filter((p) => p.active !== false);
  const selected = new Set();
  const sizeSel = el("select", { class: "input", style: "max-width:170px" }, [
    el("option", { value: "sm", text: "Küçük (24/sayfa)" }),
    el("option", { value: "md", text: "Orta (12/sayfa)", selected: true }),
    el("option", { value: "lg", text: "Büyük (6/sayfa)" }),
  ]);
  const showBarcode = el("input", { type: "checkbox", checked: true });
  const search = el("input", { class: "input", placeholder: "🔍 Ürün ara", style: "max-width:220px" });
  const listWrap = el("div", { class: "tag-pick" });
  const countLbl = el("span", { class: "muted" });

  clear(host).append(
    el("div", { class: "view-head" }, [
      el("h1", { text: "🏷️ " + t("navPriceTag") }),
      el("div", { class: "spacer" }),
      el("button", { class: "btn success", onClick: () => printTags() }, ["🖨️ Yazdır / PDF"]),
    ]),
    el("div", { class: "card", style: "display:flex;gap:12px;flex-wrap:wrap;align-items:center" }, [
      search,
      el("label", { style: "display:flex;gap:6px;align-items:center" }, [el("span", { text: "Boyut" }), sizeSel]),
      el("label", { style: "display:flex;gap:6px;align-items:center" }, [showBarcode, el("span", { text: "Barkod göster" })]),
      el("div", { class: "spacer" }),
      el("button", { class: "btn ghost tiny", onClick: () => { prods.forEach((p) => selected.add(p.id)); drawList(); } }, ["Tümünü Seç"]),
      el("button", { class: "btn ghost tiny", onClick: () => { selected.clear(); drawList(); } }, ["Temizle"]),
      countLbl,
    ]),
    listWrap,
  );

  function drawList() {
    clear(listWrap);
    const q = search.value.trim().toLowerCase();
    const rows = prods.filter((p) => !q || (p.name || "").toLowerCase().includes(q) || (p.barcode || "").includes(q));
    countLbl.textContent = selected.size + " seçili";
    if (!rows.length) { listWrap.appendChild(el("p", { class: "muted", style: "padding:12px", text: "Ürün bulunamadı." })); return; }
    rows.forEach((p) => {
      const on = selected.has(p.id);
      listWrap.appendChild(el("div", { class: "tag-pick-row" + (on ? " on" : ""), onClick: () => { on ? selected.delete(p.id) : selected.add(p.id); drawList(); } }, [
        el("span", { text: (on ? "☑ " : "☐ ") + (p.emoji || "📦") + " " + (p.name || "Ürün") }),
        el("b", { class: "num", text: money(p.price || 0) }),
      ]));
    });
  }

  function printTags() {
    const items = prods.filter((p) => selected.has(p.id));
    if (!items.length) { toast("En az bir ürün seçin", "warn"); return; }
    const s = settings.get();
    const biz = s.bizName || s.companyName || "";
    const size = sizeSel.value;
    const perRow = size === "sm" ? 4 : size === "md" ? 3 : 2;
    const wBarcode = showBarcode.checked;

    const esc = (x) => String(x == null ? "" : x).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
    const tagsHtml = items.map((p) => {
      const hasOld = Number(p.oldPrice) > 0 && Number(p.oldPrice) > Number(p.price);
      return `<div class="tag">
        <div class="tag-biz">${esc(biz)}</div>
        <div class="tag-name">${esc(p.name || "Ürün")}</div>
        ${hasOld ? `<div class="tag-old">${esc(money(p.oldPrice))}</div>` : ""}
        <div class="tag-price">${esc(money(p.price || 0))}</div>
        ${wBarcode && p.barcode ? `<div class="tag-bc">${barcodeSvg(p.barcode)}<div class="tag-bcn">${esc(p.barcode)}</div></div>` : ""}
      </div>`;
    }).join("");

    const html = `<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Fiyat Etiketleri</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:Inter,Arial,sans-serif;padding:8mm;background:#fff;color:#111}
      .sheet{display:grid;grid-template-columns:repeat(${perRow},1fr);gap:4mm}
      .tag{border:1.5px dashed #999;border-radius:8px;padding:8px 10px;text-align:center;page-break-inside:avoid;min-height:${size === "lg" ? 60 : size === "md" ? 46 : 34}mm;display:flex;flex-direction:column;justify-content:center;gap:2px}
      .tag-biz{font-size:10px;color:#666;text-transform:uppercase;letter-spacing:1px}
      .tag-name{font-size:${size === "lg" ? 20 : 15}px;font-weight:700;line-height:1.15}
      .tag-old{font-size:14px;color:#999;text-decoration:line-through}
      .tag-price{font-size:${size === "lg" ? 40 : size === "md" ? 30 : 22}px;font-weight:900;color:#c0392b}
      .tag-bc{margin-top:4px}
      .tag-bc svg{height:${size === "lg" ? 34 : 24}px;width:100%}
      .tag-bcn{font-size:10px;letter-spacing:2px;color:#333}
      @media print{@page{margin:8mm}.noprint{display:none}}
    </style></head><body>
    <div class="noprint" style="text-align:center;margin-bottom:10px">
      <button onclick="window.print()" style="padding:8px 16px;font-size:15px;border:0;border-radius:8px;background:#2563eb;color:#fff;cursor:pointer">🖨️ Yazdır</button>
      <span style="color:#666;margin-left:8px">PDF için: yazdır → "PDF olarak kaydet"</span>
    </div>
    <div class="sheet">${tagsHtml}</div>
    <script>window.onload=function(){setTimeout(function(){window.print()},350)}<\/script>
    </body></html>`;

    const w = window.open("", "_blank");
    if (!w) { toast("Açılır pencere engellendi — tarayıcı iznini kontrol edin", "error"); return; }
    w.document.open(); w.document.write(html); w.document.close();
  }

  // Basit Code-128 benzeri görsel barkod (dekoratif; okutulabilirlik için gerçek font gerekir)
  function barcodeSvg(code) {
    const str = String(code);
    let x = 0, bars = "";
    for (let i = 0; i < str.length; i++) {
      const v = str.charCodeAt(i);
      for (let b = 0; b < 4; b++) {
        const w = ((v >> b) & 1) ? 2 : 1;
        if (b % 2 === 0) bars += `<rect x="${x}" y="0" width="${w}" height="40" fill="#000"/>`;
        x += w;
      }
      x += 1;
    }
    return `<svg viewBox="0 0 ${x} 40" preserveAspectRatio="none">${bars}</svg>`;
  }

  drawList();
  search.addEventListener("input", drawList);
}
