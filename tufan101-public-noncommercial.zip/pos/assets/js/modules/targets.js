// Hedef Sistemi — patron günlük/aylık hedef belirler, gerçekleşme % gösterilir.
// Hedefler settings içinde tutulur: { targetDaily, targetMonthlyOrders, targetNewCustomers }
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

const DAY = 86400000;

function activeSales() { return db.sales.all().filter((s) => !s.void && Number(s.ts || 0) > 0); }

export function renderTargets(host) {
  const wrap = el("div", {});
  const setBtn = el("button", { class: "btn", onClick: () => form() }, ["⚙️ Hedef Belirle"]);
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🎯 " + t("navTargets") }), el("div", { class: "spacer" }), setBtn]),
    wrap,
  );

  function draw() {
    clear(wrap);
    const s = settings.get();
    const now = Date.now();
    const startToday = new Date(); startToday.setHours(0, 0, 0, 0);
    const t0 = startToday.getTime();
    const startMonth = new Date(); startMonth.setDate(1); startMonth.setHours(0, 0, 0, 0);
    const m0 = startMonth.getTime();

    const sales = activeSales();
    const todayRev = sales.filter((x) => Number(x.ts) >= t0).reduce((a, x) => a + (Number(x.total) || 0), 0);
    const monthOrders = sales.filter((x) => Number(x.ts) >= m0).length;
    // Bu ay eklenen yeni müşteriler (createdTs varsa)
    const newCust = db.customers.all().filter((c) => {
      const ts = Number(c.createdTs || c.ts || 0);
      return ts >= m0;
    }).length;

    const targetDaily = Number(s.targetDaily) || 0;
    const targetMonthlyOrders = Number(s.targetMonthlyOrders) || 0;
    const targetNewCustomers = Number(s.targetNewCustomers) || 0;

    if (!targetDaily && !targetMonthlyOrders && !targetNewCustomers) {
      wrap.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:16px", text: "Henüz hedef belirlenmedi. Sağ üstten “Hedef Belirle” ile başlayın." })]));
      return;
    }

    const gauge = (icon, title, cur, target, fmt) => {
      const pct = target > 0 ? Math.min(100, Math.round(cur / target * 100)) : 0;
      const done = pct >= 100;
      return el("div", { class: "card" }, [
        el("div", { style: "display:flex;justify-content:space-between;align-items:center" }, [
          el("h3", { style: "margin:0", text: icon + " " + title }),
          el("span", { class: "pill " + (done ? "green" : pct >= 60 ? "blue" : "amber"), text: "%" + pct }),
        ]),
        el("div", { style: "display:flex;justify-content:space-between;margin:10px 0 6px" }, [
          el("b", { class: "num", style: "font-size:22px", text: fmt(cur) }),
          el("span", { class: "muted", text: "Hedef: " + fmt(target) }),
        ]),
        el("div", { class: "tgt-bar" }, [el("div", { class: "tgt-fill" + (done ? " tgt-done" : ""), style: "width:" + pct + "%" })]),
        done ? el("div", { style: "color:var(--success);font-weight:700;margin-top:8px", text: "🎉 Hedefe ulaşıldı!" }) : el("div", { class: "muted", style: "font-size:12px;margin-top:8px", text: "Kalan: " + fmt(Math.max(0, target - cur)) }),
      ]);
    };

    const grid = el("div", { class: "smart-cols" });
    if (targetDaily) grid.appendChild(gauge("💰", "Günlük Ciro", todayRev, targetDaily, money));
    if (targetMonthlyOrders) grid.appendChild(gauge("🧾", "Aylık Sipariş", monthOrders, targetMonthlyOrders, (v) => String(Math.round(v))));
    wrap.appendChild(grid);
    if (targetNewCustomers) {
      const g2 = el("div", { class: "smart-cols" });
      g2.appendChild(gauge("👥", "Yeni Müşteri (Bu Ay)", newCust, targetNewCustomers, (v) => String(Math.round(v))));
      wrap.appendChild(g2);
    }
  }

  function form() {
    const s = settings.get();
    const daily = el("input", { class: "input num", type: "number", value: s.targetDaily || "", placeholder: "Örn. 25000" });
    const orders = el("input", { class: "input num", type: "number", value: s.targetMonthlyOrders || "", placeholder: "Örn. 800" });
    const cust = el("input", { class: "input num", type: "number", value: s.targetNewCustomers || "", placeholder: "Örn. 100" });
    modal({
      title: "🎯 Hedef Belirle",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "💰 Günlük Ciro Hedefi (TL)" }), daily]),
        el("div", { class: "field" }, [el("label", { text: "🧾 Aylık Sipariş Hedefi (adet)" }), orders]),
        el("div", { class: "field" }, [el("label", { text: "👥 Aylık Yeni Müşteri Hedefi" }), cust]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          settings.set({ targetDaily: parseFloat(daily.value) || 0, targetMonthlyOrders: parseInt(orders.value, 10) || 0, targetNewCustomers: parseInt(cust.value, 10) || 0 });
          toast("Hedefler kaydedildi", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}
