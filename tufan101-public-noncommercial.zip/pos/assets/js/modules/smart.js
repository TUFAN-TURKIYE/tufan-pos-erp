// Akıllı Patron Paneli — satış verisinden içgörü üretir.
// Haftalık kıyas, günlük kıyas, en çok satan, ölü stok, yoğun saat, düşük stok.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money } from "../core/store.js";

const DAY = 86400000;

function saleTs(s) { return Number(s.ts || s.date || 0); }
function saleTotal(s) { return Number(s.total || 0); }
function activeSales() { return db.sales.all().filter((s) => !s.void && saleTs(s) > 0); }

// [from, to) aralığındaki satışların toplamı + adedi
function sumRange(sales, from, to) {
  let rev = 0, n = 0;
  sales.forEach((s) => { const ts = saleTs(s); if (ts >= from && ts < to) { rev += saleTotal(s); n++; } });
  return { rev, n };
}

function pctChange(cur, prev) {
  if (prev <= 0) return cur > 0 ? 100 : 0;
  return Math.round(((cur - prev) / prev) * 100);
}

function trendPill(pct) {
  const up = pct >= 0;
  return el("span", { class: "pill " + (up ? "green" : "amber"), text: (up ? "▲ +" : "▼ ") + pct + "%" });
}

export function renderSmartPanel(host) {
  const sales = activeSales();
  const now = Date.now();
  const startToday = new Date(); startToday.setHours(0, 0, 0, 0);
  const t0 = startToday.getTime();

  clear(host).append(el("div", { class: "view-head" }, [el("h1", { text: "🧠 " + t("navSmart") }), el("div", { class: "spacer" })]));

  if (!sales.length) {
    host.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:20px", text: "Henüz satış verisi yok. Satış yaptıkça buraya içgörüler gelir." })]));
    return;
  }

  // ---- KPI: bugün vs dün, bu hafta vs geçen hafta ----
  const today = sumRange(sales, t0, t0 + DAY);
  const yest = sumRange(sales, t0 - DAY, t0);
  const week = sumRange(sales, now - 7 * DAY, now);
  const prevWeek = sumRange(sales, now - 14 * DAY, now - 7 * DAY);
  const month = sumRange(sales, now - 30 * DAY, now);

  const kpi = (label, val, sub) => el("div", { class: "smart-kpi" }, [
    el("div", { class: "smart-label", text: label }),
    el("div", { class: "smart-val num", text: val }),
    sub || el("span", {}),
  ]);

  host.appendChild(el("div", { class: "smart-grid" }, [
    kpi("Bugün", money(today.rev), el("div", { style: "display:flex;gap:6px;align-items:center;margin-top:4px" }, [trendPill(pctChange(today.rev, yest.rev)), el("span", { class: "muted", style: "font-size:12px", text: "düne göre" })])),
    kpi("Bu hafta (7 gün)", money(week.rev), el("div", { style: "display:flex;gap:6px;align-items:center;margin-top:4px" }, [trendPill(pctChange(week.rev, prevWeek.rev)), el("span", { class: "muted", style: "font-size:12px", text: "geçen haftaya göre" })])),
    kpi("Bu ay (30 gün)", money(month.rev), el("span", { class: "muted", style: "font-size:12px", text: month.n + " satış" })),
    kpi("Sepet ortalaması", money(week.n ? week.rev / week.n : 0), el("span", { class: "muted", style: "font-size:12px", text: "son 7 gün" })),
  ]));

  // ---- En çok satan ürünler (son 30 gün, ciroya göre) ----
  const prodMap = {}; // name → { qty, rev }
  sales.forEach((s) => {
    if (saleTs(s) < now - 30 * DAY) return;
    (Array.isArray(s.items) ? s.items : []).forEach((it) => {
      const key = it.name || it.productName || "Ürün";
      const q = Number(it.qty) || 1, rev = q * (Number(it.price) || 0);
      if (!prodMap[key]) prodMap[key] = { qty: 0, rev: 0 };
      prodMap[key].qty += q; prodMap[key].rev += rev;
    });
  });
  const topProducts = Object.entries(prodMap).sort((a, b) => b[1].rev - a[1].rev).slice(0, 6);
  const maxRev = topProducts.length ? topProducts[0][1].rev : 1;

  // ---- Yoğun saatler (son 14 gün) ----
  const hours = new Array(24).fill(0);
  sales.forEach((s) => { if (saleTs(s) >= now - 14 * DAY) hours[new Date(saleTs(s)).getHours()] += saleTotal(s); });
  const maxHour = Math.max(1, ...hours);
  const busiest = hours.indexOf(Math.max(...hours));

  // ---- Ölü stok: stok var ama son 14 günde hiç satılmadı ----
  const soldNames = new Set();
  sales.forEach((s) => { if (saleTs(s) >= now - 14 * DAY) (s.items || []).forEach((it) => soldNames.add((it.name || "").toLowerCase())); });
  const deadStock = db.products.all().filter((p) => p.active && Number(p.stock) > 0 && !soldNames.has((p.name || "").toLowerCase())).slice(0, 8);

  // ---- Düşük stok uyarısı ----
  const lowStock = db.products.all().filter((p) => p.active && typeof p.stock === "number" && p.stock > 0 && p.stock <= (Number(p.minStock) || 5)).slice(0, 8);

  const twoCol = el("div", { class: "smart-cols" });

  // En çok satanlar kartı
  twoCol.appendChild(el("div", { class: "card" }, [
    el("h3", { text: "🏆 En Çok Satanlar (30 gün)" }),
    topProducts.length
      ? el("div", { style: "margin-top:8px" }, topProducts.map(([name, d]) => el("div", { class: "smart-bar-row" }, [
          el("div", { class: "smart-bar-top" }, [el("span", { text: name }), el("b", { class: "num", text: money(d.rev) })]),
          el("div", { class: "smart-bar" }, [el("div", { class: "smart-bar-fill", style: "width:" + Math.max(6, Math.round(d.rev / maxRev * 100)) + "%" })]),
          el("div", { class: "muted", style: "font-size:12px", text: d.qty + " adet" }),
        ])))
      : el("p", { class: "muted", text: "Veri yok" }),
  ]));

  // Yoğun saatler kartı
  twoCol.appendChild(el("div", { class: "card" }, [
    el("h3", { text: "⏰ Yoğun Saatler (14 gün)" }),
    el("p", { class: "muted", style: "margin:4px 0 10px", text: "En yoğun saat: " + busiest + ":00 – " + (busiest + 1) + ":00" }),
    el("div", { class: "smart-hours" }, hours.map((v, h) => el("div", { class: "smart-hour", title: h + ":00 · " + money(v) }, [
      el("div", { class: "smart-hour-bar", style: "height:" + Math.round(v / maxHour * 100) + "%" + (h === busiest ? ";background:var(--success)" : "") }),
      (h % 3 === 0) ? el("div", { class: "smart-hour-lbl", text: h }) : el("span", {}),
    ]))),
  ]));

  host.appendChild(twoCol);

  const twoCol2 = el("div", { class: "smart-cols" });

  // Ölü stok kartı
  twoCol2.appendChild(el("div", { class: "card" }, [
    el("h3", { text: "🧊 Ölü Stok (14 gündür satılmadı)" }),
    deadStock.length
      ? el("div", { style: "margin-top:8px" }, deadStock.map((p) => el("div", { class: "smart-list-row" }, [
          el("span", { text: (p.emoji || "📦") + " " + p.name }),
          el("span", { class: "pill amber", text: "Stok: " + p.stock }),
        ])))
      : el("p", { class: "muted", style: "margin-top:8px", text: "👍 Tüm ürünler hareket görüyor." }),
  ]));

  // Düşük stok kartı
  twoCol2.appendChild(el("div", { class: "card" }, [
    el("h3", { text: "⚠️ Azalan Stok — Sipariş Ver" }),
    lowStock.length
      ? el("div", { style: "margin-top:8px" }, lowStock.map((p) => el("div", { class: "smart-list-row" }, [
          el("span", { text: (p.emoji || "📦") + " " + p.name }),
          el("span", { class: "pill red", text: "Kaldı: " + p.stock }),
        ])))
      : el("p", { class: "muted", style: "margin-top:8px", text: "✅ Kritik seviyede stok yok." }),
  ]));

  host.appendChild(twoCol2);
}
