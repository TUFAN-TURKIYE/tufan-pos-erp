// Çalışanlar — Personel / bordro yönetimi (maaş, yemek, ulaşım, SGK, sağlık) + toplam maliyet
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

export function renderStaff(host) {
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: "👥 " + t("staff") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn success", onClick: () => editStaff(null) }, ["+ " + t("staff")]),
  ]);
  const body = el("div", {});
  clear(host).append(head, body);

  function gross(s) {
    return (s.salary || 0) + (s.meal || 0) + (s.transport || 0) + (s.sgk || 0) + (s.health || 0);
  }

  function draw() {
    clear(body);
    const list = db.staff.all();
    const tot = { salary: 0, meal: 0, transport: 0, sgk: 0, health: 0 };
    list.forEach((s) => { tot.salary += s.salary || 0; tot.meal += s.meal || 0; tot.transport += s.transport || 0; tot.sgk += s.sgk || 0; tot.health += s.health || 0; });
    const grand = tot.salary + tot.meal + tot.transport + tot.sgk + tot.health;

    // Özet kartlar
    body.appendChild(el("div", { class: "stat-grid" }, [
      statCard("Maaşlar", money(tot.salary), "var(--success)"),
      statCard("Yemek", money(tot.meal), "var(--warning)"),
      statCard("Ulaşım", money(tot.transport), "var(--primary)"),
      statCard("SGK", money(tot.sgk), "#0ea5e9"),
      statCard("Sağlık Sig.", money(tot.health), "#8b5cf6"),
      statCard("TOPLAM YÜK", money(grand), "var(--danger)"),
    ]));

    // Liste
    const listCard = el("div", { class: "card", style: "margin-top:16px" });
    if (!list.length) { listCard.appendChild(el("p", { class: "muted", text: "Çalışan kaydı yok. Sağ üstten ekleyin." })); body.appendChild(listCard); return; }
    listCard.appendChild(el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [
        el("th", { text: "Ad Soyad" }), el("th", { text: "Pozisyon" }), el("th", { text: "Maaş" }),
        el("th", { text: "Yemek" }), el("th", { text: "Ulaşım" }), el("th", { text: "SGK" }),
        el("th", { text: "Sağlık" }), el("th", { text: "Toplam" }), el("th", { text: "Başlangıç" }), el("th", {}),
      ])]),
      el("tbody", {}, list.map((s) =>
        el("tr", {}, [
          el("td", { style: "font-weight:700", text: s.name }),
          el("td", {}, [el("span", { class: "pill blue", text: s.role || "—" })]),
          el("td", { class: "num", text: money(s.salary) }),
          el("td", { class: "num", text: money(s.meal) }),
          el("td", { class: "num", text: money(s.transport) }),
          el("td", { class: "num", text: money(s.sgk) }),
          el("td", { class: "num", text: money(s.health) }),
          el("td", { class: "num", style: "font-weight:700;color:var(--danger)", text: money(gross(s)) }),
          el("td", { class: "muted", text: s.startDate || "—" }),
          el("td", { style: "text-align:right;white-space:nowrap" }, [
            el("button", { class: "iconbtn", title: t("edit"), onClick: () => editStaff(s) }, ["✏️"]),
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog("Çalışanı sil?", () => { db.staff.remove(s.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
          ]),
        ])
      )),
    ]));
    body.appendChild(listCard);
  }

  function editStaff(existing) {
    const s0 = existing || {};
    const name = el("input", { class: "input", value: s0.name || "", autofocus: true });
    const role = el("input", { class: "input", value: s0.role || "", placeholder: "Kasiyer, Müdür…" });
    const salary = numInput(s0.salary);
    const meal = numInput(s0.meal);
    const transport = numInput(s0.transport);
    const sgk = numInput(s0.sgk);
    const health = numInput(s0.health);
    const start = el("input", { class: "input", type: "date", value: s0.startDate || new Date().toISOString().slice(0, 10) });
    modal({
      title: "👤 " + (existing ? t("edit") : t("staff")),
      body: el("div", {}, [
        field("Ad Soyad *", name),
        two(field("Pozisyon", role), field("İşe Başlama", start)),
        two(field("Aylık Maaş", salary), field("Yemek Yardımı", meal)),
        two(field("Ulaşım Yardımı", transport), field("SGK Primi", sgk)),
        field("Sağlık Sigortası", health),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast("Ad zorunlu", "warn"); return; }
          db.staff.upsert({
            id: s0.id || uid(), name: name.value.trim(), role: role.value.trim(),
            salary: num(salary), meal: num(meal), transport: num(transport), sgk: num(sgk), health: num(health),
            startDate: start.value,
          });
          toast(existing ? t("save") : "Çalışan eklendi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}

function numInput(v) { return el("input", { class: "input num", type: "number", step: "0.01", inputmode: "decimal", value: v != null ? v : "" }); }
function num(input) { return parseFloat(input.value) || 0; }
function field(label, node) { return el("div", { class: "field" }, [el("label", { text: label }), node]); }
function two(a, b) { return el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [a, b]); }
function statCard(label, value, color) {
  return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
    el("div", { class: "label", text: label }),
    el("div", { class: "value num", text: value }),
  ]);
}
