// mod-11 QR Menü + mod-21 Akıllı Bağlantı (Bio-link) — masadan okutulan dijital menü
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings, currentAccount, fetchAccountData, uid } from "../core/store.js";
import { cloud } from "../core/api.js";

// Herkese açık menü bağlantısı: müşteri okutunca GİRİŞ GEREKMEDEN menüyü açar.
// #/m/<hesap> → app.js bunu renderPublicMenu ile karşılar, veriyi buluttan çeker.
function publicMenuLink() {
  const acc = currentAccount();
  const base = `${location.origin}${location.pathname}`;
  return acc ? `${base}#/m/${encodeURIComponent(acc)}` : `${base}#/qrmenu`;
}

// Başvuru / Anket + CV yükleme bağlantısı — menü linkinden AYRI, kendine ait link.
// #/basvuru/<hesap> → app.js bunu renderApplicationPage ile karşılar.
function applicationLink() {
  const acc = currentAccount();
  const base = `${location.origin}${location.pathname}`;
  return acc ? `${base}#/basvuru/${encodeURIComponent(acc)}` : `${base}#/qrmenu`;
}

export function renderQrMenu(host) {
  const s = settings.get();
  const acc = currentAccount();
  const link = publicMenuLink();

  const head = el("div", { class: "view-head" }, [el("h1", { text: t("qrmenu") })]);
  const layout = el("div", { class: "grid qr-layout", style: "grid-template-columns:300px 1fr;align-items:start" });

  // Sol: QR + bio-link
  const qrBox = el("div", { style: "min-height:210px" }, [realQR(link)]);
  const left = el("div", { class: "card", style: "text-align:center" }, [
    el("h3", { text: "📱 " + t("qrmenu") }),
    qrBox,
    acc
      ? el("p", { class: "muted", style: "font-size:12px;word-break:break-all", text: link })
      : el("p", { class: "pill amber", style: "margin:8px auto", text: "Bulut hesabı yok — QR menü için giriş yapın" }),
    el("button", { class: "btn ghost block", onClick: () => { navigator.clipboard?.writeText(link); toast("Bağlantı kopyalandı", "success"); } }, ["🔗 Bağlantıyı Kopyala"]),
    el("button", { class: "btn block", style: "margin-top:8px", onClick: () => printQrPoster(link, s) }, ["🖼 Profesyonel Afiş (Tekli QR)"]),
    el("button", { class: "btn ghost block", style: "margin-top:8px", onClick: () => printQrSheet(link, s) }, ["🖨 Çoklu QR Çıktısı (A4)"]),
    el("p", { class: "muted", style: "font-size:11px;margin-top:6px", text: "Afiş: masaya/duvara asmak için tek büyük QR (QR OKUTUN! + bağlantı). Çoklu: A4'e sığdığı kadar küçük QR." }),
  ]);

  const right = el("div", { style: "display:grid;gap:16px" });

  // ---- İstatistikler (kaç kişi QR okuttu, puan, anket) ----
  const statsCard = el("div", { class: "card" }, [
    el("h3", { text: "📊 İstatistikler" }),
    el("div", { id: "qr-stats", style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px" }, [
      el("p", { class: "muted", text: "Yükleniyor…" }),
    ]),
  ]);
  right.appendChild(statsCard);
  loadQrStats(acc, statsCard.querySelector("#qr-stats"));

  // ---- Vitrin & İletişim editörü ----
  right.appendChild(showcaseEditor(s));

  // ---- Anket düzenleyici ----
  right.appendChild(surveyEditor(s, host));

  // ---- Başvuru / Anket + CV yükleme (AYRI link) ----
  right.appendChild(applicationCard(s, host));

  // ---- Randevu (AYRI link) ----
  right.appendChild(randevuCard(s, host));

  // ---- Menü önizleme (yeniden çizilebilir gövde) ----
  const previewBody = el("div", {});
  const menu = el("div", { class: "card" }, [
    el("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:6px" }, [
      el("h3", { style: "margin:0", text: "🍽 " + (s.business || "Menü") + " — Önizleme" }),
    ]),
    el("p", { class: "muted", style: "font-size:12px;margin:0 0 6px", text: "📷 Ürün fotoğrafı eklemek için: Stok Yönetimi → ürünü düzenle → Görsel. Fotoğraflar QR menüde otomatik görünür." }),
    previewBody,
  ]);
  const paintPreview = () => {
    clear(previewBody);
    const st = settings.get();
    const merged = mergeMenuItems(db.categories.all(), db.products.all().filter((p) => p.active !== false && !p.menuHide), st);
    buildMenuInto(previewBody, merged.cats, merged.products, st);
  };
  paintPreview();

  // ---- QR'a özel ürünler (stoksuz/üretim) + PDF menü ----
  right.appendChild(qrProductsCard(paintPreview));
  // ---- İşletme fotoğrafları (QR menüde galeri + afişte) ----
  right.appendChild(bizPhotosCard(paintPreview));
  right.appendChild(pdfMenuCard());

  // ---- Menüde görünecek ürünleri seç (sadece işaretliler QR menüde görünür) ----
  right.appendChild(menuVisibilityCard(paintPreview));
  right.appendChild(menu);

  layout.append(left, right);
  clear(host).append(head, layout);
}

// İstatistikleri buluttan çek ve göster
async function loadQrStats(acc, box) {
  if (!acc) { box.innerHTML = ""; box.appendChild(el("p", { class: "pill amber", text: "Bulut hesabı yok — giriş yapın" })); return; }
  let r; try { r = await cloud.stats(acc); } catch { r = null; }
  clear(box);
  const stat = (num, lbl, color) => el("div", { style: "text-align:center;padding:10px;border:1px solid var(--border);border-radius:10px" }, [
    el("div", { style: `font-size:26px;font-weight:800;color:${color}`, text: String(num) }),
    el("div", { class: "muted", style: "font-size:12px", text: lbl }),
  ]);
  if (!r || !r.ok) { box.appendChild(el("p", { class: "muted", text: "İstatistik yüklenemedi." })); return; }
  box.append(
    stat(r.scans || 0, "QR OKUTMA", "var(--primary)"),
    stat(r.ratingCount ? (r.ratingAvg + " ★") : "—", `PUAN (${r.ratingCount || 0})`, "#f59e0b"),
    stat(r.surveyCount || 0, "ANKET CEVABI", "#22c55e"),
  );
  // Anket cevaplarını listele
  if (Array.isArray(r.surveys) && r.surveys.length) {
    const list = el("div", { style: "grid-column:1/-1;margin-top:6px" }, [
      el("div", { style: "font-weight:700;margin-bottom:6px", text: "📝 Son Anket Cevapları" }),
      ...r.surveys.slice(0, 20).map((sv) => {
        const ans = Array.isArray(sv.answers) ? sv.answers : [];
        return el("div", { style: "border:1px solid var(--border);border-radius:8px;padding:8px;margin-bottom:6px" },
          ans.map((a) => el("div", { style: "font-size:13px" }, [
            el("b", { text: (a.q || "") + ": " }), el("span", { class: "muted", text: String(a.a || "") }),
          ])));
      }),
    ]);
    box.appendChild(list);
  }
}

// Vitrin & iletişim bilgileri editörü (buluta senkronlanır → müşteri menüsünde görünür)
function showcaseEditor(s) {
  const owner = el("input", { class: "input", value: s.owner || "", placeholder: "İşletme sahibinin adı soyadı" });
  const insta = el("input", { class: "input", value: s.instagram || "", placeholder: "@kullaniciadi" });
  const wa = el("input", { class: "input", inputmode: "tel", value: s.whatsapp || s.phone || "", placeholder: "905xxxxxxxxx" });
  const phone = el("input", { class: "input", inputmode: "tel", value: s.phone || "", placeholder: "0555 000 00 00" });
  const email = el("input", { class: "input", inputmode: "email", value: s.email || "", placeholder: "ornek@isletme.com" });
  const maps = el("input", { class: "input", value: s.maps || "", placeholder: "Google Maps bağlantısı veya adres" });
  const grev = el("input", { class: "input", value: s.googleReviews || "", placeholder: "Google Yorum/İşletme bağlantısı" });
  const web = el("input", { class: "input", value: s.website || "", placeholder: "www.siteniz.com" });
  const about = el("textarea", { class: "input", rows: "3", placeholder: "İşletmeniz hakkında kısa tanıtım…" }); about.value = s.about || "";
  const iban = el("input", { class: "input", value: s.iban || "", placeholder: "TR00 0000 0000 0000 0000 0000 00" });
  const bankName = el("input", { class: "input", value: s.bankName || "", placeholder: "Banka adı (örn. Ziraat)" });
  const bankHolder = el("input", { class: "input", value: s.bankHolder || "", placeholder: "Hesap sahibi ad soyad / ünvan" });
  const wifiName = el("input", { class: "input", value: s.wifiName || "", placeholder: "WiFi ağ adı" });
  const wifiPass = el("input", { class: "input", value: s.wifiPass || "", placeholder: "WiFi şifresi" });
  const menuColor = el("input", { type: "color", value: s.menuColor || "#2563EB", style: "width:60px;height:40px;padding:2px;border:1px solid var(--border);border-radius:8px;cursor:pointer" });
  // Hazır renk paleti (tek tıkla seç)
  const swatches = ["#2563EB", "#DB2777", "#7C3AED", "#059669", "#EA580C", "#DC2626", "#0891B2", "#CA8A04", "#0F172A"];
  const swatchRow = el("div", { style: "display:flex;flex-wrap:wrap;gap:8px;align-items:center" }, [
    menuColor,
    ...swatches.map((col) => el("button", {
      type: "button", title: col,
      style: `width:30px;height:30px;border-radius:50%;border:2px solid #fff;box-shadow:0 0 0 1px var(--border);cursor:pointer;background:${col}`,
      onClick: () => { menuColor.value = col; },
    })),
  ]);

  const row = (a, b) => el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:10px" }, [a, b]);
  const fld = (label, node) => el("div", { class: "field" }, [el("label", { text: label }), node]);
  const chk = (title, desc, checked) => {
    const input = el("input", { type: "checkbox" }); input.checked = !!checked;
    const wrap = el("label", { style: "display:flex;align-items:center;gap:10px;cursor:pointer;margin:6px 0;padding:8px;border:1px solid var(--border);border-radius:10px" }, [
      input, el("span", {}, [
        el("div", { style: "font-weight:700", text: title }),
        el("div", { class: "muted", style: "font-size:12px", text: desc }),
      ]),
    ]);
    return { wrap, input };
  };
  const reqTable = chk("🪑 Sipariş için masa numarası zorunlu", "Açıkken müşteri masa no girmeden sipariş/çağrı yapamaz.", s.requireTable);
  const ordering = chk("🛒 Online sipariş açık", "Kapalıyken müşteri sadece menüyü görür, sipariş veremez.", s.menuOrdering !== false);
  const waOrder = chk("💬 Siparişi WhatsApp'tan al", "Açıkken 'Siparişi Gönder' müşteriyi hazır mesajla WhatsApp'a yönlendirir.", s.menuWhatsappOrder);
  const hidePrice = chk("🏷️ Fiyatları gizle", "Açıkken menüde ürün fiyatları gösterilmez (vitrin/katalog modu).", s.hideMenuPrice);
  const ratingOn = chk("⭐ Müşteri puanlaması açık", "Kapalıyken müşteri menüde yıldızla puan veremez. (Her cihaz yalnızca 1 kez puan verebilir.)", s.ratingEnabled !== false);
  const bigPhotos = chk("🖼 Büyük ürün fotoğrafları", "QR okutulunca ürün görselleri büyük ve tam genişlikte, iştah açıcı şekilde gösterilir.", s.menuBigPhotos);
  const nutriOn = chk("🔥 Besin değerlerini göster", "Ürünlerde kalori / gram / porsiyon / alerjen bilgisi rozet olarak gösterilir.", s.showNutrition !== false);
  const tableCount = el("input", { class: "input", type: "number", inputmode: "numeric", min: "0", max: "500", value: s.tableCount ? String(s.tableCount) : "", placeholder: "Örn. 20", style: "max-width:140px" });

  return el("div", { class: "card" }, [
    el("h3", { text: "🔗 Vitrin, İletişim & Kartvizit" }),
    el("p", { class: "muted", text: "Bu bilgiler, müşteri QR'ı okutunca açılan tıklama ekranındaki butonları besler: WhatsApp, Google Maps, Web Sitemiz, Sosyal Medya, İletişim. Menü butonu ise Stok/Ürünler'den gelir." }),
    fld("👤 İşletme Sahibi", owner),
    row(fld("📷 Instagram", insta), fld("💬 WhatsApp", wa)),
    row(fld("📞 Telefon", phone), fld("✉️ E-Posta", email)),
    row(fld("🌐 Web Sitesi", web), fld("⭐ Google Yorumlar", grev)),
    fld("📍 Google Maps / Adres", maps),
    fld("ℹ️ Hakkımızda", about),
    el("div", { style: "font-weight:700;margin:8px 0 2px", text: "🏦 Banka / IBAN" }),
    fld("IBAN", iban),
    row(fld("Banka", bankName), fld("Hesap Sahibi", bankHolder)),
    row(fld("📶 WiFi Adı", wifiName), fld("🔑 WiFi Şifresi", wifiPass)),
    el("div", { style: "font-weight:700;margin:10px 0 2px", text: "🎨 Menü Rengi" }),
    el("p", { class: "muted", style: "font-size:12px;margin:0 0 6px", text: "Müşteri menüsündeki başlık ve vurgu rengi." }),
    swatchRow,
    el("div", { style: "font-weight:700;margin:10px 0 2px", text: "⚙️ Menü Ayarları" }),
    ordering.wrap, waOrder.wrap, hidePrice.wrap, reqTable.wrap, ratingOn.wrap, bigPhotos.wrap, nutriOn.wrap,
    el("div", { class: "field", style: "margin-top:6px" }, [
      el("label", { text: "🪑 Masa Sayısı (boş masaları görmek için)" }),
      tableCount,
      el("div", { class: "muted", style: "font-size:12px;margin-top:2px", text: "İşletmenizdeki toplam masa sayısı. Sipariş panelinde hangi masalar dolu/boş görebilirsiniz." }),
    ]),
    el("button", { class: "btn success", onClick: () => {
      settings.set({
        menuColor: menuColor.value || "#2563EB",
        owner: owner.value.trim(),
        instagram: insta.value.trim(), whatsapp: wa.value.trim(),
        phone: phone.value.trim(), email: email.value.trim(),
        website: web.value.trim(), googleReviews: grev.value.trim(),
        maps: maps.value.trim(), about: about.value.trim(),
        iban: iban.value.trim().toUpperCase(), bankName: bankName.value.trim(), bankHolder: bankHolder.value.trim(),
        wifiName: wifiName.value.trim(), wifiPass: wifiPass.value.trim(),
        requireTable: reqTable.input.checked,
        menuOrdering: ordering.input.checked,
        menuWhatsappOrder: waOrder.input.checked,
        hideMenuPrice: hidePrice.input.checked,
        ratingEnabled: ratingOn.input.checked,
        menuBigPhotos: bigPhotos.input.checked,
        showNutrition: nutriOn.input.checked,
        tableCount: Math.max(0, parseInt(tableCount.value, 10) || 0),
      });
      toast("Vitrin bilgileri kaydedildi", "success");
    } }, ["💾 Kaydet"]),
  ]);
}

// Anket düzenleyici — işletme sahibi soruları belirler (buluta senkronlanır)
function surveyEditor(s, host) {
  const survey = (s.survey && Array.isArray(s.survey.questions)) ? JSON.parse(JSON.stringify(s.survey)) : { title: "Görüşleriniz", questions: [] };
  const titleInp = el("input", { class: "input", value: survey.title || "", placeholder: "Anket başlığı" });
  const qList = el("div", { style: "display:grid;gap:8px;margin:8px 0" });

  function paint() {
    clear(qList);
    if (!survey.questions.length) qList.appendChild(el("p", { class: "muted", text: "Henüz soru yok. Aşağıdan ekleyin." }));
    survey.questions.forEach((q, i) => {
      qList.appendChild(el("div", { style: "display:flex;gap:8px;align-items:center" }, [
        el("span", { class: "pill blue", text: q.type === "rating" ? "⭐ Puan" : "✍ Yazı" }),
        el("span", { style: "flex:1", text: q.text }),
        el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: () => { survey.questions.splice(i, 1); paint(); } }, ["🗑"]),
      ]));
    });
  }
  paint();

  const newQ = el("input", { class: "input", placeholder: "Yeni soru metni (örn. Hizmetimizi nasıl buldunuz?)" });
  const newType = el("select", { class: "input", style: "max-width:130px" }, [
    el("option", { value: "text" }, ["✍ Yazılı"]),
    el("option", { value: "rating" }, ["⭐ Puanlı"]),
  ]);
  const addBtn = el("button", { class: "btn", onClick: () => {
    const txt = newQ.value.trim();
    if (!txt) { toast("Soru metni girin", "warn"); return; }
    survey.questions.push({ id: uid(), text: txt, type: newType.value });
    newQ.value = ""; paint();
  } }, ["+ Ekle"]);

  return el("div", { class: "card" }, [
    el("h3", { text: "📋 Anket (Müşteri Görüşleri)" }),
    el("p", { class: "muted", text: "Müşteriler QR menüde ayrı pencerede bu anketi doldurur. Cevaplar yukarıdaki istatistiklerde görünür." }),
    el("div", { class: "field" }, [el("label", { text: "Başlık" }), titleInp]),
    qList,
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [newQ, newType, addBtn]),
    el("div", { style: "display:flex;gap:8px;margin-top:10px" }, [
      el("button", { class: "btn success", onClick: () => {
        settings.set({ survey: { title: titleInp.value.trim() || "Görüşleriniz", questions: survey.questions } });
        toast("Anket kaydedildi", "success");
      } }, ["💾 Anketi Kaydet"]),
      el("button", { class: "btn ghost", onClick: () => {
        settings.set({ survey: null });
        toast("Anket kaldırıldı", "success");
        if (host) renderQrMenu(host);
      } }, ["🗑 Anketi Kaldır"]),
    ]),
  ]);
}

// Başvuru / Anket + CV yükleme kartı (yönetim) — menüden AYRI bir link üretir.
// Ayarlar settings.application içinde tutulur; buluta senkronlanır (public sayfa okur).
function applicationCard(s, host) {
  const acc = currentAccount();
  const app = (s.application && typeof s.application === "object")
    ? JSON.parse(JSON.stringify(s.application))
    : { enabled: false, title: "İş Başvurusu", desc: "Ekibimize katılmak ister misiniz? Formu doldurup CV’nizi yükleyin.", cv: true, questions: [] };
  if (!Array.isArray(app.questions)) app.questions = [];

  const link = applicationLink();

  const enableCb = el("input", { type: "checkbox" }); enableCb.checked = !!app.enabled;
  const cvCb = el("input", { type: "checkbox" }); cvCb.checked = app.cv !== false;
  const titleInp = el("input", { class: "input", value: app.title || "", placeholder: "Başlık (örn. İş Başvurusu)" });
  const descInp = el("textarea", { class: "input", rows: "2", placeholder: "Kısa açıklama" }); descInp.value = app.desc || "";

  const qList = el("div", { style: "display:grid;gap:8px;margin:8px 0" });
  function paintQ() {
    clear(qList);
    if (!app.questions.length) { qList.appendChild(el("p", { class: "muted", text: "Ek soru yok (isteğe bağlı)." })); return; }
    app.questions.forEach((q, i) => {
      qList.appendChild(el("div", { style: "display:flex;gap:8px;align-items:center" }, [
        el("span", { class: "pill blue", text: q.type === "rating" ? "⭐ Puan" : "✍ Yazı" }),
        el("span", { style: "flex:1", text: q.text }),
        el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: () => { app.questions.splice(i, 1); paintQ(); } }, ["🗑"]),
      ]));
    });
  }
  paintQ();
  const newQ = el("input", { class: "input", placeholder: "Yeni soru (örn. Neden çalışmak istiyorsunuz?)" });
  const newType = el("select", { class: "input", style: "max-width:130px" }, [
    el("option", { value: "text" }, ["✍ Yazılı"]),
    el("option", { value: "rating" }, ["⭐ Puanlı"]),
  ]);
  const addQ = el("button", { class: "btn", onClick: () => {
    const txt = newQ.value.trim();
    if (!txt) { toast("Soru metni girin", "warn"); return; }
    app.questions.push({ id: uid(), text: txt, type: newType.value });
    newQ.value = ""; paintQ();
  } }, ["+ Ekle"]);

  const save = () => {
    settings.set({ application: {
      enabled: enableCb.checked,
      title: titleInp.value.trim() || "İş Başvurusu",
      desc: descInp.value.trim(),
      cv: cvCb.checked,
      questions: app.questions,
    } });
    toast("Başvuru formu kaydedildi", "success");
  };

  // Gelen başvurular
  const inbox = el("div", { style: "display:grid;gap:8px;margin-top:8px" }, [el("p", { class: "muted", text: "Yükleniyor…" })]);
  const loadInbox = () => {
    clear(inbox); inbox.appendChild(el("p", { class: "muted", text: "Yükleniyor…" }));
    if (!acc) { clear(inbox); inbox.appendChild(el("p", { class: "muted", text: "Bulut hesabı yok." })); return; }
    cloud.applications(acc).then((r) => {
      clear(inbox);
      const list = (r && Array.isArray(r.applications)) ? r.applications : [];
      if (!list.length) { inbox.appendChild(el("p", { class: "muted", text: "Henüz başvuru yok." })); return; }
      list.forEach((a) => inbox.appendChild(applicationRow(acc, a, loadInbox)));
    }).catch(() => { clear(inbox); inbox.appendChild(el("p", { class: "muted", text: "Başvurular yüklenemedi." })); });
  };
  loadInbox();

  return el("div", { class: "card" }, [
    el("h3", { text: "📄 Başvuru & Anket (CV Yükleme)" }),
    el("p", { class: "muted", style: "font-size:12px", text: "Menü linkinden AYRI, kendine ait bir bağlantı. Müşteri/aday açtığında ad-telefon girer, CV yükler ve sorularınızı yanıtlar. Cevaplar aşağıda listelenir." }),
    el("label", { style: "display:flex;align-items:center;gap:10px;margin:6px 0", }, [enableCb, el("span", { text: "Başvuru formunu yayınla (link aktif olsun)" })]),
    el("label", { style: "display:flex;align-items:center;gap:10px;margin:6px 0", }, [cvCb, el("span", { text: "CV/dosya yükleme alanı açık olsun" })]),
    el("div", { class: "field" }, [el("label", { text: "Başlık" }), titleInp]),
    el("div", { class: "field" }, [el("label", { text: "Açıklama" }), descInp]),
    el("div", { class: "field" }, [el("label", { text: "Ek Sorular (isteğe bağlı)" }), qList,
      el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [newQ, newType, addQ]),
    ]),
    el("button", { class: "btn success", style: "margin-top:6px", onClick: save }, ["💾 Formu Kaydet"]),
    el("hr", { style: "border:none;border-top:1px solid var(--border);margin:14px 0" }),
    el("div", { style: "display:flex;align-items:center;gap:8px;flex-wrap:wrap" }, [
      el("span", { style: "font-weight:700", text: "🔗 Başvuru Bağlantısı:" }),
      acc ? el("span", { class: "muted", style: "font-size:12px;word-break:break-all;flex:1", text: link })
          : el("span", { class: "pill amber", text: "Bulut hesabı yok — giriş yapın" }),
    ]),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:8px" }, [
      el("button", { class: "btn ghost", onClick: () => { navigator.clipboard?.writeText(link); toast("Bağlantı kopyalandı", "success"); } }, ["🔗 Kopyala"]),
      el("button", { class: "btn ghost", onClick: () => printQrPoster(link, s) }, ["🖼 Başvuru Afişi (QR)"]),
    ]),
    el("hr", { style: "border:none;border-top:1px solid var(--border);margin:14px 0" }),
    el("div", { style: "display:flex;align-items:center;justify-content:space-between;gap:8px" }, [
      el("h4", { style: "margin:0", text: "📥 Gelen Başvurular" }),
      el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: loadInbox }, ["↻ Yenile"]),
    ]),
    el("div", { style: "display:flex;gap:8px;align-items:flex-start;background:#fef3c7;color:#92400e;border:1px solid #fde68a;border-radius:8px;padding:8px 10px;margin:6px 0;font-size:12.5px" }, [
      el("span", { style: "font-size:16px", text: "⏳" }),
      el("span", { text: "CV ve başvurular KVKK gereği 3 GÜN sonra otomatik silinir. Saklamak istediğiniz CV'leri lütfen HEMEN indirin." }),
    ]),
    inbox,
  ]);
}

// Tek bir başvuru satırı (yönetim listesinde) — CV indir / gör / sil.
function applicationRow(account, a, onChange) {
  const when = a.created_at ? new Date(a.created_at).toLocaleString("tr-TR") : "";
  const meta = [a.phone, a.email].filter(Boolean).join(" · ");
  const answersBox = el("div", { style: "display:grid;gap:2px;margin-top:6px" });
  if (Array.isArray(a.answers)) a.answers.forEach((x) => {
    if (x && x.q) answersBox.appendChild(el("div", { style: "font-size:12px" }, [
      el("span", { class: "muted", text: (x.q + ": ") }), el("span", { text: String(x.a ?? "") }),
    ]));
  });
  if (a.note) answersBox.appendChild(el("div", { style: "font-size:12px" }, [el("span", { class: "muted", text: "Not: " }), el("span", { text: a.note })]));

  const dlBtn = a.hasCv ? el("button", { class: "btn ghost", style: "padding:5px 12px", onClick: async (e) => {
    const btn = e.currentTarget; const old = btn.textContent; btn.textContent = "İndiriliyor…"; btn.disabled = true;
    try {
      const r = await cloud.cvfile(account, a.id);
      if (r && r.ok && r.cvData) {
        const link = document.createElement("a");
        link.href = r.cvData; link.download = r.cvName || ("cv-" + a.id);
        document.body.appendChild(link); link.click(); link.remove();
      } else toast("CV bulunamadı", "warn");
    } catch { toast("CV indirilemedi", "error"); }
    finally { btn.textContent = old; btn.disabled = false; }
  } }, ["⬇ CV İndir"]) : el("span", { class: "muted", style: "font-size:12px", text: "CV yok" });

  const delBtn = el("button", { class: "btn ghost", style: "padding:5px 12px", onClick: async () => {
    try { await cloud.appseen(account, a.id, { delete: true }); toast("Başvuru silindi", "success"); if (onChange) onChange(); }
    catch { toast("Silinemedi", "error"); }
  } }, ["🗑"]);

  // Kalan süre: oluşturulmadan 3 gün sonra otomatik silinir (KVKK).
  let ttlBadge = null;
  if (a.created_at) {
    const leftMs = (a.created_at + 3 * 24 * 60 * 60 * 1000) - Date.now();
    const hoursLeft = Math.max(0, Math.round(leftMs / 3600000));
    const label = hoursLeft <= 0 ? "yakında silinecek"
      : hoursLeft < 24 ? (hoursLeft + " saat sonra silinir")
      : (Math.ceil(hoursLeft / 24) + " gün sonra silinir");
    const urgent = hoursLeft < 24;
    ttlBadge = el("span", {
      style: "font-size:11px;font-weight:700;padding:2px 8px;border-radius:20px;" +
        (urgent ? "background:#fee2e2;color:#b91c1c" : "background:#fef3c7;color:#92400e"),
      text: "⏳ " + label,
    });
  }

  return el("div", { style: "border:1px solid var(--border);border-radius:12px;padding:10px 12px" }, [
    el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap" }, [
      el("span", { style: "font-weight:700;font-size:15px", text: a.name || "(isimsiz)" }),
      meta ? el("span", { class: "muted", style: "font-size:12px", text: meta }) : null,
      el("span", { style: "flex:1" }),
      ttlBadge,
      el("span", { class: "muted", style: "font-size:11px", text: when }),
    ]),
    answersBox,
    el("div", { style: "display:flex;gap:8px;margin-top:8px" }, [dlBtn, el("span", { style: "flex:1" }), delBtn]),
  ]);
}

// Menüde görünecek ürünleri seç — sadece işaretli ürünler QR menüde gösterilir.
// Ürün başına `menuHide` bayrağı; buluta senkronlanır (products tablosu).
function menuVisibilityCard(onChange) {
  const cats = db.categories.all();
  const catName = (id) => { const c = cats.find((x) => x.id === id); return c ? ((c.icon ? c.icon + " " : "") + c.name) : "Diğer"; };
  const listBox = el("div", { style: "display:grid;gap:6px;max-height:320px;overflow:auto;margin-top:8px" });
  const search = el("input", { class: "input", placeholder: "🔎 Ürün ara…", style: "margin-top:8px" });

  function paint(filter) {
    clear(listBox);
    const q = (filter || "").trim().toLowerCase();
    const prods = db.products.all()
      .filter((p) => p.active !== false)
      .filter((p) => !q || String(p.name || "").toLowerCase().includes(q))
      .sort((a, b) => String(catName(a.categoryId)).localeCompare(String(catName(b.categoryId)), "tr") || String(a.name).localeCompare(String(b.name), "tr"));
    if (!prods.length) { listBox.appendChild(el("p", { class: "muted", text: "Ürün bulunamadı. Stok Yönetimi'nden ürün ekleyin." })); return; }
    let lastCat = null;
    prods.forEach((p) => {
      const cn = catName(p.categoryId);
      if (cn !== lastCat) { lastCat = cn; listBox.appendChild(el("div", { style: "font-weight:700;font-size:12px;color:var(--muted);margin:6px 0 2px", text: cn })); }
      const cb = el("input", { type: "checkbox" }); cb.checked = !p.menuHide;
      cb.addEventListener("change", () => {
        db.products.upsert({ id: p.id, menuHide: !cb.checked });
        if (typeof onChange === "function") onChange();
      });
      const rowLbl = el("label", { style: "display:flex;align-items:center;gap:10px;cursor:pointer;padding:7px 10px;flex:1;min-width:0" }, [
        cb,
        p.image ? el("img", { src: p.image, alt: p.name, style: "width:28px;height:28px;border-radius:6px;object-fit:cover" }) : el("span", { style: "font-size:18px", text: p.emoji || "🍽" }),
        el("span", { style: "flex:1;font-size:14px", text: p.name || "(isimsiz)" }),
        el("span", { class: "muted", style: "font-size:12px", text: money(p.price) }),
      ]);
      const editBtn = el("button", { class: "btn ghost", style: "padding:4px 10px;margin-right:6px", title: "Ürünü düzenle", onClick: () => editProduct(p.id) }, ["✏️"]);
      listBox.appendChild(el("div", { style: "display:flex;align-items:center;border:1px solid var(--border);border-radius:10px" }, [rowLbl, editBtn]));
    });
  }

  // Stok ürününü QR bölümünden düzenle — ad, fiyat, görsel, emoji, besin değerleri.
  // Aynı ürün STOK'ta da güncellenir (tek kayıt). Stok adedi ve barkod korunur.
  function editProduct(pid) {
    const p = db.products.get(pid);
    if (!p) return;
    const eName = el("input", { class: "input", placeholder: "Ürün adı *", value: p.name || "" });
    const ePrice = el("input", { class: "input", type: "number", inputmode: "decimal", min: "0", placeholder: "Fiyat", value: p.price != null ? String(p.price) : "" });
    const eDesc = el("input", { class: "input", placeholder: "Kısa açıklama (menüde görünür)", value: p.desc || p.description || "" });
    const eEmoji = el("input", { class: "input", placeholder: "Emoji (örn. 🍔)", value: p.emoji || "", style: "max-width:120px" });
    const eKcal = el("input", { class: "input", placeholder: "Kalori", value: p.kcal || "" });
    const eGram = el("input", { class: "input", placeholder: "Gram", value: p.gram || "" });
    const ePort = el("input", { class: "input", placeholder: "Porsiyon", value: p.portion || "" });
    const eAllerg = el("input", { class: "input", placeholder: "Alerjen (Gluten, Süt…)", value: p.allergens || "" });
    let eImg = p.image || "";
    const eImgMsg = el("div", { class: "muted", style: "font-size:12px", text: eImg ? "✓ Görsel var" : "Görsel yok" });
    const eFile = el("input", { type: "file", accept: "image/*", style: "display:none" });
    eFile.addEventListener("change", () => {
      const f = eFile.files && eFile.files[0]; if (!f) return;
      if (f.size > 2 * 1024 * 1024) { toast("Görsel çok büyük (en fazla 2 MB).", "warn"); eFile.value = ""; return; }
      const r = new FileReader(); r.onload = () => { eImg = String(r.result); eImgMsg.textContent = "✓ Görsel değiştirildi (" + Math.round(f.size / 1024) + " KB)"; }; r.readAsDataURL(f);
    });
    const ePick = el("button", { class: "btn ghost", type: "button", style: "padding:8px 12px", onClick: () => eFile.click() }, ["📷 Görsel Değiştir"]);
    const eClear = el("button", { class: "btn ghost", type: "button", style: "padding:8px 12px", onClick: () => { eImg = ""; eImgMsg.textContent = "Görsel kaldırıldı"; eFile.value = ""; } }, ["🗑 Görseli Kaldır"]);
    const g2 = (a, b) => el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:8px" }, [a, b]);
    modal({
      title: "✏️ Ürünü Düzenle — " + (p.name || ""),
      body: el("div", { style: "display:grid;gap:8px" }, [
        el("p", { class: "muted", style: "font-size:12px;margin:0", text: "Bu ürün STOK bölümündeki kayıtla aynıdır; değişiklik her iki yere de yansır. Stok adedi ve barkod korunur." }),
        g2(eName, ePrice),
        g2(eDesc, eEmoji),
        g2(eKcal, eGram),
        g2(ePort, eAllerg),
        el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap" }, [ePick, eClear, eImgMsg, eFile]),
      ]),
      actions: [
        { label: "💾 Kaydet", kind: "success", onClick: (close) => {
          const nm = eName.value.trim();
          if (!nm) { toast("Ürün adı girin", "warn"); eName.focus(); return; }
          db.products.upsert({
            id: p.id, name: nm, price: Number(ePrice.value) || 0,
            desc: eDesc.value.trim(), emoji: eEmoji.value.trim(), image: eImg,
            kcal: eKcal.value.trim(), gram: eGram.value.trim(), portion: ePort.value.trim(),
            allergens: eAllerg.value.trim(),
          });
          paint(search.value); close();
          if (typeof onChange === "function") onChange();
          toast("Ürün güncellendi", "success");
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  const setAll = (visible) => {
    const q = (search.value || "").trim().toLowerCase();
    db.products.all()
      .filter((p) => p.active !== false)
      .filter((p) => !q || String(p.name || "").toLowerCase().includes(q))
      .forEach((p) => db.products.upsert({ id: p.id, menuHide: !visible }));
    paint(search.value);
    if (typeof onChange === "function") onChange();
    toast(visible ? "Tüm ürünler menüye eklendi" : "Tüm ürünler menüden gizlendi", "success");
  };

  search.addEventListener("input", () => paint(search.value));
  paint("");

  return el("div", { class: "card" }, [
    el("h3", { text: "🍽 Menüde Görünecek Ürünler" }),
    el("p", { class: "muted", style: "font-size:12px", text: "Stoktaki her ürün otomatik menüye eklenir. İşareti kaldırdığınız ürün QR menüde MÜŞTERİYE gösterilmez (stok/satış etkilenmez)." }),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:8px" }, [
      el("button", { class: "btn ghost", style: "padding:6px 12px", onClick: () => setAll(true) }, ["✓ Tümünü Göster"]),
      el("button", { class: "btn ghost", style: "padding:6px 12px", onClick: () => setAll(false) }, ["✕ Tümünü Gizle"]),
    ]),
    search,
    listBox,
  ]);
}

// QR menüye özel ürün yöneticisi — STOK'A DOKUNMADAN ürün ekle.
// Üretim/sipariş usulü ürünler (stok sayısı gerekmez) settings.menuItems içinde tutulur.
// Alanlar: ad, fiyat, kategori(ad), açıklama, görsel, kalori, gram, porsiyon, alerjen.
function qrProductsCard(onChange) {
  const s = settings.get();
  const items = Array.isArray(s.menuItems) ? JSON.parse(JSON.stringify(s.menuItems)) : [];
  const listBox = el("div", { style: "display:grid;gap:8px;margin:8px 0" });

  const persist = () => {
    settings.set({ menuItems: items });
    if (typeof onChange === "function") onChange();
  };

  function paint() {
    clear(listBox);
    // Silinmiş (mezar taşı) ürünler gösterilmez; ama dizide kalır ki silme diğer cihaza da yayılsın.
    if (!items.some((m) => m && !m._deleted)) { listBox.appendChild(el("p", { class: "muted", text: "Henüz QR'a özel ürün yok. Aşağıdan ekleyin (stok etkilenmez)." })); return; }
    items.forEach((m, i) => {
      if (!m || m._deleted) return; // i, tam dizideki gerçek index — düzenle/sil doğru öğeye işaret eder
      const nutri = [m.kcal ? "🔥" + m.kcal : "", m.gram ? "⚖️" + m.gram + "g" : "", m.portion ? "🍽" + m.portion : ""].filter(Boolean).join(" · ");
      listBox.appendChild(el("div", { style: "display:flex;align-items:center;gap:10px;border:1px solid var(--border);border-radius:10px;padding:8px 10px" }, [
        m.image ? el("img", { src: m.image, alt: m.name, style: "width:40px;height:40px;border-radius:8px;object-fit:cover" }) : el("span", { style: "font-size:22px", text: m.emoji || "🍽" }),
        el("div", { style: "flex:1;min-width:0" }, [
          el("div", { style: "font-weight:700", text: (m.name || "(isimsiz)") + (m.cat ? "  ·  " + m.cat : "") }),
          el("div", { class: "muted", style: "font-size:12px", text: [money(m.price), nutri].filter(Boolean).join("  ·  ") }),
        ]),
        el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: () => editItem(i) }, ["✏️"]),
        el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: () => { items[i] = { ...items[i], _deleted: true, _u: Date.now() }; persist(); paint(); } }, ["🗑"]),
      ]));
    });
  }
  paint();

  // Mevcut bir QR ürününü düzenle — açılır pencerede tüm alanları güncelle.
  function editItem(idx) {
    const m = items[idx];
    if (!m) return;
    const eName = el("input", { class: "input", placeholder: "Ürün adı *", value: m.name || "" });
    const ePrice = el("input", { class: "input", type: "number", inputmode: "decimal", min: "0", placeholder: "Fiyat", value: m.price != null ? String(m.price) : "" });
    const eCat = el("input", { class: "input", placeholder: "Kategori (örn. Tatlılar)", value: m.cat || "" });
    const eDesc = el("input", { class: "input", placeholder: "Kısa açıklama", value: m.desc || "" });
    const eKcal = el("input", { class: "input", placeholder: "Kalori (örn. 320)", value: m.kcal || "" });
    const eGram = el("input", { class: "input", placeholder: "Gram (örn. 250)", value: m.gram || "" });
    const ePort = el("input", { class: "input", placeholder: "Porsiyon (örn. 1 kişilik)", value: m.portion || "" });
    const eAllerg = el("input", { class: "input", placeholder: "Alerjen (örn. Gluten, Süt)", value: m.allergens || "" });
    let eImg = m.image || "";
    const eImgMsg = el("div", { class: "muted", style: "font-size:12px", text: eImg ? "✓ Görsel var" : "Görsel yok" });
    const eFile = el("input", { type: "file", accept: "image/*", style: "display:none" });
    eFile.addEventListener("change", () => {
      const f = eFile.files && eFile.files[0]; if (!f) return;
      if (f.size > 2 * 1024 * 1024) { toast("Görsel çok büyük (en fazla 2 MB).", "warn"); eFile.value = ""; return; }
      const r = new FileReader(); r.onload = () => { eImg = String(r.result); eImgMsg.textContent = "✓ Görsel değiştirildi (" + Math.round(f.size / 1024) + " KB)"; }; r.readAsDataURL(f);
    });
    const ePick = el("button", { class: "btn ghost", type: "button", style: "padding:8px 12px", onClick: () => eFile.click() }, ["📷 Görsel Değiştir"]);
    const eClear = el("button", { class: "btn ghost", type: "button", style: "padding:8px 12px", onClick: () => { eImg = ""; eImgMsg.textContent = "Görsel kaldırıldı"; eFile.value = ""; } }, ["🗑 Görseli Kaldır"]);
    const g2 = (a, b) => el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:8px" }, [a, b]);
    modal({
      title: "✏️ QR Ürününü Düzenle",
      body: el("div", { style: "display:grid;gap:8px" }, [
        g2(eName, ePrice),
        g2(eCat, eDesc),
        g2(eKcal, eGram),
        g2(ePort, eAllerg),
        el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap" }, [ePick, eClear, eImgMsg, eFile]),
      ]),
      actions: [
        { label: "💾 Kaydet", kind: "success", onClick: (close) => {
          const nm = eName.value.trim();
          if (!nm) { toast("Ürün adı girin", "warn"); eName.focus(); return; }
          items[idx] = {
            ...m, name: nm, price: Number(ePrice.value) || 0,
            cat: eCat.value.trim(), desc: eDesc.value.trim(), image: eImg,
            kcal: eKcal.value.trim(), gram: eGram.value.trim(), portion: ePort.value.trim(),
            allergens: eAllerg.value.trim(), _u: Date.now(),
          };
          persist(); paint(); close();
          toast("QR ürünü güncellendi", "success");
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  // Ekleme formu
  const nameI = el("input", { class: "input", placeholder: "Ürün adı *" });
  const priceI = el("input", { class: "input", type: "number", inputmode: "decimal", min: "0", placeholder: "Fiyat" });
  const catI = el("input", { class: "input", placeholder: "Kategori (örn. Tatlılar)" });
  const descI = el("input", { class: "input", placeholder: "Kısa açıklama" });
  const kcalI = el("input", { class: "input", placeholder: "Kalori (örn. 320)" });
  const gramI = el("input", { class: "input", placeholder: "Gram (örn. 250)" });
  const portI = el("input", { class: "input", placeholder: "Porsiyon (örn. 1 kişilik)" });
  const allergI = el("input", { class: "input", placeholder: "Alerjen (örn. Gluten, Süt)" });
  let imgData = "";
  const imgMsg = el("div", { class: "muted", style: "font-size:12px", text: "Görsel yok" });
  const fileI = el("input", { type: "file", accept: "image/*", style: "display:none" });
  fileI.addEventListener("change", () => {
    const f = fileI.files && fileI.files[0]; if (!f) return;
    if (f.size > 2 * 1024 * 1024) { toast("Görsel çok büyük (en fazla 2 MB).", "warn"); fileI.value = ""; return; }
    const r = new FileReader(); r.onload = () => { imgData = String(r.result); imgMsg.textContent = "✓ Görsel seçildi (" + Math.round(f.size / 1024) + " KB)"; }; r.readAsDataURL(f);
  });
  const pickBtn = el("button", { class: "btn ghost", type: "button", style: "padding:8px 12px", onClick: () => fileI.click() }, ["📷 Görsel Seç"]);

  const grid2 = (a, b) => el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:8px" }, [a, b]);
  const addBtn = el("button", { class: "btn", onClick: () => {
    const name = nameI.value.trim();
    if (!name) { toast("Ürün adı girin", "warn"); nameI.focus(); return; }
    items.push({
      id: "qr_" + uid(), name, price: Number(priceI.value) || 0,
      cat: catI.value.trim(), desc: descI.value.trim(), image: imgData,
      kcal: kcalI.value.trim(), gram: gramI.value.trim(), portion: portI.value.trim(),
      allergens: allergI.value.trim(), active: true, _u: Date.now(),
    });
    persist(); paint();
    [nameI, priceI, catI, descI, kcalI, gramI, portI, allergI].forEach((x) => (x.value = ""));
    imgData = ""; imgMsg.textContent = "Görsel yok"; fileI.value = "";
    toast("QR ürünü eklendi", "success");
  } }, ["+ Ürünü Ekle"]);

  return el("div", { class: "card" }, [
    el("h3", { text: "🍰 QR'a Özel Ürünler (Stoksuz / Üretim)" }),
    el("p", { class: "muted", style: "font-size:12px", text: "Stok sayısı tutulmayan, sipariş gelince üretilen ürünler. Buradan eklenen ürünler yalnızca QR menüde görünür, STOK bölümünü etkilemez." }),
    listBox,
    el("div", { style: "border-top:1px solid var(--border);margin-top:6px;padding-top:10px;display:grid;gap:8px" }, [
      grid2(nameI, priceI),
      grid2(catI, descI),
      grid2(kcalI, gramI),
      grid2(portI, allergI),
      el("div", { style: "display:flex;align-items:center;gap:10px" }, [pickBtn, imgMsg, fileI]),
      addBtn,
    ]),
  ]);
}

// PDF Menü yükleme kartı — işletme dilerse tüm menüyü PDF olarak yükler.
// settings.menuPdf (data URL) + settings.menuPdfName. Boyut sınırı ~2.5 MB.
function pdfMenuCard() {
  const s = settings.get();
  const status = el("div", { class: "muted", style: "font-size:13px;margin:6px 0" });
  const paintStatus = () => {
    const cur = settings.get();
    status.textContent = cur.menuPdf ? ("✓ Yüklü: " + (cur.menuPdfName || "Menü.pdf")) : "Henüz PDF yüklenmedi.";
  };
  paintStatus();
  const fileI = el("input", { type: "file", accept: "application/pdf,.pdf", style: "display:none" });
  fileI.addEventListener("change", () => {
    const f = fileI.files && fileI.files[0]; if (!f) return;
    if (!/pdf$/i.test(f.name) && f.type !== "application/pdf") { toast("Lütfen PDF dosyası seçin.", "warn"); fileI.value = ""; return; }
    if (f.size > 2.5 * 1024 * 1024) { toast("PDF çok büyük (en fazla 2.5 MB). Sıkıştırıp tekrar deneyin.", "warn"); fileI.value = ""; return; }
    const r = new FileReader();
    r.onload = () => { settings.set({ menuPdf: String(r.result), menuPdfName: f.name }); paintStatus(); toast("PDF menü yüklendi", "success"); };
    r.readAsDataURL(f);
  });
  return el("div", { class: "card" }, [
    el("h3", { text: "📄 PDF Menü (İsteğe Bağlı)" }),
    el("p", { class: "muted", style: "font-size:12px", text: "Hazır bir menü PDF'iniz varsa yükleyin; müşteri QR menüde '📄 PDF Menüyü Aç' ile görüntüler. (En fazla 2.5 MB)" }),
    status,
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap" }, [
      el("button", { class: "btn", type: "button", onClick: () => fileI.click() }, ["⬆ PDF Yükle / Değiştir"]),
      el("button", { class: "btn ghost", type: "button", onClick: () => { settings.set({ menuPdf: "", menuPdfName: "" }); paintStatus(); toast("PDF menü kaldırıldı", "success"); } }, ["🗑 Kaldır"]),
      fileI,
    ]),
  ]);
}

// ---- Herkese açık sayfa (müşteri QR okutunca; giriş yok, veri buluttan) ----
// Önce görsel bir "tıklama ekranı" (bio-link) açılır; oradan Menü / WhatsApp /
// Google Maps / Web Sitesi / Sosyal Medya / İletişim'e ulaşılır. QR kodu yalnızca
// yönetim (yazılım) tarafında görünür; müşteri tarafında büyük butonlar görünür.
export async function renderPublicMenu(host, account, masa) {
  clear(host);
  const loading = el("div", { class: "bio-loading" }, [
    el("div", { class: "bio-spin" }),
    el("div", { style: "margin-top:14px;font-weight:800;color:#fff;letter-spacing:.3px", text: "Yükleniyor…" }),
  ]);
  host.appendChild(loading);

  const data = await fetchAccountData(account);
  clear(host);
  if (!data || (!Array.isArray(data.products) && !Array.isArray(data.categories))) {
    host.appendChild(el("div", { style: "max-width:720px;margin:40px auto;padding:16px" }, [
      el("div", { class: "card", style: "text-align:center;padding:24px" }, [
        el("div", { style: "font-size:40px", text: "😕" }),
        el("h3", { text: "Sayfa bulunamadı" }),
        el("p", { class: "muted", text: "İşletme henüz sayfasını yayınlamamış olabilir veya bağlantı hatalı." }),
      ]),
    ]));
    return;
  }

  // QR okutma sayacı (tarayıcı başına 1 kez — sunucu şişmesin)
  try {
    const flag = "t101_scan_" + account;
    if (!sessionStorage.getItem(flag)) {
      sessionStorage.setItem(flag, "1");
      cloud.scan(account).catch(() => {});
    }
  } catch {}

  // Masalı QR ile gelindiyse masa numarasını veriye iliştir (menüde otomatik dolsun).
  if (masa) { try { data._masa = String(masa).replace(/\D/g, "").slice(0, 6); } catch {} }
  renderBioLanding(host, account, data);
}

// ---- Herkese açık BAŞVURU / ANKET + CV yükleme sayfası (ayrı link) ----
// #/basvuru/<hesap> → müşteri/aday giriş yapmadan formu doldurur, CV yükler.
// Masaüstü (PC) ve mobil cihazda otomatik uyumlu (responsive) görünür.
export async function renderApplicationPage(host, account) {
  clear(host);
  const loading = el("div", { class: "bio-loading" }, [
    el("div", { class: "bio-spin" }),
    el("div", { style: "margin-top:14px;font-weight:800;color:#fff;letter-spacing:.3px", text: "Yükleniyor…" }),
  ]);
  host.appendChild(loading);

  const data = await fetchAccountData(account);
  clear(host);
  const sett = (data && data.settings) || {};
  const app = sett.application || {};
  const biz = sett.business || sett.owner || "İşletme";
  const accent = sett.menuColor || "#2563EB";
  const cLight = mix(accent, "#ffffff", 0.20);
  let cAlt = shade(accent, -14); try { cAlt = rotateHue(accent, 34); } catch {}

  // Stil (tek seferlik) — masaüstü + mobil uyumlu
  ensureAppStyle();

  const page = el("div", { class: "t101ap-page" });
  page.style.background = `linear-gradient(140deg, ${cLight} 0%, ${accent} 46%, ${cAlt} 100%)`;
  host.appendChild(page);

  // Form kapalıysa / hesap yoksa bilgi ver
  if (!data || !app || app.enabled === false || (app.enabled === undefined && !app.title)) {
    page.appendChild(el("div", { class: "t101ap-card", style: "text-align:center" }, [
      el("div", { style: "font-size:44px", text: "📄" }),
      el("h2", { style: "margin:8px 0", text: "Başvuru formu şu an kapalı" }),
      el("p", { class: "muted", text: "İşletme başvuru/anket formunu henüz yayınlamamış olabilir." }),
    ]));
    return;
  }

  const card = el("div", { class: "t101ap-card" });
  page.appendChild(card);

  // Başlık
  card.appendChild(el("div", { class: "t101ap-head" }, [
    sett.logo ? el("img", { class: "t101ap-logo", src: sett.logo, alt: biz }) : null,
    el("div", { class: "t101ap-biz", text: biz }),
    el("h1", { class: "t101ap-title", style: `color:${accent}`, text: app.title || "İş Başvurusu" }),
    app.desc ? el("p", { class: "t101ap-desc", text: app.desc }) : null,
  ]));

  // Form gövdesi
  const form = el("div", { class: "t101ap-form" });
  card.appendChild(form);

  const nameInp = el("input", { class: "t101ap-input", type: "text", placeholder: "Örn. Ahmet Yılmaz", autocomplete: "name" });
  const phoneInp = el("input", { class: "t101ap-input", type: "tel", placeholder: "05xx xxx xx xx", autocomplete: "tel" });
  const emailInp = el("input", { class: "t101ap-input", type: "email", placeholder: "ornek@eposta.com", autocomplete: "email" });

  form.appendChild(el("div", { class: "t101ap-row2" }, [
    el("div", { class: "t101ap-field" }, [el("label", { text: "Ad Soyad *" }), nameInp]),
    el("div", { class: "t101ap-field" }, [el("label", { text: "Telefon *" }), phoneInp]),
  ]));
  form.appendChild(el("div", { class: "t101ap-field" }, [el("label", { text: "E-posta" }), emailInp]));

  // Ek sorular
  const questions = Array.isArray(app.questions) ? app.questions.filter((q) => q && q.text) : [];
  const qFields = questions.map((q) => {
    if (q.type === "rating") {
      const sel = el("select", { class: "t101ap-input" }, [
        el("option", { value: "" }, ["— Puan seç —"]),
        ...[5, 4, 3, 2, 1].map((n) => el("option", { value: String(n) }, [`${n} ⭐`])),
      ]);
      form.appendChild(el("div", { class: "t101ap-field" }, [el("label", { text: q.text }), sel]));
      return { q, get: () => sel.value };
    }
    const ta = el("textarea", { class: "t101ap-input", rows: "2", placeholder: "Cevabınız…" });
    form.appendChild(el("div", { class: "t101ap-field" }, [el("label", { text: q.text }), ta]));
    return { q, get: () => ta.value.trim() };
  });

  // CV yükleme
  let cvFile = null;
  if (app.cv !== false) {
    const fileInp = el("input", { type: "file", accept: ".pdf,.doc,.docx,.jpg,.jpeg,.png", style: "display:none" });
    const fileName = el("div", { class: "t101ap-filemsg", text: "PDF, Word veya fotoğraf (en fazla 4 MB)" });
    const drop = el("label", { class: "t101ap-drop" }, [
      el("div", { style: "font-size:30px", text: "📎" }),
      el("div", { style: "font-weight:700", text: "CV / Özgeçmiş Yükle" }),
      fileName,
      fileInp,
    ]);
    fileInp.addEventListener("change", () => {
      const f = fileInp.files && fileInp.files[0];
      if (!f) { cvFile = null; fileName.textContent = "PDF, Word veya fotoğraf (en fazla 4 MB)"; return; }
      if (f.size > 4 * 1024 * 1024) { toast("Dosya çok büyük (en fazla 4 MB).", "warn"); fileInp.value = ""; cvFile = null; return; }
      cvFile = f;
      fileName.textContent = "✓ " + f.name + " (" + Math.round(f.size / 1024) + " KB)";
      drop.classList.add("has-file");
    });
    form.appendChild(el("div", { class: "t101ap-field" }, [el("label", { text: "CV / Özgeçmiş" }), drop]));
  }

  // Not
  const noteInp = el("textarea", { class: "t101ap-input", rows: "3", placeholder: "Eklemek istedikleriniz (isteğe bağlı)" });
  form.appendChild(el("div", { class: "t101ap-field" }, [el("label", { text: "Mesajınız" }), noteInp]));

  // Gönder
  const submit = el("button", { class: "t101ap-submit", style: `background:${accent}` }, ["Başvuruyu Gönder"]);
  form.appendChild(submit);
  form.appendChild(el("p", { class: "t101ap-foot", text: "TUFAN 101 ile hazırlandı" }));

  const readFileAsDataURL = (file) => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(file);
  });

  submit.addEventListener("click", async () => {
    const name = nameInp.value.trim();
    const phone = phoneInp.value.trim();
    if (!name) { toast("Lütfen ad soyad girin.", "warn"); nameInp.focus(); return; }
    if (!phone) { toast("Lütfen telefon girin.", "warn"); phoneInp.focus(); return; }
    submit.disabled = true; const old = submit.textContent; submit.textContent = "Gönderiliyor…";
    try {
      const payload = {
        name, phone,
        email: emailInp.value.trim(),
        note: noteInp.value.trim(),
        answers: qFields.map((f) => ({ q: f.q.text, a: f.get() })).filter((x) => x.a !== ""),
      };
      if (cvFile) {
        const dataUrl = await readFileAsDataURL(cvFile);
        payload.cv = { name: cvFile.name, type: cvFile.type || "", data: dataUrl };
      }
      const r = await cloud.cvsubmit(account, payload);
      if (r && r.ok) {
        clear(card);
        card.appendChild(el("div", { style: "text-align:center;padding:20px 6px" }, [
          el("div", { style: "font-size:56px", text: "✅" }),
          el("h2", { style: "margin:10px 0", text: "Başvurunuz alındı!" }),
          el("p", { class: "muted", text: "İlginiz için teşekkürler. En kısa sürede sizinle iletişime geçilecektir." }),
          el("p", { class: "muted", style: "font-size:12px;margin-top:8px", text: "KVKK: Başvurunuz ve CV'niz en fazla 3 gün saklanır, sonra otomatik silinir." }),
        ]));
      } else {
        toast((r && r.error === "cv_too_big") ? "Dosya çok büyük." : ((r && r.msg) || "Gönderilemedi, tekrar deneyin."), "error");
        submit.disabled = false; submit.textContent = old;
      }
    } catch (e) {
      // Sunucu mesajı: tek başvuru hakkı doldu / sistem yoğunluk kilidi / çok fazla istek
      toast((e && e.data && e.data.msg) ? e.data.msg : "Bağlantı hatası, tekrar deneyin.", "warn");
      submit.disabled = false; submit.textContent = old;
    }
  });
}

// Başvuru sayfası stilleri — bir kez enjekte edilir (masaüstü + mobil uyumlu)
function ensureAppStyle() {
  if (document.getElementById("t101ap-style")) return;
  const css = `
  .t101ap-page{min-height:100vh;width:100%;display:flex;align-items:flex-start;justify-content:center;padding:28px 16px 60px;box-sizing:border-box;font-family:inherit}
  .t101ap-card{width:100%;max-width:640px;background:#fff;border-radius:22px;box-shadow:0 24px 60px rgba(0,0,0,.22);padding:28px 30px 26px;box-sizing:border-box}
  .t101ap-head{text-align:center;margin-bottom:18px}
  .t101ap-logo{width:82px;height:82px;border-radius:20px;object-fit:cover;box-shadow:0 6px 18px rgba(0,0,0,.18);margin-bottom:10px}
  .t101ap-biz{font-size:13px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:#64748b}
  .t101ap-title{margin:4px 0 6px;font-size:28px;font-weight:800;line-height:1.15}
  .t101ap-desc{margin:0;color:#475569;font-size:14px;line-height:1.5}
  .t101ap-form{display:grid;gap:14px}
  .t101ap-row2{display:grid;grid-template-columns:1fr 1fr;gap:14px}
  .t101ap-field{display:grid;gap:6px}
  .t101ap-field>label{font-size:13px;font-weight:700;color:#334155}
  .t101ap-input{width:100%;box-sizing:border-box;border:1.5px solid #e2e8f0;border-radius:12px;padding:12px 14px;font-size:15px;font-family:inherit;background:#f8fafc;transition:border-color .15s,background .15s}
  .t101ap-input:focus{outline:none;border-color:#94a3b8;background:#fff}
  textarea.t101ap-input{resize:vertical;min-height:52px}
  .t101ap-drop{display:flex;flex-direction:column;align-items:center;gap:6px;text-align:center;cursor:pointer;border:2px dashed #cbd5e1;border-radius:14px;padding:20px 14px;background:#f8fafc;transition:border-color .15s,background .15s}
  .t101ap-drop:hover{border-color:#94a3b8;background:#f1f5f9}
  .t101ap-drop.has-file{border-style:solid;border-color:#22c55e;background:#f0fdf4}
  .t101ap-filemsg{font-size:12px;color:#64748b;word-break:break-all}
  .t101ap-submit{margin-top:6px;border:none;color:#fff;font-size:16px;font-weight:800;padding:15px;border-radius:14px;cursor:pointer;box-shadow:0 10px 24px rgba(0,0,0,.18);transition:transform .1s,filter .15s}
  .t101ap-submit:hover{filter:brightness(1.06)}
  .t101ap-submit:active{transform:translateY(1px)}
  .t101ap-submit:disabled{opacity:.7;cursor:default}
  .t101ap-foot{text-align:center;font-size:11px;color:#94a3b8;margin:4px 0 0;letter-spacing:.3px}
  @media (max-width:560px){
    .t101ap-page{padding:16px 12px 44px}
    .t101ap-card{border-radius:18px;padding:22px 18px}
    .t101ap-title{font-size:23px}
    .t101ap-row2{grid-template-columns:1fr}
  }`;
  const st = document.createElement("style");
  st.id = "t101ap-style";
  st.textContent = css;
  document.head.appendChild(st);
}

// Tıklama ekranı (bio-link) — üstte işletme adı + ince çizgi, ortada büyük
// ikon-butonlar, altta imza. İçerikler yönetim panelindeki "Vitrin & İletişim"
// alanlarından (sosyal medya, web sitesi, WhatsApp, Maps) beslenir.
function renderBioLanding(host, account, data) {
  const sett = data.settings || {};
  const biz = sett.business || sett.owner || "Menü";
  const accent = sett.menuColor || "#2563EB";
  const cLight = mix(accent, "#ffffff", 0.20);
  let cAlt = shade(accent, -14); try { cAlt = rotateHue(accent, 34); } catch {}
  const ink = lum(accent) > 0.55 ? "#0f172a" : "#ffffff";

  clear(host);
  const page = el("div", { class: "bio-page" });
  page.style.setProperty("--bio-ink", ink);
  page.style.background = `linear-gradient(140deg, ${cLight} 0%, ${accent} 46%, ${cAlt} 100%)`;

  const head = el("div", { class: "bio-head" }, [
    sett.logo ? el("img", { class: "bio-logo", src: sett.logo, alt: biz }) : null,
    el("h1", { class: "bio-title", text: biz }),
    (sett.owner && sett.owner !== biz) ? el("div", { class: "bio-owner", text: sett.owner }) : null,
    el("div", { class: "bio-rule" }),
  ]);

  const grid = el("div", { class: "bio-grid" });
  const add = (name, label, onClick) => grid.appendChild(bioButton(name, label, onClick));

  // Menü — her zaman görünür (çekirdek). Stok/Ürünler'den beslenir.
  add("menu", "Menü", () => renderMenuScreen(host, account, data));

  const waNum = String(sett.whatsapp || sett.phone || "").replace(/\D/g, "");
  if (waNum) add("whatsapp", "WhatsApp", () => window.open("https://wa.me/" + waNum, "_blank", "noopener"));

  let mapsUrl = (sett.maps || "").trim();
  if (!mapsUrl && sett.address) mapsUrl = sett.address;
  if (mapsUrl && !/^https?:\/\//i.test(mapsUrl)) mapsUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(mapsUrl);
  if (mapsUrl) add("maps", "Google Maps", () => window.open(mapsUrl, "_blank", "noopener"));

  if (sett.website) {
    const web = /^https?:\/\//i.test(sett.website) ? sett.website : "https://" + sett.website;
    add("web", "Web Sitemiz", () => window.open(web, "_blank", "noopener"));
  }

  const ig = (sett.instagram || "").trim().replace(/^@/, "");
  if (ig || sett.googleReviews) add("social", "Sosyal Medya", () => socialModal(sett));

  if (sett.phone || sett.email || waNum) add("phone", "İletişim", () => contactModal(sett));

  const footer = el("div", { class: "bio-footer" }, [
    el("div", { class: "bio-sign", text: "TUFAN 101 ile hazırlandı" }),
  ]);

  // İşletme fotoğrafları — başlığın altında yatay kayan galeri (varsa).
  const photos = Array.isArray(sett.bizPhotos) ? sett.bizPhotos.filter(Boolean) : [];
  const gallery = photos.length ? el("div", {
    style: "display:flex;gap:10px;overflow-x:auto;padding:2px 2px 10px;margin:2px 0 8px;scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch",
  }, photos.slice(0, 8).map((src) => el("img", {
    src, alt: biz, loading: "lazy",
    style: "height:120px;min-width:160px;object-fit:cover;border-radius:16px;scroll-snap-align:start;box-shadow:0 6px 18px rgba(0,0,0,.22)",
  }))) : null;

  page.append(head);
  if (gallery) page.append(gallery);
  page.append(grid, footer);
  host.appendChild(page);
}

// Yemek menüsü ekranı — QrAll tarzı: renkli başlık çubuğu, "Kategoriler / Tümünü
// Gör", kategori çipleri, değerlendirme şeridi, kapak görseli, bölüm başlığı +
// liste/ızgara düğmesi, ürün kartları ve yukarı-çık düğmesi.
function renderMenuScreen(host, account, data) {
  clear(host);
  const sett = data.settings || {};
  const biz = sett.business || "Menü";
  const accent = sett.menuColor || "#2563EB";
  const headInk = lum(accent) > 0.62 ? "#0f172a" : "#ffffff";
  // Sıcak, açık arka plan (örnekteki krem/ten tonu) — işletme rengine göre türetilir
  const warmBg = mix(accent, "#efe6dd", 0.86);
  // Renk uyumu: çok açık temalarda beyaz üzerine yazı okunmaz → metin için
  // vurguyu koyulaştır; çok koyu temalarda hafif aç. Böylece her renk okunur.
  const accentInk = lum(accent) > 0.6 ? shade(accent, -42) : (lum(accent) < 0.1 ? shade(accent, 22) : accent);

  const page = el("div", { class: "public-menu qmenu" });
  page.style.setProperty("--primary", accent);
  page.style.setProperty("--qm-head-ink", headInk);
  page.style.setProperty("--qm-accent-ink", accentInk);
  page.style.background = warmBg;
  host.appendChild(page);

  // ---- Renkli başlık çubuğu: geri (yuvarlak) + logo + ortada işletme adı ----
  const header = el("div", { class: "qmenu-header" });
  const logoUrl = String(sett.logo || "").trim();
  // İşletme fotoğrafı varsa başlığa KAPAK olur; üstüne marka rengiyle okunur örtü.
  const cover = (Array.isArray(sett.bizPhotos) && sett.bizPhotos.length) ? String(sett.bizPhotos[0]) : "";
  if (cover) {
    header.style.background = `linear-gradient(180deg, ${accent}b3 0%, ${shade(accent, -22)}f0 100%), url("${cover}") center/cover no-repeat`;
    header.style.minHeight = "160px";
  } else {
    header.style.background = `linear-gradient(135deg, ${accent}, ${shade(accent, -16)})`;
  }
  // Logo başlıkta BÜYÜK gösterilir (kullanıcı isteği).
  const titleWrap = el("div", { class: "qmenu-titlewrap" }, [
    logoUrl ? el("img", { class: "qmenu-logo", src: logoUrl, alt: biz, loading: "eager", style: "width:92px;height:92px;border-radius:24px;padding:5px" }) : null,
    el("div", { class: "qmenu-title", text: biz }),
  ]);
  header.append(
    el("button", { class: "qmenu-back", type: "button", title: "Ana Sayfa", onClick: () => renderBioLanding(host, account, data) }, [
      el("span", { html: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 18l-6-6 6-6"/></svg>' }),
    ]),
    titleWrap,
    el("span", { class: "qmenu-back", style: "visibility:hidden" }),
  );
  page.appendChild(header);

  const body = el("div", { class: "qmenu-body" });
  page.appendChild(body);

  // Menü davranışı: sipariş açık mı, WhatsApp'tan mı alınıyor
  const ordering = sett.menuOrdering !== false;
  const waOrder = !!sett.menuWhatsappOrder;

  // ---- Masa no + Garson çağır ----
  const requireTable = !!sett.requireTable;
  const masaInput = el("input", { class: "input", type: "text", inputmode: "numeric", placeholder: requireTable ? "Masa no (zorunlu)" : "Masa no (örn. 5)", style: "max-width:150px" });
  // Masalı QR ile gelindiyse masa no'yu otomatik doldur (müşteri okutunca hazır gelir).
  if (data && data._masa) masaInput.value = data._masa;
  const needMasa = () => {
    if (requireTable && !masaInput.value.trim()) {
      toast("Lütfen önce masa numaranızı girin.", "warn");
      masaInput.focus();
      masaInput.style.borderColor = "#ef4444";
      setTimeout(() => { masaInput.style.borderColor = ""; }, 1500);
      return true;
    }
    return false;
  };
  const callBtn = el("button", { class: "btn warning", onClick: async () => {
    if (needMasa()) return;
    callBtn.disabled = true;
    try {
      await cloud.call(account, { type: "call", masa: masaInput.value.trim(), note: "" });
      toast("🔔 Garson çağrıldı! Birazdan geliyoruz.", "success");
    } catch { toast("Bağlantı hatası, tekrar deneyin.", "error"); }
    finally { setTimeout(() => { callBtn.disabled = false; }, 3000); }
  } }, ["🔔 Garson Çağır"]);
  body.appendChild(el("div", { class: "qmenu-toolbar" }, [masaInput, callBtn]));
  if (requireTable) body.appendChild(el("p", { class: "muted", style: "font-size:12px;margin:0 0 4px", text: "ℹ️ Sipariş verebilmek için masa numaranızı girmelisiniz." }));

  // ---- Hızlı butonlar: PDF menü + anket ----
  const quick = el("div", { class: "qmenu-quick" });
  if (sett.menuPdf) quick.appendChild(el("button", { class: "qmenu-quickbtn", type: "button", onClick: () => openPdfMenu(sett) }, ["📄 " + (sett.menuPdfName || "PDF Menü")]));
  if (sett.survey && Array.isArray(sett.survey.questions) && sett.survey.questions.length)
    quick.appendChild(el("button", { class: "qmenu-quickbtn", type: "button", onClick: () => openSurvey(account, sett.survey) }, ["📋 " + (sett.survey.title || "Ankete Katıl")]));
  if (quick.children.length) body.appendChild(quick);

  // ---- Değerlendirme şeridi (örnekteki "Bizi değerlendirin" pili) ----
  let rateBanner = null;
  if (sett.ratingEnabled !== false) {
    rateBanner = el("button", { class: "qmenu-ratebanner", type: "button", onClick: () => {
      modal({ title: "⭐ Bizi Değerlendirin", body: el("div", {}, [ratingWidget(account)]), actions: [{ label: "Kapat", kind: "ghost" }] });
    } }, [
      el("span", { class: "qmenu-ratestar", text: "★" }),
      el("span", { class: "qmenu-ratetext" }, [
        el("b", { text: "Deneyiminizi beğendiniz mi?" }),
        el("span", { class: "qmenu-ratecta", text: "Bizi değerlendirin" }),
      ]),
    ]);
  }

  // ---- Ürünler (stok + QR'a özel) ----
  const stockCats = Array.isArray(data.categories) ? data.categories : [];
  const stockProducts = (Array.isArray(data.products) ? data.products : []).filter((p) => p.active !== false && !p.menuHide);
  const merged = mergeMenuItems(stockCats, stockProducts, sett);

  // ---- Sipariş sepeti (sticky) ----
  const fmt = (n) => (sett.currency ? `${(Number(n) || 0).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${sett.currency}` : money(n));
  const cart = new Map();
  const cartBox = el("div", { class: "qmenu-cart", style: "display:none" });
  const cartInfo = el("div", { style: "flex:1;font-weight:800" });
  function renderCart() {
    const count = [...cart.values()].reduce((a, x) => a + x.qty, 0);
    const total = [...cart.values()].reduce((a, x) => a + x.qty * (Number(x.price) || 0), 0);
    cartInfo.textContent = count ? `🛒 ${count} ürün · ${fmt(total)}` : "";
    cartBox.style.display = count ? "flex" : "none";
  }
  const afterOrder = () => {
    cart.clear(); renderCart();
    setTimeout(() => toast("Afiyet olsun! 😊 Yemeğiniz bitince bizi puanlamayı unutmayın.", "success"), 700);
  };
  const sendBtn = el("button", { class: "btn success", onClick: async () => {
    if (!cart.size) return;
    if (needMasa()) return;
    const items = [...cart.values()].map((x) => ({ name: x.name, qty: x.qty, price: x.price }));
    const total = items.reduce((a, x) => a + x.qty * (Number(x.price) || 0), 0);
    const masa = masaInput.value.trim();
    if (waOrder) {
      const num = String(sett.whatsapp || sett.phone || "").replace(/\D/g, "");
      if (!num) { toast("WhatsApp numarası tanımlı değil.", "warn"); return; }
      const lines = items.map((x) => `• ${x.qty}× ${x.name}` + (sett.hideMenuPrice ? "" : ` (${fmt(x.price)})`)).join("\n");
      const msg = `Merhaba, sipariş vermek istiyorum:\n${lines}` + (masa ? `\n\nMasa: ${masa}` : "") + (sett.hideMenuPrice ? "" : `\nToplam: ${fmt(total)}`);
      window.open(`https://wa.me/${num}?text=${encodeURIComponent(msg)}`, "_blank");
      toast("WhatsApp'a yönlendiriliyorsunuz…", "success");
      afterOrder();
      return;
    }
    sendBtn.disabled = true;
    try {
      await cloud.call(account, { type: "order", masa, items, note: "" });
      toast("✅ Siparişiniz iletildi!", "success");
      afterOrder();
    } catch { toast("Bağlantı hatası, tekrar deneyin.", "error"); }
    finally { sendBtn.disabled = false; }
  } }, [waOrder ? "WhatsApp'tan Sipariş Ver →" : "Siparişi Gönder →"]);
  cartBox.append(cartInfo, sendBtn);
  const addToCart = (p) => {
    const cur = cart.get(p.id) || { name: p.name, price: p.price, qty: 0 };
    cur.qty += 1; cart.set(p.id, cur); renderCart();
    toast(`+ ${p.name}`, "success");
  };

  buildMenuInto(body, merged.cats, merged.products, sett, ordering ? addToCart : null, { afterChips: rateBanner });
  if (ordering) page.appendChild(cartBox);

  // ---- Alt bilgi: İşletme sahibi + iletişim ----
  const footer = el("div", { style: "margin-top:22px;padding-top:16px;border-top:1px solid rgba(15,23,42,.12)" });
  // En altta işletme logosu (kullanıcı isteği).
  if (logoUrl) footer.appendChild(el("div", { style: "text-align:center;margin-bottom:12px" }, [
    el("img", { src: logoUrl, alt: biz, style: "width:74px;height:74px;border-radius:18px;object-fit:cover;box-shadow:0 4px 14px rgba(0,0,0,.15)" }),
    el("div", { style: "margin-top:8px;font-weight:800;font-size:16px;color:" + accentInk, text: biz }),
  ]));
  if (sett.owner) footer.appendChild(el("div", { style: "text-align:center;font-weight:700;margin-bottom:8px", text: "👤 " + sett.owner }));
  const contact = contactBar(sett);
  if (contact) footer.appendChild(contact);
  body.appendChild(footer);
  body.appendChild(el("p", { class: "owner-sign", style: "text-align:center;margin-top:18px", text: "TUFAN 101 ile hazırlandı" }));

  // ---- Yukarı çık düğmesi (örnekteki yüzen buton) ----
  const topBtn = el("button", { class: "qmenu-top", type: "button", title: "Yukarı çık", onClick: () => window.scrollTo({ top: 0, behavior: "smooth" }) }, [
    el("span", { html: '<svg viewBox="0 0 24 24" width="24" height="24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>' }),
  ]);
  page.appendChild(topBtn);
  const onScroll = () => { topBtn.classList.toggle("show", window.scrollY > 320); };
  window.addEventListener("scroll", onScroll, { passive: true });
  onScroll();
}

// ---- Tıklama ekranı ikon-butonu ----
function bioButton(name, label, onClick) {
  return el("button", { class: "bio-btn", type: "button", onClick }, [
    el("span", { class: "bio-ico", html: bioIcon(name) }),
    el("span", { class: "bio-lbl", text: label }),
  ]);
}

// Çizgi (outline) ikonlar — currentColor ile renk alır (görsellerdeki stil)
function bioIcon(name) {
  const svg = (inner) => `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
  switch (name) {
    case "whatsapp": return svg('<path d="M12 3a9 9 0 0 0-7.7 13.6L3 21l4.6-1.2A9 9 0 1 0 12 3Z"/><path d="M8.6 8.7c-.15 0-.4.06-.6.3-.2.24-.75.73-.75 1.77 0 1.05.77 2.06.88 2.2.1.14 1.5 2.4 3.72 3.28 1.85.73 2.23.58 2.63.55.4-.04 1.29-.53 1.47-1.03.18-.5.18-.94.13-1.03-.05-.09-.2-.14-.4-.24-.21-.1-1.2-.6-1.39-.66-.19-.07-.32-.1-.46.1-.13.2-.52.65-.64.79-.12.14-.24.15-.44.05-.2-.1-.85-.31-1.62-1-.6-.53-1-1.19-1.12-1.39-.12-.2-.01-.31.09-.41.09-.09.2-.24.3-.36.1-.12.13-.2.2-.34.07-.14.03-.26-.02-.36-.05-.1-.44-1.08-.61-1.48-.16-.38-.32-.33-.44-.33Z"/>');
    case "maps": return svg('<path d="M9 4 3.5 6v14L9 18l6 2 5.5-2V4L15 6 9 4Z"/><path d="M9 4v14M15 6v14"/><circle cx="17.5" cy="8.5" r="1.4"/>');
    case "web": return svg('<circle cx="12" cy="12" r="9"/><path d="M3 12h18"/><path d="M12 3c2.6 2.5 2.6 15.5 0 18M12 3c-2.6 2.5-2.6 15.5 0 18"/>');
    case "menu": return svg('<path d="M4 17.5h16"/><path d="M5 17.5a7 7 0 0 1 14 0"/><path d="M12 7.5v3"/><circle cx="12" cy="6.4" r="1"/><path d="M3.5 20.5h17"/>');
    case "social": return svg('<rect x="3.5" y="3.5" width="17" height="17" rx="5"/><circle cx="12" cy="12" r="3.6"/><circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" stroke="none"/>');
    case "phone": return svg('<path d="M22 16.9v2.9a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.4 19.4 0 0 1-6-6A19.8 19.8 0 0 1 2 4.1 2 2 0 0 1 4 2h3a2 2 0 0 1 2 1.7c.1.9.3 1.8.6 2.6a2 2 0 0 1-.5 2.1L8.1 9.9a16 16 0 0 0 6 6l1.5-1.6a2 2 0 0 1 2.1-.5c.8.3 1.7.5 2.6.6A2 2 0 0 1 22 16.9Z"/>');
    default: return svg('<circle cx="12" cy="12" r="9"/>');
  }
}

// Sosyal medya penceresi (Instagram + Google Yorumlar + Web)
function socialModal(sett) {
  const rows = [];
  const ig = (sett.instagram || "").trim().replace(/^@/, "");
  if (ig) rows.push(bigLink("📷", "Instagram", "@" + ig, "https://instagram.com/" + encodeURIComponent(ig), "#E1306C"));
  if (sett.googleReviews) rows.push(bigLink("⭐", "Google Yorumlar", "Değerlendirin", /^https?:\/\//i.test(sett.googleReviews) ? sett.googleReviews : "https://" + sett.googleReviews, "#DB4437"));
  const web = sett.website ? (/^https?:\/\//i.test(sett.website) ? sett.website : "https://" + sett.website) : "";
  if (web) rows.push(bigLink("🌐", "Web Sitesi", sett.website, web, "#0284c7"));
  if (!rows.length) rows.push(el("p", { class: "muted", text: "Sosyal medya bağlantısı tanımlanmamış." }));
  modal({ title: "📷 Sosyal Medya", body: el("div", { class: "biglink-list" }, rows), actions: [{ label: "Kapat", kind: "ghost" }] });
}

// İletişim penceresi (Telefon / WhatsApp / E-posta / Yol tarifi)
function contactModal(sett) {
  const rows = [];
  const tel = String(sett.phone || "").replace(/[^\d+]/g, "");
  if (tel) rows.push(bigLink("📞", "Telefon", sett.phone, "tel:" + tel, "#0ea5e9"));
  const waNum = String(sett.whatsapp || sett.phone || "").replace(/\D/g, "");
  if (waNum) rows.push(bigLink("💬", "WhatsApp", "Mesaj gönder", "https://wa.me/" + waNum, "#25D366"));
  if (sett.email) rows.push(bigLink("✉️", "E-Posta", sett.email, "mailto:" + sett.email, "#6366f1"));
  let mapsUrl = (sett.maps || "").trim();
  if (!mapsUrl && sett.address) mapsUrl = sett.address;
  if (mapsUrl && !/^https?:\/\//i.test(mapsUrl)) mapsUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(mapsUrl);
  if (mapsUrl) rows.push(bigLink("📍", "Yol Tarifi", "Google Maps", mapsUrl, "#4285F4"));
  if (!rows.length) rows.push(el("p", { class: "muted", text: "İletişim bilgisi tanımlanmamış." }));
  modal({ title: "📞 İletişim", body: el("div", { class: "biglink-list" }, rows), actions: [{ label: "Kapat", kind: "ghost" }] });
}

// Modal içi büyük, tıklanabilir bağlantı satırı
function bigLink(icon, label, sub, href, color) {
  return el("a", {
    href, target: "_blank", rel: "noopener", class: "biglink", style: `--bl:${color}`,
  }, [
    el("span", { class: "biglink-ic", text: icon }),
    el("span", { class: "biglink-tx" }, [
      el("b", { text: label }),
      sub ? el("span", { class: "muted", text: sub }) : null,
    ]),
    el("span", { class: "biglink-go", text: "›" }),
  ]);
}

// ---- QR kodu çıktı: bir A4 sayfaya sığdığı kadar QR döşe ve yazdır ----
// ============================================================
//  RANDEVU — QR randevu formu (herkese açık) + işletme paneli
// ============================================================
// Randevu bağlantısı: #/randevu/<hesap>
function randevuLink() {
  const acc = currentAccount();
  const base = `${location.origin}${location.pathname}`;
  return acc ? `${base}#/randevu/${encodeURIComponent(acc)}` : `${base}#/randevu`;
}

// Herkese açık RANDEVU sayfası (#/randevu/<hesap>) — müşteri giriş yapmadan doldurur.
export async function renderRandevuPage(host, account) {
  clear(host);
  const data = await fetchAccountData(account);
  const sett = (data && data.settings) || {};
  const rdv = (sett.randevu && typeof sett.randevu === "object") ? sett.randevu : {};
  const biz = sett.business || sett.owner || "Randevu";
  const accent = sett.menuColor || "#2563EB";
  if (rdv.enabled === false) {
    host.appendChild(el("div", { style: "max-width:520px;margin:40px auto;padding:16px" }, [
      el("div", { class: "card", style: "text-align:center;padding:24px" }, [el("div", { style: "font-size:40px", text: "🗓" }), el("h3", { text: biz }), el("p", { class: "muted", text: "Şu an online randevu alınmıyor." })]),
    ]));
    return;
  }
  const services = String(rdv.services || "").split(",").map((x) => x.trim()).filter(Boolean);
  const nameI = el("input", { class: "input", placeholder: "Adınız Soyadınız *" });
  const phoneI = el("input", { class: "input", inputmode: "tel", placeholder: "Telefon *" });
  const dateI = el("input", { class: "input", type: "date", min: new Date().toISOString().slice(0, 10) });
  const timeI = el("input", { class: "input", type: "time" });
  const serviceSel = services.length
    ? el("select", { class: "input" }, [el("option", { value: "" }, ["— Hizmet seçin —"]), ...services.map((x) => el("option", { value: x }, [x]))])
    : el("input", { class: "input", placeholder: "Hizmet (opsiyonel)" });
  const noteI = el("input", { class: "input", placeholder: "Not (opsiyonel)" });
  const msg = el("div", { style: "min-height:18px;font-size:13px;margin-top:6px" });
  const submit = el("button", { class: "btn success block", style: "margin-top:10px", onClick: async () => {
    const name = nameI.value.trim(), phone = phoneI.value.trim();
    if (!name || !phone) { msg.textContent = "Ad ve telefon zorunludur."; msg.style.color = "#dc2626"; return; }
    submit.disabled = true; msg.textContent = "Gönderiliyor…"; msg.style.color = "#64748b";
    try {
      const r = await cloud.randevu(account, { name, phone, date: dateI.value, time: timeI.value, service: (serviceSel.value || "").trim(), note: noteI.value.trim() });
      if (r && r.ok) {
        clear(card);
        card.appendChild(el("div", { style: "text-align:center;padding:22px" }, [
          el("div", { style: "font-size:52px", text: "✅" }),
          el("h2", { style: "margin:10px 0 4px", text: "Randevu isteğiniz alındı!" }),
          el("p", { class: "muted", text: biz + " en kısa sürede sizinle iletişime geçecek." }),
        ]));
      } else { msg.textContent = (r && r.msg) || "Gönderilemedi, tekrar deneyin."; msg.style.color = "#dc2626"; submit.disabled = false; }
    } catch { msg.textContent = "Bağlantı hatası. Tekrar deneyin."; msg.style.color = "#dc2626"; submit.disabled = false; }
  } }, ["📅 Randevu İste"]);
  const g2 = (a, b) => el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:10px" }, [a, b]);
  const fld = (lbl, node) => el("div", { class: "field" }, [el("label", { text: lbl }), node]);
  const card = el("div", { class: "card", style: "max-width:520px;margin:0 auto;padding:20px" }, [
    sett.logo ? el("div", { style: "text-align:center;margin-bottom:10px" }, [el("img", { src: sett.logo, alt: biz, style: "width:76px;height:76px;border-radius:18px;object-fit:cover" })]) : null,
    el("h2", { style: "text-align:center;margin:0 0 2px;color:" + accent, text: biz }),
    el("p", { style: "text-align:center;margin:0 0 14px;color:#64748b;font-size:13px", text: "📅 Online Randevu" }),
    rdv.note ? el("p", { class: "muted", style: "font-size:13px;text-align:center", text: rdv.note }) : null,
    fld("Ad Soyad *", nameI),
    fld("Telefon *", phoneI),
    g2(fld("Tarih", dateI), fld("Saat", timeI)),
    fld("Hizmet", serviceSel),
    fld("Not", noteI),
    submit, msg,
    el("p", { style: "text-align:center;margin-top:14px;font-size:11px;color:#94a3b8", text: "TUFAN 101 ile hazırlandı" }),
  ]);
  host.appendChild(el("div", { style: "min-height:100vh;padding:24px 14px;background:linear-gradient(140deg," + mix(accent, "#ffffff", 0.25) + " 0%," + accent + " 60%)" }, [card]));
}

// İşletme paneli: randevu ayarları + gelen istekler (QR menü ekranında kart).
function randevuCard(s, host) {
  const acc = currentAccount();
  const link = randevuLink();
  const rdv = (s.randevu && typeof s.randevu === "object") ? s.randevu : {};
  const enableCb = el("input", { type: "checkbox" }); enableCb.checked = rdv.enabled !== false;
  const servicesInp = el("input", { class: "input", value: rdv.services || "", placeholder: "Hizmetler (virgülle): Saç Kesimi, Sakal, Boya" });
  const noteInp = el("input", { class: "input", value: rdv.note || "", placeholder: "Müşteriye not (ör. çalışma saatleri)" });
  const save = () => {
    settings.set({ randevu: { enabled: enableCb.checked, services: servicesInp.value.trim(), note: noteInp.value.trim() } });
    toast("Randevu ayarları kaydedildi", "success");
  };
  const inbox = el("div", { style: "display:grid;gap:8px;margin-top:8px" }, [el("p", { class: "muted", text: "Yükleniyor…" })]);
  const loadInbox = () => {
    clear(inbox); inbox.appendChild(el("p", { class: "muted", text: "Yükleniyor…" }));
    if (!acc) { clear(inbox); inbox.appendChild(el("p", { class: "muted", text: "Bulut hesabı yok." })); return; }
    cloud.randevuList(acc).then((r) => {
      clear(inbox);
      const list = (r && Array.isArray(r.appointments)) ? r.appointments : [];
      if (!list.length) { inbox.appendChild(el("p", { class: "muted", text: "Henüz randevu isteği yok." })); return; }
      list.forEach((a) => inbox.appendChild(randevuRow(acc, a, loadInbox)));
    }).catch(() => { clear(inbox); inbox.appendChild(el("p", { class: "muted", text: "Randevular yüklenemedi." })); });
  };
  loadInbox();
  return el("div", { class: "card" }, [
    el("h3", { text: "📅 Randevu (QR Randevu Formu)" }),
    el("p", { class: "muted", style: "font-size:12px", text: "Menüden AYRI bir link. Müşteri açınca ad-telefon-tarih-saat girip randevu ister; istekler aşağıda listelenir." }),
    el("label", { style: "display:flex;align-items:center;gap:10px;margin:6px 0" }, [enableCb, el("span", { text: "Randevu formunu yayınla (link aktif olsun)" })]),
    el("div", { class: "field" }, [el("label", { text: "Hizmet listesi" }), servicesInp]),
    el("div", { class: "field" }, [el("label", { text: "Müşteriye not" }), noteInp]),
    el("button", { class: "btn success", style: "margin-top:6px", onClick: save }, ["💾 Kaydet"]),
    el("hr", { style: "border:none;border-top:1px solid var(--border);margin:14px 0" }),
    el("div", { style: "display:flex;align-items:center;gap:8px;flex-wrap:wrap" }, [
      el("span", { style: "font-weight:700", text: "🔗 Randevu Bağlantısı:" }),
      acc ? el("span", { class: "muted", style: "font-size:12px;word-break:break-all;flex:1", text: link }) : el("span", { class: "pill amber", text: "Giriş yapın" }),
    ]),
    el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:8px" }, [
      el("button", { class: "btn ghost", onClick: () => { navigator.clipboard?.writeText(link); toast("Kopyalandı", "success"); } }, ["🔗 Kopyala"]),
      el("button", { class: "btn ghost", onClick: () => printQrPoster(link, s) }, ["🖼 Randevu Afişi (QR)"]),
    ]),
    el("hr", { style: "border:none;border-top:1px solid var(--border);margin:14px 0" }),
    el("div", { style: "display:flex;align-items:center;justify-content:space-between;gap:8px" }, [
      el("h4", { style: "margin:0", text: "📥 Gelen Randevu İstekleri" }),
      el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: loadInbox }, ["↻ Yenile"]),
    ]),
    inbox,
  ]);
}

function randevuRow(acc, a, reload) {
  const stMap = { bekliyor: { t: "Bekliyor", c: "amber" }, onay: { t: "Onaylandı", c: "green" }, iptal: { t: "İptal", c: "red" }, tamam: { t: "Tamamlandı", c: "blue" } };
  const st = stMap[a.status] || stMap.bekliyor;
  const when = [a.date, a.time].filter(Boolean).join(" ");
  const setStatus = (status) => cloud.randevuStatus(acc, a.id, { status }).then(() => { toast("Güncellendi", "success"); reload(); }).catch(() => toast("Güncellenemedi", "error"));
  const del = () => confirmDialog("Randevu isteği silinsin mi?", () => cloud.randevuStatus(acc, a.id, { delete: true }).then(() => { toast("Silindi", "warn"); reload(); }).catch(() => toast("Silinemedi", "error")));
  return el("div", { class: "card", style: "padding:10px 12px;border:1px solid var(--border)" }, [
    el("div", { style: "display:flex;justify-content:space-between;align-items:center;gap:8px" }, [
      el("b", { text: (a.name || "—") + (a.phone ? " · " + a.phone : "") }),
      el("span", { class: "pill " + st.c, text: st.t }),
    ]),
    el("div", { class: "muted", style: "font-size:13px;margin-top:2px", text: [when ? "🗓 " + when : "", a.service ? "✂️ " + a.service : ""].filter(Boolean).join("  ·  ") || "—" }),
    a.note ? el("div", { style: "font-size:13px;margin-top:2px", text: "📝 " + a.note }) : null,
    el("div", { style: "display:flex;gap:6px;flex-wrap:wrap;margin-top:8px" }, [
      a.phone ? el("a", { class: "btn ghost tiny", href: "tel:" + String(a.phone).replace(/[^\d+]/g, "") }, ["📞 Ara"]) : null,
      a.phone ? el("a", { class: "btn ghost tiny", href: "https://wa.me/" + String(a.phone).replace(/\D/g, ""), target: "_blank", rel: "noopener" }, ["💬 WA"]) : null,
      el("button", { class: "btn tiny success", onClick: () => setStatus("onay") }, ["✓ Onayla"]),
      el("button", { class: "btn tiny", onClick: () => setStatus("tamam") }, ["✔ Tamam"]),
      el("button", { class: "btn tiny", onClick: () => setStatus("iptal") }, ["✕ İptal"]),
      el("button", { class: "btn ghost tiny", onClick: del }, ["🗑"]),
    ]),
  ]);
}

// Görseli küçültüp JPEG dataURL döndürür. HEDEF BAYT boyutunun altına inene kadar
// kaliteyi/çözünürlüğü otomatik düşürür — böylece fotoğraflar veri bloğunu ASLA şişirmez.
function compressImage(file, maxPx, maxBytes) {
  return new Promise((resolve) => {
    if (!file) return resolve("");
    const r = new FileReader();
    r.onload = () => {
      const img = new Image();
      img.onload = () => {
        try {
          const render = (dim, q) => {
            const scale = Math.min(1, dim / Math.max(img.width, img.height));
            const w = Math.max(1, Math.round(img.width * scale)), h = Math.max(1, Math.round(img.height * scale));
            const c = document.createElement("canvas"); c.width = w; c.height = h;
            c.getContext("2d").drawImage(img, 0, 0, w, h);
            return c.toDataURL("image/jpeg", q);
          };
          const cap = maxBytes || 260 * 1024;
          let dim = maxPx || 900, q = 0.8, out = render(dim, q), guard = 0;
          while (out.length > cap && guard++ < 7) {
            if (q > 0.5) q -= 0.12; else { dim = Math.round(dim * 0.82); q = 0.72; }
            out = render(dim, q);
          }
          resolve(out);
        } catch { resolve(""); }
      };
      img.onerror = () => resolve("");
      img.src = r.result;
    };
    r.onerror = () => resolve("");
    r.readAsDataURL(file);
  });
}

// İşletme fotoğrafları kartı — settings.bizPhotos (sıkıştırılmış dataURL dizisi).
// QR menünün üstünde galeri olarak ve profesyonel afişte gösterilir.
function bizPhotosCard(onChange) {
  const MAX = 6;
  let photos = Array.isArray(settings.get().bizPhotos) ? settings.get().bizPhotos.slice() : [];
  const grid = el("div", { style: "display:grid;grid-template-columns:repeat(auto-fill,minmax(88px,1fr));gap:8px;margin:8px 0" });
  const persist = () => { settings.set({ bizPhotos: photos }); if (typeof onChange === "function") onChange(); };
  function paint() {
    clear(grid);
    if (!photos.length) { grid.appendChild(el("p", { class: "muted", style: "grid-column:1/-1;font-size:13px", text: "Henüz fotoğraf yok. İşletmenin/ürünlerin fotoğraflarını ekleyin." })); return; }
    photos.forEach((src, i) => {
      grid.appendChild(el("div", { style: "position:relative;aspect-ratio:1;border-radius:10px;overflow:hidden;border:1px solid var(--border)" }, [
        el("img", { src, alt: "", style: "width:100%;height:100%;object-fit:cover" }),
        el("button", { class: "btn danger", style: "position:absolute;top:3px;right:3px;padding:2px 8px;font-size:12px;line-height:1.2", onClick: () => { photos.splice(i, 1); persist(); paint(); } }, ["✕"]),
      ]));
    });
  }
  paint();
  const fileI = el("input", { type: "file", accept: "image/*", multiple: true, style: "display:none" });
  fileI.addEventListener("change", async () => {
    const files = [...(fileI.files || [])];
    for (const f of files) {
      if (photos.length >= MAX) { toast("En fazla " + MAX + " fotoğraf eklenebilir.", "warn"); break; }
      if (f.size > 12 * 1024 * 1024) { toast("Fotoğraf çok büyük (en fazla 12 MB): " + f.name, "warn"); continue; }
      const d = await compressImage(f, 900, 260 * 1024);  // ~260 KB hedef
      // Güvenlik: her şeye rağmen büyük kaldıysa atla (veri bloğunu şişirmesin).
      if (!d || d.length > 500 * 1024) { toast("Bir fotoğraf işlenemedi/çok büyük, atlandı.", "warn"); continue; }
      photos.push(d);
    }
    fileI.value = ""; persist(); paint();
    toast("Fotoğraf(lar) eklendi", "success");
  });
  return el("div", { class: "card" }, [
    el("h3", { text: "🖼 İşletme Fotoğrafları" }),
    el("p", { class: "muted", style: "font-size:12px", text: "İşletmenin/ürünlerin fotoğrafları — QR menünün üstünde kayan galeri olarak ve profesyonel afişte gösterilir. En fazla " + MAX + " adet." }),
    grid, fileI,
    el("button", { class: "btn", onClick: () => fileI.click() }, ["📷 Fotoğraf Ekle"]),
  ]);
}

function printQrSheet(link, s) {
  const biz = (s && s.business) || "Menü";
  const brandLogo = new URL("assets/img/tufan-logo.png", location.href).href;
  // Her QR'a masa numarası: linke ?masa=N eklenir → müşteri okutunca "Masa no"
  // otomatik dolar, sipariş/çağrı o masayla gelir. Kartın üstünde de "Masa N" yazar.
  const sep = link.indexOf("?") === -1 ? "?" : "&";
  const qrFor = (n) => "https://api.qrserver.com/v1/create-qr-code/?size=500x500&margin=8&data=" + encodeURIComponent(link + sep + "masa=" + n);
  // A4 yazdırılabilir alan ~ 194mm × 282mm (8mm kenar boşluğu)
  const cellW = 46, cellH = 62; // mm — QR + masa etiketi
  const cols = Math.max(1, Math.floor(194 / cellW));
  const rows = Math.max(1, Math.floor(282 / cellH));
  const count = cols * rows;
  let cells = "";
  for (let n = 1; n <= count; n++) {
    cells +=
      '<div class="qc">' +
        '<div class="masa">Masa ' + n + '</div>' +
        '<img src="' + qrFor(n) + '" alt="QR"/>' +
        '<div class="nm">' + escapeHtml(biz) + '</div>' +
        '<div class="sub">📱 Menü için okutun</div>' +
      '</div>';
  }
  const doc =
    '<!doctype html><html lang="tr"><head><meta charset="utf-8">' +
    '<title>QR Çıktı — ' + escapeHtml(biz) + '</title><style>' +
    '@page{size:A4;margin:8mm;}' +
    '*{box-sizing:border-box;}' +
    'body{margin:0;font-family:Arial,Helvetica,sans-serif;color:#0f172a;}' +
    '.hint{text-align:center;font-size:12px;color:#64748b;margin:6px 0 10px;}' +
    '.brandhead{text-align:center;margin:2mm 0 5mm;}' +
    '.brandhead img{height:16mm;object-fit:contain;}' +
    '.sheet{display:grid;grid-template-columns:repeat(' + cols + ',1fr);gap:4mm;}' +
    '.qc{border:1px dashed #cbd5e1;border-radius:3mm;padding:3mm 2mm;text-align:center;break-inside:avoid;}' +
    '.qc img{width:' + (cellW - 14) + 'mm;height:' + (cellW - 14) + 'mm;display:block;margin:0 auto;}' +
    '.masa{font-weight:900;font-size:13px;margin-bottom:1.5mm;color:#0f172a;letter-spacing:.5px;}' +
    '.nm{font-weight:800;font-size:11px;margin-top:2mm;line-height:1.2;}' +
    '.sub{font-size:9px;color:#475569;margin-top:.5mm;}' +
    '.credit{text-align:center;font-size:9px;letter-spacing:2.5px;color:#94a3b8;font-weight:700;margin-top:6mm;}' +
    '@media print{.hint{display:none;}}' +
    '</style></head><body>' +
    '<p class="hint">Yazdırma penceresi açılıyor… açılmazsa Ctrl+P yapın. (QR görselleri çevrimiçi üretilir; internet gerekir.)</p>' +
    '<div class="brandhead"><img src="' + escapeHtml(brandLogo) + '" alt="TUFAN101"/></div>' +
    '<div class="sheet">' + cells + '</div>' +
    '<div class="credit">BY DORUKMEN PROGRAMMER</div>' +
    '<script>window.addEventListener("load",function(){var i=[].slice.call(document.images),d=0;if(!i.length){return setTimeout(p,300);}i.forEach(function(m){m.complete?t():(m.addEventListener("load",t),m.addEventListener("error",t));});function t(){if(++d>=i.length)setTimeout(p,300);}function p(){try{window.focus();window.print();}catch(e){}}});</script>' +
    '</body></html>';
  const w = window.open("", "_blank");
  if (!w) { toast("Açılır pencere engellendi — tarayıcı iznini verin.", "warn"); return; }
  w.document.open(); w.document.write(doc); w.document.close();
}

function escapeHtml(str) {
  return String(str == null ? "" : str).replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

// ---- QR AFİŞ çıktısı: tek büyük QR + "QR OKUTUN!" + bağlantı (masaya/duvara asmalık) ----
// Referans şablon: üstte "QR OKUTUN!", aşağı ok, krem çerçeveli QR, altında bağlantı ikonu + link,
// en altta işletme logosu/adı. Herhangi bir işletme için dinamik çalışır.
function printQrPoster(link, s) {
  const biz = (s && (s.business || s.owner)) || "Menü";
  const accent = (s && s.menuColor) || "#2563EB";
  const logo = (s && s.logo) || "";
  const brandLogo = new URL("assets/img/tufan-logo.png", location.href).href;
  const qrURL = "https://api.qrserver.com/v1/create-qr-code/?size=800x800&margin=10&data=" + encodeURIComponent(link);
  // Bağlantı ikonu (zincir) — çizgi ikon, currentColor
  const linkIcon = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="#334155" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.07 0l3-3a5 5 0 0 0-7.07-7.07l-1.7 1.7"/><path d="M14 11a5 5 0 0 0-7.07 0l-3 3a5 5 0 0 0 7.07 7.07l1.7-1.7"/></svg>';
  const arrow = '<svg viewBox="0 0 24 24" width="52" height="52" fill="#0f172a"><path d="M12 3a1.6 1.6 0 0 1 1.6 1.6v9.17l3.13-3.13a1.6 1.6 0 1 1 2.26 2.26l-5.86 5.86a1.6 1.6 0 0 1-2.26 0l-5.86-5.86a1.6 1.6 0 1 1 2.26-2.26l3.13 3.13V4.6A1.6 1.6 0 0 1 12 3Z"/></svg>';
  // Logo artık ÜSTTE ve BÜYÜK gösterilir (kullanıcı isteği).
  const heroLogoHtml = logo
    ? '<img class="hero-logo" src="' + escapeHtml(logo) + '" alt="' + escapeHtml(biz) + '"/>'
    : '';
  // İşletme fotoğrafları şeridi (afişte en fazla 3).
  const photos = Array.isArray(s && s.bizPhotos) ? s.bizPhotos.filter(Boolean) : [];
  const photosHtml = photos.length
    ? '<div class="photos">' + photos.slice(0, 3).map((p) => '<img src="' + escapeHtml(p) + '" alt=""/>').join("") + '</div>'
    : '';
  const doc =
    '<!doctype html><html lang="tr"><head><meta charset="utf-8">' +
    '<title>QR Afiş — ' + escapeHtml(biz) + '</title><style>' +
    '@page{size:A4 portrait;margin:0;}' +
    '*{box-sizing:border-box;margin:0;padding:0;-webkit-print-color-adjust:exact;print-color-adjust:exact;}' +
    'body{font-family:Arial,Helvetica,sans-serif;color:#0f172a;}' +
    /* TEK SAYFA: sabit A4 yüksekliği + taşmayı kırp (asla 2. sayfaya geçmez). */
    '.page{width:210mm;height:297mm;overflow:hidden;padding:12mm 16mm;display:flex;flex-direction:column;align-items:center;' +
      'background:linear-gradient(135deg,#f8fafc 0%,#e9edf3 55%,#dfe4ea 100%);}' +
    '.hero-logo{width:150px;height:150px;object-fit:contain;border-radius:28px;background:#fff;' +
      'padding:9px;box-shadow:0 10px 26px rgba(0,0,0,.16);margin-bottom:4mm;}' +
    '.title{font-size:40px;font-weight:900;letter-spacing:1px;text-align:center;margin-bottom:4mm;}' +
    '.arrow{margin-bottom:3mm;}' +
    '.frame{background:linear-gradient(135deg,#fdf6e3,#f6e7c4);border-radius:7mm;padding:6mm;' +
      'box-shadow:0 10px 30px rgba(0,0,0,.12);position:relative;width:86mm;max-width:86mm;}' +
    '.photos{display:flex;gap:4mm;justify-content:center;margin-top:5mm;width:150mm;}' +
    '.photos img{width:34mm;height:34mm;object-fit:cover;border-radius:4mm;box-shadow:0 8px 20px rgba(0,0,0,.16);}' +
    '.frame:before{content:"";position:absolute;inset:5mm;border:1.5px solid #caa96a;border-radius:5mm;pointer-events:none;}' +
    '.frame:after{content:"";position:absolute;inset:8mm;border:1px solid #d9be86;border-radius:4mm;pointer-events:none;}' +
    '.qr{display:block;width:100%;height:auto;border-radius:2mm;position:relative;z-index:1;background:#fff;padding:4mm;}' +
    '.linkrow{display:flex;align-items:center;justify-content:center;gap:8px;margin-top:5mm;' +
      'max-width:150mm;word-break:break-all;}' +
    '.linkrow .url{font-size:14px;color:#334155;font-weight:600;}' +
    '.spacer{flex:1;min-height:4mm;}' +
    '.brand{display:flex;flex-direction:column;align-items:center;gap:5px;margin-top:5mm;}' +
    '.brand-logo{width:70px;height:70px;object-fit:contain;border-radius:14px;}' +
    '.brand-name{font-size:22px;font-weight:800;color:' + accent + ';letter-spacing:.5px;}' +
    '.brand-sub{font-size:12px;color:#64748b;letter-spacing:2px;text-transform:uppercase;}' +
    '.tufan-mark{height:11mm;object-fit:contain;margin-top:5mm;opacity:.95;}' +
    '.hint{position:fixed;top:6px;left:0;right:0;text-align:center;font-size:12px;color:#64748b;}' +
    '@media print{.hint{display:none;}}' +
    '</style></head><body>' +
    '<p class="hint">Yazdırma penceresi açılıyor… açılmazsa Ctrl+P yapın. (QR görseli çevrimiçi üretilir; internet gerekir.)</p>' +
    '<div class="page">' +
      heroLogoHtml +
      '<div class="title">QR OKUTUN!</div>' +
      '<div class="arrow">' + arrow + '</div>' +
      '<div class="frame"><img class="qr" src="' + qrURL + '" alt="QR"/></div>' +
      '<div class="linkrow">' + linkIcon + '<span class="url">' + escapeHtml(link) + '</span></div>' +
      photosHtml +
      '<div class="spacer"></div>' +
      '<div class="brand">' +
        '<div class="brand-name">' + escapeHtml(biz) + '</div>' +
        '<div class="brand-sub">Dijital Menü</div>' +
        '<img class="tufan-mark" src="' + escapeHtml(brandLogo) + '" alt="TUFAN101"/>' +
      '</div>' +
    '</div>' +
    '<script>window.addEventListener("load",function(){var i=[].slice.call(document.images),d=0;if(!i.length){return setTimeout(p,300);}i.forEach(function(m){m.complete?t():(m.addEventListener("load",t),m.addEventListener("error",t));});function t(){if(++d>=i.length)setTimeout(p,400);}function p(){try{window.focus();window.print();}catch(e){}}});<\/script>' +
    '</body></html>';
  const w = window.open("", "_blank");
  if (!w) { toast("Açılır pencere engellendi — tarayıcı iznini verin.", "warn"); return; }
  w.document.open(); w.document.write(doc); w.document.close();
}

// ---- Renk yardımcıları (tıklama ekranı gradyanı) ----
function hexToRgb(hex) { let c = String(hex || "#2563EB").replace("#", ""); if (c.length === 3) c = c.split("").map((x) => x + x).join(""); const n = parseInt(c, 16) || 0; return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function rgbToHex(r, g, b) { const h = (v) => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0"); return "#" + h(r) + h(g) + h(b); }
function mix(a, b, t) { const A = hexToRgb(a), B = hexToRgb(b); return rgbToHex(A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t, A[2] + (B[2] - A[2]) * t); }
function lum(hex) { const v = hexToRgb(hex).map((x) => { x /= 255; return x <= 0.03928 ? x / 12.92 : Math.pow((x + 0.055) / 1.055, 2.4); }); return 0.2126 * v[0] + 0.7152 * v[1] + 0.0722 * v[2]; }
function rotateHue(hex, deg) {
  let [r, g, b] = hexToRgb(hex).map((x) => x / 255);
  const max = Math.max(r, g, b), min = Math.min(r, g, b); let h, s; const l = (max + min) / 2;
  if (max === min) { h = 0; s = 0; } else {
    const d = max - min; s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    h = max === r ? (g - b) / d + (g < b ? 6 : 0) : max === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6;
  }
  h = ((h * 360 + deg) % 360 + 360) % 360 / 360;
  if (s === 0) return rgbToHex(l * 255, l * 255, l * 255);
  const q = l < 0.5 ? l * (1 + s) : l + s - l * s, p = 2 * l - q;
  const hue = (t) => { if (t < 0) t += 1; if (t > 1) t -= 1; if (t < 1 / 6) return p + (q - p) * 6 * t; if (t < 1 / 2) return q; if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6; return p; };
  return rgbToHex(hue(h + 1 / 3) * 255, hue(h) * 255, hue(h - 1 / 3) * 255);
}

// Stoksuz QR menü ürünlerini (settings.menuItems) stok ürünleriyle birleştirir.
// menuItems kategorisi 'cat' (ad) alanına göre eşlenir; yoksa sentetik kategori
// oluşturulur. Böylece stok tarafına HİÇ dokunmadan menüye ürün eklenebilir.
function mergeMenuItems(cats, products, sett) {
  const outCats = Array.isArray(cats) ? cats.slice() : [];
  const outProds = Array.isArray(products) ? products.slice() : [];
  const items = (sett && Array.isArray(sett.menuItems)) ? sett.menuItems : [];
  items.filter((m) => m && !m._deleted && m.active !== false && String(m.name || "").trim()).forEach((m) => {
    let catId;
    const cn = String(m.cat || "").trim();
    if (cn) {
      let c = outCats.find((x) => String(x.name || "").trim().toLowerCase() === cn.toLowerCase());
      if (!c) { c = { id: "qrcat_" + cn.toLowerCase().replace(/\s+/g, "_"), name: cn }; outCats.push(c); }
      catId = c.id;
    }
    outProds.push({
      id: m.id || ("qr_" + Math.random().toString(36).slice(2)),
      name: m.name, price: m.price, image: m.image, desc: m.desc,
      kcal: m.kcal, gram: m.gram, portion: m.portion, allergens: m.allergens,
      emoji: m.emoji, categoryId: catId, active: true,
    });
  });
  return { cats: outCats, products: outProds };
}

// Besin değeri rozetleri (kalori / gram / porsiyon / alerjen).
// İşletme sahibi kapatmadıysa (showNutrition !== false) ve veri varsa gösterilir.
function nutritionBadges(p, sett) {
  if (sett && sett.showNutrition === false) return null;
  const items = [];
  const add = (icon, val) => { if (val !== undefined && val !== null && String(val).trim() !== "") items.push(el("span", { class: "menu-nutri-badge", text: icon + " " + String(val).trim() })); };
  add("🔥", p.kcal ? (p.kcal + (/\D/.test(String(p.kcal)) ? "" : " kcal")) : "");
  add("⚖️", p.gram ? (p.gram + (/\D/.test(String(p.gram)) ? "" : " g")) : "");
  add("🍽", p.portion || "");
  add("⚠️", p.allergens || "");
  if (!items.length) return null;
  return el("div", { class: "menu-nutri" }, items);
}

// Kategori+ürünleri verilen kutuya diz (hem yönetici önizleme hem müşteri menüsü)
// onAdd verilirse her ürüne "+" sipariş butonu eklenir (müşteri menüsü).
function buildMenuInto(box, cats, products, sett, onAdd, opts) {
  opts = opts || {};
  const cur = (sett && sett.currency) || undefined;
  const hidePrice = !!(sett && sett.hideMenuPrice);
  const big = !!(sett && sett.menuBigPhotos);
  const fmt = (n) => cur ? `${(Number(n) || 0).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${cur}` : money(n);

  // Klasik satır (küçük görsel solda)
  const rowCompact = (p) => el("div", { class: "menu-row" }, [
    p.image
      ? el("img", { class: "prod-thumb", src: p.image, alt: p.name })
      : el("span", { class: "prod-thumb-emoji", text: p.emoji || "🍽" }),
    el("div", { class: "menu-name" }, [
      el("div", { text: p.name }),
      (p.desc || p.description)
        ? el("div", { class: "menu-desc", text: p.desc || p.description })
        : null,
      nutritionBadges(p, sett),
    ]),
    hidePrice ? null : el("span", { class: "menu-price num", text: fmt(p.price) }),
    onAdd
      ? el("button", { class: "menu-add", title: "Sepete ekle", onClick: () => onAdd(p) }, ["+"])
      : el("span", { class: "menu-row-chev", html: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 18l6-6-6-6"/></svg>' }),
  ]);

  // Büyük fotoğraflı kart (görsel üstte, tam genişlik) — QR okutulunca şık görünüm
  const rowBig = (p) => el("div", { class: "menu-row menu-row--big" }, [
    p.image
      ? el("img", { class: "menu-photo-big", src: p.image, alt: p.name, loading: "lazy" })
      : el("div", { class: "menu-photo-big menu-photo-big--emoji", text: p.emoji || "🍽" }),
    el("div", { class: "menu-big-body" }, [
      el("div", { class: "menu-big-top" }, [
        el("div", { class: "menu-name", text: p.name }),
        hidePrice ? null : el("span", { class: "menu-price num", text: fmt(p.price) }),
      ]),
      (p.desc || p.description) ? el("div", { class: "menu-desc", text: p.desc || p.description }) : null,
      nutritionBadges(p, sett),
      onAdd ? el("button", { class: "menu-add menu-add--wide", title: "Sepete ekle", onClick: () => onAdd(p) }, ["+ Sepete Ekle"]) : null,
    ]),
  ]);

  const row = big ? rowBig : rowCompact;

  // Izgara (2 sütun) kartı — "grid" görünümü için
  const cardGrid = (p) => el("div", { class: "qmenu-card" }, [
    p.image
      ? el("img", { class: "qmenu-card-img", src: p.image, alt: p.name, loading: "lazy" })
      : el("div", { class: "qmenu-card-img qmenu-card-img--emoji", text: p.emoji || "🍽" }),
    el("div", { class: "qmenu-card-body" }, [
      el("div", { class: "qmenu-card-name", text: p.name }),
      nutritionBadges(p, sett),
      el("div", { class: "qmenu-card-foot" }, [
        hidePrice ? el("span", {}) : el("span", { class: "menu-price num", text: fmt(p.price) }),
        onAdd ? el("button", { class: "menu-add", title: "Sepete ekle", onClick: () => onAdd(p) }, ["+"]) : null,
      ]),
    ]),
  ]);

  // Kategorileri grupla (yalnız dolu olanlar). QrAll tarzı: üstte kategori
  // çipleri (sekme), altta seçili kategorinin ürünleri; ayrıca "Tümünü Gör".
  const groups = [];
  (cats || []).forEach((c) => {
    const items = (products || []).filter((p) => p.categoryId === c.id);
    if (!items.length) return;
    const cover = c.image || c.cover || ((items.find((x) => x.image) || {}).image) || "";
    groups.push({ id: c.id, name: ((c.icon ? c.icon + " " : "") + c.name), plain: c.name, color: c.color, cover, items });
  });
  const orphan = (products || []).filter((p) => !cats.some((c) => c.id === p.categoryId));
  if (orphan.length) {
    const cover = ((orphan.find((x) => x.image) || {}).image) || "";
    groups.push({ id: "__other", name: "Diğer", plain: "Diğer", color: "", cover, items: orphan });
  }

  if (!groups.length) {
    box.appendChild(el("p", { class: "muted", style: "padding:16px 0;text-align:center", text: "Henüz ürün eklenmemiş." }));
    return;
  }

  let activeId = groups[0].id;
  let gridMode = false;
  const gActive = () => groups.find((x) => x.id === activeId) || groups[0];

  const arrowRight = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
  const arrowLeft = '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M11 6l-6 6 6 6"/></svg>';
  const iconList = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M8 6h13M8 12h13M8 18h13M3 6h.01M3 12h.01M3 18h.01"/></svg>';
  const iconGrid = '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>';

  // "Kategoriler" başlığı + "Tümünü Gör"
  const catHead = el("div", { class: "qmenu-cathead" }, [
    el("span", { class: "qmenu-cathead-t", text: "Kategoriler" }),
    el("button", { class: "qmenu-seeall", type: "button", onClick: () => showFull() }, [
      el("span", { text: "Tümünü Gör" }), el("span", { class: "ico", html: arrowRight }),
    ]),
  ]);

  const chipRow = el("div", { class: "menu-chips" });
  const hero = el("div", { class: "qmenu-hero" });
  const secTitle = el("div", { class: "qmenu-sectitle" });
  const toggleBtn = el("button", { class: "qmenu-viewtoggle", type: "button", title: "Görünümü değiştir", onClick: () => { gridMode = !gridMode; toggleBtn.innerHTML = gridMode ? iconList : iconGrid; paintList(); } }, []);
  toggleBtn.innerHTML = iconGrid;
  const secHead = el("div", { class: "qmenu-sechead" }, [secTitle, toggleBtn]);
  const listBox = el("div", { class: "qmenu-list" });

  // Ana görünüm (çipler → banner → hero → başlık → ürünler)
  const mainView = el("div", {});
  mainView.appendChild(chipRow);
  if (opts.afterChips) mainView.appendChild(opts.afterChips);
  mainView.append(hero, secHead, listBox);

  // "Tümünü Gör" tam kategori listesi (büyük görsel + ad)
  const fullView = el("div", { class: "qmenu-full", style: "display:none" });

  function paintChips() {
    clear(chipRow);
    groups.forEach((gr) => {
      chipRow.appendChild(el("button", { class: "menu-chip" + (gr.id === activeId ? " active" : ""), type: "button", onClick: () => selectCat(gr.id) }, [
        gr.cover ? el("img", { class: "menu-chip-img", src: gr.cover, alt: gr.plain }) : null,
        el("span", { text: gr.name }),
      ]));
    });
  }
  function paintHero() {
    clear(hero);
    const gr = gActive();
    if (gr.cover) { hero.style.display = ""; hero.appendChild(el("img", { class: "qmenu-hero-img", src: gr.cover, alt: gr.plain, loading: "lazy" })); }
    else hero.style.display = "none";
  }
  function paintSec() { clear(secTitle); secTitle.appendChild(el("span", { text: gActive().plain })); }
  function paintList() {
    clear(listBox);
    const gr = gActive();
    if (gridMode) {
      const grid = el("div", { class: "qmenu-grid" });
      gr.items.forEach((p) => grid.appendChild(cardGrid(p)));
      listBox.appendChild(grid);
    } else {
      gr.items.forEach((p) => listBox.appendChild(row(p)));
    }
  }
  function selectCat(id) { activeId = id; paintChips(); paintHero(); paintSec(); paintList(); }

  function showFull() {
    clear(fullView);
    fullView.appendChild(el("button", { class: "qmenu-full-back", type: "button", onClick: () => hideFull() }, [
      el("span", { class: "ico", html: arrowLeft }), el("span", { text: "Menüye Dön" }),
    ]));
    groups.forEach((gr) => {
      fullView.appendChild(el("button", { class: "qmenu-full-row", type: "button", onClick: () => { hideFull(); selectCat(gr.id); window.scrollTo({ top: 0, behavior: "smooth" }); } }, [
        gr.cover ? el("img", { class: "qmenu-full-img", src: gr.cover, alt: gr.plain })
                 : el("div", { class: "qmenu-full-img qmenu-full-img--ph", text: "🍽" }),
        el("div", { class: "qmenu-full-name", text: gr.plain }),
        el("span", { class: "qmenu-full-count", text: gr.items.length + " ürün" }),
      ]));
    });
    mainView.style.display = "none"; catHead.style.display = "none"; fullView.style.display = "";
  }
  function hideFull() { fullView.style.display = "none"; mainView.style.display = ""; catHead.style.display = ""; }

  box.append(catHead, mainView, fullView);
  paintChips(); paintHero(); paintSec(); paintList();
}

// PDF menüyü tam ekran görüntüle (işletme settings.menuPdf yüklediyse).
// menuPdf bir data: URL (base64) veya http(s) bağlantısı olabilir.
function openPdfMenu(sett) {
  const src = String((sett && sett.menuPdf) || "").trim();
  if (!src) { toast("PDF menü bulunamadı", "warn"); return; }
  const name = (sett && sett.menuPdfName) || "Menü.pdf";
  const isData = /^data:/i.test(src);
  // Tam ekran katman: üstte kapat + indir, altta gömülü PDF
  const overlay = el("div", { class: "pdfmenu-overlay" });
  const frame = el("iframe", { class: "pdfmenu-frame", src, title: name });
  const close = () => { overlay.remove(); document.removeEventListener("keydown", onKey); };
  const onKey = (e) => { if (e.key === "Escape") close(); };
  document.addEventListener("keydown", onKey);
  const bar = el("div", { class: "pdfmenu-bar" }, [
    el("span", { class: "pdfmenu-name", text: "📄 " + name }),
    el("div", { style: "flex:1" }),
    el("a", { class: "pdfmenu-btn", href: src, download: name, target: isData ? "_self" : "_blank", rel: "noopener" }, ["⬇ İndir"]),
    el("button", { class: "pdfmenu-btn", type: "button", onClick: close }, ["✕ Kapat"]),
  ]);
  overlay.append(bar, frame);
  overlay.addEventListener("click", (e) => { if (e.target === overlay) close(); });
  document.body.appendChild(overlay);
}

// ---- Müşteri vitrini: sosyal + iletişim + wifi + kartvizit ----
function contactBar(sett) {
  const links = [];
  const ig = (sett.instagram || "").trim().replace(/^@/, "");
  if (ig) links.push(linkChip("📷", "Instagram", "https://instagram.com/" + encodeURIComponent(ig), "#E1306C"));
  const waNum = String(sett.whatsapp || sett.phone || "").replace(/\D/g, "");
  if (waNum) links.push(linkChip("💬", "WhatsApp", "https://wa.me/" + waNum, "#25D366"));
  const telNum = String(sett.phone || "").replace(/[^\d+]/g, "");
  if (telNum) links.push(linkChip("📞", "Ara", "tel:" + telNum, "#0ea5e9"));
  if (sett.email) links.push(linkChip("✉️", "E-Posta", "mailto:" + sett.email, "#6366f1"));
  let mapsUrl = (sett.maps || "").trim();
  if (!mapsUrl && sett.address) mapsUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(sett.address);
  if (mapsUrl && !/^https?:\/\//i.test(mapsUrl)) mapsUrl = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(mapsUrl);
  if (mapsUrl) links.push(linkChip("📍", "Yol Tarifi", mapsUrl, "#4285F4"));
  if (sett.website) links.push(linkChip("🌐", "Web Sitesi", /^https?:\/\//i.test(sett.website) ? sett.website : "https://" + sett.website, "#0284c7"));
  if (sett.googleReviews) links.push(linkChip("⭐", "Google Yorumlar", /^https?:\/\//i.test(sett.googleReviews) ? sett.googleReviews : "https://" + sett.googleReviews, "#DB4437"));
  // Aksiyon butonları (link değil): Hakkımızda, Banka/IBAN, Rehbere Ekle, Paylaş
  if (sett.about) links.push(actionChip("ℹ️", "Hakkımızda", "#64748b", () => aboutModal(sett)));
  if (sett.iban) links.push(actionChip("🏦", "Banka Bilgileri", "#0f766e", () => bankModal(sett)));
  links.push(actionChip("👤", "Rehbere Ekle", "#7c3aed", () => downloadVCard(sett)));
  if (navigator.share) links.push(actionChip("↗", "Paylaş", "#334155", () => { navigator.share({ title: sett.business || "Menü", url: location.href }).catch(() => {}); }));

  const rows = [];
  if (links.length) rows.push(el("div", { style: "display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin:8px 0" }, links));

  // WiFi bilgisi (ad + şifre, kopyalanabilir)
  if (sett.wifiName) {
    rows.push(el("div", { style: "display:flex;align-items:center;gap:10px;background:var(--bg,rgba(0,0,0,.04));border:1px solid var(--border);border-radius:10px;padding:8px 12px;margin:4px 0;flex-wrap:wrap" }, [
      el("span", { style: "font-size:18px", text: "📶" }),
      el("span", {}, [
        el("div", { style: "font-weight:700", text: "WiFi: " + sett.wifiName }),
        sett.wifiPass ? el("div", { class: "muted", style: "font-size:13px", text: "Şifre: " + sett.wifiPass }) : null,
      ]),
      el("div", { style: "flex:1" }),
      sett.wifiPass ? el("button", { class: "btn ghost", style: "padding:4px 10px", onClick: () => { navigator.clipboard?.writeText(sett.wifiPass); toast("WiFi şifresi kopyalandı", "success"); } }, ["Kopyala"]) : null,
    ]));
  }
  if (!rows.length) return null;
  return el("div", {}, rows);
}
function linkChip(icon, label, href, color) {
  return el("a", {
    href, target: "_blank", rel: "noopener",
    style: `display:inline-flex;align-items:center;gap:6px;text-decoration:none;color:#fff;background:${color};padding:7px 12px;border-radius:20px;font-size:13px;font-weight:600`,
  }, [el("span", { text: icon }), el("span", { text: label })]);
}
// Link olmayan aksiyon rozeti (Hakkımızda / Banka / Rehbere Ekle / Paylaş)
function actionChip(icon, label, color, onClick) {
  return el("button", {
    onClick,
    style: `display:inline-flex;align-items:center;gap:6px;border:0;cursor:pointer;color:#fff;background:${color};padding:7px 12px;border-radius:20px;font-size:13px;font-weight:600`,
  }, [el("span", { text: icon }), el("span", { text: label })]);
}

// "Hakkımızda" penceresi
function aboutModal(sett) {
  modal({
    title: "ℹ️ " + (sett.business || "Hakkımızda"),
    body: el("div", { style: "white-space:pre-wrap;line-height:1.6;font-size:14px" }, [sett.about || ""]),
    actions: [{ label: "Kapat", kind: "ghost" }],
  });
}

// "Banka Bilgileri / IBAN" penceresi — kopyalanabilir
function bankModal(sett) {
  const ibanClean = String(sett.iban || "").replace(/\s+/g, "");
  const line = (lbl, val) => val ? el("div", { style: "display:flex;justify-content:space-between;gap:12px;padding:8px 0;border-bottom:1px dashed var(--border)" }, [
    el("span", { class: "muted", text: lbl }), el("b", { style: "text-align:right;word-break:break-all", text: val }),
  ]) : null;
  modal({
    title: "🏦 Banka Bilgileri",
    body: el("div", {}, [
      line("Banka", sett.bankName),
      line("Hesap Sahibi", sett.bankHolder),
      line("IBAN", sett.iban),
    ]),
    actions: [
      { label: "IBAN'ı Kopyala", kind: "success", onClick: (close) => { navigator.clipboard?.writeText(ibanClean); toast("IBAN kopyalandı", "success"); if (close) close(); } },
      { label: "Kapat", kind: "ghost" },
    ],
  });
}

// Rehbere ekle — vCard (.vcf) dosyası oluşturup indir
function downloadVCard(sett) {
  const tel = String(sett.phone || sett.whatsapp || "").trim();
  const org = sett.business || "İşletme";
  const lines = [
    "BEGIN:VCARD", "VERSION:3.0",
    "FN:" + (sett.owner || org),
    "ORG:" + org,
    tel ? "TEL;TYPE=CELL:" + tel : "",
    sett.email ? "EMAIL:" + sett.email : "",
    sett.website ? "URL:" + sett.website : "",
    sett.address ? "ADR:;;" + sett.address + ";;;;" : "",
    "END:VCARD",
  ].filter(Boolean);
  try {
    const blob = new Blob([lines.join("\r\n")], { type: "text/vcard" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url; a.download = (org.replace(/[^\w]+/g, "_") || "kartvizit") + ".vcf";
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
    toast("Kartvizit indirildi — rehbere ekleyebilirsiniz", "success");
  } catch { toast("Kartvizit oluşturulamadı", "error"); }
}

// ---- Puan verme widget'ı (TUFAN 101 üzerinde toplanır) ----
function ratingWidget(account) {
  const box = el("div", { class: "rating-box", style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin:10px 0;padding:10px 12px;border:1px solid var(--border);border-radius:10px" });
  const avgLabel = el("span", { class: "muted", style: "font-size:13px", text: "" });
  const starWrap = el("div", { style: "display:flex;gap:4px;font-size:26px;cursor:pointer" });
  let current = 0;   // seçilen puan (kalıcı — tekrar tıklayınca değişir)
  let busy = false;  // gönderim sırasında çift tıklamayı engelle
  const stars = [];
  for (let i = 1; i <= 5; i++) {
    const star = el("span", { style: "filter:grayscale(1);opacity:.5;transition:.1s", text: "⭐" });
    star.addEventListener("mouseenter", () => { if (!busy) paint(i); });
    star.addEventListener("click", async () => {
      if (busy || i === current) { paint(current); return; }
      busy = true; paint(i);
      try {
        await cloud.rate(account, i);
        current = i;
        toast("Puanınız kaydedildi: " + i + "/5 ⭐ (istediğiniz zaman değiştirebilirsiniz)", "success");
      } catch (e) {
        // Sunucu mesajı: puanlama kapalı / zaten puan verildi / çok fazla istek
        toast((e && e.data && e.data.msg) ? e.data.msg : "Bağlantı hatası", "warn");
        paint(current);
      }
      finally { busy = false; }
    });
    stars.push(star); starWrap.appendChild(star);
  }
  function paint(n) { stars.forEach((s, idx) => { const on = idx < n; s.style.filter = on ? "none" : "grayscale(1)"; s.style.opacity = on ? "1" : ".5"; }); }
  // Fareyle üzerinden çekilince seçili puana geri dön (0'a değil) — böylece verilen puan görünür kalır
  starWrap.addEventListener("mouseleave", () => paint(current));
  box.append(el("span", { style: "font-weight:700", text: "Bizi puanla:" }), starWrap, avgLabel);
  // Ortalama puanı yükle
  cloud.stats(account).then((r) => {
    if (r && r.ok && r.ratingCount > 0) avgLabel.textContent = `★ ${r.ratingAvg} (${r.ratingCount} değerlendirme)`;
  }).catch(() => {});
  return box;
}

// ---- Anket penceresi (müşteri doldurur) ----
function openSurvey(account, survey) {
  const questions = (survey.questions || []).filter((q) => q && q.text);
  const fields = questions.map((q) => {
    if (q.type === "rating") {
      const sel = el("select", { class: "input" }, [
        el("option", { value: "" }, ["— Puan seç —"]),
        ...[5, 4, 3, 2, 1].map((n) => el("option", { value: String(n) }, [`${n} ⭐`])),
      ]);
      return { q, node: sel, get: () => sel.value };
    }
    const ta = el("textarea", { class: "input", rows: "2", placeholder: "Cevabınız…" });
    return { q, node: ta, get: () => ta.value.trim() };
  });
  const body = el("div", {}, fields.map((f) =>
    el("div", { class: "field", style: "margin-bottom:10px" }, [
      el("label", { text: f.q.text }), f.node,
    ]))
  );
  modal({
    title: "📋 " + (survey.title || "Anket"),
    body,
    actions: [
      { label: "Gönder", kind: "success", onClick: async (close) => {
        const answers = fields.map((f) => ({ q: f.q.text, a: f.get() })).filter((x) => x.a !== "");
        if (!answers.length) { toast("Lütfen en az bir soruyu yanıtlayın.", "warn"); return; }
        try { await cloud.survey(account, answers); toast("Anket gönderildi, teşekkürler! 🙏", "success"); close(); }
        catch { toast("Bağlantı hatası, tekrar deneyin.", "error"); }
      } },
      { label: "Kapat", kind: "ghost" },
    ],
  });
}

function bio(label, val) {
  return el("div", { style: "display:flex;justify-content:space-between;padding:6px 0;font-size:13px" }, [
    el("span", { text: label }), el("span", { class: "muted", text: val }),
  ]);
}

// Bir hex rengi koyulaştır/açıklaştır (banner gradyanı için). amt: -100..100
function shade(hex, amt) {
  try {
    let c = String(hex || "#2563EB").replace("#", "");
    if (c.length === 3) c = c.split("").map((x) => x + x).join("");
    const num = parseInt(c, 16);
    const clamp = (v) => Math.max(0, Math.min(255, v));
    const r = clamp((num >> 16) + Math.round(255 * amt / 100));
    const g = clamp(((num >> 8) & 0xff) + Math.round(255 * amt / 100));
    const b = clamp((num & 0xff) + Math.round(255 * amt / 100));
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1);
  } catch { return hex; }
}

// ---- Gerçek, taranabilir QR kodu ----
// Çevrimiçiyken güvenilir QR servisinden üretir (yazdırma/paylaşım için).
// İnternet yoksa dekoratif yer tutucuya düşer (bilgi notuyla).
function realQR(text) {
  const holder = el("div", { style: "position:relative;width:210px;margin:8px auto" });
  const img = new Image(210, 210);
  img.width = 210; img.height = 210;
  img.alt = "QR";
  img.style.cssText = "width:210px;height:210px;border-radius:12px;display:block;background:#fff";
  img.referrerPolicy = "no-referrer";
  img.src = "https://api.qrserver.com/v1/create-qr-code/?size=240x240&margin=8&data=" + encodeURIComponent(text);
  img.onerror = () => {
    holder.innerHTML = "";
    holder.appendChild(qrPlaceholder(text));
    holder.appendChild(el("p", { class: "muted", style: "font-size:11px;text-align:center", text: "QR üretmek için internet gerekli" }));
  };
  holder.appendChild(img);
  return holder;
}

// Çevrimdışı dekoratif desen (yalnızca yedek görsel — taranmaz)
function qrPlaceholder(text) {
  const size = 21;
  let h = 5381; for (let i = 0; i < text.length; i++) h = ((h << 5) + h + text.charCodeAt(i)) >>> 0;
  const rng = () => { h = (h * 1103515245 + 12345) >>> 0; return h / 4294967296; };
  const c = document.createElement("canvas"); c.width = c.height = 210; c.style.borderRadius = "12px"; c.style.margin = "8px auto"; c.style.display = "block";
  const ctx = c.getContext("2d"); const cell = 210 / size;
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, 210, 210); ctx.fillStyle = "#0F172A";
  const finder = (x, y) => { ctx.fillRect(x, y, cell * 7, cell * 7); ctx.fillStyle = "#fff"; ctx.fillRect(x + cell, y + cell, cell * 5, cell * 5); ctx.fillStyle = "#0F172A"; ctx.fillRect(x + cell * 2, y + cell * 2, cell * 3, cell * 3); };
  for (let y = 0; y < size; y++) for (let x = 0; x < size; x++) {
    if ((x < 8 && y < 8) || (x > size - 9 && y < 8) || (x < 8 && y > size - 9)) continue;
    if (rng() > 0.5) ctx.fillRect(x * cell, y * cell, cell, cell);
  }
  finder(0, 0); finder(210 - cell * 7, 0); finder(0, 210 - cell * 7);
  return c;
}
