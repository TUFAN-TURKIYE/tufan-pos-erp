// İade / Değişim
// Fiş no okut/gir → satış bulunur → iade edilecek ürünler seçilir →
// stok geri eklenir → kasadan para düşer (nakit hesaba 'out' hareketi) →
// satış iade işaretlenir. Tam veya kısmi iade desteklenir.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, ensureAccounts, defaultAccountId, postAccountMove } from "../core/store.js";
import { currentUser } from "../core/auth.js";

function findSale(q) {
  const s = String(q || "").trim().toLowerCase();
  if (!s) return null;
  return db.sales.all().find((x) =>
    x.id === q ||
    String(x.id || "").toLowerCase() === s ||
    String(x.id || "").slice(-8).toLowerCase() === s ||
    String(x.id || "").slice(-6).toLowerCase() === s
  );
}

export function renderRefund(host) {
  const search = el("input", { class: "input", placeholder: "🔍 Fiş no (son 6-8 hane) veya barkod okut", autofocus: true, style: "font-size:18px" });
  const result = el("div", { style: "margin-top:14px" });
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "↩️ " + t("navRefund") }), el("div", { class: "spacer" })]),
    el("div", { class: "card" }, [
      el("p", { class: "muted", style: "margin:0 0 10px", text: "Fiş numarasını girin (fişte “Fiş No” olarak yazar) veya barkod cihazıyla okutun." }),
      search,
    ]),
    result,
  );

  function show(sale) {
    clear(result);
    if (!sale) { result.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:16px", text: "Fiş bulunamadı. Numarayı kontrol edin." })])); return; }
    if (sale.void) { result.appendChild(el("div", { class: "card" }, [el("p", { style: "padding:16px;color:var(--danger,#dc2626)", text: "⚠️ Bu fiş zaten iade edilmiş." })])); return; }

    // Daha önce iade edilen adetleri hesaba kat: aynı fişten satılandan FAZLA iade
    // yapılamasın (tekrarlı kısmi iade ile fazla para/stok çıkışını engelle).
    const refunded = (sale.refundedQ && typeof sale.refundedQ === "object") ? sale.refundedQ : {};
    const items = (sale.items || []).map((it, i) => {
      const sold = Number(it.qty) || 1;
      const already = Number(refunded[i]) || 0;
      return { ...it, _i: i, sold, already, remaining: Math.max(0, sold - already), refundQty: 0 };
    });
    if (!items.some((it) => it.remaining > 0)) {
      result.appendChild(el("div", { class: "card" }, [el("p", { style: "padding:16px;color:var(--danger,#dc2626)", text: "⚠️ Bu fişteki tüm ürünler zaten iade edilmiş." })]));
      return;
    }

    const totalEl = el("div", { class: "num", style: "font-size:22px;font-weight:800" });
    const recalc = () => {
      const sum = items.reduce((a, it) => a + it.refundQty * (Number(it.price) || 0), 0);
      totalEl.textContent = money(sum);
      return sum;
    };

    const rows = items.filter((it) => it.remaining > 0).map((it) => {
      const qtyLabel = el("b", { class: "num", text: "0" });
      const setQ = (q) => { it.refundQty = Math.max(0, Math.min(it.remaining, q)); qtyLabel.textContent = String(it.refundQty); recalc(); };
      const info = it.already > 0
        ? money(it.price) + " × alınan " + it.sold + " · iade " + it.already + " · kalan " + it.remaining
        : money(it.price) + " × alınan " + it.sold;
      return el("div", { class: "cart-row" }, [
        el("div", { style: "flex:1" }, [
          el("div", { style: "font-weight:700", text: it.name || "Ürün" }),
          el("div", { class: "muted", style: "font-size:12px", text: info }),
        ]),
        el("div", { class: "qty" }, [
          el("button", { class: "qbtn", onClick: () => setQ(it.refundQty - 1) }, ["−"]),
          qtyLabel,
          el("button", { class: "qbtn", onClick: () => setQ(it.refundQty + 1) }, ["+"]),
        ]),
        el("button", { class: "btn ghost tiny", onClick: () => setQ(it.remaining) }, ["Tümü"]),
      ]);
    });
    recalc();

    result.appendChild(el("div", { class: "card" }, [
      el("div", { style: "display:flex;justify-content:space-between;align-items:center" }, [
        el("h3", { style: "margin:0", text: "🧾 Fiş #" + String(sale.id).slice(-8).toUpperCase() }),
        el("span", { class: "pill", text: new Date(sale.ts).toLocaleString("tr-TR") }),
      ]),
      el("p", { class: "muted", style: "margin:4px 0 12px", text: "Satış toplamı: " + money(sale.total || 0) + (sale.cashierName ? " · " + sale.cashierName : "") }),
      ...rows,
      el("div", { style: "display:flex;justify-content:space-between;align-items:center;border-top:1px solid var(--border);padding-top:12px;margin-top:8px" }, [
        el("span", { class: "muted", text: "İade tutarı" }), totalEl,
      ]),
      el("div", { style: "display:flex;gap:10px;flex-wrap:wrap;margin-top:12px" }, [
        el("button", { class: "btn danger", onClick: () => doRefund(sale, items) }, ["↩️ Seçilenleri İade Et"]),
        el("button", { class: "btn ghost", onClick: () => { items.forEach((it) => it.refundQty = it.remaining); recalc(); doRefund(sale, items); } }, ["🗑 Kalan Tümünü İade Et"]),
      ]),
    ]));
  }

  function doRefund(sale, items) {
    const refundItems = items.filter((it) => it.refundQty > 0);
    if (!refundItems.length) { toast("İade edilecek ürün seçin", "warn"); return; }
    const amount = refundItems.reduce((a, it) => a + it.refundQty * (Number(it.price) || 0), 0);
    confirmDialog("İade onayı: " + money(amount) + " kasadan düşülecek. Onaylıyor musunuz?", () => {
      // 1) Stok geri ekle
      refundItems.forEach((it) => {
        const p = it.productId ? db.products.get(it.productId) : null;
        if (p) { p.stock = (Number(p.stock) || 0) + it.refundQty; db.products.upsert(p); }
      });
      // 2) Kasadan para düş (nakit hesaba 'out')
      const user = currentUser();
      try {
        ensureAccounts();
        const accId = defaultAccountId("cash");
        if (accId) postAccountMove({ accountId: accId, dir: "out", amount, source: "refund", refId: sale.id, note: "İade · Fiş #" + String(sale.id).slice(-6).toUpperCase() + (user && user.name ? " · " + user.name : ""), party: "İade" });
      } catch {}
      // 3) İade edilen adetleri KALICI işaretle (tekrarlı iade fazla çıkış yapamasın).
      //    Satırın tamamı iade edildiyse fiş 'void' olur; kısmiyse açık kalır.
      const refunded = { ...((sale.refundedQ && typeof sale.refundedQ === "object") ? sale.refundedQ : {}) };
      refundItems.forEach((it) => { refunded[it._i] = (Number(refunded[it._i]) || 0) + it.refundQty; });
      const soldTotal = (sale.items || []).reduce((a, it) => a + (Number(it.qty) || 1), 0);
      const refTotal = Object.values(refunded).reduce((a, q) => a + (Number(q) || 0), 0);
      const fullyRefunded = refTotal >= soldTotal;
      const prev = Number(sale.refundAmount) || 0;
      db.sales.upsert({ ...sale, refundedQ: refunded, refundAmount: prev + amount, refundedAt: Date.now(), refundedBy: user ? user.name : "", void: fullyRefunded ? true : (sale.void || false) });
      // 4) Denetim kaydı (audit log)
      try {
        db.auditLog.upsert({ id: uid(), ts: Date.now(), userId: user ? user.id : null, userName: user ? user.name : "", action: "refund", entity: "sale:" + sale.id, detail: (fullyRefunded ? "Tam iade" : "Kısmi iade") + " " + money(amount) });
      } catch {}
      toast("İade tamamlandı • " + money(amount), "success");
      search.value = ""; clear(result);
    });
  }

  search.addEventListener("keydown", (e) => { if (e.key === "Enter") show(findSale(search.value)); });
  search.addEventListener("input", () => { if (search.value.trim().length >= 6) show(findSale(search.value)); });
}
