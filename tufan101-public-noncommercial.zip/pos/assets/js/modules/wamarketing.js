// WhatsApp Pazarlama — telefonu olan müşterilere kampanya mesajı hazırlar.
// Otomatik gönderim YOK (spam/izin riski). Her müşteri için wa.me linki üretir;
// kullanıcı tek tıkla WhatsApp'ta açıp kendisi gönderir. {ad} yer tutucu desteklenir.
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, settings } from "../core/store.js";

export function renderWaMarketing(host) {
  const selected = new Set();
  const bizName = settings.get().bizName || settings.get().companyName || "İşletmemiz";
  const msg = el("textarea", { class: "input", rows: "4", style: "resize:vertical", text: "Merhaba {ad}! " + bizName + " olarak size özel kampanyamız var 🎉 Detaylar için bekliyoruz." });
  const search = el("input", { class: "input", placeholder: "🔍 Müşteri ara", style: "max-width:220px" });
  const listWrap = el("div", { class: "wa-pick" });
  const countLbl = el("span", { class: "muted" });
  const linksWrap = el("div", {});

  const withPhone = () => db.customers.all().filter((c) => String(c.phone || "").replace(/\D/g, "").length >= 10);

  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "💬 " + t("navWaMarketing") }), el("div", { class: "spacer" })]),
    el("div", { class: "card" }, [
      el("label", { style: "font-weight:600", text: "Mesaj şablonu" }),
      el("p", { class: "muted", style: "font-size:12px;margin:2px 0 6px", text: "{ad} yazarsanız her müşterinin adıyla değişir." }),
      msg,
      el("p", { class: "muted", style: "font-size:12px;margin-top:6px", text: "⚠️ Otomatik gönderim yoktur — izinli (KVKK) müşterilere kendiniz gönderirsiniz." }),
    ]),
    el("div", { class: "card", style: "display:flex;gap:12px;flex-wrap:wrap;align-items:center" }, [
      search, el("div", { class: "spacer" }),
      el("button", { class: "btn ghost tiny", onClick: () => { withPhone().forEach((c) => selected.add(c.id)); drawList(); } }, ["Tümünü Seç"]),
      el("button", { class: "btn ghost tiny", onClick: () => { selected.clear(); drawList(); } }, ["Temizle"]),
      el("button", { class: "btn success", onClick: () => genLinks() }, ["🔗 Linkleri Oluştur"]),
      countLbl,
    ]),
    listWrap, linksWrap,
  );

  function drawList() {
    clear(listWrap);
    const q = search.value.trim().toLowerCase();
    const rows = withPhone().filter((c) => !q || (c.name || "").toLowerCase().includes(q) || String(c.phone).includes(q));
    countLbl.textContent = selected.size + " seçili · " + withPhone().length + " telefonlu müşteri";
    if (!rows.length) { listWrap.appendChild(el("p", { class: "muted", style: "padding:12px", text: "Telefonlu müşteri yok. Müşteriler modülünden telefon ekleyin." })); return; }
    rows.forEach((c) => {
      const on = selected.has(c.id);
      listWrap.appendChild(el("div", { class: "wa-pick-row" + (on ? " on" : ""), onClick: () => { on ? selected.delete(c.id) : selected.add(c.id); drawList(); } }, [
        el("span", { text: (on ? "☑ " : "☐ ") + "👤 " + (c.name || "Müşteri") }),
        el("span", { class: "muted", text: c.phone }),
      ]));
    });
  }

  function genLinks() {
    const targets = withPhone().filter((c) => selected.has(c.id));
    if (!targets.length) { toast("En az bir müşteri seçin", "warn"); return; }
    const template = msg.value || "";
    clear(linksWrap);
    linksWrap.appendChild(el("div", { class: "card" }, [
      el("h3", { style: "margin:0 0 4px", text: "🔗 Gönderim Linkleri (" + targets.length + ")" }),
      el("p", { class: "muted", style: "font-size:12px;margin:0 0 10px", text: "Her müşteri için WhatsApp'ı açar. Mesajı kontrol edip siz gönderirsiniz." }),
      ...targets.map((c) => {
        const num = String(c.phone).replace(/\D/g, "");
        const full = num.length === 10 ? "90" + num : num; // TR varsayılan
        const text = template.replace(/\{ad\}/g, c.name || "");
        const href = "https://wa.me/" + full + "?text=" + encodeURIComponent(text);
        return el("div", { class: "wa-link-row" }, [
          el("span", { text: "👤 " + (c.name || "Müşteri") + " · " + c.phone }),
          el("a", { class: "btn success tiny", href, target: "_blank", rel: "noopener" }, ["💬 WhatsApp'ta Aç"]),
        ]);
      }),
    ]));
    toast(targets.length + " link hazır", "success");
  }

  search.addEventListener("input", drawList);
  drawList();
}
