// Emlak Portföy — ilan yönetimi (satılık/kiralık), mülk sahibi gizli bilgisi, Sahibinden.com arama
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

const PROP_TYPES = ["Daire", "Müstakil Ev", "Villa", "Arsa", "İş Yeri", "Dükkan", "Bina", "Tarla"];
const ROOMS = ["", "1+0", "1+1", "2+1", "3+1", "4+1", "5+1", "Diğer"];
const STATUS = { aktif: "Aktif", rezerve: "Rezerve", satildi: "Satıldı / Kiralandı" };

export function renderEmlak(host) {
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: "🏠 " + t("emlak") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn", onClick: () => openSahibinden() }, ["🔎 Sahibinden'de Ara"]),
    el("button", { class: "btn success", onClick: () => editProp(null) }, ["+ İlan"]),
  ]);
  const body = el("div", {});
  clear(host).append(head, body);

  let fType = "", q = "";

  function draw() {
    clear(body);
    let list = db.properties.all().slice().sort((a, b) => b.ts - a.ts);
    if (fType) list = list.filter((p) => p.tip === fType);
    if (q) { const s = q.toLowerCase(); list = list.filter((p) => [p.title, p.il, p.ilce, p.tur].join(" ").toLowerCase().includes(s)); }

    const all = db.properties.all();
    const active = all.filter((p) => p.durum === "aktif").length;
    const sold = all.filter((p) => p.durum === "satildi").length;
    body.appendChild(el("div", { class: "stat-grid" }, [
      statCard("Toplam İlan", String(all.length), "var(--primary)"),
      statCard("Portföyde (Aktif)", String(active), "var(--success)"),
      statCard("Satıldı / Kiralandı", String(sold), "var(--warning)"),
    ]));

    // Filtre çubuğu
    const tipSel = el("select", { class: "input", style: "max-width:150px", onChange: (e) => { fType = e.target.value; draw(); } }, [
      el("option", { value: "", ...(fType === "" ? { selected: true } : {}) }, ["Tümü"]),
      el("option", { value: "satilik", ...(fType === "satilik" ? { selected: true } : {}) }, ["Satılık"]),
      el("option", { value: "kiralik", ...(fType === "kiralik" ? { selected: true } : {}) }, ["Kiralık"]),
    ]);
    const searchInp = el("input", { class: "input", placeholder: "İl, ilçe, tür, başlık ara…", value: q });
    searchInp.addEventListener("input", () => { q = searchInp.value; drawTable(); });

    const listCard = el("div", { class: "card", style: "margin-top:16px" });
    listCard.appendChild(el("div", { style: "display:flex;gap:10px;align-items:center;margin-bottom:12px;flex-wrap:wrap" }, [
      el("h3", { style: "margin:0;flex:1", text: "Portföy Listesi" }), tipSel, searchInp,
    ]));
    const tableHost = el("div", {});
    listCard.appendChild(tableHost);
    body.appendChild(listCard);

    function drawTable() {
      let rows = db.properties.all().slice().sort((a, b) => b.ts - a.ts);
      if (fType) rows = rows.filter((p) => p.tip === fType);
      if (q) { const s = q.toLowerCase(); rows = rows.filter((p) => [p.title, p.il, p.ilce, p.tur].join(" ").toLowerCase().includes(s)); }
      clear(tableHost);
      if (!rows.length) { tableHost.appendChild(el("p", { class: "muted", text: "İlan yok." })); return; }
      tableHost.appendChild(el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, [
          el("th", { text: "Başlık" }), el("th", { text: "Durum" }), el("th", { text: "Tür" }), el("th", { text: "Konum" }),
          el("th", { text: "Oda/m²" }), el("th", { text: "Fiyat" }), el("th", { text: "Sahip" }), el("th", {}),
        ])]),
        el("tbody", {}, rows.map((p) =>
          el("tr", {}, [
            el("td", { style: "font-weight:600", text: p.title || "—" }),
            el("td", {}, [el("span", { class: "pill " + (p.tip === "satilik" ? "green" : "blue"), text: p.tip === "satilik" ? "Satılık" : "Kiralık" })]),
            el("td", { text: p.tur || "—" }),
            el("td", { class: "muted", text: [p.il, p.ilce].filter(Boolean).join(" / ") || "—" }),
            el("td", { class: "muted", text: [p.oda, p.m2 ? p.m2 + "m²" : ""].filter(Boolean).join(" · ") || "—" }),
            el("td", { class: "num", style: "font-weight:700", text: p.fiyat ? money(p.fiyat) : "—" }),
            el("td", { class: "muted", style: "font-size:12px", text: p.sahip ? p.sahip + (p.sahiptel ? " • " + p.sahiptel : "") : "—" }),
            el("td", { style: "text-align:right;white-space:nowrap" }, [
              el("span", { class: "pill " + (p.durum === "satildi" ? "amber" : p.durum === "rezerve" ? "blue" : "green"), style: "margin-right:6px", text: STATUS[p.durum] || "Aktif" }),
              el("button", { class: "iconbtn", title: t("edit"), onClick: () => editProp(p) }, ["✏️"]),
              el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog("İlanı sil?", () => { db.properties.remove(p.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
            ]),
          ])
        )),
      ]));
    }
    drawTable();
  }

  function openSahibinden(prefill) {
    const qInp = el("input", { class: "input", placeholder: "Anahtar kelime (örn: 3+1 satılık daire)", value: prefill || "" });
    const ilInp = el("input", { class: "input", placeholder: "İl (Balıkesir)" });
    const ilceInp = el("input", { class: "input", placeholder: "İlçe (Altıeylül)" });
    modal({
      title: "🔎 Sahibinden.com'da Ara",
      body: el("div", {}, [
        field("Anahtar Kelime", qInp),
        two(field("İl", ilInp), field("İlçe", ilceInp)),
        el("p", { class: "muted", style: "font-size:12px", text: "Sahibinden.com yeni sekmede açılır." }),
      ]),
      actions: [
        { label: "🔎 Sahibinden'de Aç", kind: "success", onClick: (close) => {
          const terms = [qInp.value, ilInp.value, ilceInp.value].filter(Boolean).join(" ").trim();
          const url = "https://www.sahibinden.com/kelime-ile-arama?query_text=" + encodeURIComponent(terms || "emlak");
          window.open(url, "_blank", "noopener"); close();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function editProp(existing) {
    const p0 = existing || {};
    const title = el("input", { class: "input", value: p0.title || "", placeholder: "Örn: Merkezde 3+1 daire", autofocus: true });
    const tip = sel(["satilik", "kiralik"], ["Satılık", "Kiralık"], p0.tip || "satilik");
    const tur = sel(PROP_TYPES, PROP_TYPES, p0.tur || "Daire");
    const oda = sel(ROOMS, ROOMS.map((r) => r || "—"), p0.oda || "");
    const m2 = el("input", { class: "input num", type: "number", value: p0.m2 || "", placeholder: "0" });
    const il = el("input", { class: "input", value: p0.il || "", placeholder: "Balıkesir" });
    const ilce = el("input", { class: "input", value: p0.ilce || "", placeholder: "Altıeylül" });
    const fiyat = el("input", { class: "input num", type: "number", value: p0.fiyat || "", placeholder: "0" });
    const durum = sel(["aktif", "rezerve", "satildi"], [STATUS.aktif, STATUS.rezerve, STATUS.satildi], p0.durum || "aktif");
    const not = el("textarea", { class: "input", rows: "2", placeholder: "Detaylar, kat, ısınma…" }, [p0.not || ""]);
    const sahip = el("input", { class: "input", value: p0.sahip || "", placeholder: "Ad Soyad" });
    const sahiptel = el("input", { class: "input", inputmode: "tel", value: p0.sahiptel || "", placeholder: "05xx…" });
    modal({
      title: "🏠 " + (existing ? t("edit") : "İlan Ekle"),
      body: el("div", {}, [
        field("Başlık", title),
        two(field("Durum", tip), field("Tür", tur)),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px" }, [field("Oda", oda), field("m²", m2), field("Fiyat", fiyat)]),
        two(field("İl", il), field("İlçe / Mahalle", ilce)),
        field("Portföy Durumu", durum),
        field("Açıklama / Notlar", not),
        el("div", { class: "muted", style: "font-size:13px;font-weight:600;margin-top:6px", text: "👤 Mülk Sahibi (gizli — sadece sizde)" }),
        two(field("Sahip Adı", sahip), field("Sahip Telefon", sahiptel)),
      ]),
      actions: [
        { label: "💾 " + t("save"), kind: "success", onClick: (close) => {
          if (!title.value.trim()) { toast("Başlık zorunlu", "warn"); return; }
          db.properties.upsert({
            id: p0.id || uid(), ts: p0.ts || Date.now(), title: title.value.trim(),
            tip: tip.value, tur: tur.value, oda: oda.value, m2: parseFloat(m2.value) || 0,
            il: il.value.trim(), ilce: ilce.value.trim(), fiyat: parseFloat(fiyat.value) || 0,
            durum: durum.value, not: not.value.trim(), sahip: sahip.value.trim(), sahiptel: sahiptel.value.trim(),
          });
          toast(existing ? t("save") : "İlan kaydedildi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}

function sel(values, labels, current) {
  return el("select", { class: "input" }, values.map((v, i) => el("option", { value: v, ...(v === current ? { selected: true } : {}) }, [labels[i]])));
}
function field(label, node) { return el("div", { class: "field" }, [el("label", { text: label }), node]); }
function two(a, b) { return el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [a, b]); }
function statCard(label, value, color) {
  return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
    el("div", { class: "label", text: label }),
    el("div", { class: "value num", text: value }),
  ]);
}
