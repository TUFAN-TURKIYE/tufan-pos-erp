// Isı Haritası — hafta günü × saat yoğunluk haritası.
// Hangi gün/saat en yoğun? Satış verisinden ısı ızgarası üretir.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money } from "../core/store.js";

const DAY = 86400000;
const WD = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];

export function renderHeatmap(host) {
  const periodSel = el("select", { class: "input", style: "max-width:180px" }, [
    el("option", { value: "28", text: "Son 4 hafta", selected: true }),
    el("option", { value: "56", text: "Son 8 hafta" }),
    el("option", { value: "0", text: "Tüm zamanlar" }),
  ]);
  const metricSel = el("select", { class: "input", style: "max-width:150px" }, [
    el("option", { value: "rev", text: "Ciro" }),
    el("option", { value: "cnt", text: "Satış adedi" }),
  ]);
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🔥 " + t("navHeatmap") }), el("div", { class: "spacer" }), metricSel, periodSel]),
    body,
  );

  function draw() {
    clear(body);
    const days = Number(periodSel.value);
    const from = days > 0 ? Date.now() - days * DAY : 0;
    const useRev = metricSel.value === "rev";
    const sales = db.sales.all().filter((s) => !s.void && Number(s.ts) >= from);

    if (!sales.length) {
      body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Bu dönemde satış verisi yok." })]));
      return;
    }

    // grid[wd][hour]
    const grid = Array.from({ length: 7 }, () => new Array(24).fill(0));
    sales.forEach((s) => {
      const d = new Date(Number(s.ts));
      const wd = (d.getDay() + 6) % 7, h = d.getHours();
      grid[wd][h] += useRev ? (Number(s.total) || 0) : 1;
    });

    let max = 0, peak = { wd: 0, h: 0, v: 0 };
    for (let w = 0; w < 7; w++) for (let h = 0; h < 24; h++) { const v = grid[w][h]; if (v > max) max = v; if (v > peak.v) peak = { wd: w, h, v }; }
    max = max || 1;

    const fmt = (v) => useRev ? money(v) : Math.round(v) + " satış";
    body.appendChild(el("div", { class: "card", style: "margin-bottom:14px" }, [
      el("p", { style: "margin:0", text: "🔥 En yoğun: " + WD[peak.wd] + " " + peak.h + ":00 – " + (peak.h + 1) + ":00  ·  " + fmt(peak.v) }),
    ]));

    // Isı ızgarası
    const wrap = el("div", { class: "heat-wrap" });
    // Başlık satırı (saatler)
    const head = el("div", { class: "heat-row" }, [el("div", { class: "heat-corner" })]);
    for (let h = 0; h < 24; h++) head.appendChild(el("div", { class: "heat-hlbl", text: h % 2 === 0 ? String(h) : "" }));
    wrap.appendChild(head);

    for (let w = 0; w < 7; w++) {
      const row = el("div", { class: "heat-row" }, [el("div", { class: "heat-wlbl", text: WD[w] })]);
      for (let h = 0; h < 24; h++) {
        const v = grid[w][h];
        const a = v > 0 ? 0.12 + 0.88 * (v / max) : 0;
        row.appendChild(el("div", {
          class: "heat-cell", title: WD[w] + " " + h + ":00 · " + fmt(v),
          style: v > 0 ? "background:rgba(239,68,68," + a.toFixed(2) + ")" : "background:var(--bg-soft,#f1f5f9)",
        }));
      }
      wrap.appendChild(row);
    }
    body.appendChild(el("div", { class: "card", style: "overflow:auto" }, [wrap]));
    body.appendChild(el("div", { class: "heat-legend" }, [
      el("span", { class: "muted", text: "Az" }),
      el("div", { class: "heat-legend-bar" }),
      el("span", { class: "muted", text: "Çok" }),
    ]));
  }

  periodSel.addEventListener("change", draw);
  metricSel.addEventListener("change", draw);
  draw();
}
