// Dashboard TV Modu — dükkan içi büyük ekran için canlı gösterim.
// Bugünkü ciro, sipariş adedi, hedef %, en çok satan, saat. Otomatik yenilenir.
// Tam ekran butonu ile TV/monitörde açılır.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

const DAY = 86400000;

function todayStats() {
  const t0 = new Date(); t0.setHours(0, 0, 0, 0);
  const from = t0.getTime();
  const sales = db.sales.all().filter((s) => !s.void && Number(s.ts) >= from);
  const rev = sales.reduce((a, s) => a + (Number(s.total) || 0), 0);
  const n = sales.length;
  const basket = n ? rev / n : 0;
  // En çok satan (bugün)
  const map = {};
  sales.forEach((s) => (s.items || []).forEach((it) => {
    const k = it.name || "Ürün"; map[k] = (map[k] || 0) + (Number(it.qty) || 1);
  }));
  const top = Object.entries(map).sort((a, b) => b[1] - a[1])[0];
  return { rev, n, basket, top: top ? { name: top[0], qty: top[1] } : null };
}

export function renderTvMode(host) {
  const s = settings.get();
  const bizName = s.bizName || s.companyName || "TUFAN 101";

  const wrap = el("div", { class: "tv-wrap" });
  clear(host).append(
    el("div", { class: "view-head" }, [
      el("h1", { text: "📺 " + t("navTvmode") }),
      el("div", { class: "spacer" }),
      el("button", { class: "btn", onClick: () => { try { (wrap.requestFullscreen || wrap.webkitRequestFullscreen || (() => {})).call(wrap); } catch {} } }, ["⛶ Tam Ekran"]),
    ]),
    wrap,
  );

  function draw() {
    clear(wrap);
    const st = todayStats();
    const now = new Date();
    const target = Number(s.targetDaily) || 0;
    const pct = target > 0 ? Math.min(100, Math.round(st.rev / target * 100)) : null;

    wrap.append(
      el("div", { class: "tv-header" }, [
        el("div", { class: "tv-biz", text: bizName }),
        el("div", { class: "tv-clock num", text: now.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) + "  ·  " + now.toLocaleDateString("tr-TR", { day: "2-digit", month: "long", weekday: "long" }) }),
      ]),
      el("div", { class: "tv-hero" }, [
        el("div", { class: "tv-hero-label", text: "BUGÜNKÜ CİRO" }),
        el("div", { class: "tv-hero-val num", text: money(st.rev) }),
        target > 0
          ? el("div", { class: "tv-target" }, [
              el("div", { class: "tv-bar" }, [el("div", { class: "tv-bar-fill" + (pct >= 100 ? " tv-done" : ""), style: "width:" + pct + "%" })]),
              el("div", { class: "tv-target-txt", text: "Hedef: " + money(target) + "  ·  %" + pct + (pct >= 100 ? "  🎉" : "") }),
            ])
          : el("div", { class: "tv-target-txt muted", text: "Günlük hedef belirlenmedi (Hedefler modülü)" }),
      ]),
      el("div", { class: "tv-cards" }, [
        el("div", { class: "tv-card" }, [el("div", { class: "tv-card-label", text: "🧾 Sipariş" }), el("div", { class: "tv-card-val num", text: String(st.n) })]),
        el("div", { class: "tv-card" }, [el("div", { class: "tv-card-label", text: "🛒 Sepet Ort." }), el("div", { class: "tv-card-val num", text: money(st.basket) })]),
        el("div", { class: "tv-card" }, [el("div", { class: "tv-card-label", text: "🏆 En Çok Satan" }), el("div", { class: "tv-card-val", style: "font-size:26px", text: st.top ? st.top.name : "—" }), st.top ? el("div", { class: "muted", text: st.top.qty + " adet" }) : el("span", {})]),
      ]),
    );
  }

  draw();
  const timer = setInterval(() => { if (document.body.contains(host)) draw(); else clearInterval(timer); }, 5000);
}
