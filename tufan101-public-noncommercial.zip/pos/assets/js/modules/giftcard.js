// Hediye Çeki / Hediye Kartı
// Kart: { id, code, initial, balance, active, createdTs, history:[{ts, amount, note}] }
// Kasada ödeme olarak kullanılır; bakiye düşülür ve geçmişe işlenir.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

function genCode() {
  const s = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let c = "";
  for (let i = 0; i < 4; i++) c += s[Math.floor(Math.random() * s.length)];
  const n = String(Math.floor(1000 + Math.random() * 9000));
  return "HED-" + c + "-" + n;
}

export function findGiftcard(code) {
  const q = String(code || "").trim().toUpperCase();
  if (!q) return null;
  return db.giftcards.all().find((g) => (g.code || "").toUpperCase() === q);
}

// Karttan tutar düş. Dönüş: { ok, used, remaining } veya { ok:false, error }
export function redeemGiftcard(code, amount, note) {
  const g = findGiftcard(code);
  if (!g) return { ok: false, error: "Kart bulunamadı" };
  if (!g.active) return { ok: false, error: "Kart pasif" };
  const bal = Number(g.balance) || 0;
  if (bal <= 0) return { ok: false, error: "Bakiye yok" };
  const used = Math.min(bal, Number(amount) || 0);
  g.balance = Math.round((bal - used) * 100) / 100;
  g.history = Array.isArray(g.history) ? g.history : [];
  g.history.push({ ts: Date.now(), amount: -used, note: note || "Kasada kullanıldı" });
  db.giftcards.upsert(g);
  return { ok: true, used, remaining: g.balance };
}

export function renderGiftcards(host) {
  const wrap = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Hediye Çeki"]);
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🎁 " + t("navGiftcards") }), el("div", { class: "spacer" }), addBtn]),
    wrap,
  );

  function draw() {
    clear(wrap);
    const list = db.giftcards.all().sort((a, b) => (b.createdTs || 0) - (a.createdTs || 0));
    if (!list.length) { wrap.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:16px", text: "Henüz hediye çeki yok." })])); return; }
    wrap.appendChild(el("div", { class: "camp-grid" }, list.map((g) => {
      const bal = Number(g.balance) || 0;
      return el("div", { class: "camp-card" + (bal > 0 && g.active ? " camp-on" : "") }, [
        el("div", { style: "display:flex;justify-content:space-between;align-items:center" }, [
          el("code", { style: "font-size:15px;font-weight:700;letter-spacing:1px", text: g.code }),
          el("span", { class: "pill " + (bal > 0 && g.active ? "green" : "amber"), text: g.active ? (bal > 0 ? "Aktif" : "Tükendi") : "Pasif" }),
        ]),
        el("div", { style: "display:flex;justify-content:space-between;align-items:baseline;margin-top:8px" }, [
          el("span", { class: "muted", style: "font-size:12px", text: "Bakiye" }),
          el("b", { class: "num", style: "font-size:22px", text: money(bal) }),
        ]),
        el("div", { class: "muted", style: "font-size:12px;margin-top:2px", text: "Yüklenen: " + money(g.initial || 0) }),
        el("div", { style: "display:flex;gap:8px;margin-top:12px;flex-wrap:wrap" }, [
          el("button", { class: "btn ghost tiny", onClick: () => topUp(g) }, ["➕ Yükle"]),
          el("button", { class: "btn ghost tiny", onClick: () => historyView(g) }, ["📜 Geçmiş"]),
          el("button", { class: "btn ghost tiny", onClick: () => { db.giftcards.upsert({ ...g, active: !g.active }); draw(); } }, [g.active ? "⏸ Dondur" : "▶ Aç"]),
          el("button", { class: "btn ghost tiny", onClick: () => confirmDialog("Kart silinsin mi?", () => { db.giftcards.remove(g.id); draw(); }) }, ["🗑"]),
        ]),
      ]);
    })));
  }

  function form() {
    const code = el("input", { class: "input", value: genCode(), style: "font-family:monospace;letter-spacing:1px" });
    const regen = el("button", { class: "btn ghost", type: "button", onClick: () => code.value = genCode() }, ["🎲"]);
    const amount = el("input", { class: "input num", type: "number", step: "0.01", placeholder: "Yüklenecek tutar", style: "font-size:22px;text-align:right" });
    modal({
      title: "🎁 Yeni Hediye Çeki",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Kart Kodu" }), el("div", { style: "display:flex;gap:8px" }, [code, regen])]),
        el("div", { class: "field" }, [el("label", { text: "Tutar (TL)" }), amount]),
      ]),
      actions: [
        { label: "Oluştur", kind: "success", onClick: (close) => {
          const amt = parseFloat(amount.value) || 0;
          if (amt <= 0) { toast("Tutar girin", "warn"); return; }
          if (findGiftcard(code.value)) { toast("Bu kod zaten var", "warn"); return; }
          db.giftcards.upsert({ id: uid(), code: code.value.trim().toUpperCase(), initial: amt, balance: amt, active: true, createdTs: Date.now(), history: [{ ts: Date.now(), amount: amt, note: "Kart oluşturuldu" }] });
          toast("Hediye çeki oluşturuldu 🎁", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function topUp(g) {
    const amount = el("input", { class: "input num", type: "number", step: "0.01", placeholder: "Eklenecek tutar", style: "font-size:22px;text-align:right" });
    modal({
      title: "➕ Bakiye Yükle — " + g.code,
      body: el("div", { class: "field" }, [el("label", { text: "Tutar (TL)" }), amount]),
      actions: [
        { label: "Yükle", kind: "success", onClick: (close) => {
          const amt = parseFloat(amount.value) || 0;
          if (amt <= 0) { toast("Tutar girin", "warn"); return; }
          g.balance = (Number(g.balance) || 0) + amt;
          g.initial = (Number(g.initial) || 0) + amt;
          g.history = Array.isArray(g.history) ? g.history : [];
          g.history.push({ ts: Date.now(), amount: amt, note: "Bakiye yüklendi" });
          db.giftcards.upsert(g); toast("Yüklendi", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function historyView(g) {
    const rows = (g.history || []).slice().reverse();
    modal({
      title: "📜 " + g.code + " — Geçmiş",
      body: rows.length ? el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, ["Tarih", "İşlem", "Tutar"].map((h) => el("th", { text: h })))]),
        el("tbody", {}, rows.map((h) => el("tr", {}, [
          el("td", { text: new Date(h.ts).toLocaleString("tr-TR") }),
          el("td", { text: h.note || "—" }),
          el("td", { class: "num", style: h.amount < 0 ? "color:var(--danger,#dc2626)" : "color:var(--success)", text: (h.amount > 0 ? "+" : "") + money(h.amount) }),
        ]))),
      ]) : el("p", { class: "muted", text: "Hareket yok." }),
      actions: [{ label: t("close") || "Kapat", kind: "ghost" }],
    });
  }

  draw();
}
