// TUFAN 101 — Ek modüller (nav menüdeki tüm kalemler). Hepsi core sözleşmesini kullanır.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, settings, money, uid, pendingCount, sync, postAccountMove, removeAccountMovesByRef } from "../core/store.js";
import { users, currentUser, can, saveUser, ROLE_PERMS } from "../core/auth.js";
import { drawEAN13, generateEAN13, isValidEAN13 } from "../core/barcode.js";
import { buildAccountSelect } from "./accounts.js";
import { printReceipt } from "./pos.js";

/* ============ Ortak yardımcılar ============ */
function head(title, actions = []) {
  return el("div", { class: "view-head" }, [
    el("h1", { text: title }),
    el("div", { class: "spacer" }),
    ...actions,
  ]);
}
function card(children, style = "") { return el("div", { class: "card", style }, children); }
function empty(msg) { return el("p", { class: "muted", style: "padding:18px", text: msg || t("noData") }); }

// Küçük yerel liste deposu (db'de olmayan basit kalemler için)
function LS(k) {
  return {
    all() { try { return JSON.parse(localStorage.getItem("t101_" + k)) || []; } catch { return []; } },
    save(v) { localStorage.setItem("t101_" + k, JSON.stringify(v)); },
  };
}

// Genel amaçlı CRUD tablosu (ekle / düzenle / sil)
function crud(host, title, tbl, cols) {
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form(null) }, ["+ " + t("add")]);
  clear(host).append(head(title, [addBtn]), body);

  function cell(v, c) {
    if (v == null || v === "") return "—";
    if (c.type === "money") return money(v);
    return String(v);
  }
  function draw() {
    clear(body);
    const rows = tbl.all();
    if (!rows.length) { body.appendChild(empty(t("noData"))); return; }
    body.appendChild(card([
      el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, cols.map((c) => el("th", { text: c.label })).concat(el("th", {})))]),
        el("tbody", {}, rows.map((r) => el("tr", {}, cols.map((c) => el("td", { text: cell(r[c.k], c) })).concat(
          el("td", { style: "text-align:right;white-space:nowrap" }, [
            el("button", { class: "iconbtn", title: t("edit"), onClick: () => form(r) }, ["✏"]),
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog(t("delete") + "?", () => { tbl.remove(r.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
          ])
        )))),
      ]),
    ]));
  }
  function form(r) {
    const inputs = {};
    const fields = cols.map((c) => {
      const type = (c.type === "number" || c.type === "money") ? "number" : (c.type === "date" ? "date" : "text");
      const inp = el("input", { class: "input", type, value: r ? (r[c.k] ?? "") : "", placeholder: c.label });
      if (c.type === "money" || c.type === "number") inp.step = "0.01";
      inputs[c.k] = inp;
      return el("div", { class: "field" }, [el("label", { text: c.label }), inp]);
    });
    modal({
      title, body: el("div", {}, fields),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          const row = r ? { ...r } : { id: uid() };
          cols.forEach((c) => { let v = inputs[c.k].value.trim(); if (c.type === "money" || c.type === "number") v = parseFloat(v) || 0; row[c.k] = v; });
          tbl.upsert(row); toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }
  draw();
}

// Basit yazdırma penceresi (PDF/etiket için)
function printHtml(title, innerHtml) {
  const w = window.open("", "_blank");
  if (!w) { toast("Açılır pencere engellendi", "warn"); return; }
  w.document.write('<!doctype html><html><head><meta charset="utf-8"><title>' + title +
    '</title><style>body{font-family:Inter,Arial,sans-serif;padding:24px;color:#111}h1{margin:0 0 12px}table{width:100%;border-collapse:collapse}th,td{border:1px solid #ccc;padding:8px;text-align:left}.big{font-size:42px;letter-spacing:4px;font-family:monospace}</style></head><body>' +
    innerHtml + '<script>window.onload=function(){window.print()}<\/script></body></html>');
  w.document.close();
}

/* ============ İŞLEMLER — Profesyonel Gelir / Gider ============ */
function txnPage(host, type) {
  const CATS = type === "income"
    ? ["Satış", "Hizmet", "Tahsilat", "Faiz Geliri", "Kira Geliri", "Diğer"]
    : ["Kira", "Maaş", "Fatura (Elektrik/Su/İnternet)", "Malzeme / Alım", "Vergi / SGK", "Nakliye", "Pazarlama", "Bakım / Onarım", "Diğer"];
  const METHODS = ["Nakit", "Kredi Kartı", "Havale / EFT", "Çek", "Senet", "Diğer"];
  let period = "month"; // today | week | month | all
  let search = "";

  const searchInp = el("input", { class: "input", placeholder: t("search"), style: "max-width:180px" });
  searchInp.addEventListener("input", () => { search = searchInp.value.trim().toLowerCase(); draw(); });
  const periodSel = el("select", { class: "input", style: "max-width:140px" }, [
    el("option", { value: "today", text: "Bugün" }),
    el("option", { value: "week", text: "Bu Hafta" }),
    el("option", { value: "month", text: "Bu Ay" }),
    el("option", { value: "all", text: "Tümü" }),
  ]);
  periodSel.value = "month";
  periodSel.addEventListener("change", () => { period = periodSel.value; draw(); });
  const addBtn = el("button", { class: "btn " + (type === "income" ? "success" : "danger"), onClick: () => entry() }, ["+ " + t(type)]);
  const csvBtn = el("button", { class: "btn ghost", onClick: exportCSV }, ["⬇️ CSV"]);
  const statsWrap = el("div", { class: "stat-grid" });
  const body = el("div", {});
  clear(host).append(head(type === "income" ? "💰 " + t("navIncome") : "💸 " + t("navExpense"), [searchInp, periodSel, csvBtn, addBtn]), statsWrap, body);

  function periodStart() {
    const d = new Date(); d.setHours(0, 0, 0, 0);
    if (period === "today") return d.getTime();
    if (period === "week") { const wd = (d.getDay() + 6) % 7; d.setDate(d.getDate() - wd); return d.getTime(); }
    if (period === "month") { d.setDate(1); return d.getTime(); }
    return 0;
  }
  function filtered() {
    const start = periodStart();
    return db.txns.all()
      .filter((x) => x.type === type && x.ts >= start && (!search || (x.note || "").toLowerCase().includes(search) || (x.category || "").toLowerCase().includes(search)))
      .sort((a, b) => b.ts - a.ts);
  }
  function draw() {
    const rows = filtered();
    const total = rows.reduce((a, x) => a + (Number(x.amount) || 0), 0);
    const start = periodStart();
    const incomeT = db.txns.all().filter((x) => x.type === "income" && x.ts >= start).reduce((a, x) => a + (+x.amount || 0), 0);
    const expenseT = db.txns.all().filter((x) => x.type === "expense" && x.ts >= start).reduce((a, x) => a + (+x.amount || 0), 0);
    const net = incomeT - expenseT;
    clear(statsWrap).append(
      statCard(type === "income" ? "Dönem Geliri" : "Dönem Gideri", money(total), type === "income" ? "var(--success)" : "var(--danger)"),
      statCard("İşlem Sayısı", String(rows.length), "var(--primary)"),
      statCard("Ortalama", money(rows.length ? total / rows.length : 0), "#0ea5e9"),
      statCard("Net Kâr (Dönem)", money(net), net >= 0 ? "var(--success)" : "var(--danger)"),
    );
    clear(body);
    // Kategori dağılımı
    const byCat = {};
    rows.forEach((x) => { const c = x.category || "Diğer"; byCat[c] = (byCat[c] || 0) + (+x.amount || 0); });
    const catKeys = Object.keys(byCat).sort((a, b) => byCat[b] - byCat[a]);
    if (catKeys.length) {
      const max = Math.max(...catKeys.map((k) => byCat[k]));
      body.appendChild(card([
        el("h3", { text: "📊 Kategori Dağılımı" }),
        ...catKeys.map((k) => el("div", { style: "margin:8px 0" }, [
          el("div", { style: "display:flex;justify-content:space-between;font-size:13px" }, [el("span", { text: k }), el("span", { class: "num", text: money(byCat[k]) })]),
          el("div", { style: "height:8px;background:var(--border);border-radius:4px;overflow:hidden;margin-top:3px" }, [
            el("div", { style: `height:100%;width:${Math.round(byCat[k] / max * 100)}%;background:${type === "income" ? "var(--success)" : "var(--danger)"}` }),
          ]),
        ])),
      ]));
    }
    if (!rows.length) { body.appendChild(empty()); return; }
    body.appendChild(card([
      el("table", { class: "tbl", style: "margin-top:12px" }, [
        el("thead", {}, [el("tr", {}, [el("th", { text: t("date") }), el("th", { text: "Kategori" }), el("th", { text: t("note") }), el("th", { text: "Yöntem" }), el("th", { text: t("amount") }), el("th", {})])]),
        el("tbody", {}, rows.slice(0, 200).map((x) => el("tr", {}, [
          el("td", { class: "muted", text: new Date(x.ts).toLocaleDateString("tr-TR") }),
          el("td", {}, [el("span", { class: "pill blue", text: x.category || "—" })]),
          el("td", { text: x.note || "—" }),
          el("td", { class: "muted", text: x.method || "—" }),
          el("td", { class: "num", style: "font-weight:700;color:" + (type === "income" ? "var(--success)" : "var(--danger)"), text: money(x.amount) }),
          el("td", { style: "text-align:right;white-space:nowrap" }, [
            el("button", { class: "iconbtn", title: t("edit"), onClick: () => entry(x) }, ["✏️"]),
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog(t("delete") + "?", () => { db.txns.remove(x.id); removeAccountMovesByRef(x.id); draw(); }) }, ["🗑"]),
          ]),
        ]))),
      ]),
    ]));
  }
  function entry(existing) {
    const x0 = existing || {};
    const amount = el("input", { class: "input num", type: "number", step: "0.01", value: x0.amount != null ? x0.amount : "", autofocus: true });
    const cat = el("select", { class: "input" }, CATS.map((c) => el("option", { value: c, ...(c === x0.category ? { selected: true } : {}) }, [c])));
    const method = el("select", { class: "input" }, METHODS.map((m) => el("option", { value: m, ...(m === x0.method ? { selected: true } : {}) }, [m])));
    const date = el("input", { class: "input", type: "date", value: x0.ts ? new Date(x0.ts).toISOString().slice(0, 10) : new Date().toISOString().slice(0, 10) });
    const note = el("input", { class: "input", value: x0.note || "", placeholder: t("note") });
    // Entegrasyon: bu tutar hangi Kasa/Banka hesabına işlensin?
    const acctSel = buildAccountSelect(x0.accountId);
    modal({
      title: (existing ? "✏️ " : (type === "income" ? "💰 " : "💸 ")) + (type === "income" ? t("navIncome") : t("navExpense")),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: t("amount") }), amount]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "Kategori" }), cat]),
          el("div", { class: "field" }, [el("label", { text: "Ödeme Yöntemi" }), method]),
        ]),
        el("div", { class: "field" }, [el("label", { text: (type === "income" ? "💰 Nereye girsin?" : "💸 Nereden çıksın?") + " (Kasa / Banka)" }), acctSel]),
        el("div", { class: "field" }, [el("label", { text: t("date") }), date]),
        el("div", { class: "field" }, [el("label", { text: t("note") }), note]),
      ]),
      actions: [
        { label: t("save"), kind: type === "income" ? "success" : "danger", onClick: (close) => {
          const a = parseFloat(amount.value); if (!a || a <= 0) { toast(t("amount") + "?", "warn"); return; }
          const sameDay = x0.ts && new Date(x0.ts).toISOString().slice(0, 10) === date.value;
          const ts = sameDay ? x0.ts : new Date(date.value + "T12:00:00").getTime();
          const id = x0.id || uid();
          const accountId = acctSel ? acctSel.value : "";
          db.txns.upsert({ id, type, amount: a, category: cat.value, method: method.value, note: note.value.trim(), accountId, ts });
          // Kasa/Banka hareketi: gelir → giriş, gider → çıkış (düzenlemede eskisini yenile)
          removeAccountMovesByRef(id);
          if (accountId) postAccountMove({ accountId, dir: type === "income" ? "in" : "out", amount: a, source: type, refId: id, note: [cat.value, note.value.trim()].filter(Boolean).join(" — ") });
          toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }
  function exportCSV() {
    const rows = [["Tarih", "Kategori", "Not", "Yöntem", "Tutar"], ...filtered().map((x) => [new Date(x.ts).toLocaleDateString("tr-TR"), x.category || "", x.note || "", x.method || "", x.amount || 0])];
    const csv = rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(";")).join("\n");
    const blob = new Blob(["﻿" + csv], { type: "text/csv;charset=utf-8" });
    const a = el("a", { href: URL.createObjectURL(blob), download: (type === "income" ? "gelir" : "gider") + ".csv" });
    document.body.appendChild(a); a.click(); a.remove();
  }
  draw();
}
export function renderIncome(host) { txnPage(host, "income"); }
export function renderExpense(host) { txnPage(host, "expense"); }

/* ============ BORÇLAR / ALACAKLAR ============ */
export function renderDebts(host) {
  let tab = "payable"; // payable(borç) | receivable(alacak)
  const today = new Date().toISOString().slice(0, 10);
  const remaining = (d) => Math.max(0, (+d.amount || 0) - (+d.paid || 0));
  const statusOf = (d) => {
    if (remaining(d) <= 0) return { label: "Ödendi", cls: "green" };
    if (+d.paid > 0) return { label: "Kısmi", cls: "amber" };
    if (d.dueDate && d.dueDate < today) return { label: "Gecikmiş", cls: "red" };
    return { label: "Bekliyor", cls: "blue" };
  };

  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Kayıt"]);
  const tabs = el("div", { style: "display:flex;gap:8px;margin-bottom:6px" });
  const statsWrap = el("div", { class: "stat-grid" });
  const body = el("div", {});
  clear(host).append(head("💳 " + t("navDebts"), [addBtn]), tabs, statsWrap, body);

  const tabBtn = (id, label) => el("button", { class: "btn " + (tab === id ? "primary" : "ghost"), onClick: () => { tab = id; draw(); } }, [label]);

  function draw() {
    clear(tabs).append(tabBtn("payable", "🔻 Borçlarım"), tabBtn("receivable", "🔺 Alacaklarım"));
    const all = db.debts.all();
    const payable = all.filter((d) => d.kind === "payable");
    const receivable = all.filter((d) => d.kind === "receivable");
    const sumRem = (arr) => arr.reduce((a, d) => a + remaining(d), 0);
    const overdue = all.filter((d) => remaining(d) > 0 && d.dueDate && d.dueDate < today);
    clear(statsWrap).append(
      statCard("Toplam Borç", money(sumRem(payable)), "var(--danger)"),
      statCard("Toplam Alacak", money(sumRem(receivable)), "var(--success)"),
      statCard("Net Durum", money(sumRem(receivable) - sumRem(payable)), "var(--primary)"),
      statCard("Gecikmiş", String(overdue.length), "#f59e0b"),
    );
    const rows = (tab === "payable" ? payable : receivable).sort((a, b) => (a.dueDate || "9999").localeCompare(b.dueDate || "9999"));
    clear(body);
    if (!rows.length) { body.appendChild(empty("Kayıt yok")); return; }
    body.appendChild(card([el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: tab === "payable" ? "Kime" : "Kimden" }), el("th", { text: "Tutar" }), el("th", { text: "Ödenen" }), el("th", { text: "Kalan" }), el("th", { text: "Vade" }), el("th", { text: "Durum" }), el("th", {})])]),
      el("tbody", {}, rows.map((d) => {
        const st = statusOf(d);
        return el("tr", {}, [
          el("td", { style: "font-weight:700", text: d.party || "—" }),
          el("td", { class: "num", text: money(d.amount) }),
          el("td", { class: "num muted", text: money(d.paid || 0) }),
          el("td", { class: "num", style: "font-weight:700", text: money(remaining(d)) }),
          el("td", { class: "muted", text: d.dueDate || "—" }),
          el("td", {}, [el("span", { class: "pill " + st.cls, text: st.label })]),
          el("td", { style: "text-align:right;white-space:nowrap" }, [
            remaining(d) > 0 ? el("button", { class: "btn success sm", onClick: () => pay(d) }, ["Öde"]) : null,
            el("button", { class: "iconbtn", title: t("edit"), onClick: () => form(d) }, ["✏️"]),
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog(t("delete") + "?", () => { db.debts.remove(d.id); draw(); }) }, ["🗑"]),
          ]),
        ]);
      })),
    ])]));
  }
  function pay(d) {
    const rem = remaining(d);
    const amt = el("input", { class: "input num", type: "number", step: "0.01", value: rem, autofocus: true });
    const toTxn = el("input", { type: "checkbox" }); toTxn.checked = true;
    modal({
      title: "💵 Ödeme — " + (d.party || ""),
      body: el("div", {}, [
        el("p", { class: "muted", text: "Kalan: " + money(rem) }),
        el("div", { class: "field" }, [el("label", { text: "Ödeme Tutarı" }), amt]),
        el("label", { style: "display:flex;align-items:center;gap:8px" }, [toTxn, el("span", { text: (d.kind === "payable" ? "Gider" : "Gelir") + " olarak da kaydet" })]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          const a = parseFloat(amt.value) || 0; if (a <= 0) { toast("Tutar?", "warn"); return; }
          d.paid = (+d.paid || 0) + a; db.debts.upsert(d);
          if (toTxn.checked) db.txns.upsert({ id: uid(), type: d.kind === "payable" ? "expense" : "income", amount: a, category: d.kind === "payable" ? "Borç Ödeme" : "Tahsilat", method: "Nakit", note: (d.kind === "payable" ? "Borç: " : "Alacak: ") + (d.party || ""), ts: Date.now() });
          toast("Ödeme kaydedildi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }
  function form(existing) {
    const d0 = existing || { kind: tab };
    const kind = el("select", { class: "input" }, [
      el("option", { value: "payable", text: "Borç (ben ödeyeceğim)" }),
      el("option", { value: "receivable", text: "Alacak (bana ödenecek)" }),
    ]);
    kind.value = d0.kind || tab;
    const party = el("input", { class: "input", value: d0.party || "", autofocus: true, placeholder: "Kişi / firma adı" });
    const amount = el("input", { class: "input num", type: "number", step: "0.01", value: d0.amount != null ? d0.amount : "" });
    const due = el("input", { class: "input", type: "date", value: d0.dueDate || "" });
    const note = el("input", { class: "input", value: d0.note || "", placeholder: t("note") });
    modal({
      title: existing ? "✏️ Düzenle" : "➕ Yeni Kayıt",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Tür" }), kind]),
        el("div", { class: "field" }, [el("label", { text: "Kişi / Firma" }), party]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "Tutar" }), amount]),
          el("div", { class: "field" }, [el("label", { text: "Vade Tarihi" }), due]),
        ]),
        el("div", { class: "field" }, [el("label", { text: t("note") }), note]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          const a = parseFloat(amount.value) || 0;
          if (!party.value.trim() || a <= 0) { toast("Ad ve tutar zorunlu", "warn"); return; }
          db.debts.upsert({ id: d0.id || uid(), kind: kind.value, party: party.value.trim(), amount: a, paid: d0.paid || 0, dueDate: due.value, note: note.value.trim(), ts: d0.ts || Date.now() });
          toast(t("save"), "success"); tab = kind.value; close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }
  draw();
}

/* ============ EMLAK & ARAÇLAR ============ */
export function renderPdfGen(host) {
  const title = el("input", { class: "input", placeholder: "Başlık (örn. Teklif / Fiş)" });
  const lines = el("textarea", { class: "input", rows: "8", placeholder: "Her satıra bir madde yazın…" });
  const gen = el("button", { class: "btn success", onClick: () => {
    const rows = lines.value.split(/\n/).filter((s) => s.trim());
    const html = "<h1>" + (title.value || "Belge") + "</h1><table><tbody>" +
      rows.map((r) => "<tr><td>" + r.replace(/</g, "&lt;") + "</td></tr>").join("") +
      "</tbody></table><p style='margin-top:24px'>" + (settings.get().business || "") + "</p>";
    printHtml(title.value || "Belge", html);
  } }, ["📄 " + t("printPdf")]);
  clear(host).append(head(t("navPdf")), card([
    el("div", { class: "field" }, [el("label", { text: "Başlık" }), title]),
    el("div", { class: "field" }, [el("label", { text: "İçerik" }), lines]),
    gen,
  ]));
}

/* ============ PATRON+ : Aktif Hesaplar ============ */
export function renderActiveAccounts(host) {
  const list = users();
  clear(host).append(head(t("navAccounts")), card([
    el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: t("name") }), el("th", { text: "Kullanıcı" }), el("th", { text: t("role") }), el("th", { text: "Paket" }), el("th", { text: "Durum" })])]),
      el("tbody", {}, list.map((u) => el("tr", {}, [
        el("td", { text: u.name || "—" }),
        el("td", { text: u.username || "—" }),
        el("td", {}, [el("span", { class: "pill blue", text: t(u.role) || u.role })]),
        el("td", {}, [el("span", { class: "pill " + (u.package === "premium" ? "green" : "amber"), text: u.package === "premium" ? "💎 Premium" : "🆓 Ücretsiz" })]),
        el("td", {}, [el("span", { class: "pill " + (u.active ? "green" : "red"), text: u.active ? t("online") : t("offline") })]),
      ]))),
    ]),
  ]));
}

/* ============ EK MODÜLLER ============ */
export function renderAppointments(host) {
  crud(host, t("navAppt"), db.appointments, [
    { k: "title", label: t("name") }, { k: "when", label: t("date"), type: "date" }, { k: "note", label: t("note") },
  ]);
}
export function renderProduction(host) {
  crud(host, t("navProduction"), db.productions, [
    { k: "name", label: t("name") }, { k: "qty", label: "Adet", type: "number" }, { k: "note", label: t("note") },
  ]);
}
export function renderNotifications(host) {
  crud(host, t("navNotif"), db.notifications, [
    { k: "title", label: t("name") }, { k: "body", label: t("note") },
  ]);
}
export function renderCompany(host) {
  const s = settings.get();
  const f = {};
  const fields = [
    ["business", t("business")], ["phone", t("phone")], ["address", t("address")],
    ["taxId", t("taxId")], ["instagram", t("instagram")], ["website", t("website")],
  ].map(([k, label]) => { const inp = el("input", { class: "input", value: s[k] || "", placeholder: label }); f[k] = inp; return el("div", { class: "field" }, [el("label", { text: label }), inp]); });
  const save = el("button", { class: "btn success", onClick: () => {
    const patch = {}; Object.keys(f).forEach((k) => patch[k] = f[k].value.trim());
    settings.set(patch); toast(t("save"), "success");
  } }, ["💾 " + t("save")]);
  clear(host).append(head(t("navCompany")), card([...fields, save]));
}
export function renderEinvoice(host) {
  crud(host, t("navEinvoice"), db.invoices, [
    { k: "no", label: "No" }, { k: "customer", label: t("customer") }, { k: "total", label: t("total"), type: "money" }, { k: "date", label: t("date"), type: "date" },
  ]);
}

/* ============ İŞLETME ============ */
export function renderTools(host) {
  const out = el("div", { class: "muted", style: "margin-top:10px;line-height:1.9;font-size:14px" });
  // KDV
  const kdvBase = el("input", { class: "input", type: "number", placeholder: "Tutar (KDV hariç)" });
  const kdvRate = el("input", { class: "input", type: "number", value: "20", placeholder: "KDV %" });
  const kdvBtn = el("button", { class: "btn primary", onClick: () => {
    const b = parseFloat(kdvBase.value) || 0, r = parseFloat(kdvRate.value) || 0;
    const v = b * r / 100; out.textContent = `KDV: ${money(v)}  •  Dahil: ${money(b + v)}`;
  } }, ["Hesapla"]);
  // Kâr marjı
  const cost = el("input", { class: "input", type: "number", placeholder: t("cost") });
  const sale = el("input", { class: "input", type: "number", placeholder: t("price") });
  const marginBtn = el("button", { class: "btn primary", onClick: () => {
    const c = parseFloat(cost.value) || 0, s = parseFloat(sale.value) || 0;
    const profit = s - c, margin = s ? (profit / s * 100) : 0;
    out.textContent = `Kâr: ${money(profit)}  •  Marj: %${margin.toFixed(1)}`;
  } }, ["Hesapla"]);
  // Not defteri
  const noteStore = LS("company_notes");
  const note = el("textarea", { class: "input", rows: "5", text: (noteStore.all()[0] || {}).text || "" });
  const noteBtn = el("button", { class: "btn success", onClick: () => { noteStore.save([{ text: note.value }]); toast(t("save"), "success"); } }, ["💾 Notu Kaydet"]);
  clear(host).append(head(t("navTools")),
    el("div", { class: "grid-2", style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px" }, [
      card([el("h3", { text: "🧮 KDV Hesap" }), kdvBase, kdvRate, kdvBtn]),
      card([el("h3", { text: "📈 Kâr Marjı" }), cost, sale, marginBtn]),
      card([el("h3", { text: "📝 Notlar" }), note, noteBtn]),
    ]), card([out]));
}
export function renderPcb(host) {
  const store = { all: () => db.productions.all().filter((p) => p.pcb), upsert: (r) => db.productions.upsert({ ...r, pcb: 1 }), remove: db.productions.remove };
  // Basit parça listesi (üretim tablosunu pcb etiketiyle paylaşır)
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Parça"]);
  clear(host).append(head(t("navPcb"), [addBtn]), body);
  function draw() {
    clear(body);
    const rows = store.all();
    if (!rows.length) { body.appendChild(empty("Parça yok")); return; }
    body.appendChild(card([el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: "Parça" }), el("th", { text: "Ref" }), el("th", { text: t("stock") }), el("th", {})])]),
      el("tbody", {}, rows.map((r) => el("tr", {}, [
        el("td", { text: r.name || "—" }), el("td", { text: r.ref || "—" }), el("td", { class: "num", text: r.qty || 0 }),
        el("td", { style: "text-align:right" }, [el("button", { class: "iconbtn", onClick: () => confirmDialog(t("delete") + "?", () => { store.remove(r.id); draw(); }) }, ["🗑"])]),
      ]))),
    ])]));
  }
  function form() {
    const name = el("input", { class: "input", placeholder: "Parça adı" });
    const ref = el("input", { class: "input", placeholder: "Referans" });
    const qty = el("input", { class: "input", type: "number", placeholder: t("stock") });
    modal({ title: "PCB Parça", body: el("div", {}, [name, ref, qty].map((i) => el("div", { class: "field" }, [i]))), actions: [
      { label: t("save"), kind: "success", onClick: (close) => { if (!name.value.trim()) { toast(t("name") + "?", "warn"); return; } store.upsert({ id: uid(), name: name.value.trim(), ref: ref.value.trim(), qty: parseFloat(qty.value) || 0 }); close(); draw(); } },
      { label: t("cancel"), kind: "ghost" },
    ] });
  }
  draw();
}

/* ============ SATIŞ & İŞLETME+ ============ */
export function renderCustomers(host) {
  crud(host, t("navCustomers"), db.customers, [
    { k: "name", label: t("name") }, { k: "phone", label: t("phone") }, { k: "balance", label: t("balance"), type: "money" },
  ]);
}
// Tedarikçi Cari — alış (borç) / ödeme hareketleri, bakiye, Kasa/Banka'dan ödeme
export function renderSuppliers(host) {
  const headEl = el("div", { class: "view-head" }, [
    el("h1", { text: "🚚 " + t("navSuppliers") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn success", onClick: () => editSupplier(null) }, ["+ Tedarikçi"]),
  ]);
  const body = el("div", { class: "grid", style: "grid-template-columns:1fr 1.5fr" });
  clear(host).append(headEl, body);
  const listCard = el("div", { class: "card" });
  const detailCard = el("div", { class: "card" });
  body.append(listCard, detailCard);
  let selected = null;

  const entriesOf = (sid) => db.supplierEntries.all().filter((e) => e.supplierId === sid);
  const balanceOf = (sid) => entriesOf(sid).reduce((a, e) => a + (e.type === "purchase" ? (+e.amount || 0) : -(+e.amount || 0)), 0);
  const purchasesOf = (sid) => entriesOf(sid).filter((e) => e.type === "purchase");
  const paymentsOf = (sid) => entriesOf(sid).filter((e) => e.type === "payment");
  const sumAmt = (arr) => arr.reduce((a, e) => a + (+e.amount || 0), 0);
  // Alış özeti: toplam alış/ödeme, bu ay, son alış tarihi
  function supStats(sid) {
    const P = purchasesOf(sid);
    const now = new Date();
    const mStart = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
    return {
      totalBuy: sumAmt(P), totalPay: sumAmt(paymentsOf(sid)),
      monthBuy: sumAmt(P.filter((e) => e.ts >= mStart)),
      lastBuy: P.length ? Math.max(...P.map((e) => e.ts)) : 0, count: P.length,
    };
  }
  // Vade durumu: borç>0 ve en eski alıştan bu yana termDays günü geçtiyse gecikme
  function overdueInfo(s) {
    const bal = balanceOf(s.id);
    if (bal <= 0 || !s.termDays) return null;
    const P = purchasesOf(s.id).sort((a, b) => a.ts - b.ts);
    if (!P.length) return null;
    const daysPassed = Math.floor((Date.now() - P[0].ts) / 86400000);
    const overdueBy = daysPassed - s.termDays;
    return overdueBy > 0 ? { overdue: true, overdueBy } : { overdue: false, dueIn: s.termDays - daysPassed };
  }
  // Ürün-tedarikçi bağlantısı (product.supplierId) + stok siparişi önerisi
  const linkedProducts = (sid) => db.products.all().filter((p) => p.supplierId === sid);
  const reorderList = (sid) => linkedProducts(sid).filter((p) => (Number(p.stock) || 0) <= (p.minStock ?? 5));

  function drawList() {
    clear(listCard).appendChild(el("h3", { text: "🚚 Tedarikçiler" }));
    // Toplam borç özeti
    const totalOwe = db.suppliers.all().reduce((a, s) => a + Math.max(0, balanceOf(s.id)), 0);
    listCard.appendChild(el("div", { class: "pill amber", style: "margin-bottom:8px", text: "Toplam borç: " + money(totalOwe) }));
    const ss = db.suppliers.all();
    if (!ss.length) { listCard.appendChild(empty("Henüz tedarikçi yok.")); return; }
    ss.forEach((s) => {
      const bal = balanceOf(s.id);
      listCard.appendChild(el("div", { class: "cart-row", style: "cursor:pointer", onClick: () => { selected = s.id; drawDetail(); } }, [
        el("div", { style: "flex:1" }, [
          el("div", { style: "font-weight:700", text: s.name || "—" }),
          el("div", { class: "muted", style: "font-size:12px", text: [s.taxId ? "VKN: " + s.taxId : "", s.phone].filter(Boolean).join("  •  ") }),
        ]),
        el("span", { class: "pill " + (bal > 0 ? "red" : "green"), text: money(bal) }),
      ]));
    });
  }

  function drawDetail() {
    clear(detailCard);
    if (!selected) { detailCard.appendChild(el("p", { class: "muted", text: "← Bir tedarikçi seçin" })); return; }
    const s = db.suppliers.get(selected);
    if (!s) { selected = null; return drawDetail(); }
    const bal = balanceOf(s.id);
    const entries = entriesOf(s.id).sort((a, b) => b.ts - a.ts);
    const accName = (id) => (db.accounts.get(id) || {}).name || "";
    const st = supStats(s.id);
    const od = overdueInfo(s);
    const reorder = reorderList(s.id);

    detailCard.append(
      el("div", { style: "display:flex;align-items:center;gap:10px" }, [
        el("div", { style: "flex:1" }, [
          el("h3", { style: "margin:0", text: s.name }),
          el("div", { class: "muted", style: "font-size:12px;margin-top:2px", text: [s.taxId ? "VKN: " + s.taxId : "", s.contact ? "👤 " + s.contact : "", s.phone, s.address, s.note].filter(Boolean).join("  •  ") }),
        ]),
        el("button", { class: "iconbtn", title: t("edit"), onClick: () => editSupplier(s) }, ["✏️"]),
        el("span", { class: "pill " + (bal > 0 ? "red" : "green"), text: (bal > 0 ? "Borcumuz: " : "Bakiye: ") + money(Math.abs(bal)) }),
      ])
    );

    // Vade uyarısı
    if (od && od.overdue) {
      detailCard.appendChild(el("div", { style: "background:#fee2e2;color:#b91c1c;border:1px solid #fecaca;border-radius:8px;padding:8px 10px;margin-top:10px;font-size:13px;font-weight:600", text: "⏰ Ödeme vadesi " + od.overdueBy + " gün geçti — " + money(bal) + " borç bekliyor." }));
    } else if (od && !od.overdue && od.dueIn <= 7) {
      detailCard.appendChild(el("div", { style: "background:#fef3c7;color:#92400e;border:1px solid #fde68a;border-radius:8px;padding:8px 10px;margin-top:10px;font-size:13px;font-weight:600", text: "📅 Ödeme vadesine " + od.dueIn + " gün kaldı." }));
    }

    // Özet kartları (alış geçmişi & rapor)
    const statCell = (lbl, val, cls) => el("div", { style: "flex:1;min-width:110px;background:var(--bg,rgba(0,0,0,.03));border:1px solid var(--border);border-radius:10px;padding:8px 10px" }, [
      el("div", { class: "muted", style: "font-size:11px", text: lbl }),
      el("div", { style: "font-weight:800;font-size:15px" + (cls ? ";color:" + cls : ""), text: val }),
    ]);
    detailCard.appendChild(el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin:12px 0" }, [
      statCell("Toplam Alış", money(st.totalBuy)),
      statCell("Toplam Ödeme", money(st.totalPay), "#16a34a"),
      statCell("Bu Ay Alış", money(st.monthBuy)),
      statCell("Son Alış", st.lastBuy ? new Date(st.lastBuy).toLocaleDateString("tr-TR") : "—"),
    ]));

    // Aksiyonlar
    detailCard.appendChild(el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin:10px 0" }, [
      el("button", { class: "btn danger", onClick: () => addSupEntry(s, "purchase") }, ["+ Alış (Borç)"]),
      el("button", { class: "btn success", onClick: () => addSupEntry(s, "payment") }, ["+ Ödeme"]),
      el("button", { class: "btn ghost", onClick: () => printStatement(s) }, ["🖨 Ekstre / PDF"]),
      s.phone ? el("button", { class: "btn ghost", onClick: () => whatsappStatement(s) }, ["💬 WhatsApp Ekstre"]) : null,
      el("button", { class: "btn ghost", onClick: () => openLinkProducts(s) }, ["🔗 Ürün Bağla"]),
    ].filter(Boolean)));

    // Stok siparişi önerisi (bu tedarikçiye bağlı düşük stoklu ürünler)
    if (reorder.length) {
      detailCard.appendChild(el("div", { style: "background:#fff7ed;border:1px solid #fed7aa;border-radius:10px;padding:10px 12px;margin-bottom:10px" }, [
        el("div", { style: "font-weight:700;color:#c2410c;margin-bottom:4px", text: "📦 Sipariş önerisi (düşük stok): " + reorder.length + " ürün" }),
        el("div", { style: "display:grid;gap:2px" }, reorder.map((p) => el("div", { style: "font-size:12.5px;display:flex;justify-content:space-between;gap:8px" }, [
          el("span", { text: p.name }),
          el("span", { class: "muted", text: "stok " + (Number(p.stock) || 0) + " / min " + (p.minStock ?? 5) }),
        ]))),
        s.phone ? el("button", { class: "btn ghost", style: "margin-top:8px;padding:5px 12px", onClick: () => whatsappReorder(s, reorder) }, ["💬 Sipariş mesajı gönder"]) : null,
      ].filter(Boolean)));
    }

    detailCard.append(
      el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, ["Tarih", "Tür", "Hesap", "Açıklama", "Tutar", ""].map((h) => el("th", { text: h })))]),
        el("tbody", {}, entries.length ? entries.map((e) => el("tr", {}, [
          el("td", { class: "muted", text: new Date(e.ts).toLocaleDateString("tr-TR") }),
          el("td", {}, [el("span", { class: "pill " + (e.type === "purchase" ? "red" : "green"), text: e.type === "purchase" ? "Alış" : "Ödeme" })]),
          el("td", { class: "muted", text: e.type === "payment" ? accName(e.accountId) || "—" : "—" }),
          el("td", { text: e.note || "—" }),
          el("td", { class: "num", text: money(e.amount) }),
          el("td", { style: "text-align:right" }, [
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog(t("delete") + "?", () => { db.supplierEntries.remove(e.id); removeAccountMovesByRef(e.id); drawList(); drawDetail(); }) }, ["🗑"]),
          ]),
        ])) : [el("tr", {}, [el("td", { class: "muted", text: "—" })])]),
      ])
    );
  }

  function addSupEntry(s, type) {
    const isPayment = type === "payment";
    const amount = el("input", { class: "input num", type: "number", step: "0.01", autofocus: true });
    const note = el("input", { class: "input", placeholder: isPayment ? "Ödeme açıklaması (fatura no vb.)" : "Alış açıklaması (ürün/fatura)" });
    const acctSel = isPayment ? buildAccountSelect() : null;
    modal({
      title: s.name + " — " + (isPayment ? "Ödeme" : "Alış (Borç)"),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: t("amount") }), amount]),
        isPayment ? el("div", { class: "field" }, [el("label", { text: "💸 Nereden ödensin? (Kasa / Banka)" }), acctSel]) : null,
        el("div", { class: "field" }, [el("label", { text: t("note") }), note]),
      ]),
      actions: [
        { label: t("save"), kind: isPayment ? "success" : "danger", onClick: (close) => {
          const a = parseFloat(amount.value); if (!a || a <= 0) { toast(t("amount") + "?", "warn"); return; }
          const id = uid();
          const accountId = isPayment && acctSel ? acctSel.value : "";
          db.supplierEntries.upsert({ id, supplierId: s.id, type, amount: a, note: note.value.trim(), accountId, ts: Date.now() });
          // Entegrasyon: tedarikçiye ödeme → seçilen Kasa/Banka'dan ÇIKIŞ.
          if (isPayment && accountId) {
            postAccountMove({ accountId, dir: "out", amount: a, source: "supplier", refId: id, note: note.value.trim(), party: s.name });
            toast("Ödeme " + ((db.accounts.get(accountId) || {}).name || "") + " hesabından düşüldü", "success");
          }
          close(); drawList(); drawDetail();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function editSupplier(existing) {
    const s0 = existing || {};
    const name = el("input", { class: "input", value: s0.name || "", autofocus: true, placeholder: "Tedarikçi / firma adı" });
    const taxId = el("input", { class: "input", inputmode: "numeric", value: s0.taxId || "", placeholder: "VKN / TCKN" });
    const phone = el("input", { class: "input", inputmode: "tel", value: s0.phone || "", placeholder: "Telefon" });
    const contact = el("input", { class: "input", value: s0.contact || "", placeholder: "Yetkili kişi" });
    const address = el("input", { class: "input", value: s0.address || "", placeholder: "Adres" });
    const term = el("input", { class: "input num", type: "number", inputmode: "numeric", min: "0", value: (s0.termDays ?? "") === "" ? "" : s0.termDays, placeholder: "örn. 30" });
    const note = el("input", { class: "input", value: s0.note || "", placeholder: "Not (ürün grubu vb.)" });
    modal({
      title: existing ? "Tedarikçi Düzenle" : "Yeni Tedarikçi",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Ad *" }), name]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "VKN / TCKN" }), taxId]),
          el("div", { class: "field" }, [el("label", { text: t("phone") }), phone]),
        ]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "👤 Yetkili kişi" }), contact]),
          el("div", { class: "field" }, [el("label", { text: "📅 Ödeme vadesi (gün)" }), term]),
        ]),
        el("div", { class: "field" }, [el("label", { text: "📍 Adres" }), address]),
        el("div", { class: "field" }, [el("label", { text: t("note") }), note]),
      ]),
      actions: [
        existing ? { label: "Sil", kind: "danger", onClick: (close) => { close(); confirmDialog("Tedarikçiyi sil?", () => { db.suppliers.remove(s0.id); if (selected === s0.id) selected = null; drawList(); drawDetail(); }); } } : null,
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast("Ad gerekli", "warn"); return; }
          const td = parseInt(term.value);
          const sv = db.suppliers.upsert({ id: s0.id || uid(), name: name.value.trim(), taxId: taxId.value.trim(), phone: phone.value.trim(),
            contact: contact.value.trim(), address: address.value.trim(), termDays: (td > 0 ? td : null), note: note.value.trim() });
          selected = sv.id; close(); drawList(); drawDetail();
        } },
        { label: t("cancel"), kind: "ghost" },
      ].filter(Boolean),
    });
  }

  // Ürün-tedarikçi bağlama penceresi (product.supplierId güncellenir)
  function openLinkProducts(s) {
    const all = db.products.all().slice().sort((a, b) => String(a.name || "").localeCompare(String(b.name || ""), "tr"));
    const search = el("input", { class: "input", placeholder: "🔎 Ürün ara…" });
    const listBox = el("div", { style: "display:grid;gap:4px;max-height:340px;overflow:auto;margin-top:8px" });
    function paint(q) {
      clear(listBox);
      const f = (q || "").trim().toLowerCase();
      const rows = all.filter((p) => !f || String(p.name || "").toLowerCase().includes(f));
      if (!rows.length) { listBox.appendChild(el("p", { class: "muted", text: "Ürün yok. Önce Stok'tan ürün ekleyin." })); return; }
      rows.forEach((p) => {
        const cb = el("input", { type: "checkbox" }); cb.checked = p.supplierId === s.id;
        const other = p.supplierId && p.supplierId !== s.id;
        cb.addEventListener("change", () => { db.products.upsert({ id: p.id, supplierId: cb.checked ? s.id : "" }); });
        listBox.appendChild(el("label", { style: "display:flex;align-items:center;gap:8px;padding:5px 6px;border:1px solid var(--border);border-radius:8px" }, [
          cb, el("span", { style: "flex:1", text: p.name }),
          other ? el("span", { class: "muted", style: "font-size:11px", text: "(başka tedarikçide)" }) : null,
          el("span", { class: "muted", style: "font-size:11px", text: "stok " + (Number(p.stock) || 0) }),
        ].filter(Boolean)));
      });
    }
    search.addEventListener("input", () => paint(search.value));
    paint("");
    modal({
      title: s.name + " — Ürün Bağla",
      body: el("div", {}, [
        el("p", { class: "muted", style: "font-size:12px", text: "Bu tedarikçiden aldığınız ürünleri işaretleyin. Stok azaldığında sipariş önerisinde görünürler." }),
        search, listBox,
      ]),
      actions: [{ label: "Kapat", kind: "success", onClick: (close) => { close(); drawDetail(); } }],
    });
  }

  // Tedarikçi hesap ekstresi — yazdır / PDF
  function printStatement(s) {
    const rows = entriesOf(s.id).slice().sort((a, b) => a.ts - b.ts);
    const bal = balanceOf(s.id); const st = supStats(s.id);
    const esc = (x) => String(x == null ? "" : x).replace(/[<>&]/g, (c) => ({ "<": "&lt;", ">": "&gt;", "&": "&amp;" }[c]));
    let running = 0;
    const body = rows.map((e) => {
      running += (e.type === "purchase" ? (+e.amount || 0) : -(+e.amount || 0));
      return "<tr><td>" + new Date(e.ts).toLocaleDateString("tr-TR") + "</td><td>" + (e.type === "purchase" ? "Alış" : "Ödeme") + "</td><td>" + esc(e.note) + '</td><td class="r">' + (e.type === "purchase" ? money(e.amount) : "—") + '</td><td class="r">' + (e.type === "payment" ? money(e.amount) : "—") + '</td><td class="r">' + money(running) + "</td></tr>";
    }).join("") || '<tr><td colspan="6" style="text-align:center;color:#888">Hareket yok</td></tr>';
    const html =
      "<style>table{width:100%;border-collapse:collapse;font-size:13px}th,td{border:1px solid #ddd;padding:6px 8px}.r{text-align:right}th{background:#f3f4f6;text-align:left}</style>" +
      '<h2 style="margin:0 0 4px">Tedarikçi Hesap Ekstresi</h2>' +
      '<div style="margin-bottom:10px;color:#444"><b>' + esc(s.name) + "</b>" + (s.taxId ? " • VKN: " + esc(s.taxId) : "") + (s.phone ? " • " + esc(s.phone) : "") + "<br>Tarih: " + new Date().toLocaleDateString("tr-TR") + "</div>" +
      '<table><thead><tr><th>Tarih</th><th>Tür</th><th>Açıklama</th><th class="r">Alış</th><th class="r">Ödeme</th><th class="r">Bakiye</th></tr></thead><tbody>' + body + "</tbody></table>" +
      '<div style="margin-top:12px;font-size:14px;text-align:right">Toplam Alış: <b>' + money(st.totalBuy) + "</b> &nbsp;•&nbsp; Toplam Ödeme: <b>" + money(st.totalPay) + "</b><br>" +
      '<span style="font-size:16px">' + (bal > 0 ? "Kalan Borç" : "Bakiye") + ": <b>" + money(Math.abs(bal)) + "</b></span></div>";
    printHtml("Ekstre - " + (s.name || ""), html);
  }

  // WhatsApp ile hesap özeti / sipariş mesajı
  function whatsappStatement(s) {
    const num = String(s.phone || "").replace(/\D/g, "");
    if (!num) { toast("Telefon yok", "warn"); return; }
    const bal = balanceOf(s.id); const st = supStats(s.id);
    const msg = "*" + s.name + "* hesap özeti\nToplam Alış: " + money(st.totalBuy) + "\nToplam Ödeme: " + money(st.totalPay) + "\n" + (bal > 0 ? "Kalan Borç" : "Bakiye") + ": " + money(Math.abs(bal));
    window.open("https://wa.me/" + num + "?text=" + encodeURIComponent(msg), "_blank", "noopener");
  }
  function whatsappReorder(s, list) {
    const num = String(s.phone || "").replace(/\D/g, "");
    if (!num) { toast("Telefon yok", "warn"); return; }
    const lines = list.map((p) => "• " + p.name + " (stok " + (Number(p.stock) || 0) + ")").join("\n");
    const msg = "Merhaba, aşağıdaki ürünler için sipariş vermek istiyoruz:\n" + lines;
    window.open("https://wa.me/" + num + "?text=" + encodeURIComponent(msg), "_blank", "noopener");
  }

  drawList(); drawDetail();
}
// mod-C Şubeler — EN FAZLA 2 şube. Google Haritalar konumu, çalışan sayısı,
// şube kullanıcısı oluşturma, aktif şube seçimi ve şube bazlı satış özeti.
const MAX_BRANCHES = 2;
export function renderBranches(host) {
  const wrap = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => branchForm(null) }, ["+ Şube Ekle"]);
  clear(host).append(head("🏢 " + t("navBranches"), [addBtn]), wrap);

  function activeBranchId() { return settings.get().activeBranch || ""; }
  function setActive(id) { settings.set({ activeBranch: id }); toast("Aktif şube seçildi", "success"); draw(); }

  // Belirli şubenin bugünkü satış özeti (satışlar branchId ile etiketlenir).
  function branchSalesToday(id) {
    const start = new Date(); start.setHours(0, 0, 0, 0);
    const from = start.getTime();
    const sales = db.sales.all().filter((s) => !s.void && s.ts >= from && (s.branchId || "") === id);
    return { count: sales.length, total: sales.reduce((a, s) => a + (Number(s.total) || 0), 0) };
  }

  function mapsHref(b) {
    if (b.mapsUrl) return b.mapsUrl;
    if (b.lat && b.lng) return "https://www.google.com/maps/search/?api=1&query=" + b.lat + "," + b.lng;
    if (b.address) return "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(b.address);
    return "";
  }

  function draw() {
    clear(wrap);
    const list = db.branches.all();
    if (!list.length) {
      wrap.appendChild(card([empty("Henüz şube yok. En fazla " + MAX_BRANCHES + " şube ekleyebilirsiniz.")]));
      return;
    }
    if (!activeBranchId() && list[0]) settings.set({ activeBranch: list[0].id });

    const grid = el("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px" });
    list.forEach((b) => {
      const isActive = activeBranchId() === b.id;
      const sales = branchSalesToday(b.id);
      const branchUsers = users().filter((u) => u.branchId === b.id);
      const href = mapsHref(b);
      grid.appendChild(el("div", { class: "card branch-card" + (isActive ? " branch-active" : "") }, [
        el("div", { style: "display:flex;align-items:center;gap:10px" }, [
          el("span", { style: "font-size:26px", text: "🏪" }),
          el("div", { style: "flex:1;min-width:0" }, [
            el("div", { style: "font-weight:800;font-size:17px", text: b.name || "Şube" }),
            b.address ? el("div", { class: "muted", style: "font-size:13px", text: b.address }) : null,
          ]),
          isActive ? el("span", { class: "pill green", text: "● Aktif" }) : el("button", { class: "btn ghost tiny", onClick: () => setActive(b.id) }, ["Aktif Yap"]),
        ]),
        el("div", { style: "display:flex;gap:10px;flex-wrap:wrap;margin-top:12px" }, [
          statBox("👥", "Çalışan", String(b.employeeCount || branchUsers.length || 0)),
          statBox("🛒", "Bugün Satış", String(sales.count)),
          statBox("💰", "Bugün Ciro", money(sales.total)),
        ]),
        el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:12px" }, [
          href ? el("a", { class: "btn ghost tiny", href, target: "_blank", rel: "noopener" }, ["📍 Haritada Aç"]) : null,
          b.phone ? el("a", { class: "btn ghost tiny", href: "tel:" + b.phone }, ["📞 " + b.phone]) : null,
          el("button", { class: "btn ghost tiny", onClick: () => branchUserForm(b) }, ["👤 Şube Kullanıcısı"]),
          el("button", { class: "btn ghost tiny", onClick: () => branchForm(b) }, ["✏ Düzenle"]),
          el("button", { class: "btn ghost tiny", onClick: () => confirmDialog("Şube silinsin mi?", () => { db.branches.remove(b.id); if (activeBranchId() === b.id) settings.set({ activeBranch: "" }); toast("Şube silindi", "warn"); draw(); }) }, ["🗑 Sil"]),
        ]),
        branchUsers.length ? el("div", { class: "muted", style: "font-size:12px;margin-top:8px", text: "Şube kullanıcıları: " + branchUsers.map((u) => u.name).join(", ") }) : null,
      ]));
    });
    wrap.appendChild(grid);
    wrap.appendChild(card([
      el("p", { class: "muted", style: "margin:0;font-size:13px", text: "ℹ️ Aktif şubede yapılan satışlar o şubeye işlenir; her şubenin bugünkü satış/cirosu yukarıda görünür. Barkod cihazı (el terminali/USB okuyucu) Hızlı Satış ve Garson ekranındaki arama kutusuna otomatik yazar — ayrı kurulum gerekmez." }),
    ]));
  }

  function statBox(icon, label, val) {
    return el("div", { style: "flex:1;min-width:80px;text-align:center;padding:8px;border:1px solid var(--border);border-radius:10px" }, [
      el("div", { style: "font-size:18px", text: icon }),
      el("div", { class: "num", style: "font-weight:800;font-size:16px", text: val }),
      el("div", { class: "muted", style: "font-size:11px", text: label }),
    ]);
  }

  function branchForm(b) {
    const isNew = !b;
    if (isNew && db.branches.all().length >= MAX_BRANCHES) {
      toast("En fazla " + MAX_BRANCHES + " şube ekleyebilirsiniz.", "warn");
      return;
    }
    b = b || { id: uid() };
    const name = el("input", { class: "input", value: b.name || "", placeholder: "Şube adı (örn. Merkez)" });
    const address = el("input", { class: "input", value: b.address || "", placeholder: "Açık adres" });
    const phone = el("input", { class: "input", inputmode: "tel", value: b.phone || "", placeholder: "Telefon" });
    const mapsUrl = el("input", { class: "input", value: b.mapsUrl || "", placeholder: "Google Haritalar bağlantısı (opsiyonel)" });
    const emp = el("input", { class: "input", type: "number", min: "0", value: b.employeeCount != null ? String(b.employeeCount) : "", placeholder: "Çalışan sayısı" });
    modal({
      title: isNew ? "Şube Ekle" : "Şube Düzenle",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "🏪 Şube Adı" }), name]),
        el("div", { class: "field" }, [el("label", { text: "📍 Adres" }), address]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "📞 Telefon" }), phone]),
          el("div", { class: "field" }, [el("label", { text: "👥 Çalışan Sayısı" }), emp]),
        ]),
        el("div", { class: "field" }, [el("label", { text: "🗺️ Google Haritalar Bağlantısı" }), mapsUrl, el("div", { class: "muted", style: "font-size:12px;margin-top:2px", text: "Google Haritalar'da şubenizi bulun → Paylaş → bağlantıyı buraya yapıştırın. Boşsa adrese göre harita açılır." })]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast("Şube adı gerekli", "warn"); return; }
          db.branches.upsert({ ...b, name: name.value.trim(), address: address.value.trim(), phone: phone.value.trim(), mapsUrl: mapsUrl.value.trim(), employeeCount: parseInt(emp.value, 10) || 0 });
          toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  // Şube için kullanıcı (kasiyer) oluştur — bu kullanıcı o şubeye bağlanır.
  function branchUserForm(b) {
    const name = el("input", { class: "input", placeholder: "Ad Soyad" });
    const username = el("input", { class: "input", placeholder: "Kullanıcı adı", autocomplete: "off" });
    const password = el("input", { class: "input", type: "text", placeholder: "Şifre", autocomplete: "off" });
    const roleSel = el("select", { class: "input" }, [
      el("option", { value: "cashier", selected: true }, ["Kasiyer"]),
      el("option", { value: "manager" }, ["Müdür"]),
      el("option", { value: "waiter" }, ["Garson"]),
    ]);
    modal({
      title: "👤 " + (b.name || "Şube") + " — Kullanıcı Oluştur",
      body: el("div", {}, [
        el("p", { class: "muted", style: "margin:0 0 8px;font-size:13px", text: "Bu kullanıcı seçilen şubeye bağlanır ve giriş yaptığında bu şubede işlem yapar." }),
        el("div", { class: "field" }, [el("label", { text: "Ad" }), name]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "Kullanıcı adı" }), username]),
          el("div", { class: "field" }, [el("label", { text: "Rol" }), roleSel]),
        ]),
        el("div", { class: "field" }, [el("label", { text: "Şifre" }), password]),
      ]),
      actions: [
        { label: "Oluştur", kind: "success", onClick: (close) => {
          if (!name.value.trim() || !username.value.trim() || !password.value) { toast("Ad, kullanıcı adı ve şifre gerekli", "warn"); return; }
          const role = roleSel.value;
          saveUser({ name: name.value.trim(), username: username.value.trim(), password: password.value, role, perms: { ...(ROLE_PERMS[role] || ROLE_PERMS.cashier) }, active: true, branchId: b.id });
          toast("Şube kullanıcısı oluşturuldu ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}
export function renderBarcode(host) {
  const gs1On = !!settings.get().gs1Enabled;
  const prods = db.products.all();
  const sel = el("select", { class: "input" }, [el("option", { value: "", text: "— Ürün seçin —" }), ...prods.map((p) => el("option", { value: p.id, text: (p.name || "?") + " • " + (p.gtin || p.barcode || p.id) }))]);
  const canvas = el("canvas", { style: "max-width:100%" });
  const label = el("div", { style: "margin-top:6px" });
  const preview = el("div", { style: "margin-top:14px;text-align:center" }, [label, canvas]);
  let current = null;
  // Etkin kod: GS1 açıksa ve resmi geçerli GTIN varsa onu, yoksa dahili barkodu kullan
  function effectiveCode(p) {
    const gtin = (p.gtin || "").replace(/\D/g, "");
    if (gs1On && isValidEAN13(gtin)) return { code: gtin, official: true };
    let code = (p.barcode || "").replace(/\D/g, "");
    if (!isValidEAN13(code)) { code = generateEAN13(); p.barcode = code; db.products.upsert(p); }
    return { code, official: false };
  }
  function drawPrev() {
    const p = prods.find((x) => x.id === sel.value);
    current = p;
    clear(label);
    if (!p) { canvas.style.display = "none"; return; }
    const { code, official } = effectiveCode(p);
    label.append(
      el("div", { style: "font-weight:700", text: p.name || "" }),
      el("div", { style: "font-size:18px;font-weight:800", text: money(p.price || p.salePrice || 0) }),
      el("div", { class: "pill " + (official ? "green" : "slate"), style: "margin-top:4px", text: official ? "🌍 Resmi GS1 barkodu (GTIN)" : "🏷️ Dahili barkod" }),
    );
    canvas.style.display = "";
    drawEAN13(canvas, code, { unit: 2, height: 70 });
  }
  sel.addEventListener("change", drawPrev);
  const genBtn = el("button", { class: "btn ghost", style: "margin-top:12px", onClick: () => {
    if (!current) { toast("Önce ürün seçin", "warn"); return; }
    current.barcode = generateEAN13(); db.products.upsert(current); drawPrev();
    toast("Yeni dahili barkod üretildi", "success");
  } }, ["🎲 Dahili Barkod Üret"]);
  const printBtn = el("button", { class: "btn primary", style: "margin-top:12px;margin-left:8px", onClick: () => {
    if (!current) { toast("Önce ürün seçin", "warn"); return; }
    const img = canvas.toDataURL("image/png");
    printHtml("Etiket", `<div style='text-align:center'><div style='font-weight:700'>${current.name || ""}</div><div style='font-size:18px;font-weight:800'>${money(current.price || 0)}</div><img src='${img}' style='margin-top:6px'></div>`);
  } }, ["🏷️ Etiket Yazdır"]);
  const note = el("p", { class: "muted", style: "font-size:13px;margin-top:12px" },
    [gs1On
      ? "GS1 açık: Resmi EAN/GTIN girilmiş ürünlerde o kod kullanılır (market/perakende satışı için). Aksi halde dahili barkod üretilir. Ürünün resmi kodunu Stok → ürün düzenle → GS1 alanından girin."
      : "Şu an dahili barkod modu. Resmi GS1 barkodu kullanmak isterseniz Ayarlar → 'GS1 Barkodu'nu açın; ardından ürünlere EAN/GTIN girebilirsiniz."]);
  clear(host).append(head("🏷️ " + t("navBarcode")), card([sel, preview, el("div", {}, [genBtn, printBtn]), note]));
}
export function renderReportXls(host) {
  function csv(rows) { return rows.map((r) => r.map((c) => '"' + String(c == null ? "" : c).replace(/"/g, '""') + '"').join(",")).join("\n"); }
  function download(name, rows) {
    const blob = new Blob(["﻿" + csv(rows)], { type: "text/csv;charset=utf-8" });
    const a = el("a", { href: URL.createObjectURL(blob), download: name }); document.body.appendChild(a); a.click(); a.remove();
  }
  const btns = [
    el("button", { class: "btn primary", onClick: () => download("urunler.csv", [["Ad", "Barkod", "Fiyat", "Stok"], ...db.products.all().map((p) => [p.name, p.barcode || "", p.price || p.salePrice || 0, p.stock || 0])]) }, ["📦 Ürünler CSV"]),
    el("button", { class: "btn primary", onClick: () => download("satislar.csv", [["Tarih", "Toplam"], ...db.sales.all().map((s) => [new Date(s.ts).toLocaleString("tr-TR"), s.total || 0])]) }, ["🛒 Satışlar CSV"]),
    el("button", { class: "btn primary", onClick: () => download("gelir_gider.csv", [["Tarih", "Tür", "Tutar", "Not"], ...db.txns.all().map((x) => [new Date(x.ts).toLocaleString("tr-TR"), x.type, x.amount, x.note || ""])]) }, ["💰 Gelir/Gider CSV"]),
  ];
  clear(host).append(head(t("navReportXls")), card([el("p", { class: "muted", text: "Verileri Excel'de açılabilir CSV olarak indir." }), el("div", { style: "display:flex;gap:10px;flex-wrap:wrap;margin-top:10px" }, btns)]));
}

/* ============ ANALİZ & ARAÇLAR+ ============ */
export function renderCharts(host) {
  const days = [];
  for (let i = 6; i >= 0; i--) { const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i); days.push(d); }
  const sales = db.sales.all();
  const data = days.map((d) => {
    const next = d.getTime() + 86400000;
    const tot = sales.filter((s) => s.ts >= d.getTime() && s.ts < next && !s.void).reduce((a, s) => a + (Number(s.total) || 0), 0);
    return { label: d.toLocaleDateString("tr-TR", { day: "2-digit", month: "2-digit" }), val: tot };
  });
  const max = Math.max(1, ...data.map((x) => x.val));
  const bars = el("div", { style: "display:flex;align-items:flex-end;gap:10px;height:220px;padding:12px 0" },
    data.map((x) => el("div", { style: "flex:1;text-align:center" }, [
      el("div", { style: `background:var(--primary);border-radius:6px 6px 0 0;height:${Math.round(x.val / max * 180)}px;min-height:2px` }),
      el("div", { class: "muted", style: "font-size:11px;margin-top:6px", text: x.label }),
      el("div", { style: "font-size:11px", text: money(x.val) }),
    ])));
  clear(host).append(head(t("navCharts")), card([el("h3", { text: "📈 Son 7 Gün Ciro" }), bars]));
}
export function renderCurrency(host) {
  const s = settings.get();
  const rates = s.rates || { USD: 34, EUR: 37, GBP: 43 };
  const inputs = {};
  const rateBox = el("div", {});
  const updated = el("div", { class: "muted", style: "font-size:12px;margin-top:8px", text: s.ratesUpdated ? "Son güncelleme: " + new Date(s.ratesUpdated).toLocaleString("tr-TR") : "Kaydedilmiş kur yok" });
  const cur = el("select", { class: "input" });

  function buildFields(r) {
    clear(rateBox); clear(cur);
    Object.keys(r).forEach((k) => {
      const inp = el("input", { class: "input", type: "number", step: "0.0001", value: r[k] });
      inputs[k] = inp;
      rateBox.appendChild(el("div", { class: "field" }, [el("label", { text: "1 " + k + " = ? ₺" }), inp]));
      cur.appendChild(el("option", { value: k, text: k }));
    });
  }
  buildFields(rates);

  const fetchBtn = el("button", { class: "btn primary", onClick: async () => {
    fetchBtn.textContent = "⏳ Çekiliyor…"; fetchBtn.disabled = true;
    try {
      const res = await fetch("https://open.er-api.com/v6/latest/USD");
      const j = await res.json();
      if (!j || !j.rates || !j.rates.TRY) throw 0;
      const tryPerUsd = j.rates.TRY;
      const nr = {};
      Object.keys(inputs).forEach((k) => { const perUsd = k === "USD" ? 1 : j.rates[k]; if (perUsd) nr[k] = +(tryPerUsd / perUsd).toFixed(4); });
      buildFields(nr);
      settings.set({ rates: nr, ratesUpdated: Date.now() });
      updated.textContent = "Son güncelleme: " + new Date().toLocaleString("tr-TR");
      toast("Canlı kurlar çekildi ✔", "success");
    } catch { toast("Kur çekilemedi (çevrimdışı olabilir)", "error"); }
    fetchBtn.textContent = "🔄 Canlı Kur Çek"; fetchBtn.disabled = false;
  } }, ["🔄 Canlı Kur Çek"]);
  const saveR = el("button", { class: "btn success", onClick: () => { const nr = {}; Object.keys(inputs).forEach((k) => nr[k] = parseFloat(inputs[k].value) || 0); settings.set({ rates: nr, ratesUpdated: Date.now() }); updated.textContent = "Son güncelleme: " + new Date().toLocaleString("tr-TR"); toast(t("save"), "success"); } }, ["💾 Kaydet"]);

  const amount = el("input", { class: "input num", type: "number", placeholder: "Tutar" });
  const dir = el("select", { class: "input" }, [el("option", { value: "toTry", text: "→ ₺" }), el("option", { value: "fromTry", text: "₺ →" })]);
  const out = el("div", { class: "value num", style: "font-size:22px;margin-top:8px" });
  const calc = el("button", { class: "btn primary", onClick: () => {
    const a = parseFloat(amount.value) || 0; const r = parseFloat(inputs[cur.value].value) || 1;
    out.textContent = dir.value === "toTry" ? money(a * r) : ((a / r).toFixed(2) + " " + cur.value);
  } }, ["Çevir"]);

  clear(host).append(head(t("navCurrency")),
    el("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:16px" }, [
      card([el("h3", { text: "💱 Kurlar (₺ karşılığı)" }), rateBox, el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:8px" }, [fetchBtn, saveR]), updated]),
      card([el("h3", { text: "🔄 Çevirici" }), amount, el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:8px" }, [cur, dir]), el("div", { style: "margin-top:8px" }, [calc]), out]),
    ]));
}
export function renderExcelImport(host) {
  const ta = el("textarea", { class: "input", rows: "8", placeholder: "Her satır: Ad,Barkod,Fiyat,Stok\nÖrn: Ekmek,8690001,15,120" });
  const imp = el("button", { class: "btn success", onClick: () => {
    const lines = ta.value.split(/\n/).map((l) => l.trim()).filter(Boolean);
    let n = 0;
    lines.forEach((l) => {
      const [name, barcode, price, stock] = l.split(/[,;\t]/).map((x) => (x || "").trim());
      if (!name) return;
      db.products.upsert({ id: uid(), name, barcode: barcode || "", price: parseFloat(price) || 0, stock: parseFloat(stock) || 0, active: true });
      n++;
    });
    toast(n + " ürün eklendi", "success"); ta.value = "";
  } }, ["📥 İçe Aktar"]);
  clear(host).append(head(t("navExcel")), card([el("p", { class: "muted", text: "Excel/CSV satırlarını yapıştırın (Ad,Barkod,Fiyat,Stok)." }), ta, imp]));
}

/* ============ GELİŞMİŞ MODÜLLER+ ============ */
export function renderSmartOrder(host) {
  const th = 5;
  const low = db.products.all().filter((p) => (Number(p.stock) || 0) <= th);
  clear(host).append(head(t("navSmartOrder")), card(
    !low.length ? [empty("Kritik stok yok 👍")] :
    [el("p", { class: "muted", text: "Kritik stoktaki ürünler için önerilen sipariş:" }),
     el("table", { class: "tbl", style: "margin-top:10px" }, [
       el("thead", {}, [el("tr", {}, [el("th", { text: t("name") }), el("th", { text: t("stock") }), el("th", { text: "Önerilen" })])]),
       el("tbody", {}, low.map((p) => el("tr", {}, [
         el("td", { text: p.name || "—" }), el("td", { class: "num", text: p.stock || 0 }),
         el("td", { class: "num", text: Math.max(10, (th - (Number(p.stock) || 0)) + 20) }),
       ]))),
     ])]
  ));
}
export function renderRecipeRoll(host) {
  const prods = db.products.all();
  const sel = el("select", { class: "input" }, [el("option", { value: "", text: "— Ürün seç —" }), ...prods.map((p) => el("option", { value: p.id, text: p.name }))]);
  const qty = el("input", { class: "input", type: "number", placeholder: "Fire adedi" });
  const reason = el("input", { class: "input", placeholder: "Sebep (kırık, bozuk…)" });
  const save = el("button", { class: "btn danger", onClick: () => {
    const p = prods.find((x) => x.id === sel.value); const q = parseFloat(qty.value) || 0;
    if (!p || q <= 0) { toast("Ürün ve adet girin", "warn"); return; }
    db.products.upsert({ ...p, stock: Math.max(0, (Number(p.stock) || 0) - q) });
    const log = LS("waste"); const arr = log.all(); arr.unshift({ name: p.name, qty: q, reason: reason.value, ts: Date.now() }); log.save(arr);
    toast("Fire kaydedildi, stok düşüldü", "success"); qty.value = ""; reason.value = ""; draw();
  } }, ["🧪 Fire Kaydet"]);
  const list = el("div", {});
  function draw() { const arr = LS("waste").all(); clear(list); if (!arr.length) { list.appendChild(empty()); return; } list.appendChild(el("table", { class: "tbl", style: "margin-top:12px" }, [el("thead", {}, [el("tr", {}, [el("th", { text: t("date") }), el("th", { text: t("name") }), el("th", { text: "Adet" }), el("th", { text: "Sebep" })])]), el("tbody", {}, arr.slice(0, 50).map((w) => el("tr", {}, [el("td", { class: "muted", text: new Date(w.ts).toLocaleString("tr-TR") }), el("td", { text: w.name }), el("td", { class: "num", text: w.qty }), el("td", { text: w.reason || "—" })])))])); }
  clear(host).append(head(t("navRecipe")), card([sel, qty, reason, save]), card([list]));
  draw();
}
// mod-E Kurye Yönetimi (Getir seviyesi) — durum aşamaları, kurye ataması,
// müşteri telefonu, harita ve tahsilat özeti. Kart tabanlı profesyonel panel.
const COURIER_STAGES = [
  { key: "hazirlaniyor", label: "Hazırlanıyor", icon: "👨‍🍳", pill: "amber" },
  { key: "yolda",        label: "Yola Çıktı",   icon: "🛵", pill: "blue" },
  { key: "teslim",       label: "Teslim Edildi", icon: "✅", pill: "green" },
];
// Eski kayıtlarla uyum: status yoksa done alanından türet.
function courierStatus(r) { return r.status || (r.done ? "teslim" : "hazirlaniyor"); }
function stageInfo(key) { return COURIER_STAGES.find((s) => s.key === key) || COURIER_STAGES[0]; }

export function renderCourier(host) {
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Teslimat"]);
  clear(host).append(head("🛵 " + t("navCourier"), [addBtn]), body);
  let filter = "aktif"; // aktif | teslim | all

  const payLabel = (r) => {
    const m = r.payMethod === "pos" ? "💳 POS Cihazı" : r.payMethod === "cash" ? "💵 Nakit" : r.payMethod === "paid" ? "✔ Ödendi" : "—";
    const amt = Number(r.payAmount) > 0 ? " " + money(r.payAmount) : "";
    return m + amt;
  };
  function couriers() { return users().filter((u) => u.role === "courier"); }
  function courierName(id) { const u = users().find((x) => x.id === id); return u ? u.name : ""; }

  // Durumu bir sonraki aşamaya ilerlet (Getir akışı).
  function advance(r) {
    const idx = COURIER_STAGES.findIndex((s) => s.key === courierStatus(r));
    const next = COURIER_STAGES[Math.min(idx + 1, COURIER_STAGES.length - 1)];
    db.couriers.upsert({ ...r, status: next.key, done: next.key === "teslim", ["ts_" + next.key]: Date.now() });
    draw();
  }

  function draw() {
    clear(body);
    const all = db.couriers.all().slice().sort((a, b) => {
      const rank = (x) => COURIER_STAGES.findIndex((s) => s.key === courierStatus(x));
      return rank(a) - rank(b);
    });
    const pend = all.filter((r) => courierStatus(r) !== "teslim");
    const cashDue = pend.filter((r) => r.payMethod === "cash").reduce((a, r) => a + (Number(r.payAmount) || 0), 0);
    const posDue = pend.filter((r) => r.payMethod === "pos").reduce((a, r) => a + (Number(r.payAmount) || 0), 0);

    // ---- Özet kartları ----
    body.appendChild(card([
      el("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px" }, [
        el("div", { class: "stat", style: "padding:10px;border:1px solid var(--border);border-radius:12px" }, [el("div", { class: "muted", style: "font-size:12px", text: "🛵 Aktif Teslimat" }), el("div", { style: "font-size:20px;font-weight:800", text: String(pend.length) })]),
        el("div", { class: "stat", style: "padding:10px;border:1px solid var(--border);border-radius:12px" }, [el("div", { class: "muted", style: "font-size:12px", text: "💵 Nakit Tahsilat" }), el("div", { style: "font-size:20px;font-weight:800", text: money(cashDue) })]),
        el("div", { class: "stat", style: "padding:10px;border:1px solid var(--border);border-radius:12px" }, [el("div", { class: "muted", style: "font-size:12px", text: "💳 POS Tahsilat" }), el("div", { style: "font-size:20px;font-weight:800", text: money(posDue) })]),
        el("div", { class: "stat", style: "padding:10px;border:1px solid var(--border);border-radius:12px" }, [el("div", { class: "muted", style: "font-size:12px", text: "👤 Kurye Sayısı" }), el("div", { style: "font-size:20px;font-weight:800", text: String(couriers().length) })]),
      ]),
    ]));

    // ---- Filtre sekmeleri ----
    const tabs = el("div", { style: "display:flex;gap:8px;margin:12px 0;flex-wrap:wrap" }, [
      ["aktif", "🛵 Aktif"], ["teslim", "✅ Teslim Edilen"], ["all", "Tümü"],
    ].map(([k, lbl]) => el("button", { class: "btn " + (filter === k ? "" : "ghost") + " tiny", onClick: () => { filter = k; draw(); } }, [lbl])));
    body.appendChild(tabs);

    const rows = all.filter((r) => filter === "all" ? true : filter === "teslim" ? courierStatus(r) === "teslim" : courierStatus(r) !== "teslim");
    if (!rows.length) { body.appendChild(empty("Bu görünümde teslimat yok.")); return; }

    // ---- Teslimat kartları ----
    const grid = el("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:14px" });
    rows.forEach((r) => {
      const st = courierStatus(r);
      const info = stageInfo(st);
      const cName = courierName(r.courierId);
      const mapHref = "https://www.google.com/maps/search/?api=1&query=" + encodeURIComponent(r.address || "");
      // Aşama ilerleme çubuğu
      const stepIdx = COURIER_STAGES.findIndex((s) => s.key === st);
      const steps = el("div", { class: "courier-steps" }, COURIER_STAGES.map((s, i) =>
        el("div", { class: "courier-step" + (i <= stepIdx ? " done" : "") }, [
          el("span", { class: "courier-step-dot", text: s.icon }),
          el("span", { class: "courier-step-lbl", text: s.label }),
        ])
      ));
      grid.appendChild(el("div", { class: "card courier-card" }, [
        el("div", { style: "display:flex;align-items:center;gap:10px" }, [
          el("div", { style: "flex:1;min-width:0" }, [
            el("div", { style: "font-weight:800;font-size:16px", text: r.customer || "Müşteri" }),
            el("div", { class: "muted", style: "font-size:13px", text: r.address || "—" }),
          ]),
          el("span", { class: "pill " + info.pill, text: info.icon + " " + info.label }),
        ]),
        steps,
        el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-top:6px" }, [
          el("span", { class: "pill " + (r.payMethod === "cash" ? "green" : r.payMethod === "pos" ? "blue" : "gray"), text: payLabel(r) }),
          cName ? el("span", { class: "pill slate", text: "🛵 " + cName }) : el("span", { class: "pill amber", text: "Kurye atanmadı" }),
        ]),
        r.note ? el("div", { class: "muted", style: "font-size:12px;margin-top:6px", text: "📝 " + r.note }) : null,
        el("div", { style: "display:flex;gap:6px;flex-wrap:wrap;margin-top:10px" }, [
          st !== "teslim" ? el("button", { class: "btn success tiny", onClick: () => advance(r) }, ["→ " + stageInfo(COURIER_STAGES[Math.min(stepIdx + 1, 2)].key).label]) : null,
          el("a", { class: "btn ghost tiny", href: mapHref, target: "_blank", rel: "noopener" }, ["🗺️ Harita"]),
          r.phone ? el("a", { class: "btn ghost tiny", href: "tel:" + r.phone }, ["📞 Ara"]) : null,
          el("button", { class: "btn ghost tiny", onClick: () => form(r) }, ["✏ Düzenle"]),
          el("button", { class: "btn ghost tiny", onClick: () => confirmDialog(t("delete") + "?", () => { db.couriers.remove(r.id); draw(); }) }, ["🗑"]),
        ]),
      ]));
    });
    body.appendChild(grid);
  }

  function form(edit) {
    const e = edit || {};
    const customer = el("input", { class: "input", placeholder: t("customer"), value: e.customer || "" });
    const phone = el("input", { class: "input", inputmode: "tel", placeholder: "Müşteri telefonu", value: e.phone || "" });
    const address = el("input", { class: "input", placeholder: t("address"), value: e.address || "" });
    const payMethod = el("select", { class: "input" }, [
      el("option", { value: "cash", text: "💵 Nakit — kuryeye ödenecek" }),
      el("option", { value: "pos", text: "💳 POS Cihazı — kuryede çekilecek" }),
      el("option", { value: "paid", text: "✔ Ödendi (online/havale)" }),
    ]);
    payMethod.value = e.payMethod || "cash";
    const payAmount = el("input", { class: "input", type: "number", step: "0.01", placeholder: "Tahsil edilecek tutar (TL)", value: e.payAmount || "" });
    const courierSel = el("select", { class: "input" }, [
      el("option", { value: "", text: "— Kurye atanmadı —" }),
      ...couriers().map((u) => el("option", { value: u.id, ...(e.courierId === u.id ? { selected: true } : {}) }, [u.name])),
    ]);
    const note = el("input", { class: "input", placeholder: "Not (kapı kodu, üst kat, para üstü)", value: e.note || "" });
    modal({ title: edit ? "Teslimat Düzenle" : "Yeni Teslimat", body: el("div", {}, [
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
        el("div", { class: "field" }, [el("label", { text: "👤 Müşteri" }), customer]),
        el("div", { class: "field" }, [el("label", { text: "📞 Telefon" }), phone]),
      ]),
      el("div", { class: "field" }, [el("label", { text: "📍 Adres" }), address]),
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
        el("div", { class: "field" }, [el("label", { text: "💳 Ödeme" }), payMethod]),
        el("div", { class: "field" }, [el("label", { text: "💰 Tutar" }), payAmount]),
      ]),
      el("div", { class: "field" }, [el("label", { text: "🛵 Kurye Ata" }), courierSel, el("div", { class: "muted", style: "font-size:12px;margin-top:2px", text: couriers().length ? "" : "Kurye eklemek için: Rol/Yetki → yeni kullanıcı → rol 'Kurye'." })]),
      el("div", { class: "field" }, [el("label", { text: "📝 Not" }), note]),
    ]), actions: [
      { label: t("save"), kind: "success", onClick: (close) => {
        if (!address.value.trim()) { toast(t("address") + "?", "warn"); return; }
        db.couriers.upsert({
          id: e.id || uid(), customer: customer.value.trim(), phone: phone.value.trim(), address: address.value.trim(),
          payMethod: payMethod.value, payAmount: parseFloat(payAmount.value) || 0, note: note.value.trim(),
          courierId: courierSel.value || "", status: e.status || courierStatus(e), done: courierStatus(e) === "teslim",
        });
        close(); draw();
      } },
      { label: t("cancel"), kind: "ghost" },
    ] });
  }
  draw();
}
export function renderDynPrice(host) {
  const cats = db.categories.all();
  const cat = el("select", { class: "input" }, [el("option", { value: "", text: "Tüm ürünler" }), ...cats.map((c) => el("option", { value: c.id, text: c.name }))]);
  const pct = el("input", { class: "input", type: "number", placeholder: "Yüzde (örn 10 veya -5)" });
  const apply = el("button", { class: "btn primary", onClick: () => {
    const p = parseFloat(pct.value); if (!p) { toast("Yüzde girin", "warn"); return; }
    let n = 0;
    db.products.all().forEach((pr) => {
      if (cat.value && pr.categoryId !== cat.value && pr.category !== cat.value) return;
      const base = Number(pr.price || pr.salePrice || 0);
      const nv = Math.round(base * (1 + p / 100) * 100) / 100;
      db.products.upsert({ ...pr, price: nv }); n++;
    });
    toast(n + " ürün fiyatı güncellendi", "success");
  } }, ["🏷️ Uygula"]);
  clear(host).append(head(t("navDynPrice")), card([el("p", { class: "muted", text: "Seçili gruba toplu yüzdesel fiyat değişimi uygula." }), cat, pct, apply]));
}
export function renderLoyalty(host) {
  crud(host, t("navLoyalty"), db.loyalty, [
    { k: "name", label: t("customer") }, { k: "phone", label: t("phone") }, { k: "points", label: "Puan", type: "number" },
  ]);
}
export function renderFinCal(host) {
  const store = LS("fincal");
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Kayıt"]);
  clear(host).append(head(t("navFinCal"), [addBtn]), body);
  function draw() {
    clear(body);
    const rows = store.all().sort((a, b) => (a.date || "").localeCompare(b.date || ""));
    if (!rows.length) { body.appendChild(empty()); return; }
    body.appendChild(card([el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: t("date") }), el("th", { text: t("name") }), el("th", { text: t("amount") }), el("th", {})])]),
      el("tbody", {}, rows.map((r, i) => el("tr", {}, [
        el("td", { text: r.date || "—" }), el("td", { text: r.title || "—" }), el("td", { class: "num", text: money(r.amount || 0) }),
        el("td", { style: "text-align:right" }, [el("button", { class: "iconbtn", onClick: () => { const a = store.all(); a.splice(a.indexOf(r), 1); store.save(a); draw(); } }, ["🗑"])]),
      ]))),
    ])]));
  }
  function form() {
    const title = el("input", { class: "input", placeholder: "Açıklama (örn. Kira, Fatura)" });
    const date = el("input", { class: "input", type: "date" });
    const amount = el("input", { class: "input", type: "number", placeholder: t("amount") });
    modal({ title: t("navFinCal"), body: el("div", {}, [title, date, amount].map((i) => el("div", { class: "field" }, [i]))), actions: [
      { label: t("save"), kind: "success", onClick: (close) => { const a = store.all(); a.push({ title: title.value.trim(), date: date.value, amount: parseFloat(amount.value) || 0 }); store.save(a); close(); draw(); } },
      { label: t("cancel"), kind: "ghost" },
    ] });
  }
  draw();
}
export function renderPwa(host) {
  const online = navigator.onLine;
  clear(host).append(head(t("navPwa")), card([
    el("div", { class: "stat-grid", style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:14px" }, [
      el("div", { class: "stat" }, [el("div", { class: "label", text: "Bağlantı" }), el("div", { class: "value", text: online ? "🟢 " + t("online") : "🔴 " + t("offline") })]),
      el("div", { class: "stat" }, [el("div", { class: "label", text: t("pendingSync") }), el("div", { class: "value num", text: pendingCount() })]),
    ]),
    el("p", { class: "muted", style: "margin-top:14px", text: "Uygulama internetsiz çalışır; değişiklikler kuyruğa alınır, bağlantı gelince otomatik eşitlenir." }),
    el("button", { class: "btn primary", style: "margin-top:8px", onClick: () => { sync(); toast(t("syncing"), "info"); } }, ["⟳ Şimdi Eşitle"]),
    el("p", { class: "muted", style: "margin-top:14px", text: "Kurmak için: tarayıcı menüsü → 'Ana ekrana ekle'." }),
  ]));
}

/* ============ VİZYON MODÜLLERİ+ ============ */
export function renderApprovals(host) {
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Onay Talebi"]);
  clear(host).append(head(t("navApprovals"), [addBtn]), body);
  function draw() {
    clear(body);
    const rows = db.approvals.all();
    if (!rows.length) { body.appendChild(empty()); return; }
    body.appendChild(card([el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: t("note") }), el("th", { text: t("amount") }), el("th", { text: "Durum" }), el("th", {})])]),
      el("tbody", {}, rows.map((r) => el("tr", {}, [
        el("td", { text: r.note || "—" }), el("td", { class: "num", text: money(r.amount || 0) }),
        el("td", {}, [el("span", { class: "pill " + (r.approved ? "green" : "amber"), text: r.approved ? "Onaylı" : "Bekliyor" })]),
        el("td", { style: "text-align:right;white-space:nowrap" }, [
          el("button", { class: "iconbtn", title: "Onayla", onClick: () => { db.approvals.upsert({ ...r, approved: true }); toast("Onaylandı", "success"); draw(); } }, ["✅"]),
          el("button", { class: "iconbtn", onClick: () => confirmDialog(t("delete") + "?", () => { db.approvals.remove(r.id); draw(); }) }, ["🗑"]),
        ]),
      ]))),
    ])]));
  }
  function form() {
    const note = el("input", { class: "input", placeholder: "Talep (iade, iskonto…)" });
    const amount = el("input", { class: "input", type: "number", placeholder: t("amount") });
    modal({ title: t("navApprovals"), body: el("div", {}, [note, amount].map((i) => el("div", { class: "field" }, [i]))), actions: [
      { label: t("save"), kind: "success", onClick: (close) => { db.approvals.upsert({ id: uid(), note: note.value.trim(), amount: parseFloat(amount.value) || 0, approved: false }); close(); draw(); } },
      { label: t("cancel"), kind: "ghost" },
    ] });
  }
  draw();
}
export function renderFaceShift(host) {
  const staff = db.staff.all();
  const sel = el("select", { class: "input" }, [el("option", { value: "", text: "— Personel seç —" }), ...staff.map((s) => el("option", { value: s.id, text: s.name }))]);
  const video = el("video", { autoplay: true, playsinline: true, style: "width:100%;max-width:320px;border-radius:12px;background:#000" });
  const camBtn = el("button", { class: "btn primary", onClick: async () => {
    try { const stream = await navigator.mediaDevices.getUserMedia({ video: true }); video.srcObject = stream; toast("Kamera açıldı", "success"); }
    catch { toast("Kamera erişimi yok", "error"); }
  } }, ["📷 Kamerayı Aç"]);
  const startBtn = el("button", { class: "btn success", onClick: () => {
    const s = staff.find((x) => x.id === sel.value); if (!s) { toast("Personel seç", "warn"); return; }
    db.shifts.upsert({ id: uid(), staffId: s.id, staff: s.name, start: Date.now(), face: 1 });
    toast(s.name + " vardiyası başladı", "success");
  } }, ["🟢 Vardiya Başlat"]);
  clear(host).append(head(t("navFace")), card([
    el("p", { class: "muted", text: "Personeli seçin, kamerayla doğrulayıp vardiyayı başlatın." }),
    sel, el("div", { style: "margin:12px 0" }, [video]), el("div", { style: "display:flex;gap:10px" }, [camBtn, startBtn]),
  ]));
}

/* ============ GÜVENLİK+ ============ */
export function renderSecurity(host) {
  const logs = LS("login_logs").all();
  clear(host).append(head(t("navSecurity")), card([
    el("h3", { text: "🛡️ Güvenlik Merkezi" }),
    el("div", { class: "muted", style: "line-height:1.9", html:
      "Cihaz: " + (navigator.platform || "?") + "<br>Tarayıcı: " + (navigator.userAgent.split(") ").pop() || "?") +
      "<br>Bağlantı: " + (navigator.onLine ? "Çevrimiçi" : "Çevrimdışı") +
      "<br>Bekleyen eşitleme: " + pendingCount() }),
    el("h3", { style: "margin-top:16px", text: "Giriş Kayıtları" }),
    logs.length ? el("table", { class: "tbl" }, [el("tbody", {}, logs.slice(0, 30).map((l) => el("tr", {}, [el("td", { class: "muted", text: new Date(l.ts).toLocaleString("tr-TR") }), el("td", { text: l.user || "?" }), el("td", { text: l.kind || "" })])))]) : empty("Kayıt yok"),
  ]));
}

/* ============ SÜPERMARKET KASA+ ============ */
export function renderMarketSet(host) {
  const s = settings.get();
  const receipt = el("textarea", { class: "input", rows: "3", text: s.receiptHeader || "" });
  const kdv = el("input", { class: "input", type: "number", value: s.kdvRate ?? 20 });
  const cur = el("input", { class: "input", value: s.currency || "₺" });
  const save = el("button", { class: "btn success", onClick: () => { settings.set({ receiptHeader: receipt.value, kdvRate: parseFloat(kdv.value) || 0, currency: cur.value.trim() || "₺" }); toast(t("save"), "success"); } }, ["💾 " + t("save")]);
  clear(host).append(head(t("navMarketSet")), card([
    el("div", { class: "field" }, [el("label", { text: "Fiş Başlığı" }), receipt]),
    el("div", { class: "field" }, [el("label", { text: "Varsayılan KDV %" }), kdv]),
    el("div", { class: "field" }, [el("label", { text: t("currency") }), cur]),
    save,
  ]));
}

/* ============ YÖNETİM+ ============ */
export function renderCashierPerms(host) {
  const s = settings.get();
  const perms = s.cashierPerms || { sell: true, refund: false, changePrice: false, manageStock: true, viewReports: false, cashOut: false };
  const labels = { sell: "Satış yapma", refund: "İade", changePrice: "Fiyat değiştirme", manageStock: "Stok girişi", viewReports: "Rapor görme", cashOut: "Kasa çıkışı" };
  const boxes = Object.keys(labels).map((k) => {
    const cb = el("input", { type: "checkbox" }); cb.checked = !!perms[k];
    cb.addEventListener("change", () => { const np = { ...settings.get().cashierPerms, [k]: cb.checked }; settings.set({ cashierPerms: np }); toast(t("save"), "success"); });
    return el("label", { class: "row", style: "display:flex;align-items:center;gap:10px;padding:10px;border-bottom:1px solid var(--border)" }, [cb, el("span", { text: labels[k] })]);
  });
  clear(host).append(head(t("navCashierPerms")), card([el("p", { class: "muted", text: "Kasiyer rolünün erişebileceği özellikleri aç/kapat." }), ...boxes]));
}
/* ============ ÇALIŞAN YÖNETİMİ (İK) ============ */
export function renderEmployeeMgmt(host) {
  const today = new Date().toISOString().slice(0, 10);

  const draw = () => {
    const staff = db.staff.all();
    const att = db.attendance.all();
    const leaves = db.leaves.all();
    const todayAtt = att.filter((a) => a.date === today);
    const onLeaveToday = leaves.filter((l) => l.from <= today && today <= l.to);
    const present = todayAtt.filter((a) => a.in && !a.out).length;

    const addBtn = el("button", { class: "btn success", onClick: () => editEmp(null) }, ["+ Çalışan"]);
    const leaveBtn = el("button", { class: "btn ghost", onClick: () => addLeave() }, ["📆 İzin Ver"]);
    const reportBtn = el("button", { class: "btn", onClick: () => employeeReport() }, ["📊 Çalışan Raporu"]);

    const stats = el("div", { class: "stat-grid" }, [
      statCard("Toplam Çalışan", String(staff.length), "var(--primary)"),
      statCard("Bugün İçeride", String(present), "var(--success)"),
      statCard("İzinli", String(onLeaveToday.length), "var(--warning)"),
      statCard("Pasif", String(staff.filter((s) => s.status === "passive").length), "var(--danger)"),
    ]);

    const listCard = el("div", { class: "card", style: "margin-top:16px" });
    if (!staff.length) {
      listCard.appendChild(el("p", { class: "muted", text: "Çalışan kaydı yok. Sağ üstten ekleyin." }));
    } else {
      listCard.appendChild(el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, [
          el("th", { text: "Ad Soyad" }), el("th", { text: "Departman" }), el("th", { text: "Pozisyon" }),
          el("th", { text: "Telefon" }), el("th", { text: "Durum" }), el("th", { text: "Bugün" }), el("th", {}),
        ])]),
        el("tbody", {}, staff.map((s) => {
          const rec = todayAtt.find((a) => a.staffId === s.id);
          const isLeave = onLeaveToday.some((l) => l.staffId === s.id);
          const inside = rec && rec.in && !rec.out;
          const statusPill = isLeave
            ? el("span", { class: "pill amber", text: "📆 İzinli" })
            : inside
            ? el("span", { class: "pill green", text: "🟢 İçeride" })
            : rec && rec.out
            ? el("span", { class: "pill blue", text: "Çıktı " + rec.out })
            : el("span", { class: "pill", text: "—" });
          const clockBtn = isLeave
            ? el("span", { class: "muted", text: "İzinli" })
            : inside
            ? el("button", { class: "btn danger sm", onClick: () => clockOut(s) }, ["Çıkış"])
            : el("button", { class: "btn success sm", onClick: () => clockIn(s) }, ["Giriş"]);
          return el("tr", {}, [
            el("td", { style: "font-weight:700", text: s.name }),
            el("td", { class: "muted", text: s.dept || "—" }),
            el("td", {}, [el("span", { class: "pill blue", text: s.role || "—" })]),
            el("td", { class: "muted", text: s.phone || "—" }),
            el("td", {}, [s.status === "passive" ? el("span", { class: "pill red", text: "Pasif" }) : el("span", { class: "pill green", text: "Aktif" })]),
            el("td", {}, [statusPill]),
            el("td", { style: "text-align:right;white-space:nowrap" }, [
              clockBtn,
              el("button", { class: "iconbtn", title: t("edit"), onClick: () => editEmp(s) }, ["✏️"]),
              el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog("Çalışanı sil?", () => { db.staff.remove(s.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
            ]),
          ]);
        })),
      ]));
    }

    const upcoming = leaves.filter((l) => l.to >= today).sort((a, b) => a.from.localeCompare(b.from));
    const leaveCard = el("div", { class: "card", style: "margin-top:16px" }, [
      el("h3", { text: "📆 İzinler" }),
      upcoming.length
        ? el("table", { class: "tbl" }, [
            el("thead", {}, [el("tr", {}, [el("th", { text: "Çalışan" }), el("th", { text: "Tür" }), el("th", { text: "Başlangıç" }), el("th", { text: "Bitiş" }), el("th", {})])]),
            el("tbody", {}, upcoming.map((l) => {
              const emp = staff.find((s) => s.id === l.staffId);
              return el("tr", {}, [
                el("td", { text: emp ? emp.name : "—" }),
                el("td", {}, [el("span", { class: "pill amber", text: l.type || "İzin" })]),
                el("td", { class: "muted", text: l.from }),
                el("td", { class: "muted", text: l.to }),
                el("td", { style: "text-align:right" }, [el("button", { class: "iconbtn", onClick: () => { db.leaves.remove(l.id); draw(); } }, ["🗑"])]),
              ]);
            })),
          ])
        : el("p", { class: "muted", text: "Kayıtlı izin yok." }),
    ]);

    clear(host).append(head("👔 " + t("navEmployees"), [reportBtn, leaveBtn, addBtn]), stats, listCard, leaveCard);
  };

  const clockIn = (s) => {
    const now = new Date().toTimeString().slice(0, 5);
    db.attendance.upsert({ id: uid(), staffId: s.id, date: today, in: now, out: "" });
    toast(s.name + " giriş yaptı ✔", "success"); draw();
  };
  const clockOut = (s) => {
    const rec = db.attendance.all().find((a) => a.staffId === s.id && a.date === today && a.in && !a.out);
    if (!rec) return;
    // Çıkışta "bugün tamamladığı işler" notu sor (opsiyonel) → raporda görünür.
    const jobs = el("textarea", { class: "input", rows: 3, placeholder: "Örn: Depo sayımı, 3 masa servisi, kasa kapanışı…" });
    modal({
      title: "⏹ " + s.name + " — Çıkış",
      body: el("div", {}, [
        el("p", { class: "muted", text: "Çıkış saati: " + new Date().toTimeString().slice(0, 5) }),
        el("div", { class: "field" }, [el("label", { text: "Bugün tamamladığı işler (opsiyonel)" }), jobs]),
      ]),
      actions: [
        { label: "Çıkışı Kaydet", kind: "danger", onClick: (close) => {
          rec.out = new Date().toTimeString().slice(0, 5);
          rec.note = jobs.value.trim();
          db.attendance.upsert(rec);
          toast(s.name + " çıkış yaptı", "info"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  };

  const addLeave = () => {
    const staff = db.staff.all();
    if (!staff.length) { toast("Önce çalışan ekleyin", "warn"); return; }
    const who = el("select", { class: "input" }, staff.map((s) => el("option", { value: s.id, text: s.name })));
    const type = el("select", { class: "input" }, ["Yıllık İzin", "Hastalık", "Ücretsiz", "Mazeret", "Diğer"].map((x) => el("option", { text: x })));
    const from = el("input", { class: "input", type: "date", value: today });
    const to = el("input", { class: "input", type: "date", value: today });
    modal({
      title: "📆 İzin Ver",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Çalışan" }), who]),
        el("div", { class: "field" }, [el("label", { text: "İzin Türü" }), type]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "Başlangıç" }), from]),
          el("div", { class: "field" }, [el("label", { text: "Bitiş" }), to]),
        ]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (to.value < from.value) { toast("Bitiş tarihi hatalı", "warn"); return; }
          db.leaves.upsert({ id: uid(), staffId: who.value, type: type.value, from: from.value, to: to.value });
          toast("İzin kaydedildi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  };

  const editEmp = (existing) => {
    const s0 = existing || {};
    const name = el("input", { class: "input", value: s0.name || "", autofocus: true });
    const dept = el("input", { class: "input", value: s0.dept || "", placeholder: "Satış, Mutfak, Depo…" });
    const role = el("input", { class: "input", value: s0.role || "", placeholder: "Kasiyer, Müdür…" });
    const phone = el("input", { class: "input", value: s0.phone || "", inputmode: "tel" });
    const email = el("input", { class: "input", type: "email", value: s0.email || "" });
    const start = el("input", { class: "input", type: "date", value: s0.startDate || today });
    const status = el("select", { class: "input" }, [
      el("option", { value: "active", text: "Aktif" }),
      el("option", { value: "passive", text: "Pasif" }),
    ]);
    status.value = s0.status || "active";
    const salary = el("input", { class: "input num", type: "number", step: "0.01", value: s0.salary != null ? s0.salary : "" });
    modal({
      title: "👤 " + (existing ? t("edit") : "Yeni Çalışan"),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Ad Soyad *" }), name]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "Departman" }), dept]),
          el("div", { class: "field" }, [el("label", { text: "Pozisyon" }), role]),
        ]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "Telefon" }), phone]),
          el("div", { class: "field" }, [el("label", { text: "E-posta" }), email]),
        ]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "İşe Başlama" }), start]),
          el("div", { class: "field" }, [el("label", { text: "Durum" }), status]),
        ]),
        el("div", { class: "field" }, [el("label", { text: "Aylık Maaş" }), salary]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast("Ad zorunlu", "warn"); return; }
          db.staff.upsert({
            id: s0.id || uid(), name: name.value.trim(), dept: dept.value.trim(), role: role.value.trim(),
            phone: phone.value.trim(), email: email.value.trim(), startDate: start.value,
            status: status.value, salary: parseFloat(salary.value) || 0,
            meal: s0.meal || 0, transport: s0.transport || 0, sgk: s0.sgk || 0, health: s0.health || 0,
          });
          toast(existing ? t("save") : "Çalışan eklendi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  };

  // ---- Çalışan Raporu: ada göre ara → giriş/çıkış geçmişi, süreler, izinler, tamamlanan işler ----
  const employeeReport = () => {
    const staff = db.staff.all();
    if (!staff.length) { toast("Önce çalışan ekleyin", "warn"); return; }
    const search = el("input", { class: "input", placeholder: "Çalışan adı / pozisyon ara…", autofocus: true });
    const listBox = el("div", { style: "display:flex;flex-wrap:wrap;gap:6px;margin:8px 0" });
    const detail = el("div", {});

    const hoursBetween = (a, b) => {
      if (!a || !b) return 0;
      const [ah, am] = a.split(":").map(Number), [bh, bm] = b.split(":").map(Number);
      let mins = (bh * 60 + bm) - (ah * 60 + am);
      if (mins < 0) mins += 24 * 60; // gece yarısını geçen vardiya
      return mins / 60;
    };

    const showEmp = (s) => {
      const att = db.attendance.all().filter((a) => a.staffId === s.id).sort((a, b) => (b.date || "").localeCompare(a.date || ""));
      const leaves = db.leaves.all().filter((l) => l.staffId === s.id).sort((a, b) => (b.from || "").localeCompare(a.from || ""));
      const daysWorked = att.filter((a) => a.in).length;
      const totalHours = att.reduce((sum, a) => sum + hoursBetween(a.in, a.out), 0);
      const leaveDays = leaves.reduce((sum, l) => {
        const d = (new Date(l.to) - new Date(l.from)) / 86400000 + 1;
        return sum + (isFinite(d) && d > 0 ? d : 0);
      }, 0);

      clear(detail).append(
        el("div", { class: "card", style: "margin-top:6px" }, [
          el("h3", { style: "margin-top:0", text: "👤 " + s.name }),
          el("p", { class: "muted", text: [s.role, s.dept, s.phone].filter(Boolean).join(" · ") || "—" }),
          el("div", { class: "stat-grid" }, [
            statCard("Çalışılan Gün", String(daysWorked), "var(--primary)"),
            statCard("Toplam Saat", totalHours.toFixed(1) + " sa", "var(--success)"),
            statCard("İzin Günü", String(leaveDays), "var(--warning)"),
          ]),
        ]),
        el("div", { class: "card", style: "margin-top:12px" }, [
          el("h3", { text: "🕒 Giriş / Çıkış Geçmişi" }),
          att.length
            ? el("table", { class: "tbl" }, [
                el("thead", {}, [el("tr", {}, [el("th", { text: "Tarih" }), el("th", { text: "Giriş" }), el("th", { text: "Çıkış" }), el("th", { text: "Süre" }), el("th", { text: "Tamamlanan İşler" })])]),
                el("tbody", {}, att.map((a) => el("tr", {}, [
                  el("td", { class: "muted", text: a.date || "—" }),
                  el("td", {}, [el("span", { class: "pill green", text: a.in || "—" })]),
                  el("td", {}, [a.out ? el("span", { class: "pill blue", text: a.out }) : el("span", { class: "pill amber", text: "İçeride" })]),
                  el("td", { class: "num", text: a.out ? hoursBetween(a.in, a.out).toFixed(1) + " sa" : "—" }),
                  el("td", { class: "muted", style: "white-space:normal", text: a.note || "—" }),
                ]))),
              ])
            : el("p", { class: "muted", text: "Bu çalışan için giriş/çıkış kaydı yok." }),
        ]),
        el("div", { class: "card", style: "margin-top:12px" }, [
          el("h3", { text: "📆 İzin Geçmişi" }),
          leaves.length
            ? el("table", { class: "tbl" }, [
                el("thead", {}, [el("tr", {}, [el("th", { text: "Tür" }), el("th", { text: "Başlangıç" }), el("th", { text: "Bitiş" })])]),
                el("tbody", {}, leaves.map((l) => el("tr", {}, [
                  el("td", {}, [el("span", { class: "pill amber", text: l.type || "İzin" })]),
                  el("td", { class: "muted", text: l.from }),
                  el("td", { class: "muted", text: l.to }),
                ]))),
              ])
            : el("p", { class: "muted", text: "İzin kaydı yok." }),
        ]),
      );
    };

    const paintList = () => {
      const q = search.value.trim().toLowerCase();
      const matches = staff.filter((s) => !q || (s.name || "").toLowerCase().includes(q) || (s.role || "").toLowerCase().includes(q) || (s.dept || "").toLowerCase().includes(q));
      clear(listBox);
      if (!matches.length) { listBox.appendChild(el("span", { class: "muted", text: "Eşleşme yok." })); return; }
      matches.forEach((s) => listBox.appendChild(
        el("button", { class: "btn ghost sm", onClick: () => showEmp(s) }, [s.name + (s.role ? " · " + s.role : "")])
      ));
    };
    search.addEventListener("input", paintList);
    paintList();
    if (staff.length === 1) showEmp(staff[0]);

    modal({
      title: "📊 Çalışan Raporu",
      body: el("div", {}, [
        el("p", { class: "muted", text: "Çalışan adını yazıp seçin; giriş/çıkış saatleri, çalışılan gün, izin ve tamamladığı işler listelenir." }),
        search, listBox, detail,
      ]),
      actions: [{ label: "Kapat", kind: "ghost" }],
    });
  };

  draw();
}
function statCard(label, value, color) {
  return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
    el("div", { class: "label", text: label }),
    el("div", { class: "value num", text: value }),
  ]);
}

export function renderAutoSave(host) {
  const info = el("div", { class: "muted", style: "line-height:1.9" });
  function refresh() { info.innerHTML = "Bekleyen değişiklik: <b>" + pendingCount() + "</b><br>Bağlantı: " + (navigator.onLine ? "🟢 Çevrimiçi" : "🔴 Çevrimdışı"); }
  refresh();
  const syncBtn = el("button", { class: "btn primary", onClick: () => { sync(); toast(t("syncing"), "info"); setTimeout(refresh, 800); } }, ["⟳ Şimdi Eşitle"]);
  const backupBtn = el("button", { class: "btn success", onClick: () => {
    const dump = {}; Object.keys(localStorage).filter((k) => k.startsWith("t101_")).forEach((k) => dump[k] = localStorage.getItem(k));
    const blob = new Blob([JSON.stringify(dump)], { type: "application/json" });
    const a = el("a", { href: URL.createObjectURL(blob), download: "tufan101-yedek.json" }); document.body.appendChild(a); a.click(); a.remove();
  } }, ["⬇️ Yedek Al"]);
  const file = el("input", { type: "file", accept: "application/json", style: "display:none" });
  file.addEventListener("change", () => { const f = file.files[0]; if (!f) return; const r = new FileReader(); r.onload = () => { try { const d = JSON.parse(r.result); Object.keys(d).forEach((k) => localStorage.setItem(k, d[k])); toast("Yedek yüklendi, yenileniyor…", "success"); setTimeout(() => location.reload(), 800); } catch { toast("Geçersiz dosya", "error"); } }; r.readAsText(f); });
  const restoreBtn = el("button", { class: "btn ghost", onClick: () => file.click() }, ["⬆️ Yedeği Geri Yükle"]);
  clear(host).append(head(t("navAutoSave")), card([
    el("h3", { text: "☁️ Otomatik Kayıt & Yedekleme" }), info,
    el("div", { style: "display:flex;gap:10px;flex-wrap:wrap;margin-top:12px" }, [syncBtn, backupBtn, restoreBtn, file]),
  ]));
}

/* ============ PERSONEL SATIŞ PERFORMANSI ============ */
// "Kim ne kadar sattı" — seçili günde her personelin çalışma süresi, satış adedi,
// cirosu, iadeleri ve tek tek fişleri. Vardiya (saat) + satış verisinden üretilir.
export function renderStaffSales(host) {
  const dateInp = el("input", { class: "input", type: "date", value: new Date().toISOString().slice(0, 10), style: "max-width:180px" });
  const body = el("div", {});
  clear(host).append(head("📊 Personel Satış Raporu", [dateInp]), body);

  const fmtDur = (ms) => { const m = Math.max(0, Math.round(ms / 60000)); return Math.floor(m / 60) + " sa " + (m % 60) + " dk"; };
  const timeOf = (ts) => new Date(ts).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
  const stat = (label, val) => el("div", { class: "stat", style: "padding:10px;border:1px solid var(--border);border-radius:12px" }, [
    el("div", { class: "muted", style: "font-size:12px", text: label }),
    el("div", { style: "font-size:20px;font-weight:800", text: val }),
  ]);

  function draw() {
    clear(body);
    const start = new Date(dateInp.value + "T00:00:00").getTime();
    if (!Number.isFinite(start)) { body.appendChild(empty("Tarih seçin.")); return; }
    const end = start + 86400000;
    const sales = db.sales.all().filter((s) => s.ts >= start && s.ts < end);
    const shifts = db.shifts.all().filter((sh) => (sh.closeTs && sh.closeTs >= start && sh.closeTs < end) || (sh.openTs >= start && sh.openTs < end));
    if (!sales.length && !shifts.length) { body.appendChild(empty("Bu tarihte satış/vardiya kaydı yok.")); return; }

    const map = new Map();
    const keyOf = (id, name) => id || ("name:" + (name || "—"));
    const get = (id, name) => {
      const k = keyOf(id, name);
      if (!map.has(k)) map.set(k, { name: name || "—", count: 0, gross: 0, refunds: 0, refundSum: 0, ms: 0, sales: [] });
      const o = map.get(k); if (name && o.name === "—") o.name = name; return o;
    };
    sales.forEach((s) => {
      const o = get(s.cashierId, s.cashierName);
      if (s.void) { o.refunds++; o.refundSum += Number(s.total) || 0; }
      else { o.count++; o.gross += Number(s.total) || 0; o.sales.push(s); }
    });
    shifts.forEach((sh) => { const o = get(sh.cashierId, sh.cashierName); if (sh.closeTs && sh.openTs) o.ms += (sh.closeTs - sh.openTs); });

    const rows = [...map.values()].sort((a, b) => b.gross - a.gross);
    const totGross = rows.reduce((a, r) => a + r.gross, 0);
    const totCount = rows.reduce((a, r) => a + r.count, 0);
    body.appendChild(card([
      el("div", { style: "display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px" }, [
        stat("Toplam Ciro", money(totGross)), stat("Satış Adedi", String(totCount)), stat("Personel", String(rows.length)),
      ]),
    ]));

    rows.forEach((r) => {
      const detail = el("div", { style: "display:none;margin-top:10px" });
      let open = false;
      const toggle = el("button", { class: "btn tiny ghost", onClick: () => {
        open = !open; detail.style.display = open ? "" : "none";
        if (open && !detail.childElementCount) fillDetail();
      } }, ["🧾 Fişleri Gör"]);
      const fillDetail = () => {
        if (!r.sales.length) { detail.appendChild(empty("Satış yok.")); return; }
        detail.appendChild(el("table", { class: "tbl" }, [
          el("thead", {}, [el("tr", {}, [el("th", { text: "Saat" }), el("th", { text: "Ürünler" }), el("th", { text: "Tutar" })])]),
          el("tbody", {}, r.sales.slice().sort((a, b) => a.ts - b.ts).map((s) => el("tr", {}, [
            el("td", { class: "muted", text: timeOf(s.ts) }),
            el("td", { class: "muted", style: "font-size:12px", text: (s.items || []).map((i) => (i.name || "?") + "×" + (i.qty || 1)).join(", ") || "—" }),
            el("td", { class: "num", text: money(s.total || 0) }),
          ]))),
        ]));
      };
      body.appendChild(card([
        el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap" }, [
          el("div", { style: "font-size:22px", text: "🧑‍💼" }),
          el("div", { style: "flex:1;min-width:150px" }, [
            el("b", { text: r.name }),
            el("div", { class: "muted", style: "font-size:12px", text: r.ms ? ("⏱ Çalışma: " + fmtDur(r.ms)) : "Vardiya kaydı yok" }),
          ]),
          el("span", { class: "pill green", text: "💰 " + money(r.gross) }),
          el("span", { class: "pill blue", text: r.count + " satış" }),
          r.refunds ? el("span", { class: "pill amber", text: r.refunds + " iade" }) : null,
          toggle,
        ]),
        detail,
      ], "margin-top:12px"));
    });
  }
  dateInp.addEventListener("change", draw);
  draw();
}

/* ============ FİŞ GEÇMİŞİ + İADE ============ */
// Geriye dönük satış fişleri: saat, kasiyer, ürünler, tutar. Fişi yeniden yazdır
// ve (yetki varsa) iade et → stok geri eklenir, kasa/banka hareketi geri alınır.
export function renderReceipts(host) {
  const dateInp = el("input", { class: "input", type: "date", value: new Date().toISOString().slice(0, 10), style: "max-width:170px" });
  const search = el("input", { class: "input", placeholder: "Fiş no / ürün ara…", style: "max-width:220px" });
  const body = el("div", {});
  clear(host).append(head("🧾 Fiş Geçmişi", [search, dateInp]), body);
  const timeOf = (ts) => new Date(ts).toLocaleString("tr-TR");
  const allowRefund = () => can("refund") || can("voidSale") || currentUser()?.role === "owner";

  function refund(s) {
    confirmDialog("Bu satış iade edilsin mi? Ürün stoğu geri eklenir ve kasadan düşülür.", () => {
      (s.items || []).forEach((it) => { const p = db.products.get(it.productId); if (p) { p.stock = (Number(p.stock) || 0) + (Number(it.qty) || 0); db.products.upsert(p); } });
      try { removeAccountMovesByRef(s.id); } catch {}
      db.sales.upsert({ ...s, void: true, refundedAt: Date.now(), refundedBy: currentUser()?.name || "" });
      toast("İade tamamlandı ✔", "success"); draw();
    });
  }
  function draw() {
    clear(body);
    const start = new Date(dateInp.value + "T00:00:00").getTime();
    const end = start + 86400000;
    const q = search.value.trim().toLowerCase();
    let list = db.sales.all().filter((s) => s.ts >= start && s.ts < end);
    if (q) list = list.filter((s) => String(s.id).toLowerCase().includes(q) || (s.items || []).some((i) => String(i.name || "").toLowerCase().includes(q)));
    list.sort((a, b) => b.ts - a.ts);
    if (!list.length) { body.appendChild(empty("Bu tarihte fiş yok.")); return; }
    body.appendChild(card([el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: "Saat" }), el("th", { text: "Fiş No" }), el("th", { text: "Kasiyer" }), el("th", { text: "Ürünler" }), el("th", { text: "Tutar" }), el("th", {})])]),
      el("tbody", {}, list.map((s) => el("tr", { style: s.void ? "opacity:.55" : "" }, [
        el("td", { class: "muted", style: "font-size:12px", text: timeOf(s.ts) }),
        el("td", { class: "muted", text: String(s.id || "").slice(-8).toUpperCase() }),
        el("td", { class: "muted", text: s.cashierName || "—" }),
        el("td", { class: "muted", style: "font-size:12px", text: (s.items || []).map((i) => (i.name || "?") + "×" + (i.qty || 1)).join(", ") || "—" }),
        el("td", { class: "num", text: money(s.total || 0) }),
        el("td", { style: "text-align:right;white-space:nowrap" }, [
          s.void ? el("span", { class: "pill amber", style: "margin-right:6px", text: "İade" }) : null,
          el("button", { class: "iconbtn", title: "Yeniden Yazdır", onClick: () => { try { printReceipt(s); } catch {} } }, ["🖨"]),
          (!s.void && allowRefund()) ? el("button", { class: "iconbtn", style: "margin-left:6px", title: "İade Et", onClick: () => refund(s) }, ["↩️"]) : null,
        ]),
      ]))),
    ])]));
  }
  search.addEventListener("input", draw);
  dateInp.addEventListener("change", draw);
  draw();
}
