// Gelir / Gider girişi + basit grafikler (mod-10) — ücretsiz sürümde açık
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

export function renderFinance(host) {
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: t("finance") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn success", onClick: () => entry("income") }, ["+ " + t("income")]),
    el("button", { class: "btn danger", onClick: () => entry("expense") }, ["+ " + t("expense")]),
  ]);
  const body = el("div", {});
  clear(host).append(head, body);

  function draw() {
    clear(body);
    const txns = db.txns.all().slice().sort((a, b) => b.ts - a.ts);
    const income = txns.filter((x) => x.type === "income").reduce((a, x) => a + x.amount, 0);
    const expense = txns.filter((x) => x.type === "expense").reduce((a, x) => a + x.amount, 0);

    // Bu ay bakiyesi
    const mStart = new Date(); mStart.setDate(1); mStart.setHours(0, 0, 0, 0);
    const monthTx = txns.filter((x) => x.ts >= mStart.getTime());
    const monthBal = monthTx.reduce((a, x) => a + (x.type === "income" ? x.amount : -x.amount), 0);

    body.appendChild(el("div", { class: "stat-grid" }, [
      statCard(t("income"), money(income), "var(--success)"),
      statCard(t("expense"), money(expense), "var(--danger)"),
      statCard(t("balance"), money(income - expense), "var(--primary)"),
      statCard(t("thisMonth"), money(monthBal), "var(--warning)"),
    ]));

    // Gelir/gider pasta benzeri oran çubuğu
    const tot = income + expense || 1;
    body.appendChild(el("div", { class: "card", style: "margin-top:16px" }, [
      el("h3", { text: "📈 " + t("finance") }),
      el("div", { style: "display:flex;height:26px;border-radius:8px;overflow:hidden;border:1px solid var(--border)" }, [
        el("div", { style: `width:${(income / tot) * 100}%;background:var(--success)` }),
        el("div", { style: `width:${(expense / tot) * 100}%;background:var(--danger)` }),
      ]),
      el("div", { class: "muted", style: "margin-top:8px;font-size:13px", text: `🟢 ${t("income")} ${money(income)}  •  🔴 ${t("expense")} ${money(expense)}` }),
    ]));

    const listCard = el("div", { class: "card", style: "margin-top:16px" });
    if (!txns.length) listCard.appendChild(el("p", { class: "muted", text: "—" }));
    else listCard.appendChild(el("table", { class: "tbl" }, [
      el("thead", {}, [el("tr", {}, [el("th", { text: t("date") }), el("th", { text: t("type") }), el("th", { text: t("note") }), el("th", { text: t("amount") }), el("th", {})])]),
      el("tbody", {}, txns.slice(0, 50).map((x) =>
        el("tr", {}, [
          el("td", { class: "muted", text: new Date(x.ts).toLocaleString("tr-TR") }),
          el("td", {}, [el("span", { class: "pill " + (x.type === "income" ? "green" : "red"), text: t(x.type) })]),
          el("td", { text: x.note || "—" }),
          el("td", { class: "num", text: money(x.amount) }),
          el("td", { style: "text-align:right" }, [
            el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog(t("delete") + "?", () => { db.txns.remove(x.id); toast(t("delete"), "warn"); draw(); }) }, ["🗑"]),
          ]),
        ])
      )),
    ]));
    body.appendChild(listCard);
  }

  function entry(type) {
    const amount = el("input", { class: "input num", type: "number", step: "0.01", autofocus: true });
    const note = el("input", { class: "input", placeholder: t("note") });
    modal({
      title: type === "income" ? t("income") : t("expense"),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: t("amount") }), amount]),
        el("div", { class: "field" }, [el("label", { text: t("note") }), note]),
      ]),
      actions: [
        { label: t("save"), kind: type === "income" ? "success" : "danger", onClick: (close) => {
          const a = parseFloat(amount.value); if (!a || a <= 0) { toast(t("amount") + "?", "warn"); return; }
          db.txns.upsert({ id: uid(), type, amount: a, note: note.value.trim(), ts: Date.now() });
          toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}

function statCard(label, value, color) {
  return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
    el("div", { class: "label", text: label }),
    el("div", { class: "value num", text: value }),
  ]);
}
