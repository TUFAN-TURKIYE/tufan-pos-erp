// Envanter Sayımı — fiziksel sayım ile sistem stoğunu karşılaştır, farkları uygula.
// Ürünlere sayılan adet girilir; sistemle farkı gösterilir; uygulanınca stok
// güncellenir, stok hareketi (stockMoves) + denetim kaydı yazılır.
import { el, clear, toast, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, uid } from "../core/store.js";
import { logAudit } from "./audit.js";

export function renderStocktake(host) {
  const counted = {}; // productId → sayılan
  const search = el("input", { class: "input", placeholder: "🔍 Ürün / barkod ara", style: "max-width:260px" });
  const onlyDiff = el("input", { type: "checkbox" });
  const listWrap = el("div", {});
  const summary = el("div", { class: "card", style: "position:sticky;bottom:0;z-index:5" });

  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "📋 " + t("navStocktake") }), el("div", { class: "spacer" })]),
    el("div", { class: "card", style: "display:flex;gap:12px;flex-wrap:wrap;align-items:center" }, [
      search,
      el("label", { style: "display:flex;gap:6px;align-items:center" }, [onlyDiff, el("span", { text: "Sadece farklılar" })]),
      el("span", { class: "muted", style: "font-size:13px", text: "Sayılan adedi girin; boş bıraktığınız ürünlere dokunulmaz." }),
    ]),
    listWrap, summary,
  );

  function diffs() {
    return Object.keys(counted).map((id) => {
      const p = db.products.get(id); if (!p) return null;
      const sys = Number(p.stock) || 0, cnt = Number(counted[id]);
      return { p, sys, cnt, delta: cnt - sys };
    }).filter((x) => x && !isNaN(x.cnt) && x.delta !== 0);
  }

  function drawSummary() {
    clear(summary);
    const d = diffs();
    const plus = d.filter((x) => x.delta > 0).length, minus = d.filter((x) => x.delta < 0).length;
    summary.append(
      el("div", { style: "display:flex;gap:14px;flex-wrap:wrap;align-items:center" }, [
        el("b", { text: d.length + " üründe fark" }),
        el("span", { class: "pill green", text: "▲ " + plus + " fazla" }),
        el("span", { class: "pill amber", text: "▼ " + minus + " eksik" }),
        el("div", { class: "spacer" }),
        el("button", { class: "btn success", onClick: () => apply() }, ["✅ Farkları Uygula"]),
      ]),
    );
  }

  function draw() {
    clear(listWrap);
    const q = search.value.trim().toLowerCase();
    let rows = db.products.all().filter((p) => p.active !== false);
    if (q) rows = rows.filter((p) => (p.name || "").toLowerCase().includes(q) || (p.barcode || "").includes(q));
    if (onlyDiff.checked) rows = rows.filter((p) => { const c = counted[p.id]; return c != null && c !== "" && Number(c) !== (Number(p.stock) || 0); });

    const tbl = el("div", { class: "card", style: "padding:0" });
    rows.slice(0, 400).forEach((p) => {
      const sys = Number(p.stock) || 0;
      const inp = el("input", { class: "input num", type: "number", value: counted[p.id] != null ? counted[p.id] : "", placeholder: String(sys), style: "max-width:90px", onInput: (e) => { counted[p.id] = e.target.value; drawSummary(); updateDelta(); } });
      const deltaEl = el("span", { class: "pill", style: "min-width:60px;text-align:center" });
      const updateDelta = () => {
        const c = counted[p.id];
        if (c == null || c === "" || isNaN(Number(c))) { deltaEl.textContent = "—"; deltaEl.className = "pill gray"; return; }
        const d = Number(c) - sys;
        deltaEl.textContent = d === 0 ? "✓" : (d > 0 ? "+" + d : String(d));
        deltaEl.className = "pill " + (d === 0 ? "green" : d > 0 ? "blue" : "amber");
      };
      updateDelta();
      tbl.appendChild(el("div", { class: "stk-row" }, [
        el("span", { style: "flex:1", text: (p.emoji || "📦") + " " + (p.name || "Ürün") }),
        el("span", { class: "muted", style: "min-width:70px;text-align:right", text: "Sistem: " + sys }),
        inp, deltaEl,
      ]));
    });
    if (!rows.length) tbl.appendChild(el("p", { class: "muted", style: "padding:16px", text: "Ürün yok." }));
    listWrap.appendChild(tbl);
    drawSummary();
  }

  function apply() {
    const d = diffs();
    if (!d.length) { toast("Uygulanacak fark yok", "warn"); return; }
    confirmDialog(d.length + " üründe stok güncellenecek. Onaylıyor musunuz?", () => {
      d.forEach(({ p, cnt, delta }) => {
        db.products.upsert({ ...p, stock: cnt });
        try { db.stockMoves.upsert({ id: uid(), productId: p.id, type: "count", delta, before: p.stock, after: cnt, note: "Envanter sayımı", ts: Date.now() }); } catch {}
      });
      logAudit("price", "stocktake", d.length + " üründe sayım farkı uygulandı");
      toast(d.length + " ürün güncellendi ✔", "success");
      Object.keys(counted).forEach((k) => delete counted[k]);
      draw();
    });
  }

  search.addEventListener("input", draw);
  onlyDiff.addEventListener("change", draw);
  draw();
}
