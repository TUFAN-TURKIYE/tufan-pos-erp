// Mutfak Ekranı (KDS — Kitchen Display System)
// Garson/QR menüden gelen siparişleri fiş kartları olarak gösterir.
// Mutfak personeli: "Hazırlanıyor" → "Hazır ✓" akışıyla ilerletir.
// Durum akışı buluttaki çağrı sistemini kullanır: bekliyor → alindi → hazir → tamam
import { el, clear, toast, sound } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { money, currentAccount } from "../core/store.js";
import { cloud } from "../core/api.js";

let _timer = null;
let _tickets = [];
let _lastCount = 0;

function orderTotal(c) {
  const items = Array.isArray(c.items) ? c.items : [];
  return items.reduce((a, it) => a + (Number(it.qty) || 1) * (Number(it.price) || 0), 0);
}

function relTime(ts) {
  const n = Number(ts) || 0;
  if (!n) return "";
  const diff = Math.max(0, Date.now() - (n < 1e12 ? n * 1000 : n));
  const m = Math.floor(diff / 60000);
  if (m < 1) return "az önce";
  if (m < 60) return m + " dk";
  return Math.floor(m / 60) + " sa";
}

export function renderKitchen(host) {
  const account = currentAccount();
  const board = el("div", { class: "kds-board" });
  const status = el("span", { class: "muted", style: "font-size:13px" });
  const refreshBtn = el("button", { class: "btn ghost", onClick: () => poll(true) }, ["⟳ Yenile"]);

  clear(host).append(
    el("div", { class: "view-head" }, [
      el("h1", { text: "🍳 " + t("navKitchen") }),
      el("div", { class: "spacer" }), status, refreshBtn,
    ]),
    board,
  );

  if (!account) {
    clear(board).append(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Bulut hesabı yok — sipariş akışı için işletme hesabıyla giriş yapın." })]));
    return;
  }

  async function poll(manual) {
    try {
      const res = await cloud.listCalls(account);
      const list = (res && (res.calls || res.data || res)) || [];
      // Yalnızca sipariş türü + tamamlanmamışlar
      _tickets = (Array.isArray(list) ? list : [])
        .filter((c) => c.type === "order" && (c.status || "bekliyor") !== "tamam")
        .sort((a, b) => (a.created_at || 0) - (b.created_at || 0));
      // Yeni sipariş geldiyse sesli uyarı
      if (_tickets.length > _lastCount && !manual) { try { sound.add(); } catch {} }
      _lastCount = _tickets.length;
      status.textContent = _tickets.length ? _tickets.length + " aktif sipariş" : "Bekleyen sipariş yok";
      draw();
    } catch {
      status.textContent = "Bağlantı yok — tekrar denenecek";
    }
  }

  async function setStatus(id, st) {
    // Anlık his: yerelde güncelle
    if (st === "tamam" || st === "hazir") {
      // hazir kalır listede (servis bekler); tamam ise düşer
    }
    _tickets = _tickets.map((c) => (c.id === id ? { ...c, status: st } : c));
    if (st === "tamam") _tickets = _tickets.filter((c) => c.id !== id);
    draw();
    try { await cloud.setCallStatus(account, id, st); toast("Güncellendi", "success"); }
    catch { toast("Güncellenemedi (bağlantı yok)", "error"); }
    setTimeout(() => poll(true), 500);
  }

  function draw() {
    clear(board);
    if (!_tickets.length) {
      board.appendChild(el("div", { class: "card", style: "grid-column:1/-1" }, [
        el("p", { class: "muted", style: "padding:28px;text-align:center;font-size:16px", text: "🍽 Şu an bekleyen sipariş yok." }),
      ]));
      return;
    }
    _tickets.forEach((c) => {
      const st = c.status || "bekliyor";
      const items = Array.isArray(c.items) ? c.items : [];
      const masa = c.masa ? "Masa " + c.masa : "Paket / Belirtilmemiş";
      const waiter = String(c.waiter || "").trim();
      const total = orderTotal(c);
      const stClass = st === "hazir" ? "kds-ready" : st === "alindi" ? "kds-cooking" : "kds-new";
      const stLabel = st === "hazir" ? "✅ HAZIR" : st === "alindi" ? "👨‍🍳 HAZIRLANIYOR" : "🆕 YENİ";

      const actions = [];
      if (st === "bekliyor") actions.push(el("button", { class: "btn primary block", onClick: () => setStatus(c.id, "alindi") }, ["👨‍🍳 Hazırlamaya Başla"]));
      else if (st === "alindi") actions.push(el("button", { class: "btn success block", onClick: () => setStatus(c.id, "hazir") }, ["✅ Hazır"]));
      else if (st === "hazir") actions.push(el("button", { class: "btn ghost block", onClick: () => setStatus(c.id, "tamam") }, ["🍽 Servis Edildi"]));

      board.appendChild(el("div", { class: "kds-ticket " + stClass }, [
        el("div", { class: "kds-top" }, [
          el("span", { class: "kds-masa", text: masa }),
          el("span", { class: "kds-time", text: relTime(c.created_at) }),
        ]),
        el("div", { class: "kds-state", text: stLabel }),
        el("div", { class: "kds-items" }, items.length
          ? items.map((it) => el("div", { class: "kds-item" }, [
              el("b", { class: "kds-qty", text: (it.qty || 1) + "×" }),
              el("span", { text: it.name || "Ürün" }),
            ]))
          : [el("div", { class: "muted", text: c.note || "—" })]),
        (c.note && items.length) ? el("div", { class: "kds-note", text: "📝 " + c.note }) : el("span", {}),
        el("div", { class: "kds-foot" }, [
          waiter ? el("span", { class: "muted", text: "👤 " + waiter }) : el("span", {}),
          total > 0 ? el("b", { class: "num", text: money(total) }) : el("span", {}),
        ]),
        ...actions,
      ]));
    });
  }

  poll(true);
  _timer = setInterval(() => {
    if (!document.body.contains(host)) { clearInterval(_timer); _timer = null; return; }
    poll(false);
  }, 12000);
}
