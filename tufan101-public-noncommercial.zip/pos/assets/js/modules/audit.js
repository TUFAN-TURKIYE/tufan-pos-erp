// Denetim Modu (Audit Log) — kim, ne zaman, neyi değiştirdi?
// Kritik işlemler (iade, silme, fiyat değişikliği, kasa, ayar) buraya yazılır.
// Kayıtlar SİLİNEMEZ — sadece görüntülenir/dışa aktarılır. Şeffaflık ve güven için.
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, uid } from "../core/store.js";
import { currentUser } from "../core/auth.js";

// Diğer modüllerin çağırabileceği ortak yardımcı — tek satırla denetim kaydı bırakır.
export function logAudit(action, entity, detail) {
  try {
    const u = currentUser();
    db.auditLog.upsert({
      id: uid(), ts: Date.now(),
      userId: u ? u.id : null, userName: u ? (u.name || u.username || "") : "",
      action: String(action || ""), entity: String(entity || ""), detail: String(detail || ""),
    });
  } catch {}
}

const ACTIONS = {
  refund:   { icon: "↩️", label: "İade", cls: "amber" },
  delete:   { icon: "🗑", label: "Silme", cls: "red" },
  price:    { icon: "🏷️", label: "Fiyat Değişikliği", cls: "blue" },
  cash:     { icon: "💵", label: "Kasa", cls: "green" },
  settings: { icon: "⚙️", label: "Ayar", cls: "blue" },
  login:    { icon: "🔑", label: "Giriş", cls: "" },
  wipe:     { icon: "💣", label: "Veri Silme", cls: "red" },
};
function meta(a) { return ACTIONS[a] || { icon: "•", label: a || "İşlem", cls: "" }; }

export function renderAudit(host) {
  const filterSel = el("select", { class: "input", style: "max-width:200px" }, [
    el("option", { value: "", text: "Tüm işlemler" }),
    ...Object.keys(ACTIONS).map((k) => el("option", { value: k, text: meta(k).icon + " " + meta(k).label })),
  ]);
  const searchInp = el("input", { class: "input", placeholder: "🔍 Kullanıcı / detay ara", style: "max-width:240px" });
  const list = el("div", { style: "margin-top:14px" });

  clear(host).append(
    el("div", { class: "view-head" }, [
      el("h1", { text: "🔒 " + t("navAudit") }),
      el("div", { class: "spacer" }),
      el("button", { class: "btn ghost", onClick: () => exportCsv() }, ["📤 CSV"]),
    ]),
    el("div", { class: "card", style: "display:flex;gap:10px;flex-wrap:wrap;align-items:center" }, [
      el("span", { class: "muted", style: "font-size:13px", text: "🛡️ Bu kayıtlar silinemez. Her kritik işlem otomatik loglanır." }),
      el("div", { class: "spacer" }), filterSel, searchInp,
    ]),
    list,
  );

  function rows() {
    let all = db.auditLog.all().slice().sort((a, b) => (b.ts || 0) - (a.ts || 0));
    const f = filterSel.value, q = searchInp.value.trim().toLowerCase();
    if (f) all = all.filter((r) => r.action === f);
    if (q) all = all.filter((r) => ((r.userName || "") + " " + (r.detail || "") + " " + (r.entity || "")).toLowerCase().includes(q));
    return all;
  }

  function draw() {
    clear(list);
    const all = rows();
    if (!all.length) {
      list.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Henüz denetim kaydı yok. İade, silme, fiyat/kasa/ayar işlemleri burada görünecek." })]));
      return;
    }
    const table = el("div", { class: "card", style: "padding:0;overflow:auto" });
    const head = el("div", { class: "audit-row audit-head" }, [
      el("span", { text: "Zaman" }), el("span", { text: "Kullanıcı" }),
      el("span", { text: "İşlem" }), el("span", { text: "Detay" }),
    ]);
    table.appendChild(head);
    all.slice(0, 500).forEach((r) => {
      const m = meta(r.action);
      table.appendChild(el("div", { class: "audit-row" }, [
        el("span", { class: "muted", style: "font-size:12px", text: new Date(r.ts).toLocaleString("tr-TR") }),
        el("span", { text: r.userName || "—" }),
        el("span", {}, [el("span", { class: "pill " + m.cls, text: m.icon + " " + m.label })]),
        el("span", { style: "font-size:13px", text: (r.detail || "") + (r.entity ? "  ·  " + r.entity : "") }),
      ]));
    });
    list.appendChild(table);
    list.appendChild(el("p", { class: "muted", style: "font-size:12px;margin-top:8px", text: all.length + " kayıt" + (all.length > 500 ? " (ilk 500 gösteriliyor)" : "") }));
  }

  function exportCsv() {
    const all = rows();
    if (!all.length) { toast("Dışa aktarılacak kayıt yok", "warn"); return; }
    const esc = (v) => '"' + String(v == null ? "" : v).replace(/"/g, '""') + '"';
    const lines = [["Zaman", "Kullanıcı", "İşlem", "Nesne", "Detay"].map(esc).join(",")];
    all.forEach((r) => lines.push([new Date(r.ts).toLocaleString("tr-TR"), r.userName || "", meta(r.action).label, r.entity || "", r.detail || ""].map(esc).join(",")));
    const blob = new Blob(["﻿" + lines.join("\r\n")], { type: "text/csv;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob); a.download = "denetim-kaydi-" + new Date().toISOString().slice(0, 10) + ".csv";
    a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast("Denetim kaydı indirildi", "success");
  }

  filterSel.addEventListener("change", draw);
  searchInp.addEventListener("input", draw);
  draw();
}
