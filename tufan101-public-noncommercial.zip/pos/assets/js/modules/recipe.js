// Üretim / Reçete (BOM) — bir mamul hangi hammaddelerden oluşur?
// Latte = süt(200) + kahve(18) gibi. Mamul satılınca hammadde stoğu otomatik
// düşer (pos.js checkout'ta). Ayrıca "Üret" ile toplu üretim: hammadde düşülür,
// mamul stoğu artar. Reçete ürünün `recipe:[{productId, qty, unit}]` alanında tutulur.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, uid, money } from "../core/store.js";
import { logAudit } from "./audit.js";

function ingName(id) { const p = db.products.get(id); return p ? p.name : "?"; }

export function renderRecipe(host) {
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form() }, ["+ Reçete"]);
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🧪 " + t("navRecipe2") }), el("div", { class: "spacer" }), addBtn]),
    el("div", { class: "card" }, [el("p", { class: "muted", style: "margin:0", text: "Mamul (satılan ürün) için hammadde reçetesi tanımlayın. Satışta hammadde stoğu otomatik düşer. Toplu üretim için “Üret” kullanın." })]),
    body,
  );

  function withRecipe() { return db.products.all().filter((p) => Array.isArray(p.recipe) && p.recipe.length); }

  function draw() {
    clear(body);
    const list = withRecipe();
    if (!list.length) { body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:16px", text: "Henüz reçete yok. “+ Reçete” ile ekleyin." })])); return; }
    const grid = el("div", { class: "rec-grid" });
    list.forEach((p) => {
      // Bu reçeteden kaç adet üretilebilir? (hammadde stoğuna göre)
      let canMake = Infinity;
      p.recipe.forEach((ing) => { const raw = db.products.get(ing.productId); const st = raw ? Number(raw.stock) || 0 : 0; const need = Number(ing.qty) || 0; if (need > 0) canMake = Math.min(canMake, Math.floor(st / need)); });
      if (!isFinite(canMake)) canMake = 0;
      let cost = 0;
      p.recipe.forEach((ing) => { const raw = db.products.get(ing.productId); cost += (raw ? Number(raw.cost) || 0 : 0) * (Number(ing.qty) || 0); });

      grid.appendChild(el("div", { class: "card rec-card" }, [
        el("div", { style: "display:flex;justify-content:space-between;align-items:center;gap:8px" }, [
          el("h3", { style: "margin:0", text: (p.emoji || "🍹") + " " + p.name }),
          el("span", { class: "pill " + (canMake > 0 ? "green" : "red"), text: "Üretilebilir: " + canMake }),
        ]),
        el("div", { class: "rec-ings" }, p.recipe.map((ing) => el("div", { class: "rec-ing" }, [
          el("span", { text: ingName(ing.productId) }),
          el("b", { class: "num", text: (Number(ing.qty) || 0) + (ing.unit ? " " + ing.unit : "") }),
        ]))),
        cost > 0 ? el("div", { class: "muted", style: "font-size:12px;margin-top:6px", text: "Birim maliyet ≈ " + money(cost) }) : el("span", {}),
        el("div", { style: "display:flex;gap:8px;flex-wrap:wrap;margin-top:10px" }, [
          el("button", { class: "btn success tiny", onClick: () => produce(p) }, ["🏭 Üret"]),
          el("button", { class: "btn ghost tiny", onClick: () => form(p) }, ["✏ Düzenle"]),
          el("button", { class: "btn ghost tiny", onClick: () => confirmDialog("Reçeteyi kaldır?", () => { db.products.upsert({ ...p, recipe: [] }); toast("Reçete kaldırıldı", "success"); draw(); }) }, ["🗑"]),
        ]),
      ]));
    });
    body.appendChild(grid);
  }

  // Toplu üretim: X adet üret → hammadde düş, mamul stoğu artır
  function produce(p) {
    const qtyInp = el("input", { class: "input num", type: "number", value: "1", min: "1" });
    const preview = el("div", { class: "muted", style: "margin-top:8px;font-size:13px" });
    const refresh = () => {
      const n = Math.max(1, parseInt(qtyInp.value, 10) || 1);
      preview.innerHTML = "";
      p.recipe.forEach((ing) => {
        const raw = db.products.get(ing.productId);
        const need = (Number(ing.qty) || 0) * n;
        const st = raw ? Number(raw.stock) || 0 : 0;
        const ok = st >= need;
        preview.appendChild(el("div", { style: "color:" + (ok ? "inherit" : "var(--danger,#dc2626)") }, [ingName(ing.productId) + ": " + need + " gerekli / " + st + " mevcut " + (ok ? "✔" : "✖ yetersiz")]));
      });
    };
    qtyInp.addEventListener("input", refresh); refresh();
    modal({
      title: "🏭 Üret — " + p.name,
      body: el("div", {}, [el("div", { class: "field" }, [el("label", { text: "Üretilecek adet" }), qtyInp]), preview]),
      actions: [
        { label: "Üret", kind: "success", onClick: (close) => {
          const n = Math.max(1, parseInt(qtyInp.value, 10) || 1);
          // Yeterlilik kontrolü
          for (const ing of p.recipe) { const raw = db.products.get(ing.productId); const st = raw ? Number(raw.stock) || 0 : 0; if (st < (Number(ing.qty) || 0) * n) { toast("Yetersiz hammadde: " + ingName(ing.productId), "error"); return; } }
          p.recipe.forEach((ing) => { const raw = db.products.get(ing.productId); if (raw) { raw.stock = Math.max(0, (Number(raw.stock) || 0) - (Number(ing.qty) || 0) * n); db.products.upsert(raw); } });
          const fresh = db.products.get(p.id);
          db.products.upsert({ ...fresh, stock: (Number(fresh.stock) || 0) + n });
          logAudit("price", "production:" + p.id, n + " adet " + p.name + " üretildi (hammadde düşüldü)");
          toast(n + " adet " + p.name + " üretildi ✔", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function form(edit) {
    const prods = db.products.all();
    const target = edit || null;
    const sel = el("select", { class: "input" }, [
      el("option", { value: "", text: "— Mamul ürün seç —" }),
      ...prods.map((p) => el("option", { value: p.id, ...(target && target.id === p.id ? { selected: true } : {}) }, [p.name])),
    ]);
    let ings = target && Array.isArray(target.recipe) ? target.recipe.map((x) => ({ ...x })) : [];
    const ingWrap = el("div", {});

    const drawIngs = () => {
      clear(ingWrap);
      ings.forEach((ing, i) => {
        const rawSel = el("select", { class: "input", style: "flex:1", onChange: (e) => ing.productId = e.target.value }, [
          el("option", { value: "", text: "— Hammadde —" }),
          ...prods.map((p) => el("option", { value: p.id, ...(ing.productId === p.id ? { selected: true } : {}) }, [p.name])),
        ]);
        const qtyI = el("input", { class: "input num", type: "number", step: "0.01", value: ing.qty || "", placeholder: "Miktar", style: "max-width:100px", onInput: (e) => ing.qty = parseFloat(e.target.value) || 0 });
        const unitI = el("input", { class: "input", value: ing.unit || "", placeholder: "birim", style: "max-width:80px", onInput: (e) => ing.unit = e.target.value });
        ingWrap.appendChild(el("div", { style: "display:flex;gap:6px;margin-bottom:6px;align-items:center" }, [
          rawSel, qtyI, unitI,
          el("button", { class: "btn ghost tiny", onClick: () => { ings.splice(i, 1); drawIngs(); } }, ["✕"]),
        ]));
      });
    };
    drawIngs();

    modal({
      title: (edit ? "Reçete Düzenle" : "Yeni Reçete"),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Mamul (satılan ürün)" }), sel]),
        el("label", { style: "font-weight:600;margin-top:6px;display:block", text: "Hammaddeler" }),
        ingWrap,
        el("button", { class: "btn ghost tiny", onClick: () => { ings.push({ productId: "", qty: 0, unit: "" }); drawIngs(); } }, ["+ Hammadde Ekle"]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          const pid = sel.value;
          if (!pid) { toast("Mamul ürün seçin", "warn"); return; }
          const clean = ings.filter((x) => x.productId && (Number(x.qty) || 0) > 0);
          if (!clean.length) { toast("En az bir hammadde girin", "warn"); return; }
          const p = db.products.get(pid);
          db.products.upsert({ ...p, recipe: clean });
          logAudit("settings", "recipe:" + pid, (p.name || "Ürün") + " reçetesi güncellendi (" + clean.length + " hammadde)");
          toast("Reçete kaydedildi", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
}
