// Otomasyon Kuralları — koşul gerçekleşince otomatik bildirim üretir.
// Kurallar settings.automationRules içinde tutulur. "Şimdi Kontrol Et" veya
// açılışta değerlendirilir; tetiklenen kural bildirim merkezine düşer.
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, settings } from "../core/store.js";
import { logAudit } from "./audit.js";

const DAY = 86400000;

// Kural tanımları — her biri değerlendirilir, {hit, message} döndürür.
const RULES = {
  lowstock: {
    icon: "📦", title: "Düşük Stok Uyarısı",
    desc: (th) => "Stok " + th + " adedin altına düşen ürünler için bildirim.",
    def: 5,
    eval(th) {
      const list = db.products.all().filter((p) => p.active !== false && typeof p.stock === "number" && p.stock >= 0 && p.stock <= th);
      if (!list.length) return null;
      return { message: list.length + " üründe stok ≤ " + th + ": " + list.slice(0, 6).map((p) => p.name + "(" + p.stock + ")").join(", ") + (list.length > 6 ? "…" : "") };
    },
  },
  highrev: {
    icon: "🎉", title: "Yüksek Ciro Kutlaması",
    desc: (th) => "Günlük ciro " + money(th) + " üzerine çıkınca bildirim.",
    def: 50000,
    eval(th) {
      const t0 = new Date(); t0.setHours(0, 0, 0, 0);
      const rev = db.sales.all().filter((s) => !s.void && Number(s.ts) >= t0.getTime()).reduce((a, s) => a + (Number(s.total) || 0), 0);
      if (rev < th) return null;
      return { message: "🎯 Günlük ciro hedefi aştı! Bugün: " + money(rev) + " (eşik " + money(th) + ")" };
    },
  },
  deadstock: {
    icon: "🧊", title: "Ölü Stok Uyarısı",
    desc: (th) => th + " gündür satılmayan (stoğu olan) ürünler için bildirim.",
    def: 14,
    eval(th) {
      const from = Date.now() - th * DAY;
      const sold = new Set();
      db.sales.all().filter((s) => !s.void && Number(s.ts) >= from).forEach((s) => (s.items || []).forEach((it) => sold.add((it.name || "").toLowerCase())));
      const list = db.products.all().filter((p) => p.active !== false && Number(p.stock) > 0 && !sold.has((p.name || "").toLowerCase()));
      if (!list.length) return null;
      return { message: list.length + " ürün " + th + " gündür satılmadı: " + list.slice(0, 6).map((p) => p.name).join(", ") + (list.length > 6 ? "…" : "") };
    },
  },
  opencash: {
    icon: "💵", title: "Açık Kasa Hatırlatması",
    desc: () => "Kasa oturumu hâlâ açıksa (gün sonu kapatılmadıysa) bildirim.",
    def: 0,
    eval() {
      const open = db.cashSessions.all().find((s) => s.open);
      if (!open) return null;
      return { message: "Kasa hâlâ açık — gün sonunda kapatmayı unutmayın (Z raporu)." };
    },
  },
};

function getRules() {
  const s = settings.get();
  return (s.automationRules && typeof s.automationRules === "object") ? s.automationRules : {};
}
function saveRules(r) { settings.set({ automationRules: r }); }

// Dışarıdan da çağrılabilir: aktif kuralları değerlendirip bildirim üretir.
export function runAutomation(silent) {
  const cfg = getRules();
  let fired = 0;
  Object.keys(RULES).forEach((key) => {
    const rc = cfg[key];
    if (!rc || !rc.active) return;
    const th = Number(rc.threshold != null ? rc.threshold : RULES[key].def);
    const res = RULES[key].eval(th);
    if (res) {
      try {
        db.notifications.upsert({ id: "auto:" + key + ":" + new Date().toISOString().slice(0, 10), title: RULES[key].icon + " " + RULES[key].title, body: res.message, type: "automation", createdAt: Date.now() });
      } catch {}
      fired++;
    }
  });
  if (!silent) toast(fired ? fired + " kural tetiklendi → Bildirimler'e bakın" : "Şu an tetiklenen kural yok", fired ? "success" : "info");
  return fired;
}

export function renderAutomation(host) {
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [
      el("h1", { text: "⚙️ " + t("navAutomation") }),
      el("div", { class: "spacer" }),
      el("button", { class: "btn", onClick: () => runAutomation(false) }, ["▶️ Şimdi Kontrol Et"]),
    ]),
    el("div", { class: "card" }, [el("p", { class: "muted", style: "margin:0", text: "Kuralı açın ve eşik değeri girin. Koşul gerçekleşince Bildirimler'e otomatik uyarı düşer." })]),
    body,
  );

  function draw() {
    clear(body);
    const cfg = getRules();
    Object.keys(RULES).forEach((key) => {
      const R = RULES[key];
      const rc = cfg[key] || {};
      const active = !!rc.active;
      const thVal = rc.threshold != null ? rc.threshold : R.def;

      const toggle = el("button", { class: "btn " + (active ? "success" : "ghost") + " tiny", onClick: () => {
        const nc = getRules(); nc[key] = { ...(nc[key] || {}), active: !active, threshold: thVal };
        saveRules(nc); logAudit("settings", "automation:" + key, (!active ? "açıldı" : "kapatıldı")); draw();
      } }, [active ? "✅ Açık" : "⭕ Kapalı"]);

      const thInput = R.def > 0
        ? el("input", { class: "input num", type: "number", value: thVal, style: "max-width:140px", onChange: (e) => {
            const nc = getRules(); nc[key] = { ...(nc[key] || {}), active, threshold: Number(e.target.value) || R.def }; saveRules(nc); draw();
          } })
        : null;

      body.appendChild(el("div", { class: "card auto-rule" }, [
        el("div", { class: "auto-icon", text: R.icon }),
        el("div", { style: "flex:1;min-width:0" }, [
          el("div", { style: "display:flex;justify-content:space-between;align-items:center;gap:8px" }, [
            el("h3", { style: "margin:0", text: R.title }), toggle,
          ]),
          el("p", { class: "muted", style: "margin:4px 0 8px", text: R.desc(thVal) }),
          thInput ? el("div", { class: "field", style: "margin:0" }, [el("label", { style: "font-size:12px", text: R.def > 1000 ? "Eşik (TL)" : "Eşik (adet/gün)" }), thInput]) : el("span", {}),
        ]),
      ]));
    });
  }

  draw();
}
