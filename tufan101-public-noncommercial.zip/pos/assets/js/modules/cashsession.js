// Kasa Açılış / Kapanış (Z raporu mantığı)
// Sabah: kasaya konan başlangıç parası (örn. 500 TL) girilir → oturum açılır.
// Akşam: sayılan gerçek nakit girilir → beklenen ile karşılaştırılır, fark (eksik/fazla) çıkar.
// Beklenen = açılış + oturum boyunca kasaya giren nakit − çıkan nakit.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid, settings, ensureAccounts, defaultAccountId, postAccountMove } from "../core/store.js";
import { currentUser } from "../core/auth.js";

// Açık oturumu döndür (varsa)
export function openCashSession() {
  return db.cashSessions.all().find((s) => s.open);
}

// Oturum başlangıcından bu yana kasadaki (nakit hesap) net nakit hareketi
function cashFlowSince(openTs) {
  let inSum = 0, outSum = 0;
  try {
    ensureAccounts();
    const cashId = defaultAccountId("cash");
    db.accountMoves.all().forEach((m) => {
      if (cashId && m.accountId !== cashId) return;
      if ((m.ts || 0) < openTs) return;
      const amt = Number(m.amount) || 0;
      if (m.dir === "in") inSum += amt; else if (m.dir === "out") outSum += amt;
    });
  } catch {}
  return { inSum, outSum, net: inSum - outSum };
}

// Nakit satış adedi/tutarı (bilgi amaçlı)
function cashSalesSince(openTs) {
  const list = db.sales.all().filter((s) => !s.void && (s.ts || 0) >= openTs && s.method === "cash");
  return { count: list.length, total: list.reduce((a, s) => a + (Number(s.total) || 0), 0) };
}

export function renderCashSession(host) {
  const wrap = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "💵 " + t("navCashSession") }), el("div", { class: "spacer" })]),
    wrap,
  );

  function draw() {
    clear(wrap);
    const cur = openCashSession();
    if (cur) drawOpen(cur); else drawClosed();
    drawHistory();
  }

  function drawClosed() {
    const opening = el("input", { class: "input num", type: "number", step: "0.01", inputmode: "decimal", placeholder: "Örn. 500", style: "font-size:24px;text-align:right" });
    wrap.appendChild(el("div", { class: "card" }, [
      el("h3", { text: "🌅 Kasa Açılışı" }),
      el("p", { class: "muted", text: "Sabah kasaya koyduğunuz başlangıç parasını girin." }),
      el("div", { class: "field", style: "max-width:280px" }, [el("label", { text: "Başlangıç Parası (TL)" }), opening]),
      el("button", { class: "btn success lg", onClick: () => {
        const amt = parseFloat(opening.value) || 0;
        const user = currentUser();
        db.cashSessions.upsert({
          id: uid(), open: true, openTs: Date.now(), opening: amt,
          userId: user ? user.id : null, userName: user ? user.name : "",
          branchId: (user && user.branchId) || settings.get().activeBranch || "",
        });
        toast("Kasa açıldı • " + money(amt), "success"); draw();
      } }, ["🔓 Kasayı Aç"]),
    ]));
  }

  function drawOpen(s) {
    const flow = cashFlowSince(s.openTs);
    const sales = cashSalesSince(s.openTs);
    // Beklenen = açılış + net nakit hareketi. Ancak açılış zaten hesapta yoksa
    // net akış satışları içerir; açılış parasını ayrıca ekleriz.
    const expected = Math.round((Number(s.opening || 0) + flow.net) * 100) / 100;

    const stat = (icon, label, val, cls) => el("div", { class: "cs-stat" }, [
      el("div", { style: "font-size:20px", text: icon }),
      el("div", { class: "num" + (cls ? " " + cls : ""), style: "font-weight:800;font-size:20px", text: val }),
      el("div", { class: "muted", style: "font-size:12px", text: label }),
    ]);

    wrap.appendChild(el("div", { class: "card" }, [
      el("div", { style: "display:flex;align-items:center;gap:10px;margin-bottom:4px" }, [
        el("h3", { style: "margin:0", text: "🟢 Kasa Açık" }),
        el("span", { class: "pill green", text: new Date(s.openTs).toLocaleString("tr-TR") }),
      ]),
      s.userName ? el("p", { class: "muted", style: "margin:0 0 12px", text: "Açan: " + s.userName }) : el("span", {}),
      el("div", { class: "cs-grid" }, [
        stat("🌅", "Açılış", money(s.opening || 0)),
        stat("💵", "Nakit Satış", money(sales.total) + " (" + sales.count + ")"),
        stat("➕", "Kasa Girişi", money(flow.inSum)),
        stat("➖", "Kasa Çıkışı", money(flow.outSum)),
        stat("🎯", "Beklenen Nakit", money(expected)),
      ]),
      el("div", { style: "display:flex;gap:10px;flex-wrap:wrap;margin-top:14px" }, [
        el("button", { class: "btn ghost", onClick: () => cashMove("in") }, ["➕ Para Girişi"]),
        el("button", { class: "btn ghost", onClick: () => cashMove("out") }, ["➖ Para Çıkışı"]),
        el("button", { class: "btn danger", onClick: () => closeForm(s, expected, sales, flow) }, ["🔒 Kasayı Kapat (Z Raporu)"]),
      ]),
    ]));
  }

  // Elle kasa para giriş/çıkışı → nakit hesaba işlenir, beklenen tutarı etkiler.
  function cashMove(dir) {
    const amt = el("input", { class: "input num", type: "number", step: "0.01", inputmode: "decimal", style: "font-size:22px;text-align:right" });
    const note = el("input", { class: "input", placeholder: dir === "in" ? "Açıklama (örn. bozuk para eklendi)" : "Açıklama (örn. tedarikçi ödemesi)" });
    modal({
      title: dir === "in" ? "➕ Kasaya Para Girişi" : "➖ Kasadan Para Çıkışı",
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Tutar (TL)" }), amt]),
        el("div", { class: "field" }, [el("label", { text: "Açıklama" }), note]),
      ]),
      actions: [
        { label: t("save"), kind: dir === "in" ? "success" : "danger", onClick: (close) => {
          const v = parseFloat(amt.value) || 0;
          if (v <= 0) { toast("Tutar girin", "warn"); return; }
          try {
            ensureAccounts();
            const accId = defaultAccountId("cash");
            if (accId) postAccountMove({ accountId: accId, dir, amount: v, source: "cashdrawer", refId: uid(), note: note.value.trim() || (dir === "in" ? "Kasa girişi" : "Kasa çıkışı"), party: "Kasa" });
          } catch {}
          toast("İşlendi", "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  function closeForm(s, expected, sales, flow) {
    const counted = el("input", { class: "input num", type: "number", step: "0.01", inputmode: "decimal", placeholder: "Sayılan nakit", style: "font-size:24px;text-align:right" });
    const diffEl = el("div", { style: "font-size:18px;font-weight:800;margin-top:8px;text-align:right" });
    const upd = () => {
      const c = parseFloat(counted.value);
      if (isNaN(c)) { diffEl.textContent = ""; return; }
      const d = Math.round((c - expected) * 100) / 100;
      diffEl.textContent = d === 0 ? "✅ Tam eşleşme" : (d > 0 ? "🟢 Fazla: " + money(d) : "🔴 Eksik: " + money(Math.abs(d)));
      diffEl.style.color = d === 0 ? "var(--success)" : (d > 0 ? "var(--success)" : "var(--danger,#dc2626)");
    };
    counted.addEventListener("input", upd);
    const note = el("input", { class: "input", placeholder: "Not (opsiyonel)" });
    modal({
      title: "🔒 Kasa Kapanış — Z Raporu",
      body: el("div", {}, [
        el("div", { style: "background:var(--bg-soft,#f1f5f9);border-radius:10px;padding:12px;margin-bottom:12px" }, [
          rowLine("🌅 Açılış", money(s.opening || 0)),
          rowLine("💵 Nakit satış", money(sales.total)),
          rowLine("➕ Kasa girişi", money(flow.inSum)),
          rowLine("➖ Kasa çıkışı", "- " + money(flow.outSum)),
          el("div", { style: "border-top:1px solid var(--border);margin:6px 0" }),
          rowLine("🎯 Beklenen nakit", money(expected), true),
        ]),
        el("div", { class: "field" }, [el("label", { text: "Sayılan Gerçek Nakit (TL)" }), counted, diffEl]),
        el("div", { class: "field" }, [el("label", { text: "Not" }), note]),
      ]),
      actions: [
        { label: "🔒 Kapat & Kaydet", kind: "danger", onClick: (close) => {
          const c = parseFloat(counted.value);
          if (isNaN(c)) { toast("Sayılan tutarı girin", "warn"); return; }
          const diff = Math.round((c - expected) * 100) / 100;
          db.cashSessions.upsert({ ...s, open: false, closeTs: Date.now(), counted: c, expected, diff, note: note.value.trim() });
          toast(diff === 0 ? "Kasa kapandı — tam eşleşme ✔" : (diff > 0 ? "Kasa kapandı — fazla " + money(diff) : "Kasa kapandı — eksik " + money(Math.abs(diff))), diff < 0 ? "warn" : "success");
          close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
    setTimeout(() => counted.focus(), 60);
  }

  function rowLine(label, val, bold) {
    return el("div", { style: "display:flex;justify-content:space-between;padding:3px 0" + (bold ? ";font-weight:800;font-size:16px" : "") }, [
      el("span", { text: label }), el("span", { class: "num", text: val }),
    ]);
  }

  function drawHistory() {
    const rows = db.cashSessions.all().filter((s) => !s.open).sort((a, b) => (b.closeTs || 0) - (a.closeTs || 0)).slice(0, 30);
    if (!rows.length) return;
    wrap.appendChild(el("div", { class: "card" }, [
      el("h3", { text: "📜 Geçmiş Kasa Kapanışları" }),
      el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, ["Tarih", "Açılış", "Beklenen", "Sayılan", "Fark"].map((h) => el("th", { text: h })))]),
        el("tbody", {}, rows.map((s) => el("tr", {}, [
          el("td", { text: new Date(s.closeTs).toLocaleString("tr-TR") }),
          el("td", { class: "num", text: money(s.opening || 0) }),
          el("td", { class: "num", text: money(s.expected || 0) }),
          el("td", { class: "num", text: money(s.counted || 0) }),
          el("td", {}, [el("span", { class: "pill " + (s.diff === 0 ? "green" : s.diff > 0 ? "green" : "red"), text: s.diff === 0 ? "✅ 0" : (s.diff > 0 ? "+" + money(s.diff) : money(s.diff)) })]),
        ]))),
      ]),
    ]));
  }

  draw();
}
