// Kampanya & İndirim motoru — kasada otomatik uygulanır.
// Kampanya: { id, name, kind:'percent'|'fixed', value, minTotal, active }
//   percent → ara toplam >= minTotal ise %value indirim
//   fixed   → ara toplam >= minTotal ise value TL indirim
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, uid } from "../core/store.js";

// Bir ara toplama uygulanabilecek kampanyalardan EN İYİSİNİ (en çok indirim) döndürür.
// Dönüş: { campaign, amount, label } veya null.
export function bestCampaign(subtotal) {
  const sub = Number(subtotal) || 0;
  if (sub <= 0) return null;
  let best = null;
  db.campaigns.all().forEach((c) => {
    if (!c.active) return;
    const min = Number(c.minTotal) || 0;
    if (sub < min) return;
    const val = Number(c.value) || 0;
    if (val <= 0) return;
    let amount = c.kind === "fixed" ? val : Math.round(sub * (val / 100) * 100) / 100;
    if (amount > sub) amount = sub; // indirim toplamı geçemez
    if (amount <= 0) return;
    if (!best || amount > best.amount) {
      best = { campaign: c, amount, label: c.name || describeCampaign(c) };
    }
  });
  return best;
}

// Kampanyayı okunur metne çevir (etiket/fiş için)
export function describeCampaign(c) {
  const val = Number(c.value) || 0;
  const min = Number(c.minTotal) || 0;
  const body = c.kind === "fixed" ? money(val) + " indirim" : "%" + val + " indirim";
  return (min > 0 ? money(min) + " üzeri " : "") + body;
}

export function renderCampaigns(host) {
  const body = el("div", {});
  const addBtn = el("button", { class: "btn success", onClick: () => form(null) }, ["+ " + t("add")]);
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🎯 " + t("navCampaigns") }), el("div", { class: "spacer" }), addBtn]),
    el("p", { class: "muted", style: "margin:0 0 12px", text: "Aktif kampanyalar kasada otomatik uygulanır. En yüksek indirim seçilir." }),
    body,
  );

  function draw() {
    clear(body);
    const rows = db.campaigns.all();
    if (!rows.length) {
      body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Henüz kampanya yok. Örn: “100 TL üzeri %10 indirim”." })]));
      return;
    }
    body.appendChild(el("div", { class: "camp-grid" }, rows.map((c) => {
      const on = !!c.active;
      return el("div", { class: "camp-card" + (on ? " camp-on" : "") }, [
        el("div", { style: "display:flex;align-items:center;gap:8px" }, [
          el("span", { class: "camp-badge", text: c.kind === "fixed" ? "₺ TL" : "% Yüzde" }),
          el("span", { class: "pill " + (on ? "green" : "amber"), text: on ? "Aktif" : "Pasif" }),
        ]),
        el("h3", { style: "margin:8px 0 2px", text: c.name || describeCampaign(c) }),
        el("div", { class: "muted", style: "font-size:13px", text: describeCampaign(c) }),
        el("div", { style: "display:flex;gap:8px;margin-top:12px" }, [
          el("button", { class: "btn ghost tiny", onClick: () => { db.campaigns.upsert({ ...c, active: !on }); toast(on ? "Pasif" : "Aktif", "success"); draw(); } }, [on ? "⏸ Durdur" : "▶ Başlat"]),
          el("button", { class: "btn ghost tiny", onClick: () => form(c) }, ["✏ " + t("edit")]),
          el("button", { class: "btn ghost tiny", onClick: () => confirmDialog(t("delete") + "?", () => { db.campaigns.remove(c.id); draw(); }) }, ["🗑"]),
        ]),
      ]);
    })));
  }

  function form(r) {
    const name = el("input", { class: "input", value: r ? (r.name || "") : "", placeholder: "Kampanya adı (örn. Hafta Sonu)" });
    const kind = el("select", { class: "input" }, [
      el("option", { value: "percent", text: "Yüzde indirim (%)" }),
      el("option", { value: "fixed", text: "Tutar indirim (TL)" }),
    ]);
    if (r) kind.value = r.kind || "percent";
    const value = el("input", { class: "input", type: "number", step: "0.01", value: r ? (r.value ?? "") : "", placeholder: "Değer (örn. 10)" });
    const minTotal = el("input", { class: "input", type: "number", step: "0.01", value: r ? (r.minTotal ?? "") : "", placeholder: "Alt sınır TL (0 = her sepet)" });
    const preview = el("div", { class: "muted", style: "margin-top:6px;font-weight:600" });
    const upd = () => {
      const c = { kind: kind.value, value: parseFloat(value.value) || 0, minTotal: parseFloat(minTotal.value) || 0 };
      preview.textContent = "Önizleme: " + describeCampaign(c);
    };
    [kind, value, minTotal].forEach((i) => i.addEventListener("input", upd)); upd();
    modal({
      title: r ? t("edit") : t("navCampaigns"),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: "Ad" }), name]),
        el("div", { class: "field" }, [el("label", { text: "Tür" }), kind]),
        el("div", { class: "field" }, [el("label", { text: "Değer" }), value]),
        el("div", { class: "field" }, [el("label", { text: "Alt sınır (TL)" }), minTotal]),
        preview,
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          const val = parseFloat(value.value) || 0;
          if (val <= 0) { toast("Değer girin", "warn"); return; }
          const row = r ? { ...r } : { id: uid(), active: true };
          row.name = name.value.trim();
          row.kind = kind.value;
          row.value = val;
          row.minTotal = parseFloat(minTotal.value) || 0;
          db.campaigns.upsert(row); toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }
  draw();
}
