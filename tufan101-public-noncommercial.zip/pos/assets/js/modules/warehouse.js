// Akıllı Depo Haritası — ürünlere raf/konum kodu atanır, depo görsel olarak
// bölgelere ayrılır. "Ürün nerede?" araması konumu vurgular. Konum ürünün
// `location` alanında tutulur (ör. "A1", "Raf-3", "Soğuk Oda").
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db } from "../core/store.js";

export function renderWarehouse(host) {
  const search = el("input", { class: "input", placeholder: "🔍 Ürün ara → konumunu bul", style: "max-width:280px" });
  const body = el("div", {});
  let highlight = "";

  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🗺️ " + t("navWarehouse") }), el("div", { class: "spacer" })]),
    el("div", { class: "card", style: "display:flex;gap:12px;flex-wrap:wrap;align-items:center" }, [
      search,
      el("span", { class: "muted", style: "font-size:13px", text: "Ürün kartına tıklayıp raf/konum atayın. Aynı konumdakiler bir bölgede toplanır." }),
    ]),
    body,
  );

  function draw() {
    clear(body);
    const products = db.products.all().filter((p) => p.active !== false);
    if (!products.length) { body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:16px", text: "Ürün yok." })])); return; }

    // Arama: eşleşen ürünlerin konumları
    const q = search.value.trim().toLowerCase();
    if (q) {
      const hits = products.filter((p) => (p.name || "").toLowerCase().includes(q));
      const found = el("div", { class: "card", style: "margin-bottom:14px" }, [
        el("h3", { style: "margin:0 0 8px", text: "🔎 Sonuç" }),
        ...(hits.length ? hits.slice(0, 12).map((p) => el("div", { class: "wh-hit", onClick: () => { highlight = p.location || ""; draw(); } }, [
          el("span", { text: (p.emoji || "📦") + " " + p.name }),
          el("span", { class: "pill " + (p.location ? "blue" : "amber"), text: p.location ? "📍 " + p.location : "Konum yok" }),
        ])) : [el("p", { class: "muted", text: "Eşleşme yok." })]),
      ]);
      body.appendChild(found);
    }

    // Konuma göre grupla
    const zones = {};
    products.forEach((p) => { const loc = (p.location || "").trim() || "— Atanmamış —"; (zones[loc] = zones[loc] || []).push(p); });
    const keys = Object.keys(zones).sort((a, b) => a === "— Atanmamış —" ? 1 : b === "— Atanmamış —" ? -1 : a.localeCompare(b, "tr"));

    const map = el("div", { class: "wh-map" });
    keys.forEach((loc) => {
      const items = zones[loc];
      const isHi = highlight && loc === highlight;
      map.appendChild(el("div", { class: "wh-zone" + (isHi ? " wh-hl" : "") + (loc === "— Atanmamış —" ? " wh-none" : "") }, [
        el("div", { class: "wh-zone-head" }, [el("b", { text: loc }), el("span", { class: "pill", text: items.length + " ürün" })]),
        el("div", { class: "wh-chips" }, items.map((p) => el("button", { class: "wh-chip", title: "Konum düzenle", onClick: () => editLoc(p, draw) }, [(p.emoji || "📦") + " " + (p.name || "Ürün")]))),
      ]));
    });
    body.appendChild(map);
  }

  function editLoc(p, after) {
    const inp = el("input", { class: "input", value: p.location || "", placeholder: "Örn. A1, Raf-3, Soğuk Oda", autofocus: true });
    // Mevcut konumlardan hızlı seçim
    const existing = [...new Set(db.products.all().map((x) => (x.location || "").trim()).filter(Boolean))];
    const chips = el("div", { style: "display:flex;gap:6px;flex-wrap:wrap;margin-top:8px" }, existing.map((loc) => el("button", { class: "btn ghost tiny", onClick: () => inp.value = loc }, [loc])));
    modal({
      title: "📍 Konum — " + (p.name || "Ürün"),
      body: el("div", {}, [el("div", { class: "field" }, [el("label", { text: "Raf / Konum kodu" }), inp]), existing.length ? el("div", {}, [el("label", { class: "muted", style: "font-size:12px", text: "Mevcut konumlar:" }), chips]) : el("span", {})]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => { db.products.upsert({ ...p, location: inp.value.trim() }); toast("Konum kaydedildi", "success"); close(); after && after(); } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  search.addEventListener("input", draw);
  draw();
}
