// Kasa & Banka — muhasebe hesap yönetimi (nakit kasa + banka hesapları)
// Bakiye tutar; POS satışı, gelir/gider, cari tahsilat ve tedarikçi ödemesi
// buraya para akıtır. Modüller "ada" değil, birbirine bağlı çalışır.
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import {
  db, money, uid, settings,
  ensureAccounts, listAccounts, accountBalance, postAccountMove,
} from "../core/store.js";

// Ödeme sağlayıcıları (banka hesabına bağlanabilir — canlı için sunucu tarafı gerekir)
const PROVIDERS = [
  { v: "", label: "Yok (sadece hesap)" },
  { v: "paytr", label: "PayTR" },
  { v: "iyzico", label: "iyzico" },
  { v: "param", label: "Param" },
  { v: "sipay", label: "Sipay" },
  { v: "other", label: "Diğer" },
];
const providerLabel = (v) => (PROVIDERS.find((p) => p.v === v) || {}).label || "";

// Hareket kaynağı → okunur etiket + renk
const SOURCE = {
  sale: { txt: "POS Satışı", cls: "blue" },
  income: { txt: "Gelir", cls: "green" },
  expense: { txt: "Gider", cls: "red" },
  cari: { txt: "Cari Tahsilat", cls: "green" },
  supplier: { txt: "Tedarikçi Ödeme", cls: "red" },
  transfer: { txt: "Transfer", cls: "violet" },
  manual: { txt: "Elle Kayıt", cls: "slate" },
};
const srcOf = (s) => SOURCE[s] || SOURCE.manual;

// ---- Hesap seçici (cari & tedarikçi modülleri de kullanır) ----
// Ödeme/tahsilat sırasında "Kasa mı, Banka mı?" sorusunu karşılar.
export function buildAccountSelect(preselectId, preferType) {
  ensureAccounts();
  const list = listAccounts();
  const sel = el("select", { class: "input" }, list.map((a) =>
    el("option", { value: a.id, ...(a.id === preselectId ? { selected: true } : {}) },
      [(a.type === "bank" ? "🏦 " : "💵 ") + a.name + " · " + money(accountBalance(a.id))])
  ));
  if (!preselectId && list.length) {
    const pref = preferType === "bank" ? list.find((a) => a.type === "bank") : list.find((a) => a.type === "cash");
    sel.value = (pref || list[0]).id;
  }
  return sel;
}

export function renderAccounts(host) {
  ensureAccounts();

  const head = el("div", { class: "view-head" }, [
    el("h1", { text: "🏦 " + t("navKasa") }),
    el("div", { class: "spacer" }),
    el("button", { class: "btn ghost", onClick: () => transferModal(refresh) }, ["↔ Transfer"]),
    el("button", { class: "btn success", onClick: () => accountForm(null, refresh) }, ["+ Hesap"]),
  ]);
  const body = el("div", {});
  clear(host).append(head, body);
  refresh();

  function refresh() {
    clear(body);
    const accs = listAccounts();

    // ---- Özet: toplam nakit / banka / genel ----
    const cash = accs.filter((a) => a.type === "cash").reduce((s, a) => s + accountBalance(a.id), 0);
    const bank = accs.filter((a) => a.type === "bank").reduce((s, a) => s + accountBalance(a.id), 0);
    body.appendChild(el("div", { class: "stat-grid" }, [
      statCard("💵 Toplam Nakit (Kasa)", money(cash), "var(--success)"),
      statCard("🏦 Toplam Banka", money(bank), "var(--primary)"),
      statCard("Σ Genel Toplam", money(cash + bank), cash + bank >= 0 ? "#7C3AED" : "var(--danger)"),
    ]));

    // ---- Hesap kartları ----
    const cards = el("div", { class: "acc-grid" });
    accs.forEach((a) => {
      const bal = accountBalance(a.id);
      const sub = a.type === "bank"
        ? [a.bankName, a.iban].filter(Boolean).join(" · ") || "Banka hesabı"
        : "Nakit kasa";
      cards.appendChild(el("div", { class: "acc-card" }, [
        el("div", { class: "acc-card-top" }, [
          el("span", { class: "acc-ico", text: a.type === "bank" ? "🏦" : "💵" }),
          el("div", { style: "flex:1" }, [
            el("div", { class: "acc-name", text: a.name }),
            el("div", { class: "muted", style: "font-size:12px", text: sub }),
          ]),
          a.provider ? el("span", { class: "pill violet", text: "⚡ " + providerLabel(a.provider) }) : null,
        ]),
        el("div", { class: "acc-bal num", style: "color:" + (bal >= 0 ? "var(--success)" : "var(--danger)"), text: money(bal) }),
        el("div", { class: "acc-actions" }, [
          el("button", { class: "btn ghost tiny", onClick: () => moveModal(a, "in", refresh) }, ["+ Giriş"]),
          el("button", { class: "btn ghost tiny", onClick: () => moveModal(a, "out", refresh) }, ["− Çıkış"]),
          el("button", { class: "btn ghost tiny", onClick: () => accountForm(a, refresh) }, ["⚙ Düzenle"]),
          (a.type === "bank" && a.provider) ? el("button", { class: "btn ghost tiny", onClick: () => payLinkModal(a) }, ["🔗 Ödeme Linki"]) : null,
        ]),
      ]));
    });
    body.appendChild(cards);

    // ---- Hareket defteri ----
    const moves = db.accountMoves.all().sort((a, b) => b.ts - a.ts).slice(0, 60);
    const nameOf = (id) => { const a = db.accounts.get(id); return a ? a.name : "—"; };
    body.appendChild(el("div", { class: "card", style: "margin-top:16px" }, [
      el("div", { class: "card-head" }, [el("h3", { text: "📒 Hesap Hareketleri" }), el("span", { class: "pill slate", text: db.accountMoves.all().length + " kayıt" })]),
      moves.length ? el("table", { class: "tbl" }, [
        el("thead", {}, [el("tr", {}, ["Tarih", "Hesap", "Kaynak", "Açıklama", "Tutar", ""].map((h) => el("th", { text: h })))]),
        el("tbody", {}, moves.map((m) => {
          const s = srcOf(m.source);
          return el("tr", {}, [
            el("td", { class: "muted", style: "font-size:12px;white-space:nowrap", text: new Date(m.ts).toLocaleString("tr-TR", { day: "2-digit", month: "2-digit", hour: "2-digit", minute: "2-digit" }) }),
            el("td", { text: nameOf(m.accountId) }),
            el("td", {}, [el("span", { class: "pill " + s.cls, text: s.txt })]),
            el("td", { style: "font-size:13px", text: [m.party, m.note].filter(Boolean).join(" — ") || "—" }),
            el("td", { class: "num", style: "font-weight:800;color:" + (m.dir === "in" ? "var(--success)" : "var(--danger)"), text: (m.dir === "in" ? "+ " : "− ") + money(m.amount) }),
            el("td", { style: "text-align:right" }, [
              el("button", { class: "iconbtn", title: t("delete"), onClick: () => confirmDialog("Bu hareketi sil?", () => { db.accountMoves.remove(m.id); toast(t("delete"), "warn"); refresh(); }) }, ["🗑"]),
            ]),
          ]);
        })),
      ]) : el("p", { class: "muted", style: "padding:14px", text: "Henüz hareket yok. POS satışı, gelir/gider, cari tahsilat ve tedarikçi ödemeleri otomatik buraya işlenir." }),
    ]));
  }
}

// ---- Hesap ekle / düzenle ----
function accountForm(existing, done) {
  const a0 = existing || {};
  const name = el("input", { class: "input", value: a0.name || "", placeholder: "Örn. Ana Kasa / Ziraat Vadesiz", autofocus: true });
  const type = el("select", { class: "input" }, [
    el("option", { value: "cash", ...(a0.type !== "bank" ? { selected: true } : {}) }, ["💵 Nakit Kasa"]),
    el("option", { value: "bank", ...(a0.type === "bank" ? { selected: true } : {}) }, ["🏦 Banka Hesabı"]),
  ]);
  const opening = el("input", { class: "input num", type: "number", step: "0.01", value: a0.opening != null ? a0.opening : "", placeholder: "Açılış bakiyesi (₺)" });
  const bankName = el("input", { class: "input", value: a0.bankName || "", placeholder: "Banka adı (örn. Ziraat)" });
  const iban = el("input", { class: "input", value: a0.iban || "", placeholder: "TR__ ____ ____ ____ ____ ____ __" });
  const provider = el("select", { class: "input" }, PROVIDERS.map((p) => el("option", { value: p.v, ...(p.v === (a0.provider || "") ? { selected: true } : {}) }, [p.label])));
  const merchantId = el("input", { class: "input", value: a0.merchantId || "", placeholder: "Üye işyeri no / Merchant ID" });
  const merchantKey = el("input", { class: "input", type: "password", value: a0.merchantKey || "", placeholder: "API anahtarı / Merchant Key" });

  const bankBox = el("div", {}, [
    field("Banka Adı", bankName),
    field("IBAN", iban),
    el("div", { style: "font-weight:700;margin:8px 0 4px", text: "⚡ Sanal POS / Ödeme Sağlayıcı" }),
    el("p", { class: "muted", style: "font-size:12px;margin:0 0 6px", text: "PayTR, iyzico vb. Buraya üye işyeri bilgilerinizi girin. Canlı tahsilat için sunucu (PHP) tarafı entegrasyon gerekir; bilgiler burada güvenle saklanır." }),
    field("Sağlayıcı", provider),
    el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:10px" }, [field("Merchant ID", merchantId), field("Merchant Key", merchantKey)]),
  ]);
  const syncBankVis = () => { bankBox.style.display = type.value === "bank" ? "" : "none"; };
  type.addEventListener("change", syncBankVis); syncBankVis();

  modal({
    title: existing ? "⚙ Hesabı Düzenle" : "+ Yeni Hesap",
    body: el("div", {}, [
      field("Hesap Adı", name),
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:10px" }, [field("Tür", type), field("Açılış Bakiyesi", opening)]),
      bankBox,
    ]),
    actions: [
      existing ? { label: "Sil", kind: "danger", onClick: (close) => { close(); confirmDialog("Hesabı sil? (Hareketler kalır)", () => { db.accounts.remove(a0.id); toast(t("delete"), "warn"); done && done(); }); } } : null,
      { label: t("save"), kind: "success", onClick: (close) => {
        if (!name.value.trim()) { toast("Hesap adı gerekli", "warn"); return; }
        const isBank = type.value === "bank";
        db.accounts.upsert({
          id: a0.id || uid(), name: name.value.trim(), type: type.value,
          opening: parseFloat(opening.value) || 0, active: true, order: a0.order || 0,
          bankName: isBank ? bankName.value.trim() : "", iban: isBank ? iban.value.trim().toUpperCase() : "",
          provider: isBank ? provider.value : "", merchantId: isBank ? merchantId.value.trim() : "", merchantKey: isBank ? merchantKey.value.trim() : "",
        });
        toast(t("save"), "success"); close(); done && done();
      } },
      { label: t("cancel"), kind: "ghost" },
    ].filter(Boolean),
  });
}

// ---- Elle giriş / çıkış ----
function moveModal(acc, dir, done) {
  const amount = el("input", { class: "input num", type: "number", step: "0.01", autofocus: true, placeholder: "Tutar" });
  const note = el("input", { class: "input", placeholder: "Açıklama (örn. Kasa devri, banka masrafı)" });
  modal({
    title: (dir === "in" ? "+ Giriş — " : "− Çıkış — ") + acc.name,
    body: el("div", {}, [field("Tutar", amount), field("Açıklama", note)]),
    actions: [
      { label: t("save"), kind: dir === "in" ? "success" : "danger", onClick: (close) => {
        const a = parseFloat(amount.value); if (!a || a <= 0) { toast("Tutar?", "warn"); return; }
        postAccountMove({ accountId: acc.id, dir, amount: a, source: "manual", note: note.value.trim() });
        toast("İşlendi", "success"); close(); done && done();
      } },
      { label: t("cancel"), kind: "ghost" },
    ],
  });
}

// ---- Hesaplar arası transfer ----
function transferModal(done) {
  const accs = listAccounts();
  if (accs.length < 2) { toast("Transfer için en az 2 hesap gerekir.", "warn"); return; }
  const from = el("select", { class: "input" }, accs.map((a) => el("option", { value: a.id }, [a.name + " · " + money(accountBalance(a.id))])));
  const to = el("select", { class: "input" }, accs.map((a) => el("option", { value: a.id }, [a.name + " · " + money(accountBalance(a.id))])));
  to.value = accs[1].id;
  const amount = el("input", { class: "input num", type: "number", step: "0.01", placeholder: "Tutar" });
  const note = el("input", { class: "input", placeholder: "Açıklama (opsiyonel)" });
  modal({
    title: "↔ Hesaplar Arası Transfer",
    body: el("div", {}, [
      el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:10px" }, [field("Kaynak", from), field("Hedef", to)]),
      field("Tutar", amount), field("Açıklama", note),
    ]),
    actions: [
      { label: "Transfer Et", kind: "success", onClick: (close) => {
        const a = parseFloat(amount.value); if (!a || a <= 0) { toast("Tutar?", "warn"); return; }
        if (from.value === to.value) { toast("Kaynak ve hedef aynı olamaz.", "warn"); return; }
        const ref = uid();
        const fn = db.accounts.get(from.value)?.name || "", tn = db.accounts.get(to.value)?.name || "";
        postAccountMove({ accountId: from.value, dir: "out", amount: a, source: "transfer", refId: ref, note: "→ " + tn, party: note.value.trim() });
        postAccountMove({ accountId: to.value, dir: "in", amount: a, source: "transfer", refId: ref, note: "← " + fn, party: note.value.trim() });
        toast("Transfer yapıldı", "success"); close(); done && done();
      } },
      { label: t("cancel"), kind: "ghost" },
    ],
  });
}

// ---- Ödeme linki (dürüst taslak — canlı için sunucu entegrasyonu gerekir) ----
function payLinkModal(acc) {
  const amount = el("input", { class: "input num", type: "number", step: "0.01", placeholder: "Tahsil edilecek tutar" });
  const desc = el("input", { class: "input", placeholder: "Açıklama (sipariş no vb.)" });
  modal({
    title: "🔗 Ödeme Linki — " + providerLabel(acc.provider),
    body: el("div", {}, [
      el("p", { class: "muted", style: "font-size:13px", text: "Bu banka hesabına " + providerLabel(acc.provider) + " sağlayıcısı tanımlı. Canlı ödeme linki üretimi için üye işyeri anahtarlarınızla sunucu (PHP) tarafı entegrasyon devreye alınmalıdır." }),
      field("Tutar", amount), field("Açıklama", desc),
      acc.merchantId ? el("p", { class: "muted", style: "font-size:12px", text: "Merchant ID: " + acc.merchantId }) : el("p", { class: "pill amber", style: "margin-top:8px", text: "Merchant ID/Key girilmemiş — hesabı düzenleyip ekleyin." }),
    ]),
    actions: [
      { label: "Bilgi", kind: "ghost" },
    ],
  });
}

// ---- Küçük yardımcılar ----
function field(label, node) { return el("div", { class: "field" }, [el("label", { text: label }), node]); }
function statCard(label, value, color) {
  return el("div", { class: "stat", style: `border-left:6px solid ${color}` }, [
    el("div", { class: "label", text: label }),
    el("div", { class: "value num", style: "color:" + color, text: value }),
  ]);
}
