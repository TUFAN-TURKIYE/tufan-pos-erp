// Şubeler Arası Karşılaştırma — satışları branchId'ye göre gruplar, kıyaslar.
// Ciro, sipariş adedi, sepet ortalaması; çubuk grafik + sıralı tablo.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money } from "../core/store.js";

const DAY = 86400000;

export function renderBranchCompare(host) {
  const periodSel = el("select", { class: "input", style: "max-width:180px" }, [
    el("option", { value: "7", text: "Son 7 gün" }),
    el("option", { value: "30", text: "Son 30 gün", selected: true }),
    el("option", { value: "0", text: "Tüm zamanlar" }),
  ]);
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🏪 " + t("navBranchCompare") }), el("div", { class: "spacer" }), periodSel]),
    body,
  );

  function branchName(id) {
    if (!id) return "Merkez / Tanımsız";
    const b = db.branches.get(id);
    return b ? (b.name || b.title || "Şube") : "Şube " + String(id).slice(-4);
  }

  function draw() {
    clear(body);
    const days = Number(periodSel.value);
    const from = days > 0 ? Date.now() - days * DAY : 0;
    const sales = db.sales.all().filter((s) => !s.void && Number(s.ts) >= from);

    if (!sales.length) {
      body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Bu dönemde satış verisi yok." })]));
      return;
    }

    const map = {}; // branchId → {rev, n}
    sales.forEach((s) => {
      const id = s.branchId || "";
      if (!map[id]) map[id] = { rev: 0, n: 0 };
      map[id].rev += Number(s.total || 0); map[id].n++;
    });

    const rows = Object.entries(map).map(([id, d]) => ({ id, name: branchName(id), rev: d.rev, n: d.n, basket: d.n ? d.rev / d.n : 0 }))
      .sort((a, b) => b.rev - a.rev);

    if (rows.length === 1) {
      body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:14px", text: "ℹ️ Tek şube/kaynak var. Şube modülünden şube ekleyip satışlara şube atadığınızda karşılaştırma zenginleşir." })]));
    }

    const totalRev = rows.reduce((a, r) => a + r.rev, 0);
    const maxRev = Math.max(...rows.map((r) => r.rev), 1);

    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Toplam Ciro" }), el("div", { class: "smart-val num", text: money(totalRev) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Şube/Kaynak" }), el("div", { class: "smart-val num", text: String(rows.length) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Lider Şube" }), el("div", { class: "smart-val", style: "font-size:22px", text: rows[0].name })]),
    ]));

    const chart = el("div", { class: "card" }, [el("h3", { text: "📊 Ciro Karşılaştırması" })]);
    rows.forEach((r) => {
      const share = totalRev ? Math.round(r.rev / totalRev * 100) : 0;
      chart.appendChild(el("div", { class: "smart-bar-row" }, [
        el("div", { class: "smart-bar-top" }, [el("span", { text: r.name }), el("b", { class: "num", text: money(r.rev) + "  ·  %" + share })]),
        el("div", { class: "smart-bar" }, [el("div", { class: "smart-bar-fill", style: "width:" + Math.max(6, Math.round(r.rev / maxRev * 100)) + "%" })]),
        el("div", { class: "muted", style: "font-size:12px", text: r.n + " satış · " + money(r.basket) + " sepet ort." }),
      ]));
    });
    body.appendChild(chart);
  }

  periodSel.addEventListener("change", draw);
  draw();
}
