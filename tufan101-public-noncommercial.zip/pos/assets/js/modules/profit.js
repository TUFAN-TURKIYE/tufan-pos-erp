// Karlılık Haritası — ürünleri kâr marjına göre 🟢🟡🔴 renklendirir.
// Ürüne maliyet (cost) girilir; satış fiyatına göre marj hesaplanır.
// 🟢 yüksek marj (≥%40) · 🟡 orta (%15–40) · 🔴 düşük (<%15) · ⚪ maliyet girilmemiş.
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money } from "../core/store.js";
import { logAudit } from "./audit.js";

const DAY = 86400000;

function marginPct(price, cost) {
  price = Number(price) || 0; cost = Number(cost) || 0;
  if (price <= 0) return 0;
  return Math.round((price - cost) / price * 100);
}
function band(price, cost) {
  if (cost == null || cost === "" || Number(cost) <= 0) return { key: "none", cls: "prof-none", label: "Maliyet yok" };
  const m = marginPct(price, cost);
  if (m >= 40) return { key: "hi", cls: "prof-hi", label: "🟢 Yüksek" };
  if (m >= 15) return { key: "mid", cls: "prof-mid", label: "🟡 Orta" };
  return { key: "lo", cls: "prof-lo", label: "🔴 Düşük" };
}

// Son 30 günde ürün başına satılan adet (kâr katkısı için)
function soldQtyMap() {
  const map = {};
  const from = Date.now() - 30 * DAY;
  db.sales.all().filter((s) => !s.void && Number(s.ts) >= from).forEach((s) => {
    (s.items || []).forEach((it) => { if (it.productId) map[it.productId] = (map[it.productId] || 0) + (Number(it.qty) || 1); });
  });
  return map;
}

export function renderProfit(host) {
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "💹 " + t("navProfit") }), el("div", { class: "spacer" })]),
    body,
  );

  function draw() {
    clear(body);
    const products = db.products.all().filter((p) => p.active !== false);
    if (!products.length) {
      body.appendChild(el("div", { class: "card" }, [el("p", { class: "muted", style: "padding:18px", text: "Ürün yok. Önce Stok modülünden ürün ekleyin." })]));
      return;
    }
    const sold = soldQtyMap();

    // Özet: kategori bazında dağılım + toplam potansiyel kâr
    let hi = 0, mid = 0, lo = 0, none = 0, profit30 = 0;
    products.forEach((p) => {
      const b = band(p.price, p.cost);
      if (b.key === "hi") hi++; else if (b.key === "mid") mid++; else if (b.key === "lo") lo++; else none++;
      if (Number(p.cost) > 0) profit30 += (Number(p.price) - Number(p.cost)) * (sold[p.id] || 0);
    });

    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "🟢 Yüksek marj" }), el("div", { class: "smart-val num", text: String(hi) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "🟡 Orta marj" }), el("div", { class: "smart-val num", text: String(mid) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "🔴 Düşük marj" }), el("div", { class: "smart-val num", text: String(lo) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "💰 Tahmini kâr (30g)" }), el("div", { class: "smart-val num", text: money(profit30) })]),
    ]));

    if (none) body.appendChild(el("p", { class: "muted", style: "margin:10px 2px", text: "ℹ️ " + none + " üründe maliyet girilmemiş — marj hesaplanamıyor. Karta tıklayıp maliyet girin." }));

    // Marja göre sırala (düşük marj üstte — dikkat çeksin)
    const rank = { lo: 0, mid: 1, hi: 2, none: 3 };
    const sorted = products.slice().sort((a, b) => rank[band(a.price, a.cost).key] - rank[band(b.price, b.cost).key]);

    const grid = el("div", { class: "prof-grid" });
    sorted.forEach((p) => {
      const b = band(p.price, p.cost);
      const m = marginPct(p.price, p.cost);
      const hasCost = Number(p.cost) > 0;
      grid.appendChild(el("div", { class: "prof-card " + b.cls, onClick: () => editCost(p, draw), title: "Maliyet düzenle" }, [
        el("div", { class: "prof-name", text: (p.emoji || "📦") + " " + (p.name || "Ürün") }),
        el("div", { class: "prof-margin num", text: hasCost ? "%" + m : "—" }),
        el("div", { class: "prof-meta", text: hasCost ? money(p.cost) + " → " + money(p.price) : "Maliyet girilmedi" }),
        el("div", { class: "prof-band", text: b.label }),
        (sold[p.id] ? el("div", { class: "muted", style: "font-size:11px;margin-top:4px", text: sold[p.id] + " adet/30g" }) : el("span", {})),
      ]));
    });
    body.appendChild(grid);
  }

  draw();
}

function editCost(p, after) {
  const costInp = el("input", { class: "input num", type: "number", step: "0.01", value: p.cost != null ? p.cost : "", placeholder: "Alış/üretim maliyeti" });
  const priceInp = el("input", { class: "input num", type: "number", step: "0.01", value: p.price != null ? p.price : "", placeholder: "Satış fiyatı" });
  const preview = el("div", { class: "muted", style: "margin-top:8px;font-size:14px" });
  const refresh = () => {
    const c = Number(costInp.value) || 0, pr = Number(priceInp.value) || 0;
    if (c > 0 && pr > 0) { const m = marginPct(pr, c); preview.textContent = "Marj: %" + m + "  ·  Birim kâr: " + money(pr - c) + "  ·  " + band(pr, c).label; }
    else preview.textContent = "Maliyet ve fiyat girin.";
  };
  costInp.addEventListener("input", refresh); priceInp.addEventListener("input", refresh); refresh();

  modal({
    title: "💹 " + (p.name || "Ürün") + " — Maliyet & Marj",
    body: el("div", {}, [
      el("div", { class: "field" }, [el("label", { text: "Maliyet (alış/üretim)" }), costInp]),
      el("div", { class: "field" }, [el("label", { text: "Satış fiyatı" }), priceInp]),
      preview,
    ]),
    actions: [
      { label: t("save"), kind: "success", onClick: (close) => {
        const newCost = parseFloat(costInp.value) || 0;
        const newPrice = parseFloat(priceInp.value) || 0;
        const changed = newCost !== (Number(p.cost) || 0) || newPrice !== (Number(p.price) || 0);
        db.products.upsert({ ...p, cost: newCost, price: newPrice });
        if (changed) logAudit("price", "product:" + p.id, (p.name || "Ürün") + " · maliyet " + money(newCost) + " · fiyat " + money(newPrice));
        toast("Kaydedildi", "success"); close(); after && after();
      } },
      { label: t("cancel"), kind: "ghost" },
    ],
  });
}
