// Gider Bütçe Takibi — kategori bazlı aylık bütçe belirle, gerçekleşen giderle karşılaştır.
// Bütçeler settings.budgets = { "2026-07": { "Kira": 15000, ... } } yapısında saklanır.
// Gerçekleşen giderler db.txns (type:"expense") üzerinden aya göre toplanır.
import { el, clear, toast, modal } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

function ymOf(ts) { const d = new Date(ts); return d.getFullYear() + "-" + String(d.getMonth() + 1).padStart(2, "0"); }
function curYm() { return ymOf(Date.now()); }
function getBudgets() { const s = settings.get(); return (s.budgets && typeof s.budgets === "object") ? s.budgets : {}; }
function saveBudgets(b) { settings.set({ budgets: b }); }

// O aya ait kategori→gerçekleşen gider haritası
function actualByCat(ym) {
  const map = {};
  db.txns.all().forEach((x) => {
    if ((x.type || "") !== "expense") return;
    if (ymOf(x.ts) !== ym) return;
    const cat = (x.category || "Diğer").trim() || "Diğer";
    map[cat] = (map[cat] || 0) + (Number(x.amount) || 0);
  });
  return map;
}

export function renderBudget(host) {
  let ym = curYm();

  const monthInput = el("input", { type: "month", class: "input", value: ym, style: "max-width:180px" });
  monthInput.addEventListener("change", () => { ym = monthInput.value || curYm(); draw(); });

  const addBtn = el("button", { class: "btn", onClick: () => editCat() }, ["➕ Bütçe Ekle"]);

  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [el("h1", { text: "🎯 " + t("navBudget") }), el("div", { class: "spacer" }), monthInput, addBtn]),
    body,
  );

  function editCat(name) {
    const budgets = getBudgets();
    const cur = budgets[ym] || {};
    const nameInp = el("input", { class: "input", placeholder: "Kategori (örn. Kira, Elektrik)", value: name || "" });
    const amtInp = el("input", { class: "input", type: "number", placeholder: "Aylık bütçe ₺", value: name ? (cur[name] || "") : "" });
    if (name) nameInp.disabled = true;
    const close = modal({
      title: name ? "✏️ " + name : "➕ Yeni Bütçe Kalemi",
      body: el("div", { style: "display:grid;gap:10px" }, [
        el("label", { class: "muted", style: "font-size:12px", text: "Kategori adı" }), nameInp,
        el("label", { class: "muted", style: "font-size:12px", text: "Aylık bütçe (" + ym + ")" }), amtInp,
      ]),
      actions: [
        name ? { label: "🗑 Sil", kind: "ghost", onClick: (c) => { const b = getBudgets(); if (b[ym]) { delete b[ym][name]; saveBudgets(b); } toast("Silindi", "success"); c(); draw(); } } : null,
        { label: t("cancel"), kind: "ghost" },
        { label: "💾 Kaydet", kind: "success", onClick: (c) => {
          const nm = nameInp.value.trim(); const amt = Number(amtInp.value) || 0;
          if (!nm) { toast("Kategori adı gerekli", "warn"); return; }
          const b = getBudgets(); if (!b[ym]) b[ym] = {}; b[ym][nm] = amt; saveBudgets(b);
          toast("Bütçe kaydedildi", "success"); c(); draw();
        } },
      ].filter(Boolean),
    });
    return close;
  }

  function draw() {
    clear(body);
    const budgets = getBudgets();
    const planned = budgets[ym] || {};
    const actual = actualByCat(ym);

    // Bütçesi olmayan ama gideri olan kategorileri de göster
    const cats = Array.from(new Set([...Object.keys(planned), ...Object.keys(actual)])).sort();

    const totalPlan = Object.values(planned).reduce((a, v) => a + (Number(v) || 0), 0);
    const totalAct = cats.reduce((a, c) => a + (actual[c] || 0), 0);
    const remain = totalPlan - totalAct;

    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Planlanan Bütçe" }), el("div", { class: "smart-val num", text: money(totalPlan) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Gerçekleşen Gider" }), el("div", { class: "smart-val num", text: money(totalAct) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: remain >= 0 ? "Kalan Bütçe" : "Bütçe Aşımı" }), el("div", { class: "smart-val num", style: "color:" + (remain >= 0 ? "var(--ok,#16a34a)" : "var(--danger,#dc2626)"), text: money(Math.abs(remain)) })]),
    ]));

    if (!cats.length) {
      body.appendChild(el("p", { class: "muted", style: "padding:16px", text: "Bu ay için bütçe kalemi yok. '➕ Bütçe Ekle' ile başlayın." }));
      return;
    }

    const list = el("div", { class: "bud-list" });
    cats.forEach((c) => {
      const plan = Number(planned[c]) || 0;
      const act = actual[c] || 0;
      const pct = plan > 0 ? Math.min(999, Math.round((act / plan) * 100)) : (act > 0 ? 100 : 0);
      const over = plan > 0 && act > plan;
      const noPlan = plan <= 0;
      const barCls = over ? "over" : (pct >= 85 ? "warn" : "ok");
      list.appendChild(el("div", { class: "bud-row" + (over ? " over" : ""), onClick: () => editCat(c) }, [
        el("div", { class: "bud-top" }, [
          el("div", { class: "bud-name", text: c }),
          el("div", { class: "bud-nums num", text: money(act) + (noPlan ? " (bütçesiz)" : " / " + money(plan)) }),
        ]),
        el("div", { class: "bud-bar" }, [el("div", { class: "bud-fill " + barCls, style: "width:" + Math.min(100, pct) + "%" })]),
        el("div", { class: "bud-foot" }, [
          el("span", { class: "muted", style: "font-size:11px", text: noPlan ? "Bütçe belirlenmemiş" : "%" + pct + " kullanıldı" }),
          el("span", { class: "muted", style: "font-size:11px", text: over ? "⚠️ " + money(act - plan) + " aşım" : (noPlan ? "" : money(plan - act) + " kaldı") }),
        ]),
      ]));
    });
    body.appendChild(list);
  }

  draw();
}
