// mod-01 "Tek Bakışta Kasa" — patron özet ekranı (yeniden tasarım)
import { el, clear, modal, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, todaySales, money, lowStockProducts, todayRange, settings } from "../core/store.js";
import { navigate } from "../core/nav.js";

export function renderDashboard(host) {
  const s = settings.get();
  const sales = todaySales();
  const revenue = sales.reduce((a, x) => a + (Number(x.total) || 0), 0);
  const low = lowStockProducts();
  const start = todayRange();
  const txns = db.txns.all().filter((x) => x.ts >= start);
  const incomeExtra = txns.filter((x) => x.type === "income").reduce((a, x) => a + (Number(x.amount) || 0), 0);
  const expense = txns.filter((x) => x.type === "expense").reduce((a, x) => a + (Number(x.amount) || 0), 0);
  const cashIn = revenue + incomeExtra - expense;
  const avgTicket = sales.length ? revenue / sales.length : 0;

  // Dünkü ciro (karşılaştırma için)
  const yStart = start - 86400000;
  const yRevenue = db.sales.all().filter((x) => !x.void && x.ts >= yStart && x.ts < start).reduce((a, x) => a + (Number(x.total) || 0), 0);
  const trend = yRevenue > 0 ? Math.round(((revenue - yRevenue) / yRevenue) * 100) : (revenue > 0 ? 100 : 0);

  const now = new Date();
  const hour = now.getHours();
  const greet = hour < 6 ? "İyi geceler" : hour < 12 ? "Günaydın" : hour < 18 ? "İyi günler" : "İyi akşamlar";
  const dateStr = now.toLocaleDateString("tr-TR", { weekday: "long", day: "numeric", month: "long", year: "numeric" });

  // ---- Hero ----
  host.appendChild(el("div", { class: "dash-hero" }, [
    el("div", {}, [
      el("div", { class: "dash-hero-greet", text: greet + " 👋" }),
      el("h1", { class: "dash-hero-title", text: s.business || "İşletmem" }),
      el("div", { class: "dash-hero-date", text: dateStr }),
    ]),
    el("div", { class: "dash-hero-badge" }, [
      el("div", { class: "dash-hero-badge-lbl", text: "BUGÜNKÜ CİRO" }),
      el("div", { class: "dash-hero-badge-val num", text: money(revenue) }),
      el("div", { class: "dash-trend " + (trend >= 0 ? "up" : "down") }, [
        el("span", { text: (trend >= 0 ? "▲ " : "▼ ") + Math.abs(trend) + "%" }),
        el("span", { class: "muted", style: "font-weight:500", text: " düne göre" }),
      ]),
    ]),
  ]));

  // ---- KPI kartları ----
  host.appendChild(el("div", { class: "kpi-grid" }, [
    kpi("💰", t("todaySales") || "Bugün Ciro", money(revenue), sales.length + " işlem", "blue"),
    kpi("🪙", t("cashInDrawer") || "Kasa", money(cashIn), "net akış", "green"),
    kpi("🧾", "Ort. Sepet", money(avgTicket), "işlem başına", "violet"),
    kpi("💸", t("navExpense") || "Bugün Gider", money(expense), txns.filter((x) => x.type === "expense").length + " kayıt", "amber"),
    kpi("⚠️", t("lowStock") || "Düşük Stok", String(low.length), "ürün kritik", low.length ? "red" : "slate"),
  ]));

  // ---- Şu an çalışan personel (vardiyada) ----
  host.appendChild(onShiftWidget());

  // ---- Hızlı işlemler ----
  const quick = el("div", { class: "quick-row" }, [
    quickBtn("🛒", "Satış Yap", "pos"),
    quickBtn("📦", "Ürünler", "products"),
    quickBtn("💰", "Gelir", "income"),
    quickBtn("💸", "Gider", "expense"),
    quickBtn("📋", "Raporlar", "reports"),
  ]);
  host.appendChild(quick);

  // ---- 7 günlük satış grafiği (daha okunur: ortalama çizgisi + en iyi gün) ----
  const days = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - i);
    const from = d.getTime(), to = from + 86400000;
    const total = db.sales.all().filter((x) => !x.void && x.ts >= from && x.ts < to).reduce((a, x) => a + (Number(x.total) || 0), 0);
    days.push({ label: d.toLocaleDateString("tr-TR", { weekday: "short" }), total, today: i === 0 });
  }
  const weekTotal = days.reduce((a, d) => a + d.total, 0);
  const dayAvg = weekTotal / 7;
  const chartMax = Math.max(1, ...days.map((d) => d.total), dayAvg);
  const PLOT = 150;               // grafik çizim yüksekliği (px)
  const LBL = 22;                 // gün etiketi alanı (px)
  const bestIdx = days.reduce((bi, d, i, a) => (d.total > a[bi].total ? i : bi), 0);
  const avgBottom = LBL + Math.round((dayAvg / chartMax) * PLOT);

  const plot = el("div", { class: "tchart-plot", style: `height:${PLOT + LBL + 20}px` }, [
    dayAvg > 0 ? el("div", { class: "tchart-avg", style: `bottom:${avgBottom}px` }, [
      el("span", { class: "tchart-avg-tag", text: "Ort " + shortMoney(dayAvg) }),
    ]) : null,
    ...days.map((d, i) => {
      const h = Math.max(4, Math.round((d.total / chartMax) * PLOT));
      const cls = "tchart-bar" + (d.today ? " is-today" : "") + (i === bestIdx && d.total > 0 ? " is-best" : "");
      return el("div", { class: "tchart-col" }, [
        el("div", { class: "tchart-val num", text: d.total ? shortMoney(d.total) : "" }),
        el("div", { class: cls, style: `height:${h}px`, title: d.label + ": " + money(d.total) }),
        el("div", { class: "tchart-lbl", text: d.label }),
      ]);
    }),
  ]);

  host.appendChild(el("div", { class: "card dash-chart" }, [
    el("div", { class: "card-head" }, [
      el("h3", { text: "📈 Son 7 Gün Satış" }),
      el("span", { class: "pill blue", text: "Toplam " + money(weekTotal) }),
    ]),
    plot,
    el("div", { class: "tchart-legend" }, [
      el("span", {}, [el("i", { class: "lg-dot lg-avg" }), el("span", { text: "Günlük ort. " + money(dayAvg) })]),
      el("span", {}, [el("i", { class: "lg-dot lg-best" }), el("span", { text: "En iyi: " + days[bestIdx].label + " (" + money(days[bestIdx].total) + ")" })]),
      el("span", {}, [el("i", { class: "lg-dot lg-today" }), el("span", { text: "Bugün" })]),
    ]),
  ]));

  // ---- Bugün ödeme dağılımı (nakit / kart) — anlaşılır oran çubukları ----
  host.appendChild(paymentSplitCard(sales));

  // ---- İki sütun: En çok satanlar + Son satışlar ----
  const cols = el("div", { class: "dash-cols" });

  // En çok satanlar (bugün)
  const prodMap = new Map();
  sales.forEach((sale) => (sale.items || []).forEach((it) => {
    const key = it.name || it.productId || "?";
    const cur = prodMap.get(key) || { name: key, qty: 0, total: 0 };
    cur.qty += Number(it.qty) || 0;
    cur.total += (Number(it.qty) || 0) * (Number(it.price) || 0);
    prodMap.set(key, cur);
  }));
  const topProducts = [...prodMap.values()].sort((a, b) => b.qty - a.qty).slice(0, 6);
  cols.appendChild(el("div", { class: "card" }, [
    el("div", { class: "card-head" }, [el("h3", { text: "🔥 Bugün En Çok Satanlar" })]),
    topProducts.length
      ? el("div", { class: "mini-list" }, topProducts.map((p, i) =>
          el("div", { class: "mini-row" }, [
            el("span", { class: "rank rank-" + (i < 3 ? i + 1 : "n"), text: String(i + 1) }),
            el("span", { class: "mini-name", text: p.name }),
            el("span", { class: "pill slate", text: p.qty + " adet" }),
            el("b", { class: "num", text: money(p.total) }),
          ])
        ))
      : emptyState("Bugün henüz satış yok."),
  ]));

  // Son satışlar
  const recent = db.sales.all().filter((x) => !x.void).sort((a, b) => b.ts - a.ts).slice(0, 6);
  cols.appendChild(el("div", { class: "card" }, [
    el("div", { class: "card-head" }, [el("h3", { text: "🧾 Son Satışlar" })]),
    recent.length
      ? el("div", { class: "mini-list" }, recent.map((r) =>
          el("div", { class: "mini-row" }, [
            el("span", { class: "mini-ico", text: r.method === "card" ? "💳" : "💵" }),
            el("span", { class: "mini-name" }, [
              el("div", { text: (r.items || []).length + " ürün" }),
              el("div", { class: "muted", style: "font-size:12px", text: new Date(r.ts).toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" }) + (r.cashierName ? " · " + r.cashierName : "") }),
            ]),
            el("b", { class: "num", style: "margin-left:auto;color:var(--success)", text: money(r.total) }),
          ])
        ))
      : emptyState("Henüz satış kaydı yok."),
  ]));
  host.appendChild(cols);

  // ---- Düşük stok ----
  if (low.length) {
    host.appendChild(el("div", { class: "card dash-lowstock" }, [
      el("div", { class: "card-head" }, [
        el("h3", { text: "⚠️ Kritik Stok" }),
        el("span", { class: "pill red", text: low.length + " ürün" }),
      ]),
      el("div", { class: "chip-wrap" }, low.slice(0, 24).map((p) =>
        el("span", { class: "stock-chip" }, [
          p.image ? el("img", { class: "chip-thumb", src: p.image, alt: p.name }) : el("span", { text: p.emoji || "📦" }),
          el("span", { text: p.name }),
          el("b", { class: "num", text: String(p.stock) }),
        ])
      )),
    ]));
  }
}

// ---- Şu an çalışan personel (vardiyadaki ekip) — sadece cihazda tutulur (yerel) ----
const ON_SHIFT_KEY = "t101_onShift";
function readOnShift() { try { return JSON.parse(localStorage.getItem(ON_SHIFT_KEY)) || []; } catch { return []; } }
function writeOnShift(ids) { try { localStorage.setItem(ON_SHIFT_KEY, JSON.stringify(ids)); } catch {} }

function onShiftWidget() {
  const wrap = el("div", { class: "card dash-onshift" });

  function draw() {
    clear(wrap);
    const staff = db.staff.all();
    const ids = readOnShift();
    const working = staff.filter((s) => ids.includes(s.id));

    wrap.appendChild(el("div", { class: "card-head" }, [
      el("h3", { text: "👷 Şu An Çalışan Personel" }),
      working.length ? el("span", { class: "pill green", text: working.length + " kişi vardiyada" }) : null,
      el("span", { class: "spacer" }),
      el("button", { class: "btn ghost sm", onClick: pick }, ["Düzenle"]),
    ]));

    if (!staff.length) {
      wrap.appendChild(el("p", { class: "muted", text: "Henüz çalışan kaydı yok. 'Çalışanlar' bölümünden ekleyin, sonra buradan vardiyaya alın." }));
      return;
    }
    if (!working.length) {
      wrap.appendChild(el("p", { class: "muted", text: "Şu an vardiyada personel yok. 'Düzenle' ile çalışanları işaretleyin." }));
      return;
    }
    wrap.appendChild(el("div", { class: "shift-people" }, working.map((s) =>
      el("div", { class: "shift-person" }, [
        el("span", { class: "shift-avatar", text: (s.name || "?").trim().charAt(0).toUpperCase() }),
        el("div", { class: "shift-meta" }, [
          el("div", { class: "shift-name", text: s.name }),
          el("div", { class: "shift-role", text: s.role || "Personel" }),
        ]),
        el("span", { class: "shift-live" }, [el("i", {}), el("span", { text: "aktif" })]),
      ])
    )));
  }

  function pick() {
    const staff = db.staff.all();
    const ids = new Set(readOnShift());
    const rows = staff.map((s) => {
      const cb = el("input", { type: "checkbox" });
      cb.checked = ids.has(s.id);
      cb.addEventListener("change", () => { if (cb.checked) ids.add(s.id); else ids.delete(s.id); });
      return el("label", { class: "shift-pick-row" }, [
        cb,
        el("span", { class: "shift-pick-name", text: s.name }),
        s.role ? el("span", { class: "pill blue", text: s.role }) : null,
      ]);
    });
    modal({
      title: "👷 Vardiyadaki Personel",
      body: staff.length
        ? el("div", { class: "shift-pick" }, rows)
        : el("p", { class: "muted", text: "Önce 'Çalışanlar' bölümünden personel ekleyin." }),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => { writeOnShift([...ids]); toast("Vardiya güncellendi ✔", "success"); close(); draw(); } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }

  draw();
  return wrap;
}

function kpi(icon, label, value, sub, color) {
  return el("div", { class: "kpi kpi-" + color }, [
    el("div", { class: "kpi-ico", text: icon }),
    el("div", { class: "kpi-body" }, [
      el("div", { class: "kpi-lbl", text: label }),
      el("div", { class: "kpi-val num", text: value }),
      el("div", { class: "kpi-sub", text: sub }),
    ]),
  ]);
}

function quickBtn(icon, label, route) {
  return el("button", { class: "quick-btn", onClick: () => { try { navigate(route); } catch { location.hash = "#/" + route; } } }, [
    el("span", { class: "quick-ico", text: icon }),
    el("span", { text: label }),
  ]);
}

function emptyState(txt) {
  return el("div", { class: "empty-state" }, [
    el("div", { style: "font-size:32px;opacity:.5", text: "📭" }),
    el("div", { class: "muted", text: txt }),
  ]);
}

function shortMoney(n) {
  n = Number(n) || 0;
  if (n >= 1000000) return (n / 1000000).toFixed(1).replace(".0", "") + "M";
  if (n >= 1000) return (n / 1000).toFixed(1).replace(".0", "") + "K";
  return String(Math.round(n));
}

// Bugün ödeme dağılımı: nakit / kart / diğer — okunur oran çubukları
function paymentSplitCard(sales) {
  const b = { cash: 0, card: 0, other: 0 };
  (sales || []).forEach((s) => {
    const m = String(s.method || "").toLowerCase();
    const amt = Number(s.total) || 0;
    if (m === "card" || m === "kart" || m === "kredi" || m === "credit") b.card += amt;
    else if (m === "cash" || m === "nakit" || m === "") b.cash += amt;
    else b.other += amt;
  });
  const total = b.cash + b.card + b.other;
  const rows = [
    { lbl: "Nakit", icon: "💵", color: "#22C55E", val: b.cash },
    { lbl: "Kart", icon: "💳", color: "#2563EB", val: b.card },
    { lbl: "Diğer", icon: "🧾", color: "#94A3B8", val: b.other },
  ].filter((r) => r.val > 0);

  const body = total > 0
    ? el("div", { class: "paybar-list" }, rows.map((r) => {
        const pct = Math.round((r.val / total) * 100);
        return el("div", { class: "paybar-row" }, [
          el("div", { class: "paybar-head" }, [
            el("span", { text: r.icon + " " + r.lbl }),
            el("b", { class: "num", text: money(r.val) + "  ·  %" + pct }),
          ]),
          el("div", { class: "paybar-track" }, [
            el("div", { class: "paybar-fill", style: `width:${pct}%;background:${r.color}` }),
          ]),
        ]);
      }))
    : emptyState("Bugün henüz satış yok.");

  return el("div", { class: "card" }, [
    el("div", { class: "card-head" }, [
      el("h3", { text: "💳 Bugün Ödeme Dağılımı" }),
      total > 0 ? el("span", { class: "pill slate", text: "Toplam " + money(total) }) : null,
    ]),
    body,
  ]);
}
