// Patron Paneli — yalnızca işletme sahibi (doruk) görür.
// STOK ARAYÜZ yönetim panelini (log kayıtları, kullanıcı ekleme, müşteri/ödeme yönetimi)
// aynı origin altındaki KÖK (landing) dizinden iframe ile POS içine gömer.
// Yeni yapı: landing kökte, POS /pos/ altında → ".." kök = landing (#admin = yönetici).
// Panelin kendi girişi (kullanıcı adı/şifre: doruk) verileri korur.
import { el, clear } from "../core/ui.js";
import { currentUser } from "../core/auth.js";

// Oturumdaki kullanıcı "doruk" (patron) mu? — birden çok alanı kontrol et
export function isBoss() {
  const u = currentUser();
  if (!u) return false;
  const vals = [u.uye, u.name, u.username, u.id].map((x) => String(x || "").toLowerCase());
  return vals.some((v) => v === "doruk" || v === "cloud:doruk");
}

export function renderBoss(host) {
  clear(host);
  const head = el("div", { class: "view-head" }, [el("h1", { text: "🛡️ Patron Paneli" })]);

  if (!isBoss()) {
    host.append(head, el("div", { class: "card" }, [
      el("div", { style: "text-align:center;padding:30px" }, [
        el("div", { style: "font-size:44px", text: "🔒" }),
        el("h3", { text: "Erişim yok" }),
        el("p", { class: "muted", text: "Bu bölüm yalnızca işletme sahibine (patron) açıktır." }),
      ]),
    ]));
    return;
  }

  const panelUrl = "../#admin";
  const frame = el("iframe", {
    src: panelUrl,
    style: "width:100%;height:calc(100vh - 170px);min-height:520px;border:0;border-radius:14px;background:#fff",
    title: "Patron Paneli",
    loading: "lazy",
  });

  const bar = el("div", { style: "display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:12px" }, [
    el("span", { class: "muted", text: "Log kayıtları · Kullanıcı ekleme · Müşteri & ödeme yönetimi" }),
    el("div", { style: "flex:1" }),
    el("button", { class: "btn ghost", onClick: () => { const w = window.open(panelUrl, "_blank"); if (!w) location.href = panelUrl; } }, ["↗ Yeni sekmede aç"]),
    el("button", { class: "btn ghost", onClick: () => { frame.src = frame.src; } }, ["↻ Yenile"]),
  ]);

  const card = el("div", { class: "card" }, [bar, frame]);
  host.append(head, card);
}
