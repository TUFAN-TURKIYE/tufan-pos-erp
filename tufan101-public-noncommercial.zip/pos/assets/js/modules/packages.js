// mod-18 Paket Yönetimi — Freemium / Premium VIP yönlendirmesi
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { settings } from "../core/store.js";

export function renderPackages(host, ctx) {
  const s = settings.get();
  const head = el("div", { class: "view-head" }, [el("h1", { text: t("packages") })]);
  const grid = el("div", { class: "grid", style: "grid-template-columns:repeat(auto-fit,minmax(280px,1fr));max-width:840px" });

  grid.appendChild(planCard({
    active: s.package === "free", badge: "🆓 " + t("freeVersion"), price: "0 ₺",
    feats: ["Gelir / Gider", "Stok Takibi", "Kategoriler", "Tek Bakışta Kasa"],
    locked: ["Hızlı POS", "QR Menü", "Cari/Veresiye", "Vardiya & Z Raporu", "Raporlar"],
    action: s.package === "free" ? null : { label: "Ücretsiz'e Dön", kind: "ghost", set: "free" },
  }, ctx));

  grid.appendChild(planCard({
    active: s.package === "premium", badge: "💎 " + t("premium"), price: "800 ₺ / " + t("monthly"),
    sub: "8.000 ₺ / " + t("yearly") + " (2 ay bedava)",
    feats: ["Tüm modüller açık", "Sınırsız cihaz senkronizasyonu", "Hızlı POS + QR Menü", "Cari, Vardiya, Raporlar", "Kamera ile barkod"],
    highlight: true,
    action: s.package === "premium" ? null : { label: "💎 " + t("upgrade"), kind: "success", set: "premium" },
  }, ctx));

  clear(host).append(head, grid,
    el("p", { class: "muted", style: "margin-top:16px;max-width:840px",
      text: "Not: Ödemeler sistem üzerinden otomatik tahsil edilmez. Havale/EFT sonrası Süper Admin paneli üzerinden manuel olarak VIP paket ataması yapılır." }));
}

function planCard(p, ctx) {
  return el("div", { class: "card", style: "display:flex;flex-direction:column" + (p.highlight ? ";border:2px solid var(--primary)" : "") }, [
    el("div", { class: "pill " + (p.highlight ? "green" : "amber"), text: p.badge }),
    el("div", { class: "price", style: "font-size:30px;margin:12px 0 2px", text: p.price }),
    p.sub ? el("div", { class: "muted", text: p.sub }) : null,
    el("div", { style: "margin-top:12px" }, (p.feats || []).map((f) => el("div", { style: "padding:5px 0", text: "✅ " + f }))),
    ...(p.locked || []).map((f) => el("div", { class: "muted", style: "padding:5px 0", text: "🔒 " + f })),
    el("div", { style: "flex:1" }),
    p.action ? el("button", { class: "btn " + p.action.kind + " block", style: "margin-top:14px", onClick: () => {
      settings.set({ package: p.action.set });
      toast(p.action.set === "premium" ? "💎 Premium aktif!" : "Ücretsiz sürüm", "success");
      ctx.refresh();
    } }, [p.action.label]) : el("div", { class: "pill green", style: "margin-top:14px;justify-content:center", text: "✓ Aktif Plan" }),
  ]);
}
