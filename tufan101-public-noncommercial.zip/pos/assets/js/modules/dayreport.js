// Günlük Rapor — seçilen gün için özet: ciro, ödeme türü dağılımı, iade,
// gelir/gider, en çok satanlar. Ekranda gösterir + yazdırılabilir (PDF) rapor üretir.
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money, settings } from "../core/store.js";

const METHOD_LABEL = { cash: "💵 Nakit", card: "💳 Kart", pos: "💳 POS", gift: "🎁 Hediye Çeki", credit: "📒 Veresiye", transfer: "🏦 Havale" };

function dayRange(dateStr) {
  const d = dateStr ? new Date(dateStr + "T00:00:00") : new Date();
  d.setHours(0, 0, 0, 0);
  return [d.getTime(), d.getTime() + 86400000];
}

export function renderDayReport(host) {
  const dateInp = el("input", { class: "input", type: "date", value: new Date().toISOString().slice(0, 10), style: "max-width:180px" });
  const body = el("div", {});
  clear(host).append(
    el("div", { class: "view-head" }, [
      el("h1", { text: "🧾 " + t("navDayReport") }),
      el("div", { class: "spacer" }), dateInp,
      el("button", { class: "btn success", onClick: () => printReport() }, ["🖨️ Yazdır / PDF"]),
    ]),
    body,
  );

  function compute() {
    const [from, to] = dayRange(dateInp.value);
    const all = db.sales.all().filter((s) => Number(s.ts) >= from && Number(s.ts) < to);
    const active = all.filter((s) => !s.void);
    const gross = active.reduce((a, s) => a + (Number(s.total) || 0), 0);
    const refunds = all.filter((s) => s.void);
    const refundAmt = refunds.reduce((a, s) => a + (Number(s.refundAmount || s.total) || 0), 0);

    const byMethod = {};
    active.forEach((s) => { const m = s.method || "cash"; byMethod[m] = (byMethod[m] || 0) + (Number(s.total) || 0); });

    const txns = db.txns.all().filter((x) => Number(x.ts) >= from && Number(x.ts) < to);
    const income = txns.filter((x) => x.type === "income").reduce((a, x) => a + (Number(x.amount) || 0), 0);
    const expense = txns.filter((x) => x.type === "expense").reduce((a, x) => a + (Number(x.amount) || 0), 0);

    const prodMap = {};
    active.forEach((s) => (s.items || []).forEach((it) => { const k = it.name || "Ürün"; if (!prodMap[k]) prodMap[k] = { qty: 0, rev: 0 }; prodMap[k].qty += Number(it.qty) || 1; prodMap[k].rev += (Number(it.qty) || 1) * (Number(it.price) || 0); }));
    const top = Object.entries(prodMap).sort((a, b) => b[1].rev - a[1].rev).slice(0, 10);

    return { from, gross, n: active.length, refunds: refunds.length, refundAmt, byMethod, income, expense, top };
  }

  function draw() {
    clear(body);
    const r = compute();
    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Ciro" }), el("div", { class: "smart-val num", text: money(r.gross) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Satış Adedi" }), el("div", { class: "smart-val num", text: String(r.n) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "İade" }), el("div", { class: "smart-val num", text: r.refunds + " · " + money(r.refundAmt) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Net (Ciro+Gelir−Gider)" }), el("div", { class: "smart-val num", text: money(r.gross + r.income - r.expense) })]),
    ]));

    const cols = el("div", { class: "smart-cols" });
    // Ödeme türü dağılımı
    const pm = el("div", { class: "card" }, [el("h3", { text: "💰 Ödeme Türü Dağılımı" })]);
    const methods = Object.entries(r.byMethod).sort((a, b) => b[1] - a[1]);
    if (methods.length) methods.forEach(([m, v]) => pm.appendChild(el("div", { class: "smart-list-row" }, [el("span", { text: METHOD_LABEL[m] || m }), el("b", { class: "num", text: money(v) })])));
    else pm.appendChild(el("p", { class: "muted", text: "Satış yok" }));
    // Gelir/Gider
    pm.appendChild(el("div", { class: "smart-list-row", style: "border-top:1px solid var(--border);margin-top:8px;padding-top:8px" }, [el("span", { text: "➕ Diğer Gelir" }), el("b", { class: "num", text: money(r.income) })]));
    pm.appendChild(el("div", { class: "smart-list-row" }, [el("span", { text: "➖ Gider" }), el("b", { class: "num", style: "color:var(--danger,#dc2626)", text: money(r.expense) })]));
    cols.appendChild(pm);

    // En çok satanlar
    const tp = el("div", { class: "card" }, [el("h3", { text: "🏆 En Çok Satanlar" })]);
    if (r.top.length) r.top.forEach(([name, d]) => tp.appendChild(el("div", { class: "smart-list-row" }, [el("span", { text: name + "  ×" + d.qty }), el("b", { class: "num", text: money(d.rev) })])));
    else tp.appendChild(el("p", { class: "muted", text: "Veri yok" }));
    cols.appendChild(tp);
    body.appendChild(cols);
  }

  function printReport() {
    const r = compute();
    const s = settings.get();
    const biz = s.bizName || s.companyName || "İşletme";
    const dateLabel = new Date(r.from).toLocaleDateString("tr-TR", { day: "2-digit", month: "long", year: "numeric" });
    const esc = (x) => String(x == null ? "" : x).replace(/[&<>]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]));
    const row = (a, b) => `<tr><td>${esc(a)}</td><td style="text-align:right">${esc(b)}</td></tr>`;
    const methodRows = Object.entries(r.byMethod).map(([m, v]) => row(METHOD_LABEL[m] || m, money(v))).join("") || row("—", money(0));
    const topRows = r.top.map(([n, d]) => `<tr><td>${esc(n)}</td><td style="text-align:center">${d.qty}</td><td style="text-align:right">${esc(money(d.rev))}</td></tr>`).join("") || "<tr><td colspan=3>—</td></tr>";

    const html = `<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Günlük Rapor ${esc(dateLabel)}</title>
    <style>
      *{box-sizing:border-box;margin:0;padding:0}
      body{font-family:Inter,Arial,sans-serif;padding:14mm;color:#111;font-size:13px}
      h1{font-size:20px;margin-bottom:2px}.sub{color:#666;margin-bottom:14px}
      .kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:16px}
      .kpi{border:1px solid #ddd;border-radius:8px;padding:10px;text-align:center}
      .kpi .l{font-size:11px;color:#666}.kpi .v{font-size:18px;font-weight:800}
      table{width:100%;border-collapse:collapse;margin-bottom:16px}
      th,td{border-bottom:1px solid #eee;padding:6px 8px;text-align:left}
      th{background:#f5f5f5;font-size:12px}
      h3{font-size:14px;margin:10px 0 6px}
      .foot{margin-top:20px;color:#888;font-size:11px;text-align:center;border-top:1px solid #eee;padding-top:8px}
      @media print{@page{margin:12mm}.noprint{display:none}}
    </style></head><body>
    <div class="noprint" style="text-align:center;margin-bottom:12px"><button onclick="window.print()" style="padding:8px 16px;border:0;border-radius:8px;background:#2563eb;color:#fff;font-size:15px;cursor:pointer">🖨️ Yazdır</button></div>
    <h1>${esc(biz)} — Günlük Rapor</h1>
    <div class="sub">${esc(dateLabel)}</div>
    <div class="kpis">
      <div class="kpi"><div class="l">Ciro</div><div class="v">${esc(money(r.gross))}</div></div>
      <div class="kpi"><div class="l">Satış</div><div class="v">${r.n}</div></div>
      <div class="kpi"><div class="l">İade</div><div class="v">${r.refunds}</div></div>
      <div class="kpi"><div class="l">Net</div><div class="v">${esc(money(r.gross + r.income - r.expense))}</div></div>
    </div>
    <h3>Ödeme Türü Dağılımı</h3>
    <table>${methodRows}${row("➕ Diğer Gelir", money(r.income))}${row("➖ Gider", money(r.expense))}${row("↩️ İade", money(r.refundAmt))}</table>
    <h3>En Çok Satanlar</h3>
    <table><thead><tr><th>Ürün</th><th style="text-align:center">Adet</th><th style="text-align:right">Ciro</th></tr></thead><tbody>${topRows}</tbody></table>
    <div class="foot">TUFAN 101 · ${new Date().toLocaleString("tr-TR")}</div>
    <script>window.onload=function(){setTimeout(function(){window.print()},350)}<\/script>
    </body></html>`;

    const w = window.open("", "_blank");
    if (!w) { toast("Açılır pencere engellendi", "error"); return; }
    w.document.open(); w.document.write(html); w.document.close();
  }

  dateInp.addEventListener("change", draw);
  draw();
}
