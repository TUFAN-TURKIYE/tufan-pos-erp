// Kategoriler — görsel/ikon destekli (okuma gerektirmeyen yapı)
import { el, clear, toast, modal, confirmDialog } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db } from "../core/store.js";
import { can } from "../core/auth.js";

export function renderCategories(host) {
  const canEdit = can("manageStock");
  const head = el("div", { class: "view-head" }, [
    el("h1", { text: t("categories") }),
    el("div", { class: "spacer" }),
    canEdit ? el("button", { class: "btn", onClick: () => edit(null) }, ["+ " + t("add")]) : null,
  ]);
  const grid = el("div", { class: "grid", style: "grid-template-columns:repeat(auto-fill,minmax(180px,1fr))" });
  clear(host).append(head, grid);

  function draw() {
    clear(grid);
    db.categories.all().forEach((c) => {
      const count = db.products.all().filter((p) => p.categoryId === c.id).length;
      grid.appendChild(el("div", { class: "card", style: `border-left:6px solid ${c.color}` }, [
        el("div", { style: "font-size:30px", text: c.icon || "🏷️" }),
        el("div", { style: "font-weight:700;margin-top:6px", text: c.name }),
        el("div", { class: "muted", text: count + " " + t("products").toLowerCase() }),
        canEdit ? el("div", { style: "display:flex;gap:6px;margin-top:10px" }, [
          el("button", { class: "btn ghost", style: "flex:1", onClick: () => edit(c) }, ["✏️"]),
          el("button", { class: "btn ghost", onClick: () => confirmDialog(t("delete") + "?", () => { db.categories.remove(c.id); draw(); }) }, ["🗑"]),
        ]) : null,
      ]));
    });
  }

  function edit(c) {
    const isNew = !c; c = c || { color: "#2563EB", icon: "🏷️" };
    const name = el("input", { class: "input", value: c.name || "" });
    const icon = el("input", { class: "input", value: c.icon || "🏷️", maxlength: 4 });
    const color = el("input", { class: "input", type: "color", value: c.color || "#2563EB", style: "height:52px;padding:4px" });
    modal({
      title: isNew ? t("add") : t("edit"),
      body: el("div", {}, [
        el("div", { class: "field" }, [el("label", { text: t("name") }), name]),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [
          el("div", { class: "field" }, [el("label", { text: "İkon" }), icon]),
          el("div", { class: "field" }, [el("label", { text: "Renk" }), color]),
        ]),
      ]),
      actions: [
        { label: t("save"), kind: "success", onClick: (close) => {
          if (!name.value.trim()) { toast(t("name") + "?", "warn"); return; }
          db.categories.upsert({ ...c, name: name.value.trim(), icon: icon.value.trim() || "🏷️", color: color.value });
          toast(t("save"), "success"); close(); draw();
        } },
        { label: t("cancel"), kind: "ghost" },
      ],
    });
  }
  draw();
}
