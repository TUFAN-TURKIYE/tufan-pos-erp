// Takvim Analizi — günlük ciroyu takvim üzerinde renklendirir.
// Ay ay gezilir; bu ay vs geçen ay, en iyi gün, hafta günü ortalamaları.
import { el, clear } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { db, money } from "../core/store.js";

const WD = ["Pzt", "Sal", "Çar", "Per", "Cum", "Cmt", "Paz"];
const MONTHS = ["Ocak", "Şubat", "Mart", "Nisan", "Mayıs", "Haziran", "Temmuz", "Ağustos", "Eylül", "Ekim", "Kasım", "Aralık"];

function dayKey(ts) { const d = new Date(ts); return d.getFullYear() + "-" + d.getMonth() + "-" + d.getDate(); }

export function renderCalAnalysis(host) {
  let cur = new Date(); cur.setDate(1); cur.setHours(0, 0, 0, 0);
  const body = el("div", {});
  const title = el("h1", {});
  clear(host).append(
    el("div", { class: "view-head" }, [
      el("button", { class: "btn ghost", onClick: () => { cur.setMonth(cur.getMonth() - 1); draw(); } }, ["‹"]),
      title,
      el("button", { class: "btn ghost", onClick: () => { cur.setMonth(cur.getMonth() + 1); draw(); } }, ["›"]),
      el("div", { class: "spacer" }),
    ]),
    body,
  );

  // Günlük ciro haritası (tüm satışlardan)
  function revByDay() {
    const map = {};
    db.sales.all().filter((s) => !s.void && Number(s.ts) > 0).forEach((s) => {
      const k = dayKey(Number(s.ts)); map[k] = (map[k] || 0) + (Number(s.total) || 0);
    });
    return map;
  }

  function draw() {
    clear(body);
    title.textContent = "📅 " + MONTHS[cur.getMonth()] + " " + cur.getFullYear();
    const map = revByDay();
    const year = cur.getFullYear(), month = cur.getMonth();
    const first = new Date(year, month, 1);
    const startWd = (first.getDay() + 6) % 7; // Pazartesi = 0
    const daysInMonth = new Date(year, month + 1, 0).getDate();

    // Bu ay & geçen ay toplamları
    let monthTotal = 0, prevTotal = 0, best = { day: 0, rev: 0 };
    const wdSum = new Array(7).fill(0), wdCnt = new Array(7).fill(0);
    for (let d = 1; d <= daysInMonth; d++) {
      const rev = map[year + "-" + month + "-" + d] || 0;
      monthTotal += rev;
      if (rev > best.rev) best = { day: d, rev };
      const wd = (new Date(year, month, d).getDay() + 6) % 7;
      if (rev > 0) { wdSum[wd] += rev; wdCnt[wd]++; }
    }
    const pm = new Date(year, month - 1, 1);
    const pdays = new Date(pm.getFullYear(), pm.getMonth() + 1, 0).getDate();
    for (let d = 1; d <= pdays; d++) prevTotal += map[pm.getFullYear() + "-" + pm.getMonth() + "-" + d] || 0;

    const pct = prevTotal > 0 ? Math.round((monthTotal - prevTotal) / prevTotal * 100) : (monthTotal > 0 ? 100 : 0);
    const maxDay = Math.max(1, ...Array.from({ length: daysInMonth }, (_, i) => map[year + "-" + month + "-" + (i + 1)] || 0));

    body.appendChild(el("div", { class: "smart-grid" }, [
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Ay Toplamı" }), el("div", { class: "smart-val num", text: money(monthTotal) })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "Geçen Aya Göre" }), el("div", { class: "smart-val num", style: "color:" + (pct >= 0 ? "var(--success,#16a34a)" : "var(--danger,#dc2626)"), text: (pct >= 0 ? "▲ +" : "▼ ") + pct + "%" })]),
      el("div", { class: "smart-kpi" }, [el("div", { class: "smart-label", text: "En İyi Gün" }), el("div", { class: "smart-val num", text: best.day ? best.day + " " + MONTHS[month].slice(0, 3) : "—" }), el("span", { class: "muted", style: "font-size:12px", text: best.rev ? money(best.rev) : "" })]),
    ]));

    // Takvim ızgarası
    const cal = el("div", { class: "cal-grid" });
    WD.forEach((w) => cal.appendChild(el("div", { class: "cal-wd", text: w })));
    for (let i = 0; i < startWd; i++) cal.appendChild(el("div", { class: "cal-cell cal-empty" }));
    const today = new Date();
    for (let d = 1; d <= daysInMonth; d++) {
      const rev = map[year + "-" + month + "-" + d] || 0;
      const intensity = rev > 0 ? 0.15 + 0.85 * (rev / maxDay) : 0;
      const isToday = today.getFullYear() === year && today.getMonth() === month && today.getDate() === d;
      cal.appendChild(el("div", {
        class: "cal-cell" + (isToday ? " cal-today" : ""),
        style: rev > 0 ? "background:rgba(37,99,235," + intensity.toFixed(2) + ");color:" + (intensity > 0.55 ? "#fff" : "inherit") : "",
        title: d + " " + MONTHS[month] + ": " + money(rev),
      }, [
        el("div", { class: "cal-day", text: String(d) }),
        rev > 0 ? el("div", { class: "cal-rev num", text: rev >= 1000 ? Math.round(rev / 1000) + "k" : Math.round(rev) }) : el("span", {}),
      ]));
    }
    body.appendChild(el("div", { class: "card" }, [cal]));

    // Hafta günü ortalamaları
    const maxWd = Math.max(1, ...wdSum.map((s, i) => wdCnt[i] ? s / wdCnt[i] : 0));
    const wdCard = el("div", { class: "card" }, [el("h3", { text: "📊 Hafta Günü Ortalaması (bu ay)" })]);
    WD.forEach((w, i) => {
      const avg = wdCnt[i] ? wdSum[i] / wdCnt[i] : 0;
      wdCard.appendChild(el("div", { class: "smart-bar-row" }, [
        el("div", { class: "smart-bar-top" }, [el("span", { text: w }), el("b", { class: "num", text: money(avg) })]),
        el("div", { class: "smart-bar" }, [el("div", { class: "smart-bar-fill", style: "width:" + Math.max(4, Math.round(avg / maxWd * 100)) + "%" })]),
      ]));
    });
    body.appendChild(wdCard);
  }

  draw();
}
