// Sözleşmeler — hazır hukuki şablonlar, alanları doldur, önizle, PDF olarak yazdır
import { el, clear, toast } from "../core/ui.js";
import { t } from "../core/i18n.js";
import { settings } from "../core/store.js";

const bugun = () => new Date().toLocaleDateString("tr-TR");

const TEMPLATES = {
  kira: {
    label: "🏠 Kira Sözleşmesi",
    fields: [["taraf1", "Kiraya Veren (Ad Soyad)"], ["taraf2", "Kiracı (Ad Soyad)"], ["konu", "Kiralanan Adres"], ["tutar", "Aylık Kira (₺)"], ["sure", "Süre (ay/yıl)"], ["tarih", "Başlangıç Tarihi"]],
    body: (v) => `KİRA SÖZLEŞMESİ

1. TARAFLAR
   Kiraya Veren : ${v.taraf1 || "..............."}
   Kiracı       : ${v.taraf2 || "..............."}

2. KİRALANAN
   ${v.konu || "..............."}

3. KİRA BEDELİ VE SÜRE
   Aylık kira bedeli ${v.tutar || "......"} ₺ olup her ayın başında peşin ödenir.
   Sözleşme süresi ${v.sure || "1 yıl"} olup ${v.tarih || bugun()} tarihinde başlar.

4. GENEL HÜKÜMLER
   Kiracı, kiralananı özenle kullanmayı ve sözleşme sonunda tahliye etmeyi kabul eder.
   Aidat, elektrik, su, doğalgaz giderleri kiracıya aittir.
   İşbu sözleşme iki nüsha düzenlenmiş olup taraflarca imzalanmıştır.

   Kiraya Veren                         Kiracı
   ${(v.taraf1 || "").padEnd(28)} ${v.taraf2 || ""}
   İmza                                 İmza`,
  },
  is: {
    label: "💼 İş / Hizmet Sözleşmesi",
    fields: [["taraf1", "İşveren"], ["taraf2", "Çalışan / Hizmet Veren"], ["konu", "İşin Konusu"], ["tutar", "Ücret (₺)"], ["sure", "Süre"], ["tarih", "Başlangıç Tarihi"]],
    body: (v) => `İŞ / HİZMET SÖZLEŞMESİ

1. TARAFLAR
   İşveren : ${v.taraf1 || "..............."}
   Çalışan : ${v.taraf2 || "..............."}

2. İŞİN KONUSU
   ${v.konu || "..............."}

3. ÜCRET VE SÜRE
   Ücret ${v.tutar || "......"} ₺ olarak belirlenmiştir.
   Sözleşme ${v.tarih || bugun()} tarihinde başlar, süresi ${v.sure || "belirsiz"}dir.

4. YÜKÜMLÜLÜKLER
   Çalışan işini özenle ve zamanında yapmayı; işveren ücreti zamanında ödemeyi kabul eder.
   İşbu sözleşme iki nüsha düzenlenmiştir.

   İşveren                              Çalışan
   İmza                                 İmza`,
  },
  satis: {
    label: "🤝 Satış Sözleşmesi",
    fields: [["taraf1", "Satıcı"], ["taraf2", "Alıcı"], ["konu", "Satılan Mal / Hizmet"], ["tutar", "Satış Bedeli (₺)"], ["tarih", "Tarih"]],
    body: (v) => `SATIŞ SÖZLEŞMESİ

1. TARAFLAR
   Satıcı : ${v.taraf1 || "..............."}
   Alıcı  : ${v.taraf2 || "..............."}

2. SÖZLEŞMENİN KONUSU
   ${v.konu || "..............."}

3. BEDEL
   Satış bedeli ${v.tutar || "......"} ₺ olup ${v.tarih || bugun()} tarihinde ödenmiştir.

4. HÜKÜMLER
   Satıcı malı ayıpsız teslim etmeyi, alıcı bedeli ödemeyi kabul eder.
   Teslim ile birlikte mülkiyet ve hasar alıcıya geçer.

   Satıcı                               Alıcı
   İmza                                 İmza`,
  },
  borc: {
    label: "📜 Borç Senedi",
    fields: [["taraf1", "Borçlu"], ["taraf2", "Alacaklı"], ["tutar", "Borç Tutarı (₺)"], ["sure", "Vade / Ödeme Tarihi"], ["tarih", "Düzenleme Tarihi"]],
    body: (v) => `BORÇ SENEDİ

Aşağıda imzası bulunan ben ${v.taraf1 || "..............."},
${v.taraf2 || "..............."} adlı kişiye ${v.tutar || "......"} ₺ (${v.tutar || "..."} Türk Lirası)
borçlu olduğumu; işbu borcu ${v.sure || "............."} tarihinde nakden ve defaten
ödeyeceğimi kabul ve taahhüt ederim.

Düzenleme Tarihi : ${v.tarih || bugun()}

   Borçlu                               Alacaklı
   ${(v.taraf1 || "").padEnd(28)} ${v.taraf2 || ""}
   İmza                                 İmza`,
  },
  gizlilik: {
    label: "🔒 Gizlilik Sözleşmesi (NDA)",
    fields: [["taraf1", "Bilgiyi Veren Taraf"], ["taraf2", "Bilgiyi Alan Taraf"], ["konu", "Gizli Bilginin Konusu"], ["sure", "Gizlilik Süresi"], ["tarih", "Tarih"]],
    body: (v) => `GİZLİLİK SÖZLEŞMESİ (NDA)

1. TARAFLAR
   Bilgiyi Veren : ${v.taraf1 || "..............."}
   Bilgiyi Alan  : ${v.taraf2 || "..............."}

2. KONU
   ${v.konu || "..............."} kapsamındaki tüm bilgiler gizlidir.

3. YÜKÜMLÜLÜK
   Bilgiyi alan taraf, edindiği bilgileri üçüncü kişilerle paylaşmamayı,
   yalnızca sözleşme amacı için kullanmayı taahhüt eder.
   Gizlilik yükümlülüğü ${v.sure || "2 yıl"} süreyle geçerlidir.

Tarih : ${v.tarih || bugun()}

   Bilgiyi Veren                        Bilgiyi Alan
   İmza                                 İmza`,
  },
};

export function renderContracts(host) {
  const head = el("div", { class: "view-head" }, [el("h1", { text: "📑 " + t("contractsGen") })]);
  const layout = el("div", { class: "grid", style: "grid-template-columns:340px 1fr;gap:16px;align-items:start" });
  clear(host).append(head, layout);

  let type = "kira";
  const typeSel = el("select", { class: "input", onChange: (e) => { type = e.target.value; buildForm(); } },
    Object.entries(TEMPLATES).map(([k, v]) => el("option", { value: k }, [v.label])));

  const fieldsHost = el("div", { style: "display:flex;flex-direction:column;gap:10px;margin-top:12px" });
  const preview = el("pre", { style: "white-space:pre-wrap;font:13px/1.6 ui-monospace,monospace;background:var(--bg,#0000000a);border:1px solid var(--border);border-radius:10px;padding:16px;max-height:70vh;overflow:auto" });

  const formCard = el("div", { class: "card" }, [
    el("div", { class: "field" }, [el("label", { text: "Sözleşme Türü" }), typeSel]),
    fieldsHost,
    el("div", { style: "display:flex;gap:8px;margin-top:14px" }, [
      el("button", { class: "btn ghost", style: "flex:1", onClick: () => refresh() }, ["👁 Önizle"]),
      el("button", { class: "btn success", style: "flex:1", onClick: () => printDoc() }, ["📥 PDF Yazdır"]),
    ]),
    el("button", { class: "btn block", style: "margin-top:8px", onClick: () => copyText() }, ["⧉ Metni Kopyala"]),
  ]);
  const previewCard = el("div", { class: "card" }, [el("h3", { text: "📄 Önizleme" }), preview]);
  layout.append(formCard, previewCard);

  const inputs = {};
  function buildForm() {
    clear(fieldsHost);
    inputs.map = {};
    TEMPLATES[type].fields.forEach(([key, label]) => {
      const isDate = /tarih/i.test(label);
      const inp = el("input", { class: "input", type: isDate ? "date" : "text", placeholder: label });
      inp.addEventListener("input", refresh);
      inputs.map[key] = inp;
      fieldsHost.appendChild(el("div", { class: "field" }, [el("label", { text: label }), inp]));
    });
    refresh();
  }
  function values() {
    const v = {};
    Object.entries(inputs.map).forEach(([k, inp]) => {
      v[k] = inp.type === "date" && inp.value ? new Date(inp.value).toLocaleDateString("tr-TR") : inp.value;
    });
    return v;
  }
  function text() { return TEMPLATES[type].body(values()); }
  function refresh() { preview.textContent = text(); }

  function copyText() {
    navigator.clipboard?.writeText(text()).then(() => toast("Metin kopyalandı ✔", "success"), () => toast("Kopyalanamadı", "warn"));
  }
  function printDoc() {
    const biz = settings.get().business || "TUFAN 101";
    const w = window.open("", "_blank");
    if (!w) { toast("Açılır pencere engellendi (PDF için izin verin)", "warn"); return; }
    const esc = (s) => String(s).replace(/[&<>]/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;" }[m]));
    w.document.write(`<html><head><meta charset="utf-8"><title>${esc(biz)} — Sözleşme</title>
      <style>body{font-family:'Times New Roman',Georgia,serif;padding:40px;color:#0F172A;line-height:1.7}
      pre{white-space:pre-wrap;font-family:inherit;font-size:14px}
      .foot{margin-top:40px;color:#94A3B8;font-size:11px;text-align:center;border-top:1px solid #E2E8F0;padding-top:10px}</style></head><body>
      <pre>${esc(text())}</pre>
      <div class="foot">${esc(biz)} • TUFAN 101 • Bu yapı Balıkesir / Doruk Tufan'a aittir.</div>
      <script>window.onload=()=>window.print()<\/script></body></html>`);
    w.document.close();
  }

  typeSel.value = type;
  buildForm();
}
