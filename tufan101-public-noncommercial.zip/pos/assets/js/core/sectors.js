// 100 Sektör Veritabanı — kurulum sihirbazı için hazır sektör listesi + hızlı ürün şablonları
// (zip mod-02'den uyarlandı) Fuzzy arama (Levenshtein) ile Türkçe karakter toleranslı.

export const SECTORS = [
  "E-Ticaret", "Yazılım ve Teknoloji", "Restoran ve Kafe", "Otomotiv", "Emlak ve Gayrimenkul",
  "Sağlık ve Medikal", "Eğitim ve Kurslar", "Finans ve Muhasebe", "Hukuk ve Danışmanlık", "İnşaat ve Mimarlık",
  "Tekstil ve Giyim", "Turizm ve Otelcilik", "Lojistik ve Taşımacılık", "Tarım ve Hayvancılık", "Gıda Sanayii",
  "Kozmetik ve Güzellik", "Spor Salonu ve Fitness", "Mobilya ve Dekorasyon", "Kuyumculuk ve Mücevher", "Matbaa ve Yayıncılık",
  "Enerji ve Güneş Sistemleri", "Reklam ve Dijital Ajans", "Fotoğrafçılık ve Video", "Organizasyon ve Düğün", "Temizlik Şirketi",
  "Güvenlik Sistemleri", "Donanım ve Elektronik Tamir", "Ev Tekstili", "Petshop ve Veteriner", "Oyuncak ve Kırtasiye",
  "Kitabevi", "Eczane", "Diş Kliniği", "Mimarlık Ofisi", "Oto Kiralama (Rent a Car)",
  "Kargo ve Kurye Hizmetleri", "Kuru Temizleme", "Kuaför ve Berber", "Diyetisyen ve Beslenme", "Psikolojik Danışmanlık",
  "Yazılım Geliştirme", "Siber Güvenlik", "Bulut Bilişim", "Yapay Zeka Teknolojileri", "Kripto Para ve Blockchain",
  "Veri Analitiği", "Mobil Uygulama Geliştirme", "Oyun Stüdyosu", "Web Tasarım Ajansı", "SEO ve Dijital Pazarlama",
  "Sosyal Medya Yönetimi", "E-Ticaret Pazaryeri Satıcılığı", "Dropshipping", "Endüstriyel Otomasyon", "3D Baskı ve Modelleme",
  "Robotik Kodlama Sistemleri", "Akıllı Ev Teknolojileri", "İklimlendirme ve Isıtma", "Elektrik Taahhüt", "Hırdavat ve Nalbur",
  "Boya ve Kimya Sanayii", "Plastik Enjeksiyon", "Ambalaj Sanayii", "Mantar Yetiştiriciliği", "Seracılık",
  "Arıcılık", "Tıbbi ve Aromatik Bitkiler", "Zeytincilik", "Büyükbaş Hayvancılık", "Süt ve Süt Ürünleri",
  "Unlu Mamuller ve Fırın", "Kasap ve Şarküteri", "Manav", "Kuruyemiş ve Baharat", "Aktar ve Doğal Ürünler",
  "Cafe & Bistro", "Fast Food", "Pide ve Lahmacun Salonu", "Et Lokantası", "Balık Restoranı",
  "Pastane ve Tatlıcı", "Kahve Kavurma (Roastery)", "Catering Yemek Üretimi", "Meyhane ve Eğlence Mekanı", "Butik Otel",
  "Pansiyon", "Seyahat Acentesi", "Araç Ekspertiz", "Oto Servis ve Tamir", "Oto Lastik",
  "Oto Yıkama ve Detailing", "Yedek Parça", "Motosiklet Satış ve Servis", "Bisiklet Mağazası", "Kargo Dağıtım Merkezi",
  "Gümrük Müşavirliği", "Depolama Hizmetleri", "Uluslararası Nakliyat", "Evden Eve Nakliyat", "Kurye Şirketi",
];

// Bilinen sektörler için hızlı başlangıç ürünleri (kurulumda içe aktarılabilir)
export const SECTOR_QUICK_PRODUCTS = {
  "e-ticaret": [
    { name: "Kalpli Mum", price: 50, cat: "Online Satış" },
    { name: "T-Shirt Siyah", price: 250, cat: "Online Satış" },
    { name: "Kupa Bardak", price: 120, cat: "Online Satış" },
  ],
  "restoran": [
    { name: "Lahmacun", price: 120, cat: "Satış" },
    { name: "Kıymalı Pide", price: 180, cat: "Satış" },
    { name: "Ayran", price: 30, cat: "Satış" },
  ],
  "cafe": [
    { name: "Türk Kahvesi", price: 60, cat: "Sıcak İçecek" },
    { name: "Latte", price: 90, cat: "Sıcak İçecek" },
    { name: "Cheesecake", price: 140, cat: "Tatlı" },
  ],
  "manav": [
    { name: "Domates (kg)", price: 35, cat: "Meyve/Sebze" },
    { name: "Elma (kg)", price: 40, cat: "Meyve/Sebze" },
    { name: "Muz (kg)", price: 60, cat: "Meyve/Sebze" },
  ],
  "kasap": [
    { name: "Dana Kıyma (kg)", price: 480, cat: "Et/Kasap" },
    { name: "Kuzu Pirzola (kg)", price: 720, cat: "Et/Kasap" },
    { name: "Tavuk Göğüs (kg)", price: 180, cat: "Et/Kasap" },
  ],
  "arıcılık": [
    { name: "Süzme Bal 1KG", price: 450, cat: "Satış" },
    { name: "Petek Bal", price: 600, cat: "Satış" },
    { name: "Polen 250G", price: 200, cat: "Satış" },
  ],
  "eczane": [
    { name: "Vitamin C", price: 85, cat: "Genel" },
    { name: "Ağrı Kesici", price: 45, cat: "Genel" },
    { name: "Termometre", price: 120, cat: "Genel" },
  ],
  "kuaför": [
    { name: "Saç Kesimi", price: 200, cat: "Hizmet" },
    { name: "Sakal Tıraşı", price: 120, cat: "Hizmet" },
    { name: "Saç Boya", price: 450, cat: "Hizmet" },
  ],
};

// Türkçe karakterleri sadeleştir
export function normalizeText(text) {
  if (!text) return "";
  return String(text).toLowerCase()
    .replace(/ı/g, "i").replace(/ğ/g, "g").replace(/ü/g, "u")
    .replace(/ş/g, "s").replace(/ö/g, "o").replace(/ç/g, "c")
    .replace(/[^a-z0-9\s]/g, "").trim();
}

// Levenshtein mesafesi — yaklaşık eşleşme için
export function levenshtein(a, b) {
  const t = Array(b.length + 1).fill(null).map(() => Array(a.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) t[0][i] = i;
  for (let j = 0; j <= b.length; j++) t[j][0] = j;
  for (let j = 1; j <= b.length; j++)
    for (let i = 1; i <= a.length; i++) {
      const c = a[i - 1] === b[j - 1] ? 0 : 1;
      t[j][i] = Math.min(t[j - 1][i] + 1, t[j][i - 1] + 1, t[j - 1][i - 1] + c);
    }
  return t[b.length][a.length];
}

// Sorguya göre sektör listesini filtrele (fuzzy)
export function searchSectors(query) {
  const q = normalizeText(query);
  if (!q) return SECTORS.slice();
  return SECTORS.filter((s) => {
    const ns = normalizeText(s);
    if (ns.includes(q)) return true;
    const d = levenshtein(q, ns.substring(0, q.length + 2));
    return d <= 2;
  });
}

// Sektör adına göre hızlı ürünleri getir (anahtar kelime eşleşmesi)
export function quickProductsFor(sector) {
  const ns = normalizeText(sector);
  for (const key of Object.keys(SECTOR_QUICK_PRODUCTS)) {
    if (ns.includes(normalizeText(key))) return SECTOR_QUICK_PRODUCTS[key];
  }
  return [];
}
