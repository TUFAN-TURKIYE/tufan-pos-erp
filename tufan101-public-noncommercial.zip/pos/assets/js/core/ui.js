// UI yardımcıları: element oluşturma, toast, modal, sesli uyarılar (dökümandeki gereksinim)
export function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") node.className = v;
    else if (k === "html") node.innerHTML = v;
    else if (k === "text") node.textContent = v;
    else if (k.startsWith("on") && typeof v === "function") node.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v !== null && v !== undefined && v !== false) node.setAttribute(k, v === true ? "" : v);
  }
  (Array.isArray(children) ? children : [children]).forEach((c) => {
    if (c == null || c === false) return;
    node.appendChild(typeof c === "string" ? document.createTextNode(c) : c);
  });
  return node;
}
export const clear = (n) => { while (n.firstChild) n.removeChild(n.firstChild); return n; };

// ---- Toast ----
export function toast(msg, kind = "") {
  const root = document.getElementById("toasts");
  const t = el("div", { class: "toast " + kind, text: msg });
  root.appendChild(t);
  setTimeout(() => { t.style.opacity = "0"; setTimeout(() => t.remove(), 250); }, 2600);
}

// ---- Modal ----
export function modal({ title, body, actions }) {
  const root = document.getElementById("modal-root");
  // Yığın (stack) mantığı: her modal KENDİ backdrop'unu ekler ve close()
  // yalnızca kendi backdrop'unu kaldırır. Böylece bir modal içinden ikinci bir
  // modal açıldığında (ör. ürün eklerken barkod tarama) alttaki form KAYBOLMAZ.
  const close = () => { backdrop.remove(); };
  const backdrop = el("div", { class: "modal-backdrop", onClick: (e) => { if (e.target === backdrop) close(); } }, [
    el("div", { class: "modal" }, [
      title ? el("h3", { text: title }) : null,
      typeof body === "string" ? el("div", { html: body }) : body,
      el("div", { class: "modal-actions" }, (actions || []).map((a) =>
        el("button", { class: "btn " + (a.kind || "ghost"), onClick: () => a.onClick ? a.onClick(close) : close() }, [a.label])
      )),
    ]),
  ]);
  root.appendChild(backdrop);   // öncekini SİLME → üst üste yığ
  return close;
}

// ---- Sesli uyarılar (WebAudio; dosya gerektirmez) ----
let actx;
function tone(freq, dur = 0.12, type = "sine", gain = 0.05) {
  try {
    actx = actx || new (window.AudioContext || window.webkitAudioContext)();
    const o = actx.createOscillator(), g = actx.createGain();
    o.type = type; o.frequency.value = freq; g.gain.value = gain;
    o.connect(g); g.connect(actx.destination);
    o.start(); o.stop(actx.currentTime + dur);
  } catch {}
}
export const sound = {
  ok: () => tone(880, 0.09, "sine", 0.05),
  scan: () => { tone(1200, 0.06); },                       // barkod/ürün okundu — kısa bip
  add: () => { tone(1046, 0.05, "triangle", 0.045); },     // sepete eklendi — nazik tık
  tick: () => { tone(1500, 0.03, "sine", 0.03); },         // küçük tık (adet vb.)
  remove: () => { tone(420, 0.07, "sine", 0.045); },       // çıkarıldı — alçak ton
  error: () => { tone(200, 0.18, "square", 0.06); },
  cash: () => { tone(660, 0.08); setTimeout(() => tone(990, 0.1), 90); },
  // Satış tamamlandı — neşeli 3 notalı melodi (küçük ama belirgin)
  sale: () => {
    tone(784, 0.09, "sine", 0.06);
    setTimeout(() => tone(1046, 0.09, "sine", 0.06), 100);
    setTimeout(() => tone(1318, 0.14, "sine", 0.06), 210);
  },
  // Yeni bildirim — iki notalı "ding"
  notify: () => { tone(1046, 0.08, "sine", 0.05); setTimeout(() => tone(1568, 0.12, "sine", 0.05), 110); },
};

export function confirmDialog(message, onYes) {
  modal({
    title: message,
    body: el("div", { class: "muted", text: "" }),
    actions: [
      { label: "İptal", kind: "ghost" },
      { label: "Onayla", kind: "danger", onClick: (close) => { onYes(); close(); } },
    ],
  });
}
