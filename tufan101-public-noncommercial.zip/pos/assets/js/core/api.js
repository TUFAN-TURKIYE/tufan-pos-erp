// Backend (PHP/MySQL) ile iletişim. Token localStorage'da tutulur.
const BASE = "api/";

function token() { return localStorage.getItem("t101_token") || ""; }
export function setToken(tk) {
  if (tk) localStorage.setItem("t101_token", tk);
  else localStorage.removeItem("t101_token");
}

async function request(path, opts = {}) {
  const res = await fetch(BASE + path, {
    method: opts.method || "GET",
    headers: {
      "Content-Type": "application/json",
      ...(token() ? { Authorization: "Bearer " + token() } : {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!res.ok) throw Object.assign(new Error(data.error || res.statusText), { status: res.status, data });
  return data;
}

export const api = {
  get: (p) => request(p),
  post: (p, body) => request(p, { method: "POST", body }),
  put: (p, body) => request(p, { method: "PUT", body }),
  del: (p, body) => request(p, { method: "DELETE", body }),
};

// ============================================================
//  Lisans + cihazlar arası senkron sunucusu (STOK ARAYÜZ / api.php)
//  Yeni yapı: Panel (landing) KÖK dizinde, POS uygulaması /pos/ altında.
//  Bu yüzden POS'tan panele göreli "../api.php" ile ulaşılır (kök = /api.php).
//  Panel farklı bir alan adındaysa index.html içinde
//  window.__TUFAN_LICENSE_API__ = "https://.../api.php" tanımlayın.
// ============================================================
export const LICENSE_API =
  (typeof window !== "undefined" && window.__TUFAN_LICENSE_API__) || "../api.php";

async function licRequest(action, opts = {}) {
  const tk = token();
  // Token'ı 3 yolla da gönder: header + adres + gövde.
  // (Bazı paylaşımlı sunucular Authorization başlığını PHP'ye iletmez.)
  const query = { ...(opts.query || {}) };
  if (tk) query.token = tk;
  const qs = Object.keys(query).length ? "&" + new URLSearchParams(query).toString() : "";
  let body = opts.body;
  if (tk && body && typeof body === "object") body = { ...body, token: tk };
  const res = await fetch(LICENSE_API + "?action=" + encodeURIComponent(action) + qs, {
    method: opts.method || "GET",
    headers: {
      ...(body ? { "Content-Type": "application/json" } : {}),
      ...(tk ? { Authorization: "Bearer " + tk } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = { raw: text }; }
  if (!res.ok) throw Object.assign(new Error(data.error || res.statusText), { status: res.status, data });
  return data;
}

export const license = {
  posLogin: (tufan_user, tufan_pass) => licRequest("pos_login", { method: "POST", body: { tufan_user, tufan_pass } }),
  push: (changes) => licRequest("push", { method: "POST", body: { changes } }),
  pull: (since) => licRequest("pull", { query: { since: since || 0 } }),
};

// ============================================================
//  Bulut senkron ("blob" yöntemi) — api/cloud.php  (GÜVENLİ SÜRÜM)
//  Sahibe özel işlemler (save/load/calls/seen/callstatus/applications/
//  cvfile/appseen) artık ORTAK token ile değil; sahibin giriş sonrası
//  aldığı LİSANS TOKEN'ı (localStorage: t101_token) ile doğrulanır.
//  Müşteri (QR menü) işlemleri anonim kalır; menü verisi için gizli alan
//  içermeyen ayrı "menu" ucu kullanılır.
//  Panel farklı bir adresteyse index.html içinde ayarlayın:
//    window.__TUFAN_CLOUD_API__ = "https://.../api/cloud.php";
// ============================================================
export const CLOUD_API =
  (typeof window !== "undefined" && window.__TUFAN_CLOUD_API__) || "api/cloud.php";

async function cloudRequest(action, opts = {}) {
  const tk = token(); // sahibin lisans token'ı (giriş yapılmışsa)
  const qs = new URLSearchParams({ action, ...(opts.query || {}) }).toString();
  const res = await fetch(CLOUD_API + "?" + qs, {
    method: opts.method || "GET",
    headers: {
      ...(opts.body ? { "Content-Type": "application/json" } : {}),
      // Token varsa gönder (sahibe özel işlemler için gerekli). Yoksa istek
      // anonim gider → yalnızca herkese açık uçlar (menu/call/scan/...) çalışır.
      ...(tk ? { Authorization: "Bearer " + tk } : {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });
  const text = await res.text();
  let data; try { data = JSON.parse(text); } catch { data = { ok: false, raw: text }; }
  if (!res.ok) throw Object.assign(new Error(data.error || res.statusText), { status: res.status, data });
  return data;
}

export const cloud = {
  // --- Sahibe özel (lisans token'ı gerekli) ---
  // opts.wipe: true → sunucudaki "boş veri dolu veriyi ezemez" korumasını bilerek aş
  // (yalnızca "Tüm verilerimi sil" için kullanılır).
  save: (account, data, opts = {}) =>
    cloudRequest("save", { method: "POST", body: { account, data, ...(opts && opts.wipe ? { wipe: true } : {}) } }),
  load: (account) =>
    cloudRequest("load", { query: { account } }),
  // İşletme sahibi bildirimleri çeker
  listCalls: (account, opts = {}) =>
    cloudRequest("calls", { query: { account, ...(opts.onlyNew ? { new: "1" } : {}), ...(opts.since ? { since: opts.since } : {}) } }),
  // Görüldü işaretle
  markSeen: (account, ids) =>
    cloudRequest("seen", { method: "POST", body: { account, ...(ids === "all" || !ids ? { all: true } : { ids }) } }),
  // Sipariş/çağrı durumunu değiştir (bekliyor|alindi|hazir|tamam)
  setCallStatus: (account, id, status) =>
    cloudRequest("callstatus", { method: "POST", body: { account, id, status } }),
  // İşletme sahibi başvuruları listeler (CV dosyası hariç)
  applications: (account) =>
    cloudRequest("applications", { query: { account } }),
  // Tek başvurunun CV dosyasını getir (indirmek için)
  cvfile: (account, id) =>
    cloudRequest("cvfile", { query: { account, id } }),
  // Başvuruyu görüldü işaretle / sil
  appseen: (account, id, opts = {}) =>
    cloudRequest("appseen", { method: "POST", body: { account, id, ...(opts.delete ? { delete: true } : {}) } }),

  // --- Herkese açık (müşteri / QR menü — giriş gerektirmez) ---
  // Menü için sadeleştirilmiş, gizli alan içermeyen veri
  menu: (account) =>
    cloudRequest("menu", { query: { account } }),
  // Garson çağır / masa siparişi (müşteri QR menüden yazar)
  call: (account, payload) =>
    cloudRequest("call", { method: "POST", body: { account, ...payload } }),
  // QR okutma sayacı (müşteri menüyü açınca)
  scan: (account) =>
    cloudRequest("scan", { method: "POST", body: { account } }),
  // Puan ver (1-5)
  rate: (account, rating) =>
    cloudRequest("rate", { method: "POST", body: { account, rating } }),
  // Anket cevabı gönder
  survey: (account, answers) =>
    cloudRequest("survey", { method: "POST", body: { account, answers } }),
  // İşletme istatistikleri (okutma/puan herkese açık; anket cevapları yalnız sahibe)
  stats: (account) =>
    cloudRequest("stats", { query: { account } }),
  // Başvuru/anket + CV gönder (aday/müşteri ayrı linkten doldurur)
  cvsubmit: (account, payload) =>
    cloudRequest("cvsubmit", { method: "POST", body: { account, ...payload } }),

  // --- Randevu (QR randevu formu) ---
  // Müşteri randevu isteği gönderir (herkese açık, giriş gerektirmez)
  randevu: (account, payload) =>
    cloudRequest("randevu", { method: "POST", body: { account, ...payload } }),
  // İşletme sahibi randevu isteklerini çeker (token gerekli)
  randevuList: (account) =>
    cloudRequest("randevu_list", { query: { account } }),
  // Randevu durumunu değiştir (bekliyor|onay|iptal|tamam) veya sil
  randevuStatus: (account, id, opts = {}) =>
    cloudRequest("randevu_status", { method: "POST", body: { account, id, ...(opts.delete ? { delete: true } : { status: opts.status }) } }),
};

// ============================================================
//  AI Asistan — api/ai.php (GÜVENLİ)
//  Anahtar sunucuda; istek sahibin lisans token'ı ile doğrulanır.
//  İşletme özeti (kişisel veri YOK) + soru gönderilir, cevap döner.
//  Panel farklı adresteyse: window.__TUFAN_AI_API__ = "https://.../api/ai.php"
// ============================================================
// Yeni "havalı" uç adı: yapayzeka.php  (eski api/ai.php geriye dönük çalışır —
// o dosya artık yapayzeka.php'yi çağıran ince bir köprü.)
export const AI_API =
  (typeof window !== "undefined" && window.__TUFAN_AI_API__) || "api/yapayzeka.php";

export const ai = {
  // opts.signal → AbortController.signal (İptal butonu için)
  ask: async ({ question, context, history }, opts = {}) => {
    const tk = token();
    // Giriş yapılmamışsa boşuna sunucuya gitme; anlamlı hata ver.
    if (!tk) {
      throw Object.assign(new Error("AI asistanı için önce giriş yapmalısınız."),
        { status: 401, data: { ok: false, error: "unauthorized" } });
    }
    // Token'ı 3 yolla da gönder: header + adres (?token=) + gövde.
    // (Bazı paylaşımlı sunucular Authorization başlığını PHP'ye iletmez;
    //  lisans/senkron ucu — licRequest — de aynı yöntemi kullanıyor.)
    const url = AI_API + (AI_API.indexOf("?") === -1 ? "?" : "&") +
      "token=" + encodeURIComponent(tk);
    const res = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: "Bearer " + tk,
      },
      body: JSON.stringify({ question, context, history: history || [], token: tk }),
      signal: opts.signal,
    });
    const text = await res.text();
    let data; try { data = JSON.parse(text); } catch { data = { ok: false, raw: text }; }
    if (!res.ok) throw Object.assign(new Error(data.error || res.statusText), { status: res.status, data });
    return data;
  },
};
