// mod-06 Temel Giriş (Kullanıcı adı + Şifre), mod-15 Rol Yönetimi, mod-22 Süper Admin köprüsü
import { api, setToken, license } from "./api.js";
import { uid, settings } from "./store.js";

const UKEY = "t101_users_v2"; // v2: PIN yerine kullanıcı adı + şifre
const SKEY = "t101_session";
const OWNER_KEY = "t101_owner_account"; // işletme sahibinin bulut kutusu anahtarı

// store.js'teki cloudAccount() ile AYNI temizleme: alt kullanıcıların oturumuna
// bu anahtarı `uye` olarak yazınca, veriler patronun kutusunu paylaşır.
function acctKey(a) {
  return String(a == null ? "" : a).trim().toLowerCase().replace(/[^a-z0-9_\-.]/g, "").slice(0, 64);
}
function setOwnerAccount(k) { try { if (k) localStorage.setItem(OWNER_KEY, k); } catch {} }
function getOwnerAccount() { try { return localStorage.getItem(OWNER_KEY) || ""; } catch { return ""; } }

// İzin şablonları (mod-15). Çırak yalnızca satış yapabilir.
export const ROLE_PERMS = {
  owner:      { sell: 1, refund: 1, changePrice: 1, manageStock: 1, viewReports: 1, manageUsers: 1, cashOut: 1, voidSale: 1 },
  manager:    { sell: 1, refund: 1, changePrice: 1, manageStock: 1, viewReports: 1, manageUsers: 0, cashOut: 1, voidSale: 1 },
  cashier:    { sell: 1, refund: 0, changePrice: 0, manageStock: 1, viewReports: 0, manageUsers: 0, cashOut: 1, voidSale: 0 },
  apprentice: { sell: 1, refund: 0, changePrice: 0, manageStock: 0, viewReports: 0, manageUsers: 0, cashOut: 0, voidSale: 0 },
  // Garson: menüden masaya sipariş alır → ana kasaya bildirim düşer. Kasadan para/iade yok.
  waiter:     { sell: 1, refund: 0, changePrice: 0, manageStock: 0, viewReports: 0, manageUsers: 0, cashOut: 0, voidSale: 0 },
  // Mutfak: gelen siparişleri görür/hazır işaretler. Satış/kasa yetkisi yok.
  kitchen:    { sell: 0, refund: 0, changePrice: 0, manageStock: 0, viewReports: 0, manageUsers: 0, cashOut: 0, voidSale: 0 },
  // Kurye: teslimat/sipariş görür. Satış/kasa yetkisi yok.
  courier:    { sell: 0, refund: 0, changePrice: 0, manageStock: 0, viewReports: 0, manageUsers: 0, cashOut: 0, voidSale: 0 },
};

function readUsers() {
  try { return JSON.parse(localStorage.getItem(UKEY)) || null; } catch { return null; }
}
function writeUsers(list) { localStorage.setItem(UKEY, JSON.stringify(list)); }

export function users() {
  let list = readUsers();
  if (!list) {
    // GUVENLIK: Sabit sifreli varsayilan hesaplar (Doruk/deneme = doruk2011001)
    // KALDIRILDI. Bunlar kodda acikta durdugu icin arka kapiydi. Gercek giris
    // bulut (lisans) hesabiyla yapilir; yerel kullanicilar patron panelinden
    // olusturulur.
    list = [];
    writeUsers(list);
  }
  return list;
}
export function saveUser(u) {
  const list = users();
  if (!u.perms) u.perms = { ...(ROLE_PERMS[u.role] || ROLE_PERMS.cashier) };
  if (!u.id) { u.id = uid(); list.push(u); }
  else { const i = list.findIndex((x) => x.id === u.id); if (i >= 0) list[i] = { ...list[i], ...u }; }
  writeUsers(list);
  return u;
}
export function removeUser(id) { writeUsers(users().filter((u) => u.id !== id)); }

// ---- Oturum ----
let session = null;
try { session = JSON.parse(sessionStorage.getItem(SKEY)); } catch {}

export function currentUser() { return session; }
export function can(perm) { return !!(session && session.perms && session.perms[perm]); }

// Modül izinleri: null dönerse tüm modüller açık; dizi dönerse yalnız o id'ler.
// Ayarlar (settings) ve bildirimler her zaman erişilebilir kalır.
export function allowedModules() {
  if (!session || !Array.isArray(session.modules)) return null;
  return session.modules;
}
export function moduleAllowed(id) {
  const list = allowedModules();
  if (!list) return true;
  if (id === "settings" || id === "notifications") return true;
  return list.includes(id);
}

// Giriş: önce lisans/senkron sunucusu (TUFAN101 kullanıcı-şifre), sonra yerel yedek.
// Not: async — çağıranlar `await login(...)` kullanmalı.
export async function login(username, password) {
  const u = String(username == null ? "" : username).trim();
  const p = String(password == null ? "" : password);

  // 1) Bulut (lisans) girişi — gerçek müşteri hesabı, cihazlar arası senkron açılır
  try {
    const res = await license.posLogin(u, p);
    if (res && res.valid && res.token) {
      setToken(res.token);
      session = {
        id: "cloud:" + u, name: res.ad || u, role: "owner",
        perms: { ...ROLE_PERMS.owner }, cloud: true, uye: res.uye || u,
        pkg: res.pkg || "", expiry: res.expiry || 0,
        // Modül izinleri: null/undefined = tüm modüller açık; dizi = sadece bunlar açık
        modules: Array.isArray(res.modules) ? res.modules : null,
      };
      // Bu cihazda işletme sahibinin bulut kutusunu hatırla → alt kullanıcılar
      // (kasiyer/çırak) giriş yapınca AYNI kutuyu paylaşsın (veri + ürün + stok).
      setOwnerAccount(acctKey(session.uye));
      sessionStorage.setItem(SKEY, JSON.stringify(session));
      try { settings.set({ package: "premium" }); } catch {}
      window.dispatchEvent(new Event("cloudauth"));  // store.js: lastPull sıfırla + pull
      window.dispatchEvent(new Event("authchange"));
      return session;
    }
    if (res && res.valid === false) {
      // Kimlik doğru ama üyelik pasif/süresi dolmuş → yerel yedeğe düşme, hata döndür
      return { error: res.error || "Üyeliğiniz aktif değil.", valid: false };
    }
  } catch (e) {
    if (e && e.status === 401) {
      // Sunucu "kimlik hatalı" dedi; yine de yerel (offline master) denenir
    }
    // Sunucuya ulaşılamadı → yerel giriş denenecek
  }

  // 2) Yerel kullanıcılar (çevrimdışı / geliştirici master — örn. Doruk)
  const found = users().find((x) =>
    x.active && x.username && x.username.toLowerCase() === u.toLowerCase() && String(x.password) === p
  );
  if (!found) return null;
  session = { id: found.id, name: found.name, role: found.role, perms: found.perms, branchId: found.branchId || "" };
  // Veri kutusu (cloudAccount) paylaşımı:
  //  • Sahip (owner) → kendi kutusunu bu cihaza kaydet.
  //  • Alt kullanıcı (kasiyer/çırak/müdür) → sahibin kutusunu `uye` olarak devral;
  //    böylece patronun ürün/stok/satış verisini görür ve YAZDIĞI her şey
  //    patronun bulut kutusuna işlenir (ayrı boş kutuya değil).
  if (found.role === "owner") {
    setOwnerAccount(acctKey(found.name || found.username || found.id));
    // Sahip: tüm modüller açık (modules = null → moduleAllowed her zaman true)
  } else {
    const owner = getOwnerAccount();
    if (owner) session.uye = owner;
    // Alt kullanıcının modül izinleri: dizi ise sadece o modüller açık; yoksa hepsi açık
    session.modules = Array.isArray(found.modules) ? found.modules : null;
  }
  sessionStorage.setItem(SKEY, JSON.stringify(session));
  if (found.package) { try { settings.set({ package: found.package }); } catch {} }
  window.dispatchEvent(new Event("authchange"));
  return session;
}
export function logout() {
  session = null;
  sessionStorage.removeItem(SKEY);
  try { setToken(null); } catch {}
  window.dispatchEvent(new Event("authchange"));
}

// ---- Süper Admin (mod-22) — gerçek doğrulama sunucu tarafında yapılır ----
// İstemci şifre saklamaz; sadece backend'e iletir. Backend yoksa demo görünümü.
export async function superAdminLogin(username, password) {
  try {
    const res = await api.post("auth.php?action=superadmin", { username, password });
    if (res && res.token) { setToken(res.token); return { ok: true, mode: "server" }; }
    return { ok: false, error: res.error || "Giriş başarısız" };
  } catch (e) {
    if (e.status === 401) return { ok: false, error: "Kullanıcı adı veya şifre hatalı" };
    // Backend erişilemiyor (yerel önizleme): salt-okunur demo moduna izin ver
    return { ok: false, offline: true, error: "Sunucuya ulaşılamadı (yerel demo)" };
  }
}
