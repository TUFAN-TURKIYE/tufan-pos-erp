// mod-02 Çekirdek: sıfır gecikmeli veri katmanı
// mod-17 Çevrimdışı senkronizasyon: değişiklikler bir kuyruğa yazılır, ağ gelince gönderilir.
// mod-33 Kalıcı depo: localStorage yerine IndexedDB (büyük kapasite, senkron bloklama yok).
//   • Tüm veri açılışta belleğe (MEM) yüklenir → all()/get() SENKRON kalır (modüller değişmez).
//   • Yazımlar belleği günceller + arka planda IndexedDB'ye yazar (ana iş parçacığını bloklamaz).
//   • Eski localStorage verisi ilk açılışta bir kez otomatik taşınır ve 5MB serbest kalır.
//   • IndexedDB yoksa/açılamazsa otomatik localStorage'a düşer (geriye dönük uyum).
import { cloud } from "./api.js";

const NS = "t101";
const key = (name) => `${NS}_${name}`;

// ---- Kalıcı depo: IndexedDB + bellek-içi string önbellek (MEM) ----
const IDB_DB = "tufan101_store", IDB_STORE = "kv";
const MEM = Object.create(null);   // name → JSON string (localStorage.getItem eşdeğeri)
let _idb = null;                   // açık IndexedDB bağlantısı
let _lsFallback = false;           // IndexedDB açılamadıysa localStorage'a düş

// read/write DAVRANIŞI localStorage sürümüyle AYNIdır (parse-on-read / stringify-on-write),
// yalnızca arka uç değişir. Böylece tüm modüller ve senkron/mezar-taşı mantığı aynen çalışır.
function read(name, fallback) {
  try { const v = MEM[name]; return (v != null) ? JSON.parse(v) : fallback; }
  catch { return fallback; }
}
function write(name, val) {
  let s; try { s = JSON.stringify(val); } catch { return; }
  MEM[name] = s;
  idbPut(name, s);
}
function del(name) {
  delete MEM[name];
  if (_idb) { try { _idb.transaction(IDB_STORE, "readwrite").objectStore(IDB_STORE).delete(key(name)); } catch {} }
  if (_lsFallback) { try { localStorage.removeItem(key(name)); } catch {} }
}
function idbPut(name, s) {
  if (_idb) { try { _idb.transaction(IDB_STORE, "readwrite").objectStore(IDB_STORE).put(s, key(name)); return; } catch {} }
  if (_lsFallback) { try { localStorage.setItem(key(name), s); } catch {} }
}
function idbOpen() {
  return new Promise((res) => {
    let req; try { req = indexedDB.open(IDB_DB, 1); } catch { return res(null); }
    req.onupgradeneeded = () => { try { req.result.createObjectStore(IDB_STORE); } catch {} };
    req.onsuccess = () => res(req.result);
    req.onerror = () => res(null);
    req.onblocked = () => res(null);
  });
}
// IndexedDB'deki tüm kalıcı anahtarları belleğe yükle (yalnız NS önekli).
function idbHydrate() {
  return new Promise((res) => {
    if (!_idb) return res();
    try {
      const store = _idb.transaction(IDB_STORE, "readonly").objectStore(IDB_STORE);
      const rk = store.getAllKeys(), rv = store.getAll();
      let keys = null, vals = null;
      const fill = () => {
        try { for (let i = 0; i < keys.length; i++) { const k = String(keys[i]); if (k.indexOf(NS + "_") === 0) MEM[k.slice(NS.length + 1)] = vals[i]; } } catch {}
        res();
      };
      rk.onsuccess = () => { keys = rk.result || []; if (vals) fill(); };
      rv.onsuccess = () => { vals = rv.result || []; if (keys) fill(); };
      rk.onerror = rv.onerror = () => res();
    } catch { res(); }
  });
}
// IndexedDB yoksa: eski localStorage'dan belleğe oku (geriye dönük uyum).
function lsHydrate() {
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i);
      if (k && k.indexOf(NS + "_") === 0) { try { MEM[k.slice(NS.length + 1)] = localStorage.getItem(k); } catch {} }
    }
  } catch {}
}
// İlk açılış: IndexedDB boşsa ama localStorage'da eski veri varsa → taşı.
// GÜVENLİK: localStorage yalnızca IndexedDB yazımı KESİNLEŞTİKTEN (commit) sonra silinir.
// Aksi halde asenkron yazım commit olmadan localStorage silinirse veri kaybolabilir.
async function migrateFromLocalStorage() {
  try {
    if (MEM["_idbmig"] != null) return;              // zaten taşınmış
    const names = [...SYNC_TABLES, "settings", "queue", "seeded_v3", "lastAccount"];
    const moved = [];
    const entries = [];
    names.forEach((nm) => {
      if (MEM[nm] != null) return;                   // IndexedDB'de zaten var
      let raw = null; try { raw = localStorage.getItem(key(nm)); } catch {}
      if (raw != null) { MEM[nm] = raw; entries.push([key(nm), raw]); moved.push(nm); }
    });
    MEM["_idbmig"] = "1"; entries.push([key("_idbmig"), "1"]);
    // Hepsini TEK transaction'da yaz ve COMMIT'i bekle.
    const committed = await new Promise((res) => {
      if (!_idb) return res(false);
      try {
        const tx = _idb.transaction(IDB_STORE, "readwrite");
        const st = tx.objectStore(IDB_STORE);
        entries.forEach(([k, v]) => st.put(v, k));
        tx.oncomplete = () => res(true);
        tx.onerror = tx.onabort = () => res(false);
      } catch { res(false); }
    });
    // Ancak IndexedDB kalıcı yazdıysa eski localStorage anahtarlarını sil (5MB'ı serbest bırak).
    // Yazamadıysa localStorage'a DOKUNMA → veri orada güvende kalır, sonraki açılışta tekrar denenir.
    if (committed) moved.forEach((nm) => { try { localStorage.removeItem(key(nm)); } catch {} });
  } catch {}
}

export const uid = () =>
  Date.now().toString(36) + Math.random().toString(36).slice(2, 8);

// Temiz başlangıç: örnek kategori/ürün YOK — işletme sahibi kendisi ekler.
function seed() {
  if (read("seeded_v3")) return;
  write("categories", []); write("products", []); write("sales", []); write("txns", []);
  write("customers", []); write("cariEntries", []); write("shifts", []); write("staff", []);
  write("orders", []); write("properties", []); write("queue", []);
  write("seeded_v3", true);
}

// ---- AÇILIŞ KAPISI ----
// Bu Promise çözülene kadar uygulama İLK RENDER'ı beklemelidir (app.js → ready.then).
// IndexedDB açılır, veri belleğe yüklenir, gerekirse localStorage'dan taşınır.
export const ready = (async function bootStore() {
  _idb = await Promise.race([idbOpen(), new Promise((r) => setTimeout(() => r(null), 4000))]);
  if (_idb) { await idbHydrate(); await migrateFromLocalStorage(); }
  else { _lsFallback = true; lsHydrate(); }         // IndexedDB yok → localStorage yedeği
  seed();
  initAccountBoundary();
  return true;
})();

// Basit kayıt tablosu API'si (offline-first)
function table(name) {
  return {
    // Silinmiş (mezar taşı) kayıtlar gizlenir; ama depoda kalır ki silme diğer cihaza yayılsın.
    all: () => read(name, []).filter((r) => r && !r._deleted),
    get: (id) => { const r = read(name, []).find((x) => x.id === id); return (r && !r._deleted) ? r : undefined; },
    upsert: (row) => {
      const list = read(name, []);
      if (!row.id) row.id = uid();
      row._u = Date.now(); // son değişiklik damgası (cihazlar arası çakışma çözümü)
      const i = list.findIndex((r) => r.id === row.id);
      if (i >= 0) list[i] = { ...list[i], ...row, _deleted: false }; // upsert kaydı canlandırır
      else list.push(row);
      write(name, list);
      enqueue({ table: name, op: "upsert", row: (i >= 0 ? list[i] : row) });
      emit();
      return (i >= 0 ? list[i] : row);
    },
    // Silme: fiziksel silmek yerine MEZAR TAŞI bırak (id + _deleted + _u). Böylece
    // "A'da sildiğim B'de de silinsin" çalışır ve stale cihaz kaydı geri DİRİLTMEZ.
    remove: (id) => {
      if (!id) return;
      const list = read(name, []);
      const tomb = { id, _deleted: true, _u: Date.now() };
      const i = list.findIndex((r) => r.id === id);
      if (i >= 0) list[i] = tomb; else list.push(tomb);
      write(name, list);
      enqueue({ table: name, op: "remove", row: tomb });
      emit();
    },
    replaceAll: (rows) => write(name, rows),
  };
}

// ---- Değişiklik kuyruğu (bekleyen kayıt sayacı için) ----
// Blob senkronda tüm veri tek seferde gönderilir; kuyruk sadece
// "gönderilmeyi bekleyen değişiklik var mı?" rozetini beslemek için tutulur.
function enqueue(change) {
  const q = read("queue", []);
  q.push({ ...change, ts: Date.now(), _cid: uid() });
  write("queue", q);
  scheduleSync();
}
export function pendingCount() { return read("queue", []).length; }

// ---- Hangi tablolar buluta senkronlanır ----
const SYNC_TABLES = [
  "products", "categories", "sales", "txns", "customers", "cariEntries",
  "shifts", "staff", "orders", "properties", "suppliers", "branches",
  "appointments", "productions", "notifications", "loyalty", "couriers",
  "approvals", "invoices", "contracts", "attendance", "leaves", "campaigns",
  "stockMoves", "debts", "accounts", "accountMoves", "supplierEntries",
  "cashSessions", "giftcards", "auditLog",
];
// settings içindeki cihaza özel alanlar (buluttan geldiğinde korunur)
const DEVICE_SETTINGS = ["theme", "lang", "scale"];

// Giriş yapan hesabın adı = bulut anahtarı (cihazlar arası ortak)
function cloudAccount() {
  try {
    const s = JSON.parse(sessionStorage.getItem("t101_session"));
    if (!s) return "";
    const a = s.uye || s.name || s.id || "";
    return String(a).trim().toLowerCase().replace(/[^a-z0-9_\-.]/g, "").slice(0, 64);
  } catch { return ""; }
}

// Tüm senkron verisini tek nesnede topla
function snapshot() {
  const snap = { _savedAt: Date.now() };
  SYNC_TABLES.forEach((nm) => { snap[nm] = read(nm, []); });
  snap.settings = read("settings", {});
  return snap;
}

// Boş anlık görüntü mü? (hiç veri yok + işletme bilgisi yok)
// Boş bir cihaz (yeni giriş / temizlenmiş tarayıcı) buluttaki DOLU veriyi
// EZMESİN diye kullanılır — çok cihazlı kullanımda veri kaybını önler.
function snapshotIsEmpty(snap) {
  if (!snap) return true;
  const anyRows = SYNC_TABLES.some((nm) => Array.isArray(snap[nm]) && snap[nm].length > 0);
  const s = (snap.settings && typeof snap.settings === "object") ? snap.settings : {};
  const hasBiz = !!(s.business || s.owner || s.phone || s.whatsapp ||
    (Array.isArray(s.menuItems) && s.menuItems.length) || s.menuColor || s.logo);
  return !anyRows && !hasBiz;
}

// QR'a özel ürünler (settings.menuItems) tüm ayar bloğunun TEK zaman damgasına
// (settings._u) bağlı senkronlanırdı; bu yüzden bir cihazın ayarları daha yeniyse
// diğer cihazda eklenen QR ürünü hem çekilemez hem de buluttan silinirdi.
// Çözüm: menuItems'ı normal ürünler gibi ÜRÜN BAZINDA birleştir.
//  - Ürünler 'id' ile eşlenir (id yoksa ada göre); aynı id'de daha yeni '_u' kazanır.
//  - Silinen ürünler '_deleted' mezar taşı ile taşınır ki silme de yayılsın.
// Dönüş: birleştirilmiş dizi (iki taraf da dizi değilse null → dokunma).
function mergeMenuLists(localArr, remoteArr) {
  if (!Array.isArray(localArr) && !Array.isArray(remoteArr)) return null;
  const keyOf = (m) => String((m && (m.id || ("name:" + String(m.name || "").trim().toLowerCase()))) || "");
  const map = new Map(), order = [];
  const absorb = (arr) => {
    (Array.isArray(arr) ? arr : []).forEach((m) => {
      if (!m || typeof m !== "object") return;
      const k = keyOf(m); if (!k) return;
      const cur = map.get(k);
      if (!cur) { map.set(k, m); order.push(k); }               // yeni ürün
      else if (Number(m._u || 0) >= Number(cur._u || 0)) map.set(k, m); // daha yeni sürüm kazanır
    });
  };
  absorb(localArr);   // önce yerel: mevcut sıralama korunur
  absorb(remoteArr);  // sonra uzak: daha yeni damgalılar üste yazar, yeni gelenler eklenir
  return order.map((k) => map.get(k));
}

// settings içindeki ANAHTARLI (map) koleksiyonları anahtar bazında birleştirir.
// Örnek: açık masalar/adisyonlar (settings.tables = { "M3": {items,_u}, ... }).
// Her değer kendi '_u' damgasını taşır; aynı anahtarda daha yeni '_u' kazanır.
// Kapanan masalar '_deleted' mezar taşı ile taşınır ki ödeme/boşaltma diğer
// cihaza da yansısın (ve stale bir cihaz kapanmış masayı geri DİRİLTMESİN).
// Böylece iki cihaz FARKLI masaları aynı anda açsa bile hiçbiri kaybolmaz.
function mergeMapById(localMap, remoteMap) {
  const isObj = (o) => o && typeof o === "object" && !Array.isArray(o);
  const lo = isObj(localMap) ? localMap : null;
  const ro = isObj(remoteMap) ? remoteMap : null;
  if (!lo && !ro) return null;
  const out = {};
  const keys = new Set([...(lo ? Object.keys(lo) : []), ...(ro ? Object.keys(ro) : [])]);
  keys.forEach((k) => {
    const a = lo ? lo[k] : undefined;
    const b = ro ? ro[k] : undefined;
    if (a == null) { out[k] = b; return; }
    if (b == null) { out[k] = a; return; }
    out[k] = (Number(b._u || 0) >= Number(a._u || 0)) ? b : a; // aynı anahtarda daha yeni kazanır
  });
  return out;
}

// Buluttan gelen veriyi yerelle birleştir (kayıt bazında son-yazan-kazanır)
function restore(remote) {
  if (!remote || typeof remote !== "object") return false;
  let changed = 0;
  let settingsChanged = false;
  SYNC_TABLES.forEach((nm) => {
    const rlist = Array.isArray(remote[nm]) ? remote[nm] : null;
    if (!rlist) return;
    const local = read(nm, []);
    const byId = new Map(local.map((r) => [r.id, r]));
    let touched = false;
    rlist.forEach((rrow) => {
      if (!rrow || !rrow.id) return;
      const cur = byId.get(rrow.id);
      const ru = Number(rrow._u || 0);
      if (!cur) { byId.set(rrow.id, rrow); touched = true; changed++; }
      else if (ru >= Number(cur._u || 0)) {
        // Daha yeni kayıt kazanır; silme durumu da (canlı/silinmiş) onun damgasına göre belirlenir.
        byId.set(rrow.id, { ...cur, ...rrow, _deleted: !!rrow._deleted });
        touched = true; changed++;
      }
    });
    if (touched) write(nm, Array.from(byId.values()));
  });
  // Ayarlar: iş bilgileri buluttan, cihaz tercihleri (tema/dil/ölçek) yerelden.
  // ÖNEMLİ: Yerel ayar buluttakinden daha yeniyse (kullanıcı az önce kaydettiyse)
  // bulut ayarını YAZMA — aksi halde girilen işletme adı/telefon anında silinir.
  if (remote.settings && typeof remote.settings === "object") {
    const local = read("settings", {});
    const localU = Number(local._u || 0);
    const remoteU = Number(remote.settings._u || 0);
    // QR'a özel ürünleri ürün-bazında birleştir (ayar bloğunun _u kapısından BAĞIMSIZ).
    // Böylece diğer cihazın ayarı daha yeni olsa bile QR ürünü kaybolmaz.
    const mergedMenu = mergeMenuLists(local.menuItems, remote.settings.menuItems);
    const mergedTables = mergeMapById(local.tables, remote.settings.tables); // açık masalar
    let base = null;
    if (remoteU >= localU) {
      base = { ...local, ...remote.settings };
      DEVICE_SETTINGS.forEach((k) => { if (k in local) base[k] = local[k]; });
    } else if (mergedMenu || mergedTables) {
      // Uzak ayarlar daha eski; işletme bilgilerini koru, yalnız koleksiyonları güncelle.
      base = { ...local };
    }
    if (base) {
      if (mergedMenu) base.menuItems = mergedMenu;
      if (mergedTables) base.tables = mergedTables;
      // Yalnızca gerçekten değişiklik varsa yaz (gereksiz yazımı önle).
      if (JSON.stringify(base) !== JSON.stringify(local)) { write("settings", base); settingsChanged = true; }
    }
  }
  return changed > 0 || settingsChanged;
}

// ---- Buluta gönder (save) ----
let syncing = false, syncTimer = null;
function scheduleSync() {
  clearTimeout(syncTimer);
  syncTimer = setTimeout(sync, 1200); // değişiklikleri toplayıp tek istek at
}
export async function sync() {
  if (syncing || !navigator.onLine) return;
  const account = cloudAccount();
  if (!account) return;               // giriş yok → yerel çalış
  if (!read("queue", []).length) return; // bekleyen değişiklik yok
  const snap = snapshot();
  // GÜVENLİK: Boş cihaz buluttaki dolu veriyi ezmesin. Yerelde hiç veri yoksa
  // (yeni giriş / tarayıcı temizlenmiş) buluta YAZMA — önce pull ile veri gelsin.
  if (snapshotIsEmpty(snap)) { window.dispatchEvent(new CustomEvent("syncstate", { detail: "done" })); return; }
  syncing = true;
  window.dispatchEvent(new CustomEvent("syncstate", { detail: "syncing" }));
  try {
    const res = await cloud.save(account, snap);
    if (res && res.ok) {
      write("queue", []); // gönderildi
      window.dispatchEvent(new CustomEvent("syncstate", { detail: "done" }));
    } else {
      window.dispatchEvent(new CustomEvent("syncstate", { detail: "offline" }));
    }
  } catch {
    window.dispatchEvent(new CustomEvent("syncstate", { detail: "offline" }));
  } finally {
    syncing = false;
    emit();
  }
}
window.addEventListener("online", sync);
setInterval(sync, 15000);

// ---- Buluttan indir (load) — cihazlar arası senkron ----
let pulling = false;
export async function pull() {
  if (pulling || !navigator.onLine) return;
  const account = cloudAccount();
  if (!account) return;
  pulling = true;
  try {
    const res = await cloud.load(account);
    if (res && res.ok && res.data) {
      const changed = restore(res.data);
      if (changed) {
        emit();
        window.dispatchEvent(new CustomEvent("cloudpull", { detail: { changed } }));
      }
    }
  } catch { /* backend yok / çevrimdışı */ }
  finally { pulling = false; }
}

export async function syncAll() { await sync(); await pull(); }

// ---- Tüm işletme verisini sil (yalnızca patron) ----
// Ürün, satış, gelir/gider, müşteri, stok, cari vb. tüm kayıtları hem cihazdan
// hem de buluttan temizler. İşletme ayarları (ad/logo/tercihler) ve oturum korunur;
// böylece hesap çalışmaya devam eder ama tüm veriler sıfırlanır.
export async function wipeAllData() {
  SYNC_TABLES.forEach((nm) => write(nm, []));
  write("queue", []);
  emit();
  // Buluttaki veriyi de sıfırla — yoksa bir sonraki 'pull' silinen kayıtları geri getirir.
  const account = cloudAccount();
  if (account && navigator.onLine) {
    // wipe:true → sunucudaki boş-veri koruması bu KASITLI sıfırlamayı engellemesin.
    try { await cloud.save(account, snapshot(), { wipe: true }); } catch {}
  }
  return true;
}

// ============================================================
//  YEREL YEDEK — Tüm veriyi dosyaya aktar / dosyadan geri al
//  Buluttan bağımsız çalışır: kullanıcı verisini kendi bilgisayarına
//  .json olarak indirebilir ve istediğinde geri yükleyebilir.
// ============================================================

// Dışa aktarma: tüm senkron tabloları + ayarları tek bir yedek nesnesinde topla.
export function exportData() {
  return {
    _app: "TUFAN101",
    _type: "backup",
    _version: 1,
    _account: cloudAccount() || "",
    _exportedAt: Date.now(),
    data: snapshot(),
  };
}

// Yedek nesnesindeki kayıt sayısını hızlıca say (içe alma önizlemesi için).
export function backupSummary(payload) {
  const snap = (payload && payload.data && typeof payload.data === "object") ? payload.data : payload;
  const out = { total: 0, tables: {}, hasSettings: false };
  if (!snap || typeof snap !== "object") return out;
  SYNC_TABLES.forEach((nm) => {
    if (Array.isArray(snap[nm]) && snap[nm].length) { out.tables[nm] = snap[nm].length; out.total += snap[nm].length; }
  });
  out.hasSettings = !!(snap.settings && typeof snap.settings === "object");
  return out;
}

// İçe alma: dosyadan gelen yedeği yerele yükler.
//  mode="merge"   → kayıt bazında son-yazan-kazanır (mevcut veriyle birleştirir)
//  mode="replace" → tabloların üstüne yazar (yedek neyse o olur)
// Her iki durumda da değişiklikler buluta gönderilmek üzere kuyruğa işaretlenir.
export function importData(payload, mode = "merge") {
  const snap = (payload && payload.data && typeof payload.data === "object") ? payload.data : payload;
  if (!snap || typeof snap !== "object") return { ok: false, error: "Geçersiz yedek dosyası." };
  let recognized = 0;
  SYNC_TABLES.forEach((nm) => { if (Array.isArray(snap[nm])) recognized += snap[nm].length; });
  const hasSettings = !!(snap.settings && typeof snap.settings === "object");
  if (!recognized && !hasSettings) return { ok: false, error: "Yedek içinde tanınan veri bulunamadı." };

  if (mode === "replace") {
    SYNC_TABLES.forEach((nm) => { if (Array.isArray(snap[nm])) write(nm, snap[nm]); });
    if (hasSettings) {
      const local = read("settings", {});
      const merged = { ...local, ...snap.settings, _u: Date.now() };
      DEVICE_SETTINGS.forEach((k) => { if (k in local) merged[k] = local[k]; }); // tema/dil/ölçek yerelden korunur
      write("settings", merged);
    }
  } else {
    restore(snap); // son-yazan-kazanır birleştirme
  }

  // İçe alınan veriyi buluta da yansıt: her tabloyu kuyruğa işaretle → sync() tam anlık gönderir.
  SYNC_TABLES.forEach((nm) => enqueue({ table: nm, op: "import", row: { _u: Date.now() } }));
  emit();
  return { ok: true, count: recognized };
}

// Giriş yapan hesabın bulut adı (QR menü bağlantısı için)
export function currentAccount() { return cloudAccount(); }
// Belirli bir hesabın HERKESE AÇIK menü verisini oku (QR menü — giriş gerektirmez).
// GÜVENLİK: Artık tüm veri bloğu (cloud.load) değil; yalnızca gizli alan içermeyen
// sadeleştirilmiş menü verisi (cloud.menu) çekilir. Böylece maliyet, stok, satış,
// cari, finans, personel gibi özel veriler anonim ziyaretçiye ASLA gönderilmez.
export async function fetchAccountData(account) {
  const acc = String(account || "").trim().toLowerCase().replace(/[^a-z0-9_\-.]/g, "").slice(0, 64);
  if (!acc) return null;
  try { const res = await cloud.menu(acc); return (res && res.ok) ? res.data : null; }
  catch { return null; }
}
window.addEventListener("online", pull);

// ---- Hesap sınırı: farklı bir hesaba giriş yapılınca yereli temizle ----
// Sorun: t101_* tabloları cihaz genelinde ORTAK tutulur. Aynı tarayıcıda
// A hesabından çıkıp B hesabına girildiğinde, A'nın ürün/stok/satış verisi
// yerelde kalır; ardından snapshot() ile B'nin bulut kutusuna gönderilir →
// stoklar yeni hesaba SIZAR. Çözüm: hesap değiştiğinde, yeni hesabın bulut
// verisini çekmeden ÖNCE önceki hesabın yerel verisini sıfırla.
function clearLocalTables() {
  SYNC_TABLES.forEach((nm) => write(nm, []));
  // ÖNEMLİ: Ayarlar (işletme adı/telefon/adres/logo…) da hesaba özeldir ve
  // SYNC_TABLES'ta yer almaz. Hesap değişiminde bunları da sıfırlamazsak,
  // önceki hesabın işletme adı yeni hesabın ekranında görünür ve buluta sızar.
  // Cihaz tercihleri (tema/dil/ölçek) korunur; _u=0 → yeni hesabın bulut ayarı kazanır.
  resetSettingsForAccount(cloudAccount());
  write("queue", []);
  emit();
}
// İşletme ayarlarını sıfırla ve verilen hesaba etiketle. İşletme bilgileri
// varsayılana döner; yalnızca cihaz tercihleri (tema/dil/ölçek) korunur.
function resetSettingsForAccount(account) {
  const local = read("settings", {});
  const device = {};
  DEVICE_SETTINGS.forEach((k) => { if (k in local) device[k] = local[k]; });
  del("settings");                                     // → get() varsayılanları döndürür
  write("settings", { ...settings.get(), ...device, _account: account || "", _u: 0 });
}
// Yerel ayar başka bir hesaba aitse (işletme adı sızması) sıfırla. Damgasız
// (eski sürümden kalan) ayarları güvenli sayıp yalnızca mevcut hesaba etiketler.
function guardSettingsAccount() {
  const account = cloudAccount();
  if (!account) return;
  const s = read("settings", null);
  if (!s || typeof s !== "object") return;
  if (!s._account) { s._account = account; write("settings", s); return; } // eski sürüm: yalnız damgala
  if (s._account === account) return;                                        // doğru hesap
  resetSettingsForAccount(account);                                          // farklı hesabın ayarı sızmış → sıfırla
  emit();
}
// Giriş yapılan hesap, en son senkronlanan hesaptan farklıysa yereli temizler.
// Dönüş: hesap sınırı aşıldı mı (temizlik yapıldı mı)?
function guardAccountBoundary() {
  const account = cloudAccount();
  if (!account) return false;                 // çıkış durumu — bir sonraki girişte kontrol edilir
  const last = read("lastAccount", "");
  if (account !== last) {
    clearLocalTables();                        // önceki hesabın verisi bu hesaba sızmasın
    write("lastAccount", account);
    return true;
  }
  return false;
}

// Yükseltme uyumu: bu özellik gelmeden önce zaten giriş yapmış bir kullanıcı
// varsa, mevcut yerel veri o hesaba aittir — silinmemeli. lastAccount boşsa
// (ilk kez), mevcut hesaba eşitle; böylece yalnızca GERÇEK hesap değişiminde temizlik olur.
// Not: bu, açılışta (ready) hidrasyon TAMAMLANDIKTAN sonra çağrılır (bkz. bootStore).
function initAccountBoundary() {
  const account = cloudAccount();
  if (account && !read("lastAccount", "")) write("lastAccount", account);
}

// Girişten sonra: önce hesap sınırını kontrol et (gerekiyorsa yereli temizle),
// sonra buluttan çek (diğer cihazların verisi), en son bekleyen kayıtları gönder.
async function onLoginSync() {
  guardAccountBoundary();
  guardSettingsAccount();   // işletme adı başka hesaptan sızmışsa sıfırla
  try { await pull(); } catch {}
  sync();
}
window.addEventListener("cloudauth", onLoginSync);
window.addEventListener("authchange", onLoginSync);
setInterval(pull, 15000);

// ---- Değişiklik yayını ----
const listeners = new Set();
export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit() { listeners.forEach((fn) => fn()); }

// ---- Ayarlar ----
export const settings = {
  get: () => read("settings", {
    business: "İşletmem", lang: "tr", theme: "light", package: "free", currency: "₺", scale: 1,
    phone: "", address: "", instagram: "", website: "",
    whatsapp: "", maps: "", wifiName: "", wifiPass: "", logo: "",
    // ---- Fiş / resmi işletme kimliği (satış fişinde görünür) ----
    companyTitle: "", taxOffice: "", taxNo: "", mersis: "", receiptFooter: "",
    survey: null, // { title, questions:[{id,text,type:'rating'|'text'}] }
    requireTable: false, // true: QR menüde masa numarası olmadan sipariş/çağrı yapılamaz
    // ---- QR menü / dijital kartvizit ek alanları ----
    owner: "", email: "", googleReviews: "", about: "",
    iban: "", bankName: "", bankHolder: "",
    hideMenuPrice: false,      // true: menüde ürün fiyatları gizlenir
    menuOrdering: true,        // false: müşteri sipariş veremez (sadece vitrin)
    menuWhatsappOrder: false,  // true: "Siparişi Gönder" WhatsApp'a yönlendirir
    menuColor: "#2563EB",      // QR menü vurgu rengi (işletme sahibi seçer)
  }),
  set: (patch) => {
    const s = { ...settings.get(), ...patch };
    s._u = Date.now();               // son değişiklik damgası (bulut çakışma çözümü)
    s._account = cloudAccount();      // ayarı giriş yapan hesaba etiketle (sızma koruması)
    write("settings", s);
    // Ayar değişikliğini senkron kuyruğuna işaretle ki buluta GÖNDERİLSİN.
    // Aksi halde queue boş kalır, sync() erken döner ve bir sonraki pull()
    // buluttaki eski ayarları yerelin üstüne yazıp girilen bilgiyi siler.
    enqueue({ table: "settings", op: "settings", row: { _u: s._u } });
    emit();
    return s;
  },
};

export const db = {
  products: table("products"),
  categories: table("categories"),
  sales: table("sales"),
  txns: table("txns"),
  customers: table("customers"),
  cariEntries: table("cariEntries"),
  shifts: table("shifts"),
  staff: table("staff"),
  orders: table("orders"),
  properties: table("properties"),
  // Ek modüller için tablolar (offline-first, ayni kuyruga yazar)
  suppliers: table("suppliers"),
  branches: table("branches"),
  appointments: table("appointments"),
  productions: table("productions"),
  notifications: table("notifications"),
  loyalty: table("loyalty"),
  couriers: table("couriers"),
  // Kampanya/indirim motoru: { id, name, kind:'percent'|'fixed', value, minTotal, active }
  campaigns: table("campaigns"),
  // Kasa açılış/kapanış oturumları: { id, openTs, opening, closeTs, counted, expected, diff, note, userId, userName, branchId, open }
  cashSessions: table("cashSessions"),
  // Hediye çekleri: { id, code, initial, balance, active, history:[{ts,amount,note}] }
  giftcards: table("giftcards"),
  // Denetim kaydı: { id, ts, userId, userName, action, entity, detail, before, after }
  auditLog: table("auditLog"),
  approvals: table("approvals"),
  invoices: table("invoices"),
  contracts: table("contracts"),
  attendance: table("attendance"),
  leaves: table("leaves"),
  stockMoves: table("stockMoves"),
  debts: table("debts"),
  // ---- Muhasebe: Kasa & Banka hesapları + hareketleri + tedarikçi cari ----
  accounts: table("accounts"),         // { id, name, type:'cash'|'bank', bankName, iban, provider, opening, active, order }
  accountMoves: table("accountMoves"), // { id, accountId, dir:'in'|'out', amount, source, refId, note, party, ts }
  supplierEntries: table("supplierEntries"), // { id, supplierId, type:'purchase'|'payment', amount, note, accountId, ts }
};

// ---- Türetilmiş sorgular ----
export function todayRange() {
  const d = new Date(); d.setHours(0, 0, 0, 0);
  return d.getTime();
}
export function todaySales() {
  const start = todayRange();
  return db.sales.all().filter((s) => !s.void && s.ts >= start);
}
export function money(n) {
  const c = settings.get().currency || "₺";
  return `${(Number(n) || 0).toLocaleString("tr-TR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${c}`;
}
export function lowStockProducts(threshold = 5) {
  return db.products.all().filter((p) => p.active && p.stock <= threshold);
}

// ============================================================
//  MUHASEBE ÇEKİRDEĞİ — Kasa & Banka hesapları (tek doğruluk kaynağı)
//  Tüm modüller (POS, gelir/gider, cari, tedarikçi) buraya para akıtır;
//  böylece modüller "ada" değil, birbirine bağlı çalışır.
// ============================================================

// İlk kullanımda en az bir "Ana Kasa" bulunmasını garanti et.
export function ensureAccounts() {
  const list = db.accounts.all();
  if (!list.length) {
    db.accounts.upsert({ id: "kasa-ana", name: "Ana Kasa", type: "cash", opening: 0, active: true, order: 0 });
  }
  return db.accounts.all();
}

// Aktif hesaplar (sıralı)
export function listAccounts() {
  return db.accounts.all()
    .filter((a) => a.active !== false)
    .sort((a, b) => (a.order || 0) - (b.order || 0) || String(a.name).localeCompare(String(b.name), "tr"));
}

// Bir hesabın güncel bakiyesi = açılış + girişler − çıkışlar
export function accountBalance(id) {
  const a = db.accounts.get(id);
  if (!a) return 0;
  const moves = db.accountMoves.all().filter((m) => m.accountId === id);
  return (Number(a.opening) || 0) + moves.reduce((s, m) => s + (m.dir === "in" ? (Number(m.amount) || 0) : -(Number(m.amount) || 0)), 0);
}

// Varsayılan hesabı bul (ilk nakit kasa, yoksa ilk hesap)
export function defaultAccountId(prefer) {
  const list = listAccounts();
  if (!list.length) return "";
  if (prefer === "bank") { const b = list.find((a) => a.type === "bank"); if (b) return b.id; }
  const cash = list.find((a) => a.type === "cash");
  return (cash || list[0]).id;
}

// Bir hesaba para hareketi işle (giriş/çıkış). Modüller arası köprü.
export function postAccountMove({ accountId, dir, amount, source, refId, note, party, ts }) {
  amount = Number(amount) || 0;
  if (!accountId || !amount) return null;
  return db.accountMoves.upsert({
    id: uid(), accountId, dir: dir === "out" ? "out" : "in", amount,
    source: source || "manual", refId: refId || "", note: note || "", party: party || "", ts: ts || Date.now(),
  });
}

// Bir kaynağa (refId) bağlı hareketleri sil (kayıt geri alınınca)
export function removeAccountMovesByRef(refId) {
  if (!refId) return;
  db.accountMoves.all().filter((m) => m.refId === refId).forEach((m) => db.accountMoves.remove(m.id));
}
