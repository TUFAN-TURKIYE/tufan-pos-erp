// TUFAN 101 — Gezinme & kurulum köprüsü (yan etkisiz).
// Bu modül app.js'i İÇE AKTARMAZ. Böylece app.js ↔ modüller arasındaki
// döngüsel bağımlılık (circular import / TDZ) kırılır ve sayfa yenilemede
// (F5) "MODULES before initialization" hatası oluşmaz.
import { toast } from "./ui.js";
import { t } from "./i18n.js";

export function navigate(id) { location.hash = "#/" + id; }

let _deferredInstall = null;
export function setDeferredInstall(e) { _deferredInstall = e; }
export function canInstall() { return !!_deferredInstall; }
export async function doInstall() {
  if (!_deferredInstall) {
    toast(t("installApp") + ": tarayıcı menüsünden 'Ana ekrana ekle'.", "warn");
    return;
  }
  _deferredInstall.prompt();
  await _deferredInstall.userChoice;
  _deferredInstall = null;
}
