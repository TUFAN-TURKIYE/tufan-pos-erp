// TUFAN 101 — Barkod altyapısı: EAN-13 üretimi/çizimi + kamera ile okuma
import { el, modal, toast } from "./ui.js";

/* ---------- EAN-13 kodlama tabloları ---------- */
const L = ["0001101","0011001","0010011","0111101","0100011","0110001","0101111","0111011","0110111","0001011"];
const G = ["0100111","0110011","0011011","0100001","0011101","0111001","0000101","0010001","0001001","0010111"];
const R = ["1110010","1100110","1101100","1000010","1011100","1001110","1010000","1000100","1001000","1110100"];
const PARITY = ["AAAAAA","AABABB","AABBAB","AABBBA","ABAABB","ABBAAB","ABBBAA","ABABAB","ABABBA","ABBABA"];

// 12 haneden EAN-13 kontrol hanesini hesaplar
export function ean13Check(d12) {
  const d = String(d12).replace(/\D/g, "").slice(0, 12).padStart(12, "0");
  let sum = 0;
  for (let i = 0; i < 12; i++) sum += (+d[i]) * (i % 2 === 0 ? 1 : 3);
  return (10 - (sum % 10)) % 10;
}

// Yeni benzersiz EAN-13 üretir — Türkiye (TR) GS1 ülke ön eki 869 ile başlar.
// Böylece üretilen barkodlar "8690..." biçiminde, Türkiye'ye ait görünür.
export function generateEAN13() {
  // 869 (TR) + 9 rastgele hane = 12 hane, sonra kontrol hanesi
  let base = "869" + String(Math.floor(Math.random() * 1e9)).padStart(9, "0").slice(0, 9);
  base = base.slice(0, 12);
  return base + ean13Check(base);
}

export function isValidEAN13(code) {
  const c = String(code || "").replace(/\D/g, "");
  return c.length === 13 && ean13Check(c.slice(0, 12)) === +c[12];
}

// EAN-13 kodunu canvas'a çizer (bar dizisi)
export function drawEAN13(canvas, code13, opts = {}) {
  const code = String(code13).replace(/\D/g, "").padStart(13, "0").slice(0, 13);
  const unit = opts.unit || 2;      // bir modülün piksel genişliği
  const height = opts.height || 70; // bar yüksekliği
  const quiet = 10 * unit;          // kenar boşluğu
  const first = +code[0];
  const leftDigits = code.slice(1, 7);
  const rightDigits = code.slice(7, 13);
  const parity = PARITY[first];

  let bits = "101"; // sol guard
  for (let i = 0; i < 6; i++) bits += (parity[i] === "A" ? L : G)[+leftDigits[i]];
  bits += "01010"; // orta guard
  for (let i = 0; i < 6; i++) bits += R[+rightDigits[i]];
  bits += "101"; // sağ guard

  const w = quiet * 2 + bits.length * unit;
  const h = height + 22;
  canvas.width = w; canvas.height = h;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#fff"; ctx.fillRect(0, 0, w, h);
  ctx.fillStyle = "#000";
  // guard barları biraz uzun olsun (sayı hattına iner)
  const guardIdx = new Set();
  [0,1,2, 45,46,47,48,49, 92,93,94].forEach((i) => guardIdx.add(i));
  for (let i = 0; i < bits.length; i++) {
    if (bits[i] === "1") {
      const extra = guardIdx.has(i) ? 10 : 0;
      ctx.fillRect(quiet + i * unit, 4, unit, height + extra);
    }
  }
  // insan-okunur rakamlar
  ctx.fillStyle = "#000";
  ctx.font = `${12}px monospace`;
  ctx.textBaseline = "bottom";
  ctx.fillText(code[0], 2, h);
  ctx.fillText(leftDigits, quiet + 3 * unit + 2, h);
  ctx.fillText(rightDigits, quiet + 50 * unit + 2, h);
  return canvas;
}

/* ---------- Kamera ile barkod okuma ---------- */
export function scannerSupported() { return "BarcodeDetector" in window; }

// onDetect(codeString) çağrılır; kamera modalını açar
export async function scanBarcode(onDetect) {
  if (!scannerSupported()) {
    toast("Bu tarayıcı kamera taramayı desteklemiyor. Elle girin.", "warn");
    return;
  }
  let stream, raf, stopped = false;
  const video = el("video", { autoplay: true, playsinline: true, muted: true, style: "width:100%;border-radius:12px;background:#000;aspect-ratio:4/3;object-fit:cover" });
  const hint = el("p", { class: "muted", style: "text-align:center;margin-top:8px", text: "Barkodu kameraya gösterin…" });

  const detector = new window.BarcodeDetector({ formats: ["ean_13", "ean_8", "code_128", "code_39", "upc_a", "upc_e", "qr_code"] });

  const stop = () => {
    stopped = true;
    if (raf) cancelAnimationFrame(raf);
    if (stream) stream.getTracks().forEach((tr) => tr.stop());
  };

  const close = modal({
    title: "📷 Barkod Tara",
    body: el("div", {}, [video, hint]),
    actions: [{ label: "İptal", kind: "ghost", onClick: (c) => { stop(); c(); } }],
  });

  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment" } });
    video.srcObject = stream;
    const tick = async () => {
      if (stopped) return;
      // Modal kapatıldıysa (backdrop tıklama vb.) video DOM'dan ayrılır → durdur
      if (!document.body.contains(video)) { stop(); return; }
      try {
        const codes = await detector.detect(video);
        if (codes && codes.length) {
          const value = codes[0].rawValue;
          stop(); close();
          toast("Okundu: " + value, "success");
          onDetect(value);
          return;
        }
      } catch {}
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
  } catch {
    stop();
    toast("Kameraya erişilemedi. İzin verildi mi?", "error");
  }
}
