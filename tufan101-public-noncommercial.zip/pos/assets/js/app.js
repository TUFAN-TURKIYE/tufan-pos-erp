// TUFAN 101 — Uygulama çekirdeği: iskelet, router, giriş, tema, dil, erişilebilirlik
import { t, setLang, getLang } from "./core/i18n.js";
import { settings, pendingCount, sync, pull, onChange, db, currentAccount, money, ready } from "./core/store.js";
import { cloud } from "./core/api.js";
import { el, clear, toast, modal } from "./core/ui.js";
import { SECTORS, searchSectors } from "./core/sectors.js";
import { currentUser, login, logout, users, moduleAllowed } from "./core/auth.js";
import { MODULES, PREMIUM_IDS } from "./modules/index.js";
import { isBoss } from "./modules/boss.js";
import { renderSuperAdmin } from "./modules/superadmin.js";
import { renderPublicMenu, renderApplicationPage, renderRandevuPage } from "./modules/qrmenu.js";
import { navigate, setDeferredInstall, canInstall, doInstall } from "./core/nav.js";

const root = document.getElementById("root");

// ————————————————————————————————————————————————————————————————
//  TUFAN 101 çekirdek imzası — Bu yapı Balıkesir / Doruk Tufan'a aittir.
//  Kaldırılması/değiştirilmesi telif haklarının ihlalidir.
const __OWNER_SIGNATURE__ = "Bu yapı Balıkesir/Doruk Tufan'a aittir. © Doruk Tufan";
try {
  Object.defineProperty(window, "__tufan101_owner__", { value: __OWNER_SIGNATURE__, writable: false, enumerable: false, configurable: false });
  console.log("%cTUFAN 101", "font:700 20px Orbitron,sans-serif;color:#22d3ee", "\n" + __OWNER_SIGNATURE__);
} catch {}
// ————————————————————————————————————————————————————————————————
export function ownerSignature() { return __OWNER_SIGNATURE__; }

// ————————————————————————————————————————————————————————————————
//  DOMAIN KİLİDİ + GİZLİ TELİF İMZALARI
//  Bu yazılım Doruk Tufan (Balıkesir / Karesi) ve VEBS TEKNİK'e aittir.
//  Aşağıdaki imzalar arayüzde GÖRÜNMEZ; kaynak kod izinsiz kopyalanırsa
//  sahipliğin ve telif hakkının kanıtı olarak gömülüdür. Kaldırılması suçtur.
//  Kilit: uygulama yalnızca "tufan101.com.tr" üzerinde (ve yerel geliştirmede) çalışır.
// ————————————————————————————————————————————————————————————————
const __VEBS_MARK__ = ["Doruk Tufan", "Balıkesir Karesi", "VEBS TEKNİK", "tufan101.com.tr", "© 2024-2026"];
(function domainLock() {
  const enc = ["dHVmYW4xMDEuY29tLnRy"]; // base64("tufan101.com.tr")
  const allowRoot = (() => { try { return atob(enc[0]); } catch { return "tufan101.com.tr"; } })();
  const host = (location.hostname || "").toLowerCase();
  const localOK = host === "" || host === "localhost" || host === "127.0.0.1" || host.endsWith(".local") ||
    /^192\.168\./.test(host) || /^10\./.test(host) || location.protocol === "file:";
  const domainOK = host === allowRoot || host.endsWith("." + allowRoot);
  try {
    Object.defineProperty(window, "__tufan_vebs__", {
      value: __VEBS_MARK__.join(" · "), writable: false, enumerable: false, configurable: false,
    });
  } catch {}
  if (localOK || domainOK) return; // yetkili alan → devam
  // Yetkisiz alan adı: uygulamayı kilitle
  try {
    document.title = "Yetkisiz Alan";
    document.documentElement.innerHTML =
      '<body style="margin:0;min-height:100vh;display:grid;place-items:center;font-family:system-ui,sans-serif;background:#0F172A;color:#fff;text-align:center;padding:24px">' +
      '<div><div style="font-size:56px">🔒</div>' +
      '<h1 style="font-family:Poppins,sans-serif">Bu yazılım yalnızca tufan101.com.tr üzerinde çalışır.</h1>' +
      '<p style="opacity:.75;max-width:520px;margin:10px auto">Bu uygulama ve kaynak kodu Doruk Tufan (Balıkesir / Karesi) ve VEBS TEKNİK’e aittir. İzinsiz kopyalama, dağıtma ve başka alan adında yayınlama telif haklarının ihlalidir.</p>' +
      '<p style="opacity:.5;font-size:13px;margin-top:18px">© Doruk Tufan · VEBS TEKNİK</p></div></body>';
  } catch {}
  // Modül yürütmesini durdur (route/sync başlamaz)
  throw new Error("TUFAN101: unauthorized domain");
})();

// ---- Tema & erişilebilirlik uygula ----
function applyPrefs() {
  const s = settings.get();
  // Karanlık mod kaldırıldı — uygulama her zaman aydınlık (beyaz) temada çalışır.
  document.documentElement.setAttribute("data-theme", "light");
  document.documentElement.style.setProperty("--scale", s.scale || 1);
  setLang(s.lang || "tr");
}
applyPrefs();

window.addEventListener("beforeinstallprompt", (e) => { e.preventDefault(); setDeferredInstall(e); });
export { navigate, canInstall, doInstall };

// ---- Router ----
function currentRoute() {
  const h = location.hash.replace(/^#\//, "") || "dashboard";
  return h;
}

function isLocked(mod) {
  // Paket/deneme sistemi kaldırıldı. Kilit artık ROL/MODÜL izninden gelir:
  // patronun bir alt kullanıcıya kapattığı modüller o kullanıcıda "🔒 Kilitli" görünür.
  if (!mod || mod.bossOnly) return false;
  return !moduleAllowed(mod.id);
}

// ---- Giriş ekranı (mod-06 Kullanıcı adı + Şifre) ----
function renderLogin() {
  // "Beni hatırla" ile daha önce kaydedilen kullanıcı adı (şifre ASLA saklanmaz).
  let rememberedUser = "";
  try { rememberedUser = localStorage.getItem("t101_remember_user") || ""; } catch {}
  const userInput = el("input", { class: "input", type: "text", autocomplete: "username", placeholder: t("usernameLabel"), value: rememberedUser, autofocus: true });
  const passInput = el("input", { class: "input", type: "password", autocomplete: "current-password", placeholder: t("passwordLabel"), style: "padding-right:44px" });

  // Şifreyi göster/gizle (göz) düğmesi — şifre alanının içinde sağda.
  const eyeBtn = el("button", {
    class: "login-eye", type: "button", title: "Şifreyi göster",
    onClick: () => {
      const show = passInput.type === "password";
      passInput.type = show ? "text" : "password";
      eyeBtn.textContent = show ? "🙈" : "👁";
      eyeBtn.title = show ? "Şifreyi gizle" : "Şifreyi göster";
    },
  }, ["👁"]);
  const passWrap = el("div", { style: "position:relative;display:block" }, [passInput, eyeBtn]);

  // "Beni hatırla" kutusu — işaretliyse kullanıcı adını hatırlar.
  const rememberCb = el("input", { type: "checkbox" }); rememberCb.checked = !!rememberedUser;
  const rememberRow = el("label", { class: "login-remember", style: "display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;margin:2px 0 4px" }, [
    rememberCb, el("span", { text: "Beni hatırla" }),
  ]);

  const tryLogin = async () => {
    loginBtn.disabled = true;
    let r; try { r = await login(userInput.value, passInput.value); } finally { loginBtn.disabled = false; }
    if (r && r.perms) {
      // "Beni hatırla": sadece kullanıcı adını sakla (şifre asla saklanmaz).
      try {
        if (rememberCb.checked) localStorage.setItem("t101_remember_user", userInput.value.trim());
        else localStorage.removeItem("t101_remember_user");
      } catch {}
      const s = settings.get();
      const needsOnboard = !s.onboarded && !(s.business && s.business !== "İşletmem");
      if (needsOnboard) { route(); onboardingFlow(); }
      else { toast(t("welcome") + " 👋", "success"); route(); }
    }
    else {
      const msg = (r && r.error) ? r.error : t("wrongLogin");
      toast(msg, "error"); passInput.value = ""; passInput.focus();
    }
  };

  const loginBtn = el("button", { class: "login-btn", onClick: tryLogin }, [t("loginBtn")]);
  const onEnter = (e) => { if (e.key === "Enter") { e.preventDefault(); tryLogin(); } };
  userInput.addEventListener("keydown", onEnter);
  passInput.addEventListener("keydown", onEnter);

  // ---- Gizli admin paneli girişi ----
  // Alttaki "© Balıkesir / Doruk Tufan" yazısına 5 kez hızlı (2 sn içinde) dokun → Patron Paneli açılır.
  let _tapCount = 0, _tapTimer = null;
  const ownerSign = el("p", { class: "owner-sign", text: "© Balıkesir / Doruk Tufan", style: "cursor:default;user-select:none" });
  const openAdminPanel = () => {
    _tapCount++;
    clearTimeout(_tapTimer);
    _tapTimer = setTimeout(() => { _tapCount = 0; }, 2000);
    if (_tapCount >= 5) {
      _tapCount = 0;
      toast("🛡️ Patron paneli açılıyor…", "success");
      // Panel artık kökte (landing). POS /pos/ altında olduğu için ".." kök = landing.
      window.open("../#admin", "_blank");
    }
  };
  ownerSign.addEventListener("click", openAdminPanel);

  const bizLogo = settings.get().logo;

  // Beyaz, sade giriş ekranı (karanlık mod yok). Renkler inline verildi ki
  // önbellek/tema ne olursa olsun her zaman beyaz görünür.
  const card = el("div", { class: "login-box" }, [
    // İşletme logosu (varsa) — yoksa TUFAN marka işareti
    bizLogo
      ? el("div", { style: "text-align:center;margin-bottom:18px" }, [
          el("img", { src: bizLogo, alt: "Logo", style: "width:84px;height:84px;border-radius:20px;object-fit:cover;box-shadow:0 6px 18px rgba(2,6,23,.12)" }),
        ])
      : el("div", { class: "login-logo" }, ["T"]),
    el("h1", { class: "login-title", text: "TUFAN 101" }),
    el("p", { class: "login-sub", text: t("loginPrompt") }),
    el("div", { class: "login-field" }, [el("label", { text: t("usernameLabel") }), userInput]),
    el("div", { class: "login-field" }, [el("label", { text: t("passwordLabel") }), passWrap]),
    rememberRow,
    loginBtn,
    el("button", { class: "login-about-link", type: "button", onClick: () => aboutModal() }, ["ℹ️ TUFAN 101 Hakkında — Tüm Özellikler"]),
    ownerSign,
  ]);

  clear(root).appendChild(el("div", { class: "login-page" }, [card]));
  if (rememberedUser) passInput.focus(); else userInput.focus();
}

// ---- TUFAN 101 Hakkında: giriş ekranından açılan tanıtım + tüm özellikler (A-Z) + QR Menü ----
function aboutModal() {
  // Özellik adlarını panel modüllerinden dinamik topla (menü ile hep senkron kalır)
  const fromModules = MODULES.map((m) => { try { return t(m.key); } catch { return ""; } }).filter(Boolean);
  const crossCutting = [
    "Çevrimdışı (internetsiz) çalışma",
    "Çoklu cihaz bulut senkronizasyonu",
    "Kamera ile barkod tarama (EAN-13 / TR 869)",
    "Barkod üretme ve etiket yazdırma",
    "QR Menü ve dijital kartvizit",
    "Personel giriş/çıkış (puantaj) ve çalışan raporu",
    "Otomatik yedekleme ve geri yükleme",
    "PWA — telefona kurulum, tam ekran",
    "Çoklu dil (Türkçe/İngilizce/Almanca/Rusça)",
    "İlk giriş karşılama sihirbazı",
  ];
  const all = [...new Set([...fromModules, ...crossCutting])]
    .filter((x) => x && x.trim())
    .sort((a, b) => a.localeCompare(b, "tr"));

  // Harf harf (A-Z) grupla
  const groups = {};
  all.forEach((name) => {
    const L = (name[0] || "#").toLocaleUpperCase("tr");
    (groups[L] = groups[L] || []).push(name);
  });
  const letters = Object.keys(groups).sort((a, b) => a.localeCompare(b, "tr"));

  const featureSection = el("div", { class: "about-feats" }, letters.map((L) =>
    el("div", { class: "about-feat-group" }, [
      el("div", { class: "about-feat-letter", text: L }),
      el("ul", { class: "about-feat-list" }, groups[L].map((n) => el("li", { text: n }))),
    ])
  ));

  const s = settings.get();
  const phone = "0544 964 17 75";
  const body = el("div", { class: "about-wrap" }, [
    el("div", { class: "about-hero" }, [
      el("div", { class: "about-logo", text: "T" }),
      el("div", {}, [
        el("h2", { class: "about-title", text: "TUFAN 101" }),
        el("p", { class: "about-tagline", text: "Balıkesir'den, 3 yıllık tecrübeyle — dükkânınızı tek ekrandan yönetin." }),
      ]),
    ]),
    el("p", { class: "about-lead", text: "TUFAN 101; kasa, stok, gelir-gider, personel, QR menü ve raporları tek uygulamada toplayan yerli işletme yönetim sistemidir. İnternet olmadan da çalışır, verileriniz cihazlar arasında senkronlanır." }),

    // QR Menü öne çıkan bölüm
    el("div", { class: "about-qr" }, [
      el("div", { class: "about-qr-ico", text: "🍽️" }),
      el("div", {}, [
        el("h3", { style: "margin:0 0 4px", text: "QR Menü & Dijital Kartvizit" }),
        el("p", { class: "muted", style: "margin:0", text: "Masaya koyduğunuz QR kodu okutulunca; menünüz, WhatsApp sipariş, telefon, Google Maps yol tarifi ve sosyal medya tek ekranda açılır. Menü, stok/ürünlerinizden otomatik oluşur. Panelde 'QR Menü' bölümünden yönetilir." }),
      ]),
    ]),

    el("h3", { class: "about-h", text: "📋 Tüm Özellikler (A-Z)" }),
    el("p", { class: "muted", style: "margin-top:0", text: all.length + " özellik — alfabetik sıralı." }),
    featureSection,

    el("div", { class: "about-contact" }, [
      el("h3", { style: "margin:0 0 8px", text: "📞 İletişim" }),
      el("div", { class: "about-contact-row" }, [
        el("a", { class: "about-cbtn", href: "tel:+905449641775" }, ["📞 " + phone]),
        el("a", { class: "about-cbtn", href: "https://wa.me/905449641775", target: "_blank", rel: "noopener" }, ["💬 WhatsApp"]),
        el("a", { class: "about-cbtn", href: "mailto:tufankks@tufan101.com.tr" }, ["✉️ E-Posta"]),
      ]),
      el("p", { class: "muted", style: "font-size:12px;margin:8px 0 0", text: "TUFAN 101 • Balıkesir • tufan101.com.tr" }),
    ]),
  ]);

  modal({ title: "", body, actions: [{ label: "Kapat", kind: "ghost" }] });
}

// ---- İlk giriş karşılama akışı: Sektör → İşletme bilgileri → 3sn → HOŞ GELDİNİZ ----
// Sadece ilk kez (henüz işletme adı girilmemişse) çalışır. Adımlar sırayla modal olarak açılır.
function onboardingFlow() {
  step1Sector();

  // 1) Sektör seçimi
  function step1Sector() {
    let chosen = settings.get().sector || "";
    const search = el("input", { class: "input", placeholder: "Sektör ara (örn: restoran, market, kafe)…", autofocus: true });
    const grid = el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:8px;max-height:40vh;overflow:auto;margin-top:10px" });
    const paint = (list) => {
      clear(grid);
      if (!list.length) { grid.appendChild(el("p", { class: "muted", text: "Eşleşme yok." })); return; }
      list.forEach((name) => grid.appendChild(el("button", {
        class: "btn " + (name === chosen ? "success" : "ghost"),
        style: "text-align:left;justify-content:flex-start;font-size:13px",
        onClick: () => { chosen = name; paint(list); },
      }, [name])));
    };
    search.addEventListener("input", () => paint(searchSectors(search.value)));
    paint(SECTORS);
    const close = modal({
      title: "🏭 İşletmenizin sektörü nedir?",
      body: el("div", {}, [el("p", { class: "muted", text: "Size uygun hazır ürün ve ayarlar için sektörünüzü seçin." }), search, grid]),
      actions: [{ label: "Devam →", kind: "success", onClick: (c) => {
        if (!chosen) { toast("Lütfen bir sektör seçin", "warn"); return; }
        settings.set({ sector: chosen });
        c(); step2Business();
      } }],
    });
    return close;
  }

  // 2) İşletme bilgileri
  function step2Business() {
    const s = settings.get();
    const biz = el("input", { class: "input", value: s.business && s.business !== "İşletmem" ? s.business : "", placeholder: "İşletmenizin adı", autofocus: true });
    const phone = el("input", { class: "input", inputmode: "tel", value: s.phone || "", placeholder: "05xx xxx xx xx" });
    const wa = el("input", { class: "input", inputmode: "tel", value: s.whatsapp || "", placeholder: "WhatsApp: 905xx xxx xx xx" });
    const address = el("input", { class: "input", value: s.address || "", placeholder: "Adres (Balıkesir…)" });
    const fld = (lbl, node) => el("div", { class: "field" }, [el("label", { text: lbl }), node]);
    modal({
      title: "🏪 İşletme Bilgileriniz",
      body: el("div", {}, [
        fld("İşletme Adı *", biz),
        el("div", { style: "display:grid;grid-template-columns:1fr 1fr;gap:12px" }, [fld("Telefon", phone), fld("💬 WhatsApp", wa)]),
        fld("Adres", address),
      ]),
      actions: [{ label: "Kaydet ve Gir →", kind: "success", onClick: (c) => {
        if (!biz.value.trim()) { toast("İşletme adı zorunlu", "warn"); return; }
        settings.set({ business: biz.value.trim(), phone: phone.value.trim(), whatsapp: wa.value.trim(), address: address.value.trim() });
        c(); step3Loading();
      } }],
    });
  }

  // 3) 3 saniye "giriş yapılıyor" bekleme
  function step3Loading() {
    const spin = el("div", { class: "onb-spinner" });
    const close = modal({
      title: "",
      body: el("div", { style: "text-align:center;padding:14px 6px" }, [
        spin,
        el("h3", { style: "margin:14px 0 4px", text: "Giriş yapılıyor…" }),
        el("p", { class: "muted", text: "İşletmeniz hazırlanıyor, lütfen bekleyin." }),
      ]),
      actions: [],
    });
    setTimeout(() => { close(); step4Welcome(); }, 3000);
  }

  // 4) HOŞ GELDİNİZ karşılama penceresi
  function step4Welcome() {
    const name = settings.get().business || "İşletmem";
    modal({
      title: "",
      body: el("div", { style: "text-align:center;padding:12px 6px" }, [
        el("div", { style: "font-size:52px", text: "🎉" }),
        el("h2", { style: "margin:10px 0 2px;color:var(--primary)", text: "HOŞ GELDİNİZ" }),
        el("h3", { style: "margin:0 0 6px", text: name }),
        el("p", { class: "muted", text: "Giriş başarılı. Artık işletmenizi tek ekrandan yönetebilirsiniz." }),
      ]),
      actions: [{ label: "🚀 Başla", kind: "success", onClick: (c) => {
        settings.set({ onboarded: true });
        c(); route();
      } }],
    });
  }
}

// ---- Ana iskelet (sidebar + topbar + görünüm) ----
let viewHost, titleEl, syncBadge, bellBtn, bellBadge, bellPanel;
let _cloudHasFresh = false; // başka cihazdan yeni veri geldi mi (elle yenileme için)
function renderShell() {
  const s = settings.get();
  // Grup sirasi modul kayit sirasindan turetilir (dinamik — istenen kadar grup)
  const groups = {};
  const order = [];
  // Kilitli modüller menüde HİÇ görünmez (kilit ikonu da yok). Patrona kapattığı
  // modüller o kullanıcıda tamamen gizlenir; patron-özel modüller de gizlenir.
  MODULES.filter((m) => !m.hidden && (m.bossOnly ? isBoss() : true) && !isLocked(m)).forEach((m) => {
    const g = m.group || "grpInterface";
    if (!groups[g]) { groups[g] = []; order.push(g); }
    groups[g].push(m);
  });

  const nav = el("nav", { class: "nav" });
  // Menü arama: çok modül olduğu için üstte canlı filtre kutusu.
  const navGroups = [];
  order.forEach((g) => {
    const mods = groups[g];
    if (!mods.length) return;
    const label = el("div", { class: "group-label", text: t(g) });
    nav.appendChild(label);
    const links = [];
    mods.forEach((m) => {
      const nm = (t(m.key) || "") + " " + m.id;
      const a = el("a", {
        href: "#/" + m.id, class: "navlink", "data-id": m.id,
        "data-name": nm.toLowerCase(),
      }, [
        el("span", { class: "ic", text: m.icon }),
        el("span", { text: t(m.key) }),
        m.id === "ai" ? el("span", { class: "soon-ic", text: "YAKINDA" }) : null,
      ]);
      nav.appendChild(a);
      links.push(a);
    });
    navGroups.push({ label, links });
  });

  const navSearch = el("input", {
    class: "nav-search", type: "search", placeholder: "🔍 Menüde ara…", "aria-label": "Menüde ara",
  });
  const navEmpty = el("div", { class: "nav-empty", style: "display:none", text: "Sonuç yok" });
  navSearch.addEventListener("input", () => {
    const q = navSearch.value.trim().toLowerCase();
    let total = 0;
    navGroups.forEach(({ label, links }) => {
      let anyVisible = false;
      links.forEach((a) => {
        const show = !q || (a.getAttribute("data-name") || "").includes(q);
        a.style.display = show ? "" : "none";
        if (show) { anyVisible = true; total++; }
      });
      label.style.display = anyVisible ? "" : "none";
    });
    navEmpty.style.display = total === 0 ? "" : "none";
  });

  nav.insertBefore(navEmpty, nav.firstChild);
  const sidebar = el("aside", { class: "sidebar" }, [
    el("div", { class: "brand brand-lg" }, [el("div", { class: "logo" }, ["T"]), el("b", { class: "wordmark" }, ["TUFAN 101"])]),
    navSearch,
    nav,
    el("div", { style: "margin-top:auto;padding:12px" }, [
      el("div", { class: "pill green", text: "💎 " + t("premium") }),
      el("div", { style: "margin-top:12px;text-align:center;opacity:.9" }, [
        el("img", { src: "assets/img/logo-3dmenshop.png", alt: "3D MENSHOP", style: "width:100%;max-width:150px;height:auto;object-fit:contain" }),
      ]),
      el("div", { class: "owner-sign", style: "margin-top:8px", text: "© Balıkesir / Doruk Tufan" }),
    ]),
  ]);

  titleEl = el("div", { class: "title" });
  syncBadge = el("span", { class: "pill blue", style: "cursor:pointer", title: "Yenilemek için tıklayın", onClick: () => manualRefresh() });

  // Bildirim zili (garson çağır / masa siparişi) + canlı panel
  bellBadge = el("span", { class: "bell-badge", style: "display:none" });
  bellBtn = el("button", { class: "iconbtn bell-btn", title: "Bildirimler", onClick: toggleBellPanel }, ["🔔", bellBadge]);
  bellPanel = el("div", { class: "bell-panel", style: "display:none" });
  const bellWrap = el("div", { class: "bell-wrap" }, [bellBtn, bellPanel]);

  const topbar = el("header", { class: "topbar" }, [
    el("button", { class: "iconbtn menu-toggle", onClick: () => document.body.classList.toggle("nav-open") }, ["☰"]),
    titleEl,
    el("div", { class: "spacer" }),
    syncBadge,
    bellWrap,
    el("button", { class: "iconbtn", title: t("logout"), onClick: () => { logout(); } }, ["⏻"]),
  ]);

  viewHost = el("section", { class: "view" });
  clear(root).appendChild(
    el("div", { id: "app" }, [sidebar, el("main", { class: "main" }, [topbar, viewHost])])
  );
  updateSyncBadge();
}

function updateSyncBadge() {
  if (!syncBadge) return;
  const n = pendingCount();
  const online = navigator.onLine;
  // Başka cihazdan yeni veri geldiyse: "yenile" uyarısı göster
  if (_cloudHasFresh && online) {
    syncBadge.className = "pill violet";
    syncBadge.style.cursor = "pointer";
    syncBadge.title = "Başka bir cihazdan yeni veri geldi. Görüntülemek için tıklayın.";
    syncBadge.textContent = "🔄 Yeni veri — Yenile";
    return;
  }
  syncBadge.style.cursor = "pointer";
  syncBadge.title = "Verileriniz buluta yedeklenir. Yenilemek için tıklayın.";
  syncBadge.className = "pill " + (online ? (n ? "amber" : "green") : "red");
  syncBadge.textContent = online
    ? (n ? `⟳ ${n} ${t("pendingSync")}` : "● " + t("online"))
    : "○ " + t("offline");
}
window.addEventListener("online", updateSyncBadge);
window.addEventListener("offline", updateSyncBadge);
window.addEventListener("syncstate", updateSyncBadge);
window.addEventListener("cloudauth", updateSyncBadge);
onChange(updateSyncBadge);

// ---- Görünüm yönlendirme ----
function route() {
  // Herkese açık QR menü (müşteri okutunca — GİRİŞ GEREKMEZ)
  // #/m/<hesap>
  if (location.hash.startsWith("#/m/")) {
    // #/m/<hesap>  veya  #/m/<hesap>?masa=N  (masalı QR → masa no otomatik dolar)
    const raw = location.hash.slice(4);
    const qi = raw.indexOf("?");
    const account = decodeURIComponent(qi === -1 ? raw : raw.slice(0, qi));
    let masa = "";
    if (qi !== -1) { try { masa = new URLSearchParams(raw.slice(qi + 1)).get("masa") || ""; } catch {} }
    document.documentElement.setAttribute("data-theme", "light");
    clear(root).appendChild(el("div", { id: "public-menu-root" }));
    renderPublicMenu(document.getElementById("public-menu-root"), account, masa);
    return;
  }
  // Herkese açık başvuru/anket + CV yükleme sayfası (ayrı link — GİRİŞ GEREKMEZ)
  // #/basvuru/<hesap>
  if (location.hash.startsWith("#/basvuru/")) {
    const account = decodeURIComponent(location.hash.slice(10));
    document.documentElement.setAttribute("data-theme", "light");
    clear(root).appendChild(el("div", { id: "public-menu-root" }));
    renderApplicationPage(document.getElementById("public-menu-root"), account);
    return;
  }
  // Herkese açık RANDEVU sayfası (ayrı link — GİRİŞ GEREKMEZ)
  // #/randevu/<hesap>
  if (location.hash.startsWith("#/randevu/")) {
    const account = decodeURIComponent(location.hash.slice(10));
    document.documentElement.setAttribute("data-theme", "light");
    clear(root).appendChild(el("div", { id: "public-menu-root" }));
    renderRandevuPage(document.getElementById("public-menu-root"), account);
    return;
  }
  // Gizli süper admin girişi (mod-22)
  if (location.hash.startsWith("#/merkez-yonetim")) {
    clear(root).appendChild(el("div", { id: "admin-root" }));
    renderSuperAdmin(document.getElementById("admin-root"), { navigate });
    return;
  }
  if (!currentUser()) { renderLogin(); return; }
  if (!viewHost || !document.getElementById("app")) renderShell();

  const hasHash = !!location.hash.replace(/^#\//, "");
  const id = currentRoute();
  let mod = MODULES.find((m) => m.id === id) || MODULES[0];
  const modOk = (m) => m.bossOnly ? isBoss() : moduleAllowed(m.id);
  const firstAllowed = () => MODULES.find((m) => !m.hidden && modOk(m)) || mod;
  document.body.classList.remove("nav-open");

  // Patron-özel modüle patron değilken girildiyse ilk izinli modüle yönlendir.
  if (mod.bossOnly && !isBoss()) mod = firstAllowed();

  // Modül izni kapalı (kilitli):
  if (!mod.bossOnly && !moduleAllowed(mod.id)) {
    // İlk açılış (hash yok) → kullanıcının erişebildiği ilk modüle geç, kilit ekranında takılma.
    if (!hasHash) { const fa = firstAllowed(); if (fa && fa.id !== mod.id) { navigate(fa.id); return; } }
    // Kullanıcı bilerek kilitli modüle tıkladı → engelle ve "Kilitli" ekranını göster.
    root.querySelectorAll(".navlink").forEach((a) => a.classList.toggle("active", a.dataset.id === mod.id));
    titleEl.textContent = t(mod.key);
    clear(viewHost);
    viewHost.appendChild(el("div", { class: "card locked-note", style: "text-align:center;padding:44px 20px" }, [
      el("div", { style: "font-size:54px", text: "🔒" }),
      el("h3", { style: "margin:12px 0 4px", text: t("locked") }),
      el("p", { class: "muted", text: "Bu modüle erişim yetkiniz yok. Yetki için patronunuza başvurun." }),
    ]));
    return;
  }

  root.querySelectorAll(".navlink").forEach((a) => a.classList.toggle("active", a.dataset.id === mod.id));
  titleEl.textContent = t(mod.key);

  clear(viewHost);
  try { mod.render(viewHost, { navigate, refresh: route }); }
  catch (e) { viewHost.appendChild(el("div", { class: "card", text: "Modül hatası: " + e.message })); }
}

// Gizli tuş kombinasyonu: Ctrl+Shift+D → Merkez Yönetim
window.addEventListener("keydown", (e) => {
  if (e.ctrlKey && e.shiftKey && (e.key === "D" || e.key === "d")) { e.preventDefault(); navigate("merkez-yonetim"); }
});

window.addEventListener("hashchange", route);
window.addEventListener("authchange", () => { location.hash = ""; route(); });
window.addEventListener("langchange", () => { if (currentUser()) { renderShell(); route(); } });

// Başka bir cihazdan veri gelince görünümü tazele.
// ÖNEMLİ: Kullanıcı bir alan doldururken (isim/logo vb.) veya bir modal açıkken
// arka plan senkronu ekranı YENİDEN ÇİZMEMELİ — yoksa yazılan metin sıfırlanır.
// ÖNEMLİ: Arka plan bulut senkronu ARTIK ekranı kendiliğinden YENİLEMEZ.
// Böylece isim/logo yazarken veya herhangi bir işlem yaparken içerik sıfırlanmaz.
// Yeni veri geldiğinde sadece "yeni veri var" işareti verilir; kullanıcı bir işlem
// yapınca (kaydet / menüden sayfa değiştirme) ya da senkron rozetine tıklayınca güncellenir.
window.addEventListener("cloudpull", () => {
  if (!currentUser()) return;
  _cloudHasFresh = true;
  updateSyncBadge();
});
// Kullanıcı istediğinde elle yenileme (senkron rozetine tıkla)
function manualRefresh() {
  _cloudHasFresh = false;
  if (currentUser()) route();
  updateSyncBadge();
}

// ————————————————————————————————————————————————————————————————
//  Garson çağır / masa siparişi bildirimleri (işletme sahibi tarafı)
//  Müşteri QR menüden "Garson Çağır" / sipariş yollar → burada sesli bildirim.
// ————————————————————————————————————————————————————————————————
function playCallSound() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    const ctx = new AC();
    // Bazı tarayıcılar sekme etkileşimsizken context'i askıya alır — devam ettir.
    if (ctx.state === "suspended" && ctx.resume) { try { ctx.resume(); } catch {} }
    const beep = (freq, start, dur, vol) => {
      const o = ctx.createOscillator(), g = ctx.createGain();
      o.type = "sine"; o.frequency.value = freq;
      o.connect(g); g.connect(ctx.destination);
      g.gain.setValueAtTime(0.0001, ctx.currentTime + start);
      g.gain.exponentialRampToValueAtTime(vol || 0.4, ctx.currentTime + start + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + dur);
      o.start(ctx.currentTime + start); o.stop(ctx.currentTime + start + dur);
    };
    // Dikkat çekici "ding-dong" desenini 3 kez tekrarla (yeni sipariş/çağrı).
    for (let k = 0; k < 3; k++) {
      const t = k * 0.62;
      beep(988, t, 0.20, 0.45);        // Si
      beep(1319, t + 0.22, 0.28, 0.45); // Mi
    }
    // Titreşim (mobil) — destekleyen cihazlarda
    try { if (navigator.vibrate) navigator.vibrate([120, 60, 120, 60, 120]); } catch {}
    setTimeout(() => { try { ctx.close(); } catch {} }, 2600);
  } catch {}
}

function orderTotal(c) {
  const items = Array.isArray(c.items) ? c.items : [];
  return items.reduce((a, it) => a + (Number(it.qty) || 1) * (Number(it.price) || 0), 0);
}

function describeCall(c) {
  const masa = c.masa ? `Masa ${c.masa}` : "Masa (belirtilmedi)";
  if (c.type === "order") {
    const items = Array.isArray(c.items) ? c.items : [];
    const list = items.map((it) => `${it.qty || 1}× ${it.name}`).join(", ");
    const total = orderTotal(c);
    const waiter = String(c.waiter || "").trim();
    const noteTxt = String(c.note || "").trim();
    let body = (list || noteTxt) + (total > 0 ? `  ·  Toplam: ${money(total)}` : "");
    // Sipariş garson tarafından alındıysa notu (👤 isim) da göster.
    if (list && noteTxt) body += `  ·  ${noteTxt}`;
    const title = waiter ? `🍽 ${masa} — ${waiter} sipariş aldı` : `🍽 ${masa} sipariş verdi`;
    return { title, body };
  }
  return { title: `🔔 ${masa} garson çağırdı`, body: c.note || "" };
}

// Sipariş fişi yazdır — masa, ürünler, adet, tutar, toplam. Termal 80mm uyumlu.
function printOrderReceipt(c) {
  const s = settings.get();
  const biz = s.business || s.owner || "TUFAN 101";
  const masa = c.masa ? "Masa " + c.masa : "Masa (belirtilmedi)";
  const items = Array.isArray(c.items) ? c.items : [];
  const esc = (x) => String(x == null ? "" : x).replace(/[&<>"']/g, (m) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[m]));
  const fmt = (n) => money(Number(n) || 0);
  const when = new Date(c.created_at || Date.now()).toLocaleString("tr-TR");
  const total = orderTotal(c);
  const rows = items.map((it) => {
    const qty = Number(it.qty) || 1;
    const line = qty * (Number(it.price) || 0);
    return '<tr><td class="q">' + qty + '×</td><td class="n">' + esc(it.name) +
      '</td><td class="p">' + (line > 0 ? esc(fmt(line)) : "") + '</td></tr>';
  }).join("");
  const doc =
    '<!doctype html><html lang="tr"><head><meta charset="utf-8"><title>Fiş — ' + esc(masa) + '</title><style>' +
    '@page{size:80mm auto;margin:0;}' +
    '*{box-sizing:border-box;}' +
    'body{margin:0;padding:6mm 5mm;font-family:"Courier New",monospace;color:#000;width:80mm;}' +
    'h1{font-size:16px;text-align:center;margin:0 0 2px;}' +
    '.sub{text-align:center;font-size:11px;margin-bottom:6px;}' +
    '.masa{text-align:center;font-size:20px;font-weight:700;border:2px solid #000;border-radius:6px;padding:4px;margin:6px 0;}' +
    'table{width:100%;border-collapse:collapse;font-size:12px;}' +
    'td{padding:3px 0;vertical-align:top;}' +
    '.q{width:34px;}' + '.p{text-align:right;white-space:nowrap;}' +
    'hr{border:0;border-top:1px dashed #000;margin:6px 0;}' +
    '.tot{display:flex;justify-content:space-between;font-size:15px;font-weight:700;margin-top:4px;}' +
    '.foot{text-align:center;font-size:10px;margin-top:8px;}' +
    '</style></head><body>' +
    '<h1>' + esc(biz) + '</h1>' +
    '<div class="sub">Sipariş Fişi · ' + esc(when) + '</div>' +
    '<div class="masa">' + esc(masa) + '</div>' +
    '<hr><table>' + rows + '</table><hr>' +
    (total > 0 ? '<div class="tot"><span>TOPLAM</span><span>' + esc(fmt(total)) + '</span></div>' : "") +
    (c.note ? '<div style="font-size:11px;margin-top:6px">Not: ' + esc(c.note) + '</div>' : "") +
    '<div class="foot">TUFAN 101 ile hazırlandı</div>' +
    '<script>window.addEventListener("load",function(){setTimeout(function(){try{window.focus();window.print();}catch(e){}},250);});<\/script>' +
    '</body></html>';
  const w = window.open("", "_blank", "width=380,height=640");
  if (!w) { toast("Açılır pencere engellendi — tarayıcı iznini verin.", "warn"); return; }
  w.document.open(); w.document.write(doc); w.document.close();
}

// Sipariş/çağrı durum etiketleri
const STATUS_LABELS = {
  bekliyor: { text: "Beklemede", cls: "amber" },
  alindi: { text: "Sipariş alındı", cls: "blue" },
  hazir: { text: "Hazır", cls: "green" },
  tamam: { text: "Tamamlandı", cls: "green" },
};

// İşletme sahibine gösterilen canlı çağrı listesi (bellek içi)
let _recentCalls = [];
let _bellOpen = false;
let _pollingCalls = false;
let _tableFilter = null; // Masa kontrolünde seçili masa (tıklayınca o masayı filtreler)

function relTime(ts) {
  const t = Number(ts) || 0;
  if (!t) return "";
  const diff = Math.max(0, Date.now() - (t < 1e12 ? t * 1000 : t));
  const m = Math.floor(diff / 60000);
  if (m < 1) return "az önce";
  if (m < 60) return m + " dk önce";
  const h = Math.floor(m / 60);
  if (h < 24) return h + " sa önce";
  return Math.floor(h / 24) + " gün önce";
}

async function changeCallStatus(id, status) {
  const account = currentAccount();
  if (!account) return;
  // Yerel listeyi hemen güncelle (anlık his)
  if (status === "tamam") _recentCalls = _recentCalls.filter((c) => c.id !== id);
  else _recentCalls = _recentCalls.map((c) => (c.id === id ? { ...c, status } : c));
  renderBellBadge(); renderBellPanel();
  try {
    await cloud.setCallStatus(account, id, status);
    const lbl = STATUS_LABELS[status];
    toast((lbl ? lbl.text : status) + " olarak işaretlendi", "success");
  } catch {
    toast("Durum güncellenemedi (bağlantı yok)", "error");
  }
  setTimeout(pollCalls, 400);
}

function renderBellBadge() {
  if (!bellBadge) return;
  const n = _recentCalls.filter((c) => (c.status || "bekliyor") === "bekliyor").length;
  if (n > 0) { bellBadge.textContent = n > 99 ? "99+" : String(n); bellBadge.style.display = ""; }
  else bellBadge.style.display = "none";
  if (bellBtn) bellBtn.classList.toggle("has-alert", n > 0);
}

function renderBellPanel() {
  if (!bellPanel) return;
  clear(bellPanel);
  bellPanel.appendChild(el("div", { class: "bell-head" }, [
    el("b", { text: "Masa Bildirimleri" }),
    el("span", { class: "muted", style: "font-size:12px", text: _recentCalls.length + " aktif" }),
  ]));

  // ---- Masa kontrolü: dolu / boş masalar (settings.tableCount tanımlıysa) ----
  // Masalara tıklayınca o masanın sipariş/çağrıları filtrelenir.
  const tableCount = Math.max(0, parseInt(settings.get().tableCount, 10) || 0);
  const countByTable = {}; // masa no → aktif çağrı sayısı
  _recentCalls.forEach((c) => { const n = parseInt(c.masa, 10); if (n >= 1) countByTable[n] = (countByTable[n] || 0) + 1; });
  if (tableCount > 0) {
    const busy = new Set(Object.keys(countByTable).map(Number).filter((n) => n >= 1 && n <= tableCount));
    // Geçersiz filtre temizle (masa sayısı değişmişse)
    if (_tableFilter && (_tableFilter < 1 || _tableFilter > tableCount)) _tableFilter = null;
    const grid = el("div", { class: "tables-grid" });
    for (let i = 1; i <= tableCount; i++) {
      const isBusy = busy.has(i);
      const sel = _tableFilter === i;
      const dot = el("button", {
        class: "table-dot" + (isBusy ? " busy" : " free") + (sel ? " sel" : ""),
        type: "button",
        title: isBusy ? ("Masa " + i + " — dolu (" + countByTable[i] + " sipariş)") : ("Masa " + i + " — boş"),
        onClick: () => { _tableFilter = (_tableFilter === i) ? null : i; renderBellPanel(); },
      }, [
        String(i),
        isBusy ? el("span", { class: "table-badge", text: String(countByTable[i]) }) : null,
      ]);
      grid.appendChild(dot);
    }
    const head = el("div", { class: "tables-legend" }, [
      el("span", {}, [el("i", { class: "table-dot busy", text: "" }), " Dolu: " + busy.size]),
      el("span", {}, [el("i", { class: "table-dot free", text: "" }), " Boş: " + (tableCount - busy.size)]),
      _tableFilter
        ? el("button", { class: "tables-clear", type: "button", onClick: () => { _tableFilter = null; renderBellPanel(); } }, ["✕ Masa " + _tableFilter + " filtresini kaldır"])
        : null,
    ]);
    bellPanel.appendChild(el("div", { class: "tables-box" }, [head, grid]));
  }

  // Seçili masa filtresi varsa yalnızca o masanın çağrılarını göster
  const shown = _tableFilter ? _recentCalls.filter((c) => parseInt(c.masa, 10) === _tableFilter) : _recentCalls;

  if (!shown.length) {
    bellPanel.appendChild(el("div", { class: "bell-empty muted", text: _tableFilter ? ("Masa " + _tableFilter + " için bekleyen sipariş/çağrı yok.") : "Şu an bekleyen sipariş / çağrı yok." }));
    return;
  }
  const listBox = el("div", { class: "bell-list" });
  shown.forEach((c) => {
    const d = describeCall(c);
    const st = STATUS_LABELS[c.status || "bekliyor"] || STATUS_LABELS.bekliyor;
    const actions = el("div", { class: "bell-actions" });
    if ((c.status || "bekliyor") !== "alindi")
      actions.appendChild(el("button", { class: "btn tiny blue", onClick: () => changeCallStatus(c.id, "alindi") }, ["Sipariş alındı"]));
    if ((c.status || "bekliyor") !== "hazir")
      actions.appendChild(el("button", { class: "btn tiny", onClick: () => changeCallStatus(c.id, "hazir") }, ["Hazır"]));
    if (c.type === "order")
      actions.appendChild(el("button", { class: "btn tiny", onClick: () => printOrderReceipt(c) }, ["🧾 Fiş Yazdır"]));
    actions.appendChild(el("button", { class: "btn tiny success", onClick: () => changeCallStatus(c.id, "tamam") }, ["✓ Tamamla"]));
    listBox.appendChild(el("div", { class: "bell-item" + (c.seen === 0 ? " unseen" : "") }, [
      el("div", { class: "bell-item-top" }, [
        el("b", { text: d.title }),
        el("span", { class: "pill " + st.cls, style: "font-size:11px", text: st.text }),
      ]),
      d.body ? el("div", { class: "bell-body", text: d.body }) : null,
      el("div", { class: "muted", style: "font-size:11px", text: relTime(c.created_at) }),
      actions,
    ]));
  });
  bellPanel.appendChild(listBox);
}

function toggleBellPanel() {
  _bellOpen = !_bellOpen;
  if (!bellPanel) return;
  bellPanel.style.display = _bellOpen ? "" : "none";
  if (_bellOpen) { renderBellPanel(); pollCalls(); }
}
// Panel dışına tıklayınca kapat
document.addEventListener("click", (e) => {
  if (!_bellOpen || !bellPanel) return;
  if (bellPanel.contains(e.target) || (bellBtn && bellBtn.contains(e.target))) return;
  _bellOpen = false; bellPanel.style.display = "none";
});

async function pollCalls() {
  if (_pollingCalls) return;
  if (!currentUser() || !navigator.onLine) return;
  const account = currentAccount();
  if (!account) return;
  _pollingCalls = true;
  try {
    const res = await cloud.listCalls(account);
    const calls = (res && Array.isArray(res.calls)) ? res.calls : [];
    // Yeni (seen=0) olanları tespit et → ses + toast + defter kaydı
    const fresh = calls.filter((c) => c.seen === 0);
    _recentCalls = calls;
    renderBellBadge();
    if (_bellOpen) renderBellPanel();
    if (fresh.length) {
      fresh.slice().reverse().forEach((c) => {
        const d = describeCall(c);
        try {
          db.notifications.upsert({
            id: "call:" + c.id, title: d.title, body: d.body,
            type: c.type, masa: c.masa || "", createdAt: c.created_at || Date.now(),
          });
        } catch {}
      });
      playCallSound();
      const last = fresh[0];
      const d = describeCall(last);
      toast(d.title + (d.body ? " — " + d.body : ""), "warn");
      try { await cloud.markSeen(account, fresh.map((c) => c.id)); } catch {}
      window.dispatchEvent(new Event("syncstate"));
    }
  } catch {}
  finally { _pollingCalls = false; }
}
window.addEventListener("cloudauth", () => { setTimeout(pollCalls, 1500); });
setInterval(pollCalls, 12000);

// ---- Veri yedekleme hatırlatıcı (her 5 dk) — mod-D Uyum & Güvenlik ----
// "Çıkmadan önce verilerinizi dışa aktarın; veri kaybından sorumluluk kabul edilmez."
let _backupReminderOpen = false;
function showBackupReminder() {
  if (_backupReminderOpen) return;
  if (!currentUser()) return;                 // yalnızca giriş yapılmışsa
  if (document.getElementById("modal-root").childElementCount) return; // modal açıkken rahatsız etme
  _backupReminderOpen = true;
  const bar = el("div", { class: "backup-reminder" }, [
    el("span", { class: "backup-reminder-ic", text: "💾" }),
    el("div", { class: "backup-reminder-txt" }, [
      el("b", { text: "Verilerinizi yedekleyin" }),
      el("div", { style: "font-size:12.5px;opacity:.92", text: "Çıkmadan önce Ayarlar → Veri Yedekleme'den dışa aktarın. Veri kaybı yaşanırsa sorumluluk kabul edilmez." }),
    ]),
    el("button", { class: "btn success tiny", onClick: () => { close(); navigate("settings"); } }, ["Dışa Aktar"]),
    el("button", { class: "iconbtn", title: "Kapat", onClick: () => close() }, ["✕"]),
  ]);
  function close() { bar.style.opacity = "0"; setTimeout(() => bar.remove(), 250); _backupReminderOpen = false; }
  document.getElementById("toasts").appendChild(bar);
  // 20 sn sonra kendiliğinden kapat (satışı engellemesin)
  setTimeout(() => { if (_backupReminderOpen) close(); }, 20000);
}
setInterval(showBackupReminder, 5 * 60 * 1000);

// ---- Gün sonu raporu bildirimi (gece 00:00) — mod-26 ----
// Uygulama geç saate kadar açıksa, gece yarısı "Gün sonu raporunu gör" bildirimi düşer.
const EOD_KEY = "t101_eod_notified";
function checkEndOfDayNotice() {
  if (!currentUser()) return;
  const now = new Date();
  // 00:00–00:09 aralığında, o gün için henüz bildirmediysek tetikle.
  if (now.getHours() !== 0 || now.getMinutes() >= 10) return;
  const todayKey = now.toISOString().slice(0, 10);
  let last = ""; try { last = localStorage.getItem(EOD_KEY) || ""; } catch {}
  if (last === todayKey) return;
  try { localStorage.setItem(EOD_KEY, todayKey); } catch {}
  // Bildirim defterine yaz
  try {
    db.notifications.upsert({
      id: "eod:" + todayKey, title: "🌙 Gün Sonu Raporu hazır",
      body: "Dün gün boyu yapılan tüm işlemlerin özeti hazır. Görüntülemek için dokunun.",
      ts: Date.now(), seen: 0,
    });
  } catch {}
  // Ekranda tıklanabilir bildirim
  const bar = el("div", { class: "backup-reminder" }, [
    el("span", { class: "backup-reminder-ic", text: "🌙" }),
    el("div", { class: "backup-reminder-txt" }, [
      el("b", { text: "Gün Sonu Raporu hazır" }),
      el("div", { style: "font-size:12.5px;opacity:.92", text: "Bugünün tüm satış ve işlem dökümünü görün." }),
    ]),
    el("button", { class: "btn success tiny", onClick: () => { bar.remove(); navigate("endofday"); } }, ["Gün Sonu Raporu Gör"]),
    el("button", { class: "iconbtn", title: "Kapat", onClick: () => bar.remove() }, ["✕"]),
  ]);
  document.getElementById("toasts").appendChild(bar);
}
setInterval(checkEndOfDayNotice, 60 * 1000);
setTimeout(checkEndOfDayNotice, 8000);

// İlk açılış — kalıcı depo (IndexedDB) belleğe yüklenene kadar BEKLE, sonra render et.
// Böylece ilk render'da veriler hazırdır; modüller senkron okumaya devam eder.
ready.then(() => {
  applyPrefs();            // hidrasyon sonrası dil/ölçek/temayı gerçek ayarlarla uygula
  route();
  sync();
  pull();
  setTimeout(pollCalls, 3000);
}).catch(() => { route(); }); // beklenmedik bir hata olursa yine de aç
