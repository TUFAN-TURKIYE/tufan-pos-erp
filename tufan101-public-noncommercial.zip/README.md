# TUFAN101 — Public Non-Commercial Edition

This repository contains a public, non-commercial copy of the TUFAN101 front-end. It is provided for learning, evaluation, personal projects, and non-commercial community use.

## Important limitations

- This archive does **not** include a database, database credentials, production configuration, API keys, access tokens, or server-side API implementation.
- Features that require the original PHP/MySQL backend, cloud synchronization, server authentication, licensing server, or third-party API will not work in this standalone public copy unless you independently implement a compatible backend.
- Do not enter real customer, employee, financial, or other sensitive data into a public/demo deployment.
- This is not a production-ready POS or accounting system. Test thoroughly before using any fork.

## Run locally

The front-end is mostly static. You can open `index.html` for the landing page. For the POS interface, serve the folder with a local static web server and open `/pos/`. Some browser features may not work correctly when opened directly via `file://`.

Example (Python installed):

```bash
python -m http.server 8000
```

Then open `http://localhost:8000/` and `http://localhost:8000/pos/`. This starts a static file server only; it does not provide the missing backend.

## Security note

This package was prepared for public source sharing, but automated scans cannot guarantee that every secret or personal detail has been found. Review the files yourself before publishing. If a real credential was ever committed or shared, revoke/rotate it; deleting it from this archive does not invalidate it.

## License

See [LICENSE](LICENSE). Commercial use, sale, or use primarily intended for commercial advantage is not permitted under this license.
